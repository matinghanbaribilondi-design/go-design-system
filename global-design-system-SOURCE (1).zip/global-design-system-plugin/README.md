# Global Design System — Figma ↔ design.md compiler

## Install (Figma desktop app)
Plugins → Development → Import plugin from manifest → choose `manifest.json`. No build is needed:
`code.js` and `ui.html` are ready to run.

## Layout
```
manifest.json, code.js (generated), ui.html
src/core.js                 the compiler (extraction, tokens, validation, generators, prompt, AI control)
reference-engine/           pluggable Reference module (see reference-engine/README.md)
scripts/build.mjs           builds the engine bundle and assembles code.js = engine + core
scripts/sync-reference.mjs  updates only the Reference module from your Pixel-Perfect plugin repo
tests/                      core.test.js (unit), figma-mock.test.js (pipeline against a mocked Figma API)
docs/traceability-matrix.md
assets/                     logo
```

## Build and test
```
npm install                       # only needed to rebuild the engine (esbuild)
node scripts/build.mjs            # engine bundle + code.js
node scripts/build.mjs --assemble-only   # reuse the prebuilt engine bundle
npm test
```
Edit `src/core.js` (never `code.js`), then rebuild.

## Output package
`design.md`, `tokens.css`, `tokens.md`, `components.md`, `content.md`, `validation.md`, `ai-control.md`,
`reference/` (HTML per frame, `index.html`, `icons.html`).
