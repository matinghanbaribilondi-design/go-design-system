/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./src/ui/**/*.{html,js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        figma: {
          bg: 'var(--figma-color-bg, #2c2c2c)',
          text: 'var(--figma-color-text, #ffffff)',
          border: 'var(--figma-color-border, #444444)',
          brand: '#18a0fb',
          brandHover: '#0d8ce0',
        }
      }
    },
  },
  plugins: [],
}
