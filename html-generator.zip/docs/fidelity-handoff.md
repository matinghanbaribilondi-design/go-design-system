# Handoff — Figma → HTML fidelity phase 1 (masks shipped)

> پرامپت دست‌دوم. برای دادن به یک AI دیگر، این فایل را بدهید یا محتوایش را
> کپی کنید. خودکفا نوشته شده: مخزن، قواعد سخت، کارهای تمام‌شده، کارهای
> باقی‌مانده و وضعیت دقیق درخت کار.

You are a Senior Product Designer and front-end engineer working on a Figma
plugin that converts Figma frames to HTML/CSS and Tailwind. Your goal is to
raise the **fidelity** of the output — anything a designer drew in Figma should
come out the same in HTML — **without** breaking existing behaviour or tests.

---

## 1. Project

| | |
|---|---|
| Repo | `/Users/part/Desktop/Local/Me/Github/figma-ai` |
| Branch | `main` (remote `origin/main`) |
| Plugin code | `html-generator/` — TypeScript + Vite + Vitest |
| Docs | `html-generator/README.md` is written in Persian and ships with the ZIP |

### Layout that matters

| Path | Role |
|---|---|
| `src/plugin/converter/` | The conversion engine: `layout.ts`, `styles.ts`, `typography.ts`, `assets.ts`, `utils.ts`, `masks.ts` |
| `src/plugin/types/ir.ts` | The intermediate representation (`IRNode`) — the central contract |
| `src/generator/` | CSS / HTML / Tailwind emitters |
| `src/shared/` | `constants.ts`, `responsive.ts`, `token-resolver.ts` |
| `harness/` | Measurement tooling: generates static HTML and measures it in real headless Chrome |

### Harness pattern (reuse it)

1. A `*.test.ts` emits a fixture into `harness/out/<name>.html`.
2. A `*-check.mjs` runs Chrome headless (`--no-sandbox`) over it, either with
   `--dump-dom` plus a probe script that writes a report, or by reading geometry.
3. Measuring inside an **iframe sized by `location.hash`** instead of resizing
   the browser window — Chrome on macOS refuses windows below ~500px.
4. `elementFromPoint` honours `clip-path`, so a hit test is a pixel test without
   needing a screenshot decoder.

---

## 2. Hard rules of this project

1. **Responsiveness is intrinsic.** No `@media`, no breakpoints. Everything
   derives from the design's own geometry (`flex-wrap` + `min-width` floors,
   fluid `clamp()`, region stacking via `@container`).
2. **`responsiveEnabled()` / `intrinsicReflowEnabled()` in
   `src/shared/responsive.ts` are the only readers** of the responsive flag.
3. **Thresholds live in `src/shared/constants.ts`**, never inline.
4. **Any field added to the IR must also be added to the Tailwind parity table**
   in `src/generator/tailwind-parity.test.ts`. That table is typed as
   `Record<keyof LayoutStyles | VisualStyles | TypographyStyles, Expectation>`
   and deliberately fails the build so nothing is silently dropped.
5. **Tests are pure logic** (no jsdom). Rendering claims are verified in real
   Chrome via the harness instead.
6. **Keep new logic in small, pure, individually testable modules.** Do not add
   yet another `if` to `layout.ts` when the rule deserves its own function.
7. **Every feature is documented in `README.md`** in the style of the existing
   "ویژگی‌های کلیدی" list: the problem, the solution, the safety boundaries, and
   a pointer to the test that pins it.

---

## 3. Completed and verified (phase 1 — "silent fidelity losses")

Four items are shipped. Do not redo them; read them as the pattern to follow.

### 3.1 Figma grid → CSS Grid (not a vertical column)

- `src/plugin/converter/layout.ts` (the `isGridFrame` branch), `grid.test.ts` (15 tests).
- Verbatim track list: `FIXED → px`, `FLEX → minmax(0, 1fr)`; per-axis gaps
  (`gridColumnGap`/`gridRowGap` never collapse into a `gap` shorthand).
- Cell placement from `gridColumnAnchorIndex` / `gridColumnSpan`.
- **Intrinsic reflow, no breakpoints**: flexible same-size tracks emit
  `repeat(auto-fit, minmax(min(<drawn column px>, 100%), 1fr))`, so the grid is
  exactly the drawn columns at the design width and steps down below it.
- Three safety boundaries: a `MANUAL` grid never reflows, cells are not pinned
  inside a reflowing grid, and `grid-template-rows` is dropped when columns use
  `auto-fit`.
- Measured: `harness/grid-check.mjs` → 1200→3, 1000→2, 792→2, 760→1, 375→1.

### 3.2 Real gradient geometry

- `gradientGeometry()` in `src/plugin/converter/utils.ts`, consumed by `styles.ts`.
- `GRADIENT_RADIAL` → `radial-gradient(ellipse RX RY at CX CY, …)`.
- `GRADIENT_ANGULAR` → `conic-gradient(from Xdeg at CX CY, …)` — previously
  dropped entirely, the branch did not exist.
- `paint.test.ts` (9 tests).

### 3.3 Text drop shadow → `text-shadow`

- `VisualStyles.textShadow`. Figma casts the effect onto the glyphs, so
  `box-shadow` was the same shadow attached to the wrong shape.

### 3.4 Figma masks — the most recent shipped item

- `src/plugin/converter/masks.ts` (new) + `masks.test.ts` (20 tests) +
  `harness/mask.test.ts` and `harness/mask-check.mjs`.

**The rule:** a mask is not a clip on the mask node — it clips the siblings
drawn *after* it, and it is never painted. The old code emitted
`clip-path: inset(0 round 0px)` on the mask node (a no-op on a box that already
ends at its own bounds) and then rendered that node like any other layer, so a
photo under a rounded-rect mask arrived as a solid rounded rectangle painted on
top of the photo.

**Implementation:**

- **No DOM restructuring.** Each masked sibling carries the mask shape as its
  own `clip-path`, computed in its own box (`inset(top right bottom left round
  …)` or `ellipse(rx ry at cx cy)`; unknown shapes fall back to the mask's
  bounding box). Clipping each layer by the same region and clipping their
  group give the same picture, while the sibling keeps its position, flex/grid
  participation and paint order.
- A corner pushed outside the sibling loses its radius (the clip corner on the
  box edge is no longer the mask's corner).
- ALPHA masks multiply the sibling's `opacity` by the fill alpha; LUMINANCE
  masks use brightness; VECTOR masks are geometry only.
- **Mask nodes are removed from `childrenToConvert` before the backdrop
  promotion pass**, and a masked child can never be promoted into the container
  background (`index.ts`) — it would lose the clip.
- Known limitation: one element carries one `clip-path`, so when two masks apply
  to the same sibling the nearest (upper) one wins. Nested masks in separate
  parents intersect naturally.

---

## 4. Remaining work — in this order, with pointers

### 4.1 Multi-layer and gradient strokes

- `src/plugin/converter/styles.ts:181` reads strokes through
  `strokeList.find((s) => s.visible !== false && s.type === 'SOLID')`, so a
  gradient stroke and the layers below the first solid one are dropped.
- Per-side weights are **already** read (`strokeTopWeight` / `strokeRightWeight`
  / `strokeBottomWeight` / `strokeLeftWeight`, around line 211), so the
  structure for per-side colour exists.
- Target: `border-image` with a gradient, or per-side `border-*-color`.

### 4.2 Blend-mode isolation

- `mixBlendMode` is read, but the CSS `isolation` property is never emitted for
  the group that should form the blending context. The result blends against
  the parent's backdrop instead of the group.

### 4.3 Paragraph spacing in multi-paragraph text

- `src/plugin/converter/typography.ts:169` uses `node.paragraphSpacing` only as
  a list gap. In multi-paragraph text it has no effect at all.

### 4.4 Hyperlinks

- Nothing in the repo references `hyperlink` yet. Read `TextNode.hyperlink`,
  `getRangeHyperlink` and the hyperlink in `getRangeTextStyle`, and emit a real
  `<a href="…">`. This needs a new IR field — so the Tailwind parity table must
  grow with it.

### 4.5 Image pipeline

- `exportNodeAsImage` in `src/plugin/converter/assets.ts` base64-inlines each
  node separately, and the ZIP duplicates the payload. Share the asset and
  reference it instead of repeating the base64. See the single
  `__FIGMA_IMAGE_FILL__` path in `styles.ts` and the two uses in `index.ts`
  (line ~344 and the 4b block).

### 4.6 Font metrics (phase 2 — large visual payoff)

- `size-adjust` and `ascent-override` for custom-font fallbacks, and
  `font-variant-numeric: tabular-nums` for tables.

### 4.7 "Mirror" — a pixel-diff harness (the biggest remaining item)

- `render.test.ts` builds a fixed corpus; `grid-check.mjs` / `mask-check.mjs`
  verify geometry and hit testing. What does **not** exist: a rendering compared
  against a reference screenshot, and a `data-figma-id` debug mode on the
  output. Build it as `harness/mirror-check.mjs`.

---

## 5. Working-tree state — read before committing anything

The tree carries changes to 15 tracked files plus 7 new untracked ones, and it
mixes **two** concerns. Separate them before committing:

1. **Converter fidelity work** (grid, gradient geometry, text shadow, masks)
   plus their tests, harness scripts and README section.
2. **A finished, unrelated minimap feature** in
   `src/shared/whole-file-export.ts` (CSS, canvas script and markup are all
   complete). Give it its own commit.

Also:

- `html-generator/dist/` holds **tracked build artifacts**. Run `npm run build` before
  committing, or `dist` will disagree with the source.
- `html-generator/harness/out/` is generated and git-ignored. Never commit it.
- Commit rules: **always commit and push, no need to ask.** Messages are
  English, imperative subject plus a body that explains the *why*.
- Replies to the user are **Persian**.

---

## 6. Definition of done — all of these must be green before a commit

```bash
cd html-generator

npx tsc --noEmit
npx vitest run                                                  # 29 files / 468 tests
npx vitest run harness/mask.test.ts && node harness/mask-check.mjs   # 7/7 ok
npx vitest run harness/render.test.ts && node harness/grid-check.mjs # 5/5 ok
npm run build
```

Every new feature additionally needs one pure unit test, one real-browser
measurement, and a README entry. When you have to trade, trade in the test —
never in the design.
