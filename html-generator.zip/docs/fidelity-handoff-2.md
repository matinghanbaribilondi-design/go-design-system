# Handoff — Figma → HTML fidelity, phase 2 (items 4.6 and 4.7)

> **STATUS: complete.** Both remaining items are shipped, measured and pushed:
> `8d97f09` (4.6 — the metric fallback and tabular figures measured in real
> Chrome, plus README section 21) and `5a4988e` (4.7 — the Mirror pixel-diff
> harness and the `data-figma-id` debug mode, plus README section 22). The rest
> of this file is the plan those commits were written against; it is kept
> because the reasoning behind the two design decisions — where a pixel diff's
> reference comes from, and what the diff has to say — is the part worth
> reading, not the checklist.
>
> پرامپت دست سوم. این فایل خودکفاست: وضعیت فعلی مخزن، چه چیزی تمام شده،
> چه چیزی مانده، و دقیقاً از کجا ادامه بده. برای دادن به یک AI دیگر، همین
> فایل را بدهید.
>
> سند اولیه (`fidelity-handoff.md`) هنوز معتبر است — قواعد سخت و الگوی
> کاری‌اش عوض نشده. این فایل "ادامه‌ی" همان است، نه جایگزین آن.

You are a Senior Product Designer and front-end engineer working on a Figma
plugin that converts Figma frames to HTML/CSS and Tailwind. The goal is to raise
the **fidelity** of the output — anything a designer drew in Figma should come out
the same in HTML — **without** breaking existing behaviour or tests.

---

## 1. Where the work stands right now

The whole corpus of items **4.1 through 4.5 is shipped, measured and
committed** (they came in with a responsiveness commit, so they are in one
`main`, not a feature branch). **Item 4.6 is shipped except for its README entry
and its real-browser measurement.** **Item 4.7, "Mirror", is not started.**

The working tree is **clean and pushed**. Nothing needs recovering; do not
`reset`, `stash` or `clean` anything.

```bash
cd /Users/part/Desktop/Local/Me/Github/figma-ai
git log --oneline -3
# 8128b74 chore(build): rebuild the bundle so dist matches the source
# ab90835 test(fidelity): pin the cases the stroke and segment tests were missing
# c20cd5d fix(responsive): decide a flex item's main-axis box in one place
```

### 1.1 ⚠️ Another engineer (or agent) is working in this repo at the same time

Since the first handoff was written, someone else has been committing to
`main` from the same working tree — the whole 4.1–4.5 corpus plus a
`src/shared/sizing.ts` module and a large responsiveness rework
(`layout.ts`, `fluid.ts`, `constants.ts`, `sizing.ts`, `layout.responsive.test.ts`)
arrived in `c20cd5d`, which swept up uncommitted work that was in the tree.

Practical consequences for you:

1. **Always `git pull` and `git log` before you start**, and re-check
   `git status` immediately before every commit. The tree can move under you.
2. **Commit small and often.** If you leave work uncommitted for hours, it may
   be swept into someone else's commit, or you may be committing on top of a
   tree that changed under you.
3. **Never `git reset --hard`, `git checkout --`, `git clean -fd`.** With a
   second writer, those destroy the other person's work.
4. The project rule is unchanged: **always commit and push, no need to ask.**

### 1.2 The full definition of done is currently green

Verified on 2026-10-19 at ~14:10:

```bash
cd html-generator
npx tsc --noEmit            # 0 errors

# The full `npx vitest run` gets SIGKILLed under sandbox load — run it by batch:
npx vitest run src/plugin/converter   # 13 files / 251 tests
npx vitest run src/shared             # 10 files / 202 tests
npx vitest run src/generator          #  6 files / 152 tests
npx vitest run src/ui src/plugin/variables   #  3 files /  28 tests
npx vitest run harness                #  7 files /  36 tests
# total: 39 files / 669 tests

node harness/mask-check.mjs          # 6/6 ok  (mask geometry + hit tests)
node harness/grid-check.mjs          # 5/5 ok  (1200→3, 1000→2, 792→2, 760→1, 375→1)
node harness/fidelity-check.mjs      # 22/22  (four fixtures: 23-stroke 6,
                                     #          24-blend 3, 25-paragraphs 5,
                                     #          26-links 8)
npm run build                        # ok, dist/code.js 295.73 kB
```

Chrome needs `--no-sandbox` inside the tool sandbox — the helpers in
`harness/chrome.mjs` already pass it.

---

## 2. Hard rules (unchanged, re-read them)

1. **Responsiveness is intrinsic.** No `@media`, no breakpoints. Everything
   derives from the design's own geometry (`flex-wrap` + `min-width` floors,
   fluid `clamp()`, `cqi`, region stacking via `@container`).
2. **`responsiveEnabled()` / `intrinsicReflowEnabled()` in
   `src/shared/responsive.ts` are the only readers** of the responsive flag.
3. **Thresholds live in `src/shared/constants.ts`**, never inline.
4. **Any field added to the IR must also be added to the Tailwind parity table**
   in `src/generator/tailwind-parity.test.ts`. That table is typed as
   `Record<keyof LayoutStyles | VisualStyles | TypographyStyles, Expectation>`
   and deliberately fails the build so nothing is silently dropped.
5. **Tests are pure logic** (no jsdom). Rendering claims are verified in real
   Chrome via the harness instead.
6. **Keep new logic in small, pure, individually testable modules.** Do not add
   yet another `if` to `layout.ts` when the rule deserves its own function.
7. **Every feature is documented in `README.md`** in the style of the existing
   "ویژگی‌های کلیدی" list: the problem, the solution, the safety boundaries, and
   a pointer to the test that pins it.
8. Commit rules: English imperative subject plus a body that explains the
   *why*. Always commit and push. `html-generator/harness/out/` is generated and
   git-ignored — never commit it. `html-generator/dist/` **is** tracked, so run
   `npm run build` before committing source changes.
9. Replies to the user are **Persian**.

---

## 3. Shipped — do not redo these

Read `html-generator/docs/fidelity-handoff.md` §3 for the two phase-1 items. On top of
those, sections 4.1–4.5 landed, each with a module, a unit test, a real-browser
measurement and a Persian README section (16–20). The shape of the work is the
pattern to follow for what is left:

| Item | Module(s) | Unit tests | README | Real-browser proof |
|---|---|---|---|---|
| 4.1 multi-layer + gradient strokes | `src/plugin/converter/strokes.ts` | `strokes.test.ts` (18) | 16 | `fidelity-check.mjs` 23-stroke (6) |
| 4.2 blend-mode isolation | `src/plugin/converter/blend.ts` | `blend.test.ts` (9) | 17 | 24-blend (3) |
| 4.3 paragraph spacing | `src/shared/text-flow.ts` | `text-flow.test.ts` (15) | 18 | 25-paragraphs (5) |
| 4.4 hyperlinks | `src/plugin/converter/links.ts` | `links.test.ts` (15) | 19 | 26-links (8) |
| 4.5 image pipeline | `src/shared/asset-references.ts`, cache in `assets.ts` | `asset-references.test.ts` (10) | 20 | (payload/URL evidence in `tailwind-project.test.ts`) |
| 4.6 **part one** — font metrics | `src/shared/font-metrics.ts` | `font-metrics.test.ts` (39) | **missing (21)** | **missing** |
| 4.6 **part two** — tabular figures | `src/shared/tabular.ts` | `tabular.test.ts` (33) | **missing (21)** | **missing** |

Useful details from 4.6 that the next step depends on:

- `font-metrics.ts` reads an sfnt's `head`/`hhea`/`OS/2` tables out of a base64
  payload and returns the four fallback descriptors. WOFF/WOFF2 and `.ttc`
  collections are **deliberately refused** (no inflate/brotli in the sandbox) —
  a wrong override is worse than none.
- `generateFontFaceRules` in `src/generator/css-generator.ts` emits one
  `@font-face` per family named **`<Family> Fallback`**, with
  `src: local('Arial'), local('Helvetica'), local('Liberation Sans'),
  local('Nimbus Sans')` plus `size-adjust` / `ascent-override` /
  `descent-override` / `line-gap-override`. A family's weights all share one
  twin (deduped by `twinSeen`).
- `src/plugin/converter/typography.ts` builds the stack through `familyStack()`,
  which inserts the twin **only when the export actually embeds that family**
  (`isEmbeddedFamily(fam, options.customFonts)`). Do not make this
  unconditional: it would put a name that resolves to nothing into every
  `font-family` in the output.
- `tabular.ts` decides what counts as a table from the IR alone (no pixel
  boxes): a stacked container (`flex` non-row or `grid`), ≥2 rows, ≥2 columns,
  identical row widths, identical cell widths per column, and ≥60% of the cells
  holding a number. The decision is per **container** and inherited, so nothing
  outside the table gets `tabular-nums`. `IRNode.typography.fontVariantNumeric`
  carries it; the CSS emitter writes the declaration and the Tailwind emitter
  writes the `tabular-nums` utility.
- Two regressions were caught and fixed along the way, both worth remembering:
  an **instance inherits `strokeWeight`/per-side weights from `mainComponent`**
  (`readStrokeShape`), and the image-export cache **key includes `imageScale`
  and is skipped when the node has no `id`**.

---

## 4. Remaining work — in this order

### 4.6 (finish) Font metrics — the two things left

Both are required by the rule "one pure unit test, one real-browser
measurement, one README entry". The unit tests are done; the browser
measurement and the README entry are not.

**(a) Real-browser measurement.**

Add a fixture to `html-generator/harness/fidelity.test.ts` (the next free numbers are
**27** for fonts and **28** for tables) and extend
`html-generator/harness/fidelity-check.mjs`, following the existing pattern:

1. A `*.test.ts` emits `harness/out/<name>.html` and the `*-check.mjs` drives
   headless Chrome over it.
2. Measure **inside an iframe sized by `location.hash`** (Chrome on macOS
   refuses windows below ~500px). `harness/chrome.mjs` has `probe()`,
   `screenshot()`, `inFrame()` and `report()` for exactly this.
3. `elementFromPoint` honours `clip-path`, so a hit test is a pixel test
   without needing a screenshot decoder.

For the **font** half, do it without depending on a font being installed on the
machine: build the sfnt in the harness test with the same builder the unit test
uses (12-byte header, 16-byte directory, `head`/`hhea`/`OS/2`), give it
deliberately unusual metrics (e.g. unitsPerEm 1000, ascender 900, descender
-300, avgCharWidth 500), embed it as a `data:font/ttf;base64,…` `@font-face`,
and then compare in Chrome:

- `<div style="font-family:'Synth Sans'">` vs
  `<div style="font-family:'Synth Sans Fallback'">` — **line box heights must
  agree to within 1px.** The numbers in the fallback face must come from
  `metricOverrides(parseFontMetrics(bytes))`, computed in Node, not typed by
  hand, so the whole pipeline is under test.
- A third div in plain `Arial` must **differ** — otherwise the check proves
  nothing. (Also assert the synthetic font was really used: a font with no
  glyphs may be rejected by Chrome, and then the comparison silently measures
  Arial against Arial.)
- If Chrome turns out to reject a glyph-less synthetic font, add a `.notdef` +
  two mapped glyphs (`x`, `1`) with `glyf`/`loca`/`maxp`/`hmtx`/`cmap` to the
  builder, or read a real `.ttf` from `/System/Library/Fonts/Supplemental/`
  and assert it is present before running.

For the **tabular** half, render two columns of numbers, one with
`tabular-nums` and one without, and measure the left edge of every digit (wrap
each digit in a span, or use `Range`/`getClientRects`). With the property on,
every digit in a column must share one x; without it, they must not. Then
assert that the emitted CSS actually reaches a converted table — emit a table
fixture through the converter and check the `tabular-nums` class lands on the
container.

**(b) README section 21**, Persian, in the style of 16–20 (problem, solution,
safety boundaries, pointer to the test). Number it **21** and keep the section
numbering descending to 22+ for 4.7. It must cover both halves:

- fonts: what the fallback face is for, why the twin is only named for
  embedded families, and that WOFF/WOFF2 get no fallback;
- tabular figures: why the rule is narrow (a table, not a body of prose), and
  that the declaration is inherited from the container so nothing else gets it.

### 4.7 "Mirror" — a pixel-diff harness (the biggest remaining item)

Nothing exists yet beyond two building blocks:

- `html-generator/harness/png.mjs` — `decodePng(buffer)` → `{width, height, data}`
  (RGBA, 4 bytes per pixel, built on `zlib.inflateSync`), plus `pixelAt`,
  `describePixel`, `distance` and `compare(expected, actual, tolerance)` which
  reports the differing pixel count, the ratio, the **first difference** and
  the busiest row/column — the coordinate that says "everything moved down by
  8px" instead of "12% of the page changed".
- `html-generator/harness/chrome.mjs` — `CHROME`, `OUT`, `probe()`, `screenshot()`,
  `inFrame()`, `report()`.

What does **not** exist: a rendering compared against a reference, and a
`data-figma-id` debug mode on the output. Build it as
`html-generator/harness/mirror-check.mjs`.

Two design decisions to make deliberately, because both have been the death of
every pixel-diff harness:

1. **Where the reference comes from.** A committed golden PNG makes the check
   fail on every Chrome upgrade for reasons that have nothing to do with the
   plugin. Prefer comparing two renderings produced by the same browser in the
   same run — the same fixture exported twice, once through the normal path and
   once through a deliberately perturbed one — so a *stable* difference proves
   the check can see pixels and a *changed* difference names the regression.
   If you do commit a golden file, put it in `harness/reference/` (tracked,
   no `out/`), express the tolerance in pixels **as a constant in
   `src/shared/constants.ts`**, and record the Chrome version it was taken
   under in the file header.
2. **What the diff says.** A diff that prints a coordinate is useless at 3am. It
   must point at the layer: emit `data-figma-id` on each converted node behind
   an explicit option (e.g. `options.debugFigmaIds`, default **off** so the
   normal output is byte-identical), and have the mirror script report the id
   of the element at the first differing pixel via `document.elementFromPoint`
   inside the frame. The `IRNode` already carries `id` — the emitter just drops
   it; `src/generator/html-generator.ts` and `tailwind-generator.ts` are the
   two places that write the root attributes.

Then: README section 22, one unit test if the option adds IR surface (the
parity table catches it if it does), and the definition of done below.

---

## 5. Definition of done — everything green, then commit and push

```bash
cd html-generator
npx tsc --noEmit
npx vitest run src/plugin/converter && npx vitest run src/shared
npx vitest run src/generator && npx vitest run src/ui src/plugin/variables
npx vitest run harness
node harness/mask-check.mjs && node harness/grid-check.mjs
node harness/fidelity-check.mjs
npm run build
```

`npm run build` matters: `html-generator/dist/code.js` is **tracked**, so a source
change without a rebuild leaves `dist` disagreeing with the source in `main`.

Commit in logical pieces with English imperative subjects and a body that
explains the *why*, then push to `origin/main`. Do not commit `harness/out/`.
