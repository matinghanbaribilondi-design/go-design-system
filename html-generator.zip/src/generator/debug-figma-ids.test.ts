import { describe, it, expect } from 'vitest';
import { generateFullHtmlDocument, generateHtml } from './html-generator';
import { generateTailwindHtml } from './tailwind-generator';
import type { ConversionOptions, IRNode } from '../plugin/types/ir';

/**
 * The `data-figma-id` debug mode.
 *
 * A pixel diff that says "12% of the page changed" is useless at 3am; one that
 * says "layer `1:42` moved" is an answer. The id has been on the `IRNode` all
 * along — what was missing was permission to print it.
 *
 * The other half of the contract matters just as much: the option is **off by
 * default, and off means off**. The normal export is what ships, so turning
 * this on must not change a single byte of it. That is the first assertion
 * below, and it is the reason the attribute is threaded through an option
 * rather than written unconditionally.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: false,
  designWidth: 400,
};

function node(id: string, children: IRNode[] = []): IRNode {
  return {
    id,
    name: `Layer ${id}`,
    className: `layer-${id}`,
    tag: children.length > 0 ? 'div' : 'p',
    type: children.length > 0 ? 'FRAME' : 'TEXT',
    layout: {},
    visual: {},
    text: children.length > 0 ? undefined : `text ${id}`,
    children,
  };
}

const tree = (): IRNode => node('root', [node('a', [node('a1'), node('a2')]), node('b')]);

describe('data-figma-id debug mode', () => {
  it('leaves the normal export byte-identical', () => {
    const withoutOption = generateFullHtmlDocument(tree(), options);
    const withOptionOff = generateFullHtmlDocument(tree(), { ...options, debugFigmaIds: false });

    expect(withOptionOff).toBe(withoutOption);
    expect(withoutOption).not.toContain('data-figma-id');
    expect(generateHtml(tree())).not.toContain('data-figma-id');
    expect(generateTailwindHtml(tree())).not.toContain('data-figma-id');
  });

  it('names every node when it is on', () => {
    const html = generateFullHtmlDocument(tree(), { ...options, debugFigmaIds: true });
    const markup = generateHtml(tree(), 0, false, { debugFigmaIds: true });

    for (const id of ['root', 'a', 'a1', 'a2', 'b']) {
      expect(markup).toContain(`data-figma-id="${id}"`);
      expect(html).toContain(`data-figma-id="${id}"`);
    }
    // Five nodes, and not one attribute more: the count is the whole claim.
    expect(markup.match(/data-figma-id=/g)).toHaveLength(5);
  });

  it('does the same for the Tailwind markup', () => {
    const html = generateTailwindHtml(tree(), 0, false, [], { debugFigmaIds: true });
    for (const id of ['root', 'a', 'a1', 'a2', 'b']) {
      expect(html).toContain(`data-figma-id="${id}"`);
    }
    expect(html.match(/data-figma-id=/g)).toHaveLength(5);
  });

  it('escapes an id rather than breaking out of the attribute', () => {
    // Figma ids are `1:23`, but the attribute is an attribute: a quote in a
    // name or an id must not be able to close it and add a hand of its own.
    const hostile: IRNode = {
      id: 'a" onload="alert(1)',
      name: 'Hostile',
      className: 'hostile',
      tag: 'p',
      type: 'TEXT',
      layout: {},
      visual: {},
      text: 'y',
      children: [],
    };
    const odd: IRNode = { ...node('root', [hostile]) };

    const html = generateHtml(odd, 0, false, { debugFigmaIds: true });
    expect(html).toContain('data-figma-id="a&quot; onload=&quot;alert(1)"');
    expect(html).not.toContain('onload="alert(1)"');
  });
});
