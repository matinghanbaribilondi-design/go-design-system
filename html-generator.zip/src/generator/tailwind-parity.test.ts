import { describe, it, expect } from 'vitest';
import { nodeToTailwindClasses, generateTailwindHtml } from './tailwind-generator';
import type { IRNode, LayoutStyles, TypographyStyles, VisualStyles } from '../plugin/types/ir';

/**
 * Tailwind parity.
 *
 * The plugin ships two expressions of the same design: hand-written CSS and
 * utility classes. They have to say the same thing, or the Tailwind export
 * quietly renders differently — text that was clamped to two lines spills to
 * five, a background image tiles instead of covering, a layer loses the
 * `z-index` that put it behind the icon.
 *
 * A hand-written list of "things Tailwind covers" drifts the moment someone
 * adds a field to the IR. So the tables below are typed `Record<keyof …>`:
 * adding a property to `LayoutStyles`, `VisualStyles` or `TypographyStyles` is a
 * **compile error** until it is listed here, either with the classes it should
 * produce or with an explicit reason it produces none. That is the guarantee
 * this file exists for.
 */

interface Expectation {
  /** A probe value for the property. */
  value: unknown;
  /** Classes the probe must produce. `null` means "deliberately no class". */
  classes: string[] | null;
  /** Required when `classes` is null: why no utility is emitted. */
  why?: string;
  /**
   * Properties the probe needs alongside this one. Flex utilities are only
   * emitted for a flex container, and `object-fit` only for an `<img>`, so the
   * probe has to set the context the property lives in.
   */
  also?: Record<string, unknown>;
  /** Tag the probe needs, when the property is tag-specific. */
  tag?: string;
}

const LAYOUT: Record<keyof LayoutStyles, Expectation> = {
  display: { value: 'flex', classes: ['flex'] },
  flexDirection: { value: 'column', classes: ['flex-col'], also: { display: 'flex' } },
  justifyContent: { value: 'space-between', classes: ['justify-between'], also: { display: 'flex' } },
  alignItems: { value: 'center', classes: ['items-center'], also: { display: 'flex' } },
  gridTemplateColumns: {
    value: 'repeat(3, minmax(0, 1fr))',
    classes: ['grid-cols-[repeat(3,_minmax(0,_1fr))]'],
    also: { display: 'grid' },
  },
  gridTemplateRows: {
    value: 'minmax(0, 1fr) auto',
    classes: ['grid-rows-[minmax(0,_1fr)_auto]'],
    also: { display: 'grid' },
  },
  gridColumn: { value: '2 / span 2', classes: ['col-[2_/_span_2]'], also: { display: 'grid' } },
  gridRow: { value: '1', classes: ['row-[1]'], also: { display: 'grid' } },
  flexWrap: { value: 'wrap', classes: ['flex-wrap'], also: { display: 'flex' } },
  gap: { value: '16px', classes: ['gap-[16px]'], also: { display: 'flex' } },
  rowGap: { value: '8px', classes: ['gap-y-[8px]'], also: { display: 'flex' } },
  columnGap: { value: '8px', classes: ['gap-x-[8px]'], also: { display: 'flex' } },
  padding: { value: { top: 4, right: 4, bottom: 4, left: 4 }, classes: ['p-[4px]'] },
  boxSizing: { value: 'border-box', classes: ['[box-sizing:border-box]'] },
  position: { value: 'absolute', classes: ['absolute'] },
  left: { value: '4px', classes: ['left-[4px]'] },
  top: { value: '4px', classes: ['top-[4px]'] },
  right: { value: '4px', classes: ['right-[4px]'] },
  bottom: { value: '4px', classes: ['bottom-[4px]'] },
  width: { value: '120px', classes: ['w-[120px]'] },
  height: { value: '40px', classes: ['h-[40px]'] },
  minWidth: { value: 'min(280px, 100%)', classes: ['min-w-[min(280px,_100%)]'] },
  minHeight: { value: '0', classes: ['min-h-[0]'] },
  maxWidth: { value: '100%', classes: ['max-w-full'] },
  maxHeight: { value: '100%', classes: ['max-h-full'] },
  flexGrow: { value: 1, classes: ['grow'] },
  flexShrink: { value: 0, classes: ['shrink-0'] },
  flexBasis: { value: '0%', classes: ['basis-[0%]'] },
  alignSelf: { value: 'center', classes: ['self-center'] },
  overflow: { value: 'auto', classes: ['overflow-auto'] },
  zIndex: { value: 2, classes: ['z-[2]'] },
  direction: { value: 'rtl', classes: ['[direction:rtl]'], also: { display: 'flex' } },
  transform: { value: 'translateX(-50%)', classes: ['-translate-x-1/2'] },
  constraints: {
    value: { horizontal: 'MIN', vertical: 'MIN' },
    classes: null,
    why: 'consumed by the converter to decide anchors; never a declaration of its own',
  },
  itemSpacing: { value: -8, classes: ['-space-x-[8px]'], also: { display: 'flex' } },
  itemReverseZIndex: {
    value: true,
    classes: null,
    why: 'a per-child z-index the parent imposes — travels down as a class, see the test below',
  },
  containerType: { value: 'inline-size', classes: ['@container'] },
  stackFill: { value: { maxInlineSize: '616px' }, classes: ['@max-[616px]:basis-full', '@max-[616px]:max-w-full'] },
  aspectRatio: { value: '1 / 1', classes: ['aspect-square'] },
  objectFit: { value: 'cover', classes: ['object-cover'], tag: 'img' },
  margin: { value: '0 auto', classes: ['mx-auto'] },
  marginInline: { value: 'auto', classes: ['mx-auto'] },
  marginLeft: { value: '8px', classes: ['ml-[8px]'] },
  marginRight: { value: '8px', classes: ['mr-[8px]'] },
  marginTop: { value: '8px', classes: ['mt-[8px]'] },
  marginBottom: { value: '8px', classes: ['mb-[8px]'] },
};

const VISUAL: Record<keyof VisualStyles, Expectation> = {
  background: { value: '#ffffff', classes: ['bg-[#ffffff]'] },
  backgroundSize: { value: 'cover', classes: ['bg-[length:cover]'] },
  backgroundRepeat: { value: 'no-repeat', classes: ['bg-[repeat:no-repeat]'] },
  backgroundPosition: { value: 'center', classes: ['bg-[position:center]'] },
  borderRadius: { value: '8px', classes: ['rounded-[8px]'] },
  border: { value: '1px solid #000000', classes: ['border-[1px_solid_#000000]'] },
  borderTop: { value: '1px solid #000000', classes: ['border-t-[1px_solid_#000000]'] },
  borderRight: { value: '1px solid #000000', classes: ['border-r-[1px_solid_#000000]'] },
  borderBottom: { value: '1px solid #000000', classes: ['border-b-[1px_solid_#000000]'] },
  borderLeft: { value: '1px solid #000000', classes: ['border-l-[1px_solid_#000000]'] },
  boxSizing: { value: 'border-box', classes: ['[box-sizing:border-box]'] },
  outline: { value: '2px solid red', classes: ['outline-[2px_solid_red]'] },
  outlineOffset: { value: '2px', classes: ['outline-offset-[2px]'] },
  boxShadow: { value: '0 1px 2px #000000', classes: ['shadow-[0_1px_2px_#000000]'] },
  textShadow: { value: '0 1px 2px #000000', classes: ['[text-shadow:0_1px_2px_#000000]'] },
  opacity: { value: 0.5, classes: ['opacity-[0.5]'] },
  filter: { value: 'blur(2px)', classes: ['[filter:blur(2px)]'] },
  backdropFilter: { value: 'blur(4px)', classes: ['[backdrop-filter:blur(4px)]'] },
  transform: { value: 'rotate(3deg)', classes: ['[transform:rotate(3deg)]'] },
  clipPath: { value: 'circle(50%)', classes: ['[clip-path:circle(50%)]'] },
  mixBlendMode: { value: 'multiply', classes: ['[mix-blend-mode:multiply]'] },
  isolation: { value: 'isolate', classes: ['isolate'] },
  gradientBorder: {
    value: { image: 'linear-gradient(90deg, #ff0000 0%, #0000ff 100%)', width: '2px' },
    classes: [
      'relative',
      'after:absolute',
      'after:p-[2px]',
      'after:[background:linear-gradient(90deg,_#ff0000_0%,_#0000ff_100%)]',
      'after:[mask-composite:exclude]',
    ],
  },
};

const TYPOGRAPHY: Record<keyof TypographyStyles, Expectation> = {
  fontSize: { value: '14px', classes: ['text-[14px]'] },
  fontWeight: { value: 600, classes: ['font-semibold'] },
  fontFamily: { value: 'Inter', classes: ['[font-family:Inter]'] },
  fontStyle: { value: 'italic', classes: ['italic'] },
  lineHeight: { value: '1.4', classes: ['leading-[1.4]'] },
  letterSpacing: { value: '0.5px', classes: ['tracking-[0.5px]'] },
  textAlign: { value: 'center', classes: ['text-center'] },
  textDecoration: { value: 'underline', classes: ['underline'] },
  textTransform: { value: 'uppercase', classes: ['uppercase'] },
  color: { value: '#111111', classes: ['text-[#111111]'] },
  whiteSpace: { value: 'nowrap', classes: ['whitespace-nowrap'] },
  wordBreak: { value: 'break-all', classes: ['[word-break:break-all]'] },
  overflowWrap: { value: 'break-word', classes: ['break-words'] },
  textOverflow: { value: 'ellipsis', classes: ['text-ellipsis'] },
  display: { value: '-webkit-box', classes: ['[display:-webkit-box]'] },
  webkitLineClamp: { value: 2, classes: ['line-clamp-2'] },
  webkitBoxOrient: { value: 'vertical', classes: ['[box-orient:vertical]'] },
  overflow: { value: 'hidden', classes: ['[overflow:hidden]'] },
  direction: { value: 'rtl', classes: ['[direction:rtl]'] },
  segments: {
    value: [],
    classes: null,
    why: 'multi-style runs become inline <span> styles in the markup, not classes',
  },
  isList: { value: true, classes: ['list-none', 'flex', 'flex-col'] },
  listType: {
    value: 'ordered',
    classes: null,
    why: 'chooses the <ol>/<ul> tag in the markup',
  },
  listGap: {
    value: '6px',
    classes: null,
    why: 'emitted together with `isList`, not on its own',
  },
  listBulletColor: {
    value: '#334155',
    classes: null,
    why: 'the CSS export draws bullets with `::before`, which utilities cannot express; the Tailwind markup keeps the literal bullet character instead',
  },
  paragraphSpacing: {
    value: '12px',
    classes: null,
    why: 'becomes one block per paragraph in the markup, in both outputs — a margin between paragraphs is a box, not a utility',
  },
  fontVariantNumeric: {
    value: 'tabular-nums',
    classes: ['tabular-nums'],
  },
};

function classesFor(expectation: Expectation, part: 'layout' | 'visual' | 'typography', key: string): string[] {
  const base: IRNode = {
    id: 'n',
    name: 'Node',
    className: 'n',
    tag: (expectation.tag as IRNode['tag']) ?? 'div',
    type: 'FRAME',
    layout: {},
    visual: {},
    children: [],
  };
  const own = (base[part] as Record<string, unknown>) ?? {};
  const target = { ...own, ...(expectation.also ?? {}), [key]: expectation.value };
  return nodeToTailwindClasses({ ...base, [part]: target } as IRNode);
}

const TABLES: [string, 'layout' | 'visual' | 'typography', Record<string, Expectation>][] = [
  ['layout', 'layout', LAYOUT],
  ['visual', 'visual', VISUAL],
  ['typography', 'typography', TYPOGRAPHY],
];

describe('Tailwind parity with the CSS export', () => {
  for (const [label, part, table] of TABLES) {
    describe(label, () => {
      for (const [key, expectation] of Object.entries(table)) {
        if (expectation.classes === null) {
          it(`${key}: deliberately no utility (${expectation.why})`, () => {
            expect(expectation.why, `${key} needs a reason`).toBeTruthy();
          });
          continue;
        }
        it(`${key} → ${expectation.classes.join(' ')}`, () => {
          const produced = classesFor(expectation, part, key);
          for (const expected of expectation.classes!) {
            expect(produced, `${key} produced ${produced.join(' ')}`).toContain(expected);
          }
        });
      }
    });
  }

  it('emits a grid frame as a grid, with its tracks and per-axis gaps', () => {
    const grid: IRNode = {
      id: 'g',
      name: 'Cards',
      className: 'g',
      tag: 'div',
      type: 'FRAME',
      layout: {
        display: 'grid',
        gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
        gridTemplateRows: 'minmax(0, 1fr)',
        columnGap: '24px',
        rowGap: '16px',
      },
      visual: {},
      children: [],
    };

    const classes = nodeToTailwindClasses(grid);
    expect(classes).toContain('grid');
    expect(classes).not.toContain('flex');
    expect(classes).toContain('grid-cols-[repeat(4,_minmax(0,_1fr))]');
    expect(classes).toContain('gap-x-[24px]');
    expect(classes).toContain('gap-y-[16px]');
  });

  it('merges the layout transform with the layer transform instead of dropping one', () => {
    const built = {
      id: 'n',
      name: 'Badge',
      className: 'n',
      tag: 'div',
      type: 'FRAME',
      layout: { transform: 'translateX(-50%)' },
      visual: { transform: 'rotate(3deg)' },
      children: [],
    } as IRNode;
    const classes = nodeToTailwindClasses(built);
    // One combined transform, exactly as the CSS export writes it.
    expect(classes).toContain('[transform:translateX(-50%)_rotate(3deg)]');
    expect(classes).not.toContain('[transform:rotate(3deg)]');
  });

  it('carries a parent’s reverse stacking order down to its children', () => {
    const child = (id: string): IRNode => ({
      id,
      name: id,
      className: id,
      tag: 'div',
      type: 'FRAME',
      layout: { zIndex: 9 },
      visual: {},
      children: [],
    });
    const parent: IRNode = {
      id: 'stack',
      name: 'Stack',
      className: 'stack',
      tag: 'div',
      type: 'FRAME',
      layout: { display: 'flex', itemReverseZIndex: true },
      visual: {},
      children: [child('a'), child('b')],
    };

    const html = generateTailwindHtml(parent);
    // First child on top: the first gets the highest z-index, and it replaces
    // the child's own — which is what the cascade does in the CSS export.
    expect(html).toContain('z-[2]');
    expect(html).toContain('z-[1]');
    expect(html).not.toContain('z-[9]');
  });

  it('keeps the bullet character in a list instead of relying on ::before', () => {
    const list: IRNode = {
      id: 'list',
      name: 'List',
      className: 'list',
      tag: 'ul',
      type: 'TEXT',
      layout: {},
      visual: {},
      typography: { isList: true, listGap: '6px' },
      text: '• First\n• Second',
      children: [],
    };

    const html = generateTailwindHtml(list);
    expect(html).toContain('• First');
    expect(html).toContain('• Second');
    expect(html).toContain('gap-[6px]');
  });

  it('isolates bidirectional numbers the same way the HTML export does', () => {
    const phone: IRNode = {
      id: 'phone',
      name: 'Phone',
      className: 'phone',
      tag: 'p',
      type: 'TEXT',
      layout: {},
      visual: {},
      typography: { fontSize: '14px' },
      text: 'تماس: 0912 345 6789',
      children: [],
    };
    const html = generateTailwindHtml(phone);
    expect(html).toContain('unicode-bidi: isolate');
  });
});
