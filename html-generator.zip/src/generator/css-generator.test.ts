import { describe, it, expect } from 'vitest';
import { generateFontFaceRules, generateCss } from './css-generator';
import { nodeToTailwindClasses } from './tailwind-generator';
import { ConversionOptions, CustomFontData, IRNode } from '../plugin/types/ir';

describe('generateFontFaceRules', () => {
  const baseOptions: ConversionOptions = {
    outputMode: 'pure-css',
    useRem: false,
    baseFontSize: 16,
    includeReset: false,
    inlineAssets: true,
    semanticTags: true,
    embedFontsBase64: true,
    customFonts: [],
  };

  it('generates standard @font-face rules', () => {
    const font: CustomFontData = {
      id: 'dana-1',
      family: 'Dana',
      style: 'Bold',
      weight: 700,
      format: 'woff2',
      base64: 'fake-base64',
      filename: 'Dana-Bold.woff2',
    };

    const css = generateFontFaceRules({ ...baseOptions, customFonts: [font] }, false);
    expect(css).toContain("font-family: 'Dana';");
    expect(css).toContain('font-weight: 700;');
    expect(css).toContain("src: url('data:font/woff2;base64,fake-base64') format('woff2');");
  });

  it('handles variable fonts with 100 1000 weight range and aliases', () => {
    const font: CustomFontData = {
      id: 'yekan-vf',
      family: 'Yekan Bakh VF',
      style: 'Variable',
      weight: '100 900',
      format: 'woff2',
      base64: 'data:font/woff2;base64,yekan-data',
      filename: 'YekanBakh-VF.woff2',
      isVariable: true,
    };

    const css = generateFontFaceRules({ ...baseOptions, customFonts: [font] }, false);
    expect(css).toContain("font-family: 'Yekan Bakh VF';");
    expect(css).toContain("font-family: 'Yekan Bakh';");
    expect(css).toContain("font-family: 'YekanBakh';");
    expect(css).toContain('font-weight: 100 1000;');
    expect(css).toContain("format('woff2-variations')");
  });

  it('handles IRANYekanX variable font aliases', () => {
    const font: CustomFontData = {
      id: 'iran-vf',
      family: 'IRANYekanXVF',
      style: 'Variable',
      weight: '100 1000',
      format: 'woff2',
      base64: 'fake-iran-base64',
      filename: 'IRANYekanXVF.woff2',
      isVariable: true,
    };

    const css = generateFontFaceRules({ ...baseOptions, customFonts: [font] }, false);
    expect(css).toContain("font-family: 'IRANYekanXVF';");
    expect(css).toContain("font-family: 'IRANYekanX';");
    expect(css).toContain('font-weight: 100 1000;');
  });
});

describe('generateCss negative spacing & stacking', () => {
  const options: ConversionOptions = {
    outputMode: 'pure-css',
    useRem: false,
    baseFontSize: 16,
    includeReset: true,
    inlineAssets: true,
    semanticTags: true,
  };

  it('generates negative margin sibling rule for horizontal AutoLayout', () => {
    const ir: IRNode = {
      id: 'stack-1',
      name: 'List people',
      className: 'list-people',
      tag: 'ul',
      type: 'FRAME',
      layout: {
        display: 'flex',
        flexDirection: 'row',
        itemSpacing: -4,
      },
      visual: {},
      children: [
        {
          id: 'c1',
          name: 'Avatar 1',
          className: 'avatar-1',
          tag: 'div',
          type: 'INSTANCE',
          layout: { width: '26px', height: '26px' },
          visual: {},
          children: [],
        },
        {
          id: 'c2',
          name: 'Avatar 2',
          className: 'avatar-2',
          tag: 'div',
          type: 'INSTANCE',
          layout: { width: '26px', height: '26px' },
          visual: {},
          children: [],
        },
      ],
    };

    const css = generateCss(ir, options, false);
    expect(css).toContain('.list-people > * + * {\n  margin-inline-start: -4px;\n}');
    expect(css).toContain('img {\n  display: block;\n  max-width: 100%;\n}');
  });

  it('generates correct CSS for avatar stack with outside border and border-box', () => {
    const ir: IRNode = {
      id: 'stack-avatars',
      name: 'List people',
      className: 'list-people',
      tag: 'ul',
      type: 'FRAME',
      layout: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        width: '98px',
        height: '32px',
        itemSpacing: -10,
        boxSizing: 'border-box',
      },
      visual: {},
      children: [
        {
          id: 'av-1',
          name: 'Avatar 1',
          className: 'avatar',
          tag: 'div',
          type: 'INSTANCE',
          layout: {
            width: '32px',
            height: '32px',
            boxSizing: 'border-box',
            overflow: 'hidden',
            position: 'relative',
          },
          visual: {
            borderRadius: '50%',
            border: '3px solid #ffffff',
            boxSizing: 'border-box',
          },
          children: [
            {
              id: 'av-img',
              name: 'Avatar Image',
              className: 'avatar-img',
              tag: 'img',
              type: 'ELLIPSE',
              layout: {
                width: '100%',
                height: '100%',
                position: 'absolute',
                left: '0px',
                top: '0px',
              },
              visual: {
                borderRadius: '50%',
              },
              children: [],
            },
          ],
        },
      ],
    };

    const css = generateCss(ir, options, false);
    expect(css).toContain('.list-people > * + * {\n  margin-inline-start: -10px;\n}');
    expect(css).toContain('.avatar {\n  position: relative;\n  box-sizing: border-box;\n  width: 32px;\n  height: 32px;\n  overflow: hidden;\n  border-radius: 50%;\n  box-sizing: border-box;\n  border: 3px solid #ffffff;\n}');
    expect(css).toContain('.avatar-img {\n  position: absolute;\n  left: 0px;\n  top: 0px;\n  width: 100%;\n  height: 100%;\n  border-radius: 50%;\n  object-fit: cover;\n}');
  });

  it('generates z-index rules when itemReverseZIndex is true', () => {
    const ir: IRNode = {
      id: 'stack-2',
      name: 'Stacked List',
      className: 'stacked-list',
      tag: 'div',
      type: 'FRAME',
      layout: {
        display: 'flex',
        flexDirection: 'row',
        itemSpacing: -4,
        itemReverseZIndex: true,
      },
      visual: {},
      children: [
        {
          id: 'c1',
          name: 'Item 1',
          className: 'item-1',
          tag: 'div',
          type: 'INSTANCE',
          layout: { width: '26px', height: '26px' },
          visual: {},
          children: [],
        },
        {
          id: 'c2',
          name: 'Item 2',
          className: 'item-2',
          tag: 'div',
          type: 'INSTANCE',
          layout: { width: '26px', height: '26px' },
          visual: {},
          children: [],
        },
      ],
    };

    const css = generateCss(ir, options, false);
    expect(css).toContain('.item-1 {\n  z-index: 2;\n}');
    expect(css).toContain('.item-2 {\n  z-index: 1;\n}');
  });
});

describe('generateCss image borders and radii', () => {
  const options: ConversionOptions = {
    outputMode: 'pure-css',
    useRem: false,
    baseFontSize: 16,
    includeReset: false,
    inlineAssets: true,
    semanticTags: true,
  };

  it('generates border and border-radius on standalone img nodes', () => {
    const ir: IRNode = {
      id: 'img-1',
      name: 'Profile Photo',
      className: 'profile-photo',
      tag: 'img',
      type: 'RECTANGLE',
      layout: { width: '48px', height: '48px' },
      visual: {
        borderRadius: '50%',
        border: '3px solid #ffffff',
        boxSizing: 'border-box',
      },
      children: [],
    };

    const css = generateCss(ir, options, false);
    expect(css).toContain('.profile-photo {\n  width: 48px;\n  height: 48px;\n  border-radius: 50%;\n  box-sizing: border-box;\n  border: 3px solid #ffffff;\n  object-fit: cover;\n}');
  });

  it('generates independent borders on both card and nested image', () => {
    const ir: IRNode = {
      id: 'card-1',
      name: 'Card',
      className: 'card',
      tag: 'div',
      type: 'FRAME',
      layout: { width: '320px', height: '400px' },
      visual: {
        border: '1px solid #e2e8f0',
        borderRadius: '12px',
      },
      children: [
        {
          id: 'card-img',
          name: 'Thumbnail',
          className: 'thumbnail',
          tag: 'img',
          type: 'RECTANGLE',
          layout: { width: '280px', height: '180px' },
          visual: {
            border: '2px solid #3b82f6',
            borderRadius: '8px',
          },
          children: [],
        },
      ],
    };

    const css = generateCss(ir, options, false);
    expect(css).toContain('.card {\n  box-sizing: border-box;\n  width: 320px;\n  height: 400px;\n  border-radius: 12px;\n  border: 1px solid #e2e8f0;\n}');
    expect(css).toContain('.thumbnail {\n  box-sizing: border-box;\n  width: 280px;\n  height: 180px;\n  border-radius: 8px;\n  border: 2px solid #3b82f6;\n  object-fit: cover;\n}');
  });

  it('generates outline and outline-offset for outside strokes without shrinking box model', () => {
    const ir: IRNode = {
      id: 'avatar-1',
      name: 'Avatar',
      className: 'avatar',
      tag: 'div',
      type: 'INSTANCE',
      layout: { width: '26px', height: '26px' },
      visual: {
        borderRadius: '50%',
        outline: '3px solid #ffffff',
      },
      children: [
        {
          id: 'avatar-img',
          name: 'Avatar Photo',
          className: 'avatar-photo',
          tag: 'img',
          type: 'ELLIPSE',
          layout: { width: '26px', height: '26px' },
          visual: {},
          children: [],
        },
      ],
    };

    const css = generateCss(ir, options, false);
    expect(css).toContain('.avatar {\n  width: 26px;\n  height: 26px;\n  border-radius: 50%;\n  outline: 3px solid #ffffff;\n}');
    expect(css).toContain('.avatar-photo {\n  width: 26px;\n  height: 26px;\n  object-fit: cover;\n}');

    const twClasses = nodeToTailwindClasses(ir);
    expect(twClasses).toContain('outline-[3px_solid_#ffffff]');
    expect(twClasses).toContain('rounded-full');
  });

  it('renders horizontal and vertical LINE dividers cleanly with border-top/border-right', () => {
    const horizontalDivider: IRNode = {
      id: 'divider-1',
      name: 'Divider',
      className: 'divider',
      tag: 'div',
      type: 'LINE',
      layout: { width: '336px', height: '0px', flexShrink: 0 },
      visual: { borderTop: '1px solid #dedede', boxSizing: 'border-box' },
      children: [],
    };

    const css = generateCss(horizontalDivider, options, false);
    expect(css).toContain('width: 336px;');
    expect(css).toContain('height: 0px;');
    expect(css).toContain('border-top: 1px solid #dedede;');
    expect(css).not.toContain('border: 1px solid');
  });
});



