import { describe, it, expect } from 'vitest';
import { generateCss } from './css-generator';
import { nodeToTailwindClasses } from './tailwind-generator';
import { ConversionOptions, IRNode } from '../plugin/types/ir';

describe('Intrinsic responsive output', () => {
  const responsiveOptions: ConversionOptions = {
    outputMode: 'pure-css',
    useRem: false,
    baseFontSize: 16,
    includeReset: true,
    inlineAssets: true,
    semanticTags: true,
    responsive: true,
    intrinsicReflow: true,
    designWidth: 1200,
  };

  it('generates a fluid root container with width 100%, max-width, min-height and margin-inline auto', () => {
    const rootIr: IRNode = {
      id: 'root-1',
      name: 'Landing Page',
      className: 'landing-page',
      tag: 'div',
      type: 'FRAME',
      layout: {
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        width: '100%',
        maxWidth: '1200px',
        minHeight: '800px',
        marginInline: 'auto',
        boxSizing: 'border-box',
      },
      visual: {},
      children: [],
    };

    const css = generateCss(rootIr, responsiveOptions, false);
    expect(css).toContain('width: 100%;');
    expect(css).toContain('max-width: 1200px;');
    expect(css).toContain('min-height: 800px;');
    expect(css).toContain('margin-inline: auto;');
    expect(css).not.toContain('  width: 1200px;');

    // Reset includes a top-aligned, scrollable body
    expect(css).toContain('justify-content: flex-start;');
    expect(css).toContain('flex-direction: column;');

    const twClasses = nodeToTailwindClasses(rootIr);
    expect(twClasses).toContain('w-full');
    expect(twClasses).toContain('max-w-[1200px]');
    expect(twClasses).toContain('min-h-[800px]');
    expect(twClasses).toContain('mx-auto');
  });

  it('emits no @media breakpoint and no md: prefixes — responsiveness is continuous', () => {
    const rowIr: IRNode = {
      id: 'row',
      name: 'Row',
      className: 'row',
      tag: 'div',
      type: 'FRAME',
      layout: { display: 'flex', flexDirection: 'row', flexWrap: 'wrap' },
      visual: {},
      children: [],
    };

    const css = generateCss(rowIr, responsiveOptions, false);
    expect(css).not.toContain('@media');
    expect(css).not.toContain('max-width: 768px');

    const tw = nodeToTailwindClasses(rowIr);
    expect(tw.some((c) => c.startsWith('md:'))).toBe(false);
    expect(tw).toContain('flex-wrap');
  });

  it('keeps max-width 100% on fixed-width containers', () => {
    const cardIr: IRNode = {
      id: 'card-1',
      name: 'Feature Card',
      className: 'feature-card',
      tag: 'div',
      type: 'FRAME',
      layout: {
        display: 'flex',
        flexDirection: 'column',
        width: '360px',
        maxWidth: '100%',
        minHeight: '240px',
      },
      visual: {},
      children: [],
    };

    const css = generateCss(cardIr, responsiveOptions, false);
    expect(css).toContain('width: 360px;');
    expect(css).toContain('max-width: 100%;');
    expect(css).toContain('min-height: 240px;');

    const twClasses = nodeToTailwindClasses(cardIr);
    expect(twClasses).toContain('w-[360px]');
    expect(twClasses).toContain('max-w-full');
    expect(twClasses).toContain('min-h-[240px]');
  });

  it('reflows a multi-column row intrinsically: flex-wrap plus a min-width floor, never a breakpoint', () => {
    const rowIr: IRNode = {
      id: 'columns-row',
      name: 'Features Grid',
      className: 'features-grid',
      tag: 'div',
      type: 'FRAME',
      layout: {
        display: 'flex',
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
        gap: 'clamp(21px, 2.67%, 32px)',
        padding: {
          top: 'clamp(31px, 4%, 48px)',
          right: 'clamp(31px, 4%, 48px)',
          bottom: 'clamp(31px, 4%, 48px)',
          left: 'clamp(31px, 4%, 48px)',
        },
      },
      visual: {},
      children: [
        {
          id: 'col-1',
          name: 'Col 1',
          className: 'col-1',
          tag: 'div',
          type: 'FRAME',
          layout: {
            flexGrow: 1,
            flexShrink: 1,
            flexBasis: '320px',
            maxWidth: '320px',
            minWidth: 'min(280px, 100%)',
          },
          visual: {},
          children: [],
        },
      ],
    };

    const css = generateCss(rowIr, responsiveOptions, false);
    expect(css).toContain('flex-wrap: wrap;');
    expect(css).toContain('gap: clamp(21px, 2.67%, 32px);');
    expect(css).toContain('padding: clamp(31px, 4%, 48px);');
    expect(css).toContain('flex-basis: 320px;');
    expect(css).toContain('max-width: 320px;');
    expect(css).toContain('min-width: min(280px, 100%);');
    // The whole point: no viewport breakpoint anywhere in the stylesheet.
    expect(css).not.toContain('@media');

    const rowTw = nodeToTailwindClasses(rowIr);
    expect(rowTw).toContain('flex-wrap');
    expect(rowTw).toContain('gap-[clamp(21px,_2.67%,_32px)]');
    expect(rowTw).toContain('p-[clamp(31px,_4%,_48px)]');

    const colTw = nodeToTailwindClasses(rowIr.children[0]!);
    expect(colTw).toContain('grow');
    expect(colTw).toContain('basis-[320px]');
    expect(colTw).toContain('max-w-[320px]');
    expect(colTw).toContain('min-w-[min(280px,_100%)]');
  });

  it('scales display type fluidly with a unitless line-height, and leaves body copy fixed', () => {
    const headingIr: IRNode = {
      id: 'h1',
      name: 'Main Title',
      className: 'main-title',
      tag: 'h1',
      type: 'TEXT',
      layout: { width: '100%' },
      visual: {},
      typography: {
        fontSize: 'clamp(31px, 4cqi, 48px)',
        fontWeight: 700,
        lineHeight: '1.25',
      },
      text: 'Responsive Heading',
      children: [],
    };

    const css = generateCss(headingIr, responsiveOptions, false);
    expect(css).toContain('font-size: clamp(31px, 4cqi, 48px);');
    expect(css).toContain('line-height: 1.25;');
    expect(css).not.toContain('@media');

    const twClasses = nodeToTailwindClasses(headingIr);
    expect(twClasses).toContain('text-[clamp(31px,_4cqi,_48px)]');
    expect(twClasses).toContain('leading-[1.25]');
    expect(twClasses.some((c) => c.startsWith('md:'))).toBe(false);
  });

  it('preserves circular avatars with aspect-ratio 1 / 1 and flex-shrink 0 without distortion', () => {
    const avatarIr: IRNode = {
      id: 'avatar-user',
      name: 'Avatar',
      className: 'avatar-user',
      tag: 'img',
      type: 'ELLIPSE',
      layout: {
        width: '40px',
        height: '40px',
        minWidth: '40px',
        minHeight: '40px',
        aspectRatio: '1 / 1',
        flexShrink: 0,
        objectFit: 'cover',
      },
      visual: {
        borderRadius: '50%',
      },
      children: [],
    };

    const css = generateCss(avatarIr, responsiveOptions, false);
    expect(css).toContain('width: 40px;');
    expect(css).toContain('height: 40px;');
    expect(css).toContain('aspect-ratio: 1 / 1;');
    expect(css).toContain('flex-shrink: 0;');
    expect(css).toContain('border-radius: 50%;');
    expect(css).toContain('object-fit: cover;');

    const twClasses = nodeToTailwindClasses(avatarIr);
    expect(twClasses).toContain('w-[40px]');
    expect(twClasses).toContain('h-[40px]');
    expect(twClasses).toContain('aspect-square');
    expect(twClasses).toContain('rounded-full');
  });

  /** A rail beside a body — the case where wrapping alone leaves a stranded rail. */
  function railAndBodyIr(): IRNode {
    const region = (id: string, name: string, className: string, basis: string): IRNode => ({
      id,
      name,
      className,
      tag: 'div',
      type: 'FRAME',
      layout: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: basis,
        maxWidth: basis,
        minWidth: 'min(280px, 100%)',
        stackFill: { maxInlineSize: '1200px' },
      },
      visual: {},
      children: [],
    });
    return {
      id: 'shell',
      name: 'App Shell',
      className: 'app-shell',
      tag: 'div',
      type: 'FRAME',
      layout: {
        display: 'flex',
        flexDirection: 'row',
        flexWrap: 'wrap',
        containerType: 'inline-size',
        gap: 'clamp(21px, 2.67%, 32px)',
      },
      visual: {},
      children: [
        region('rail', 'Sidebar', 'sidebar', '320px'),
        region('body', 'Content', 'content', '848px'),
      ],
    };
  }

  it('makes a regions row its own query container and lets each region fill the stacked line', () => {
    const shell = railAndBodyIr();
    const css = generateCss(shell, responsiveOptions, false);

    expect(css).toContain('container-type: inline-size;');
    // Strict: a packed row still fits at its wrap point, so the query must not
    // match there. Tailwind's `@max-[…]` compiles to this same form.
    expect(css).toContain('@container (width < 1200px) {');
    expect(css).not.toContain('max-width: 1200px)');
    expect(css).toContain('flex-basis: 100%;');
    expect(css).toContain('max-width: 100%;');

    // The override has to come after the region's own rule, or its designed
    // `max-width` would win and the region would stay narrow when stacked.
    expect(css.indexOf('@container')).toBeGreaterThan(css.indexOf('.sidebar {'));
    expect(css.indexOf('@container')).toBeGreaterThan(css.indexOf('.content {'));

    // Still no viewport breakpoint: the query is against the row's own width.
    expect(css).not.toContain('@media');
  });

  it('groups every region of a stacked row into a single container query', () => {
    const css = generateCss(railAndBodyIr(), responsiveOptions, false);
    const occurrences = css.split('@container').length - 1;
    expect(occurrences).toBe(1);
    expect(css).toContain('.sidebar,\n  .content {');
  });

  it('expresses the stack with container-query variants in Tailwind, not breakpoints', () => {
    const shell = railAndBodyIr();

    const rowClasses = nodeToTailwindClasses(shell);
    expect(rowClasses).toContain('@container');

    const railClasses = nodeToTailwindClasses(shell.children[0]!);
    expect(railClasses).toContain('@max-[1200px]:basis-full');
    expect(railClasses).toContain('@max-[1200px]:max-w-full');
    expect(railClasses.some((c) => c.startsWith('md:'))).toBe(false);
  });

  it('leaves a grid row without a query container — it reflows two-up, one-up', () => {
    const grid: IRNode = {
      id: 'grid',
      name: 'Cards',
      className: 'cards',
      tag: 'div',
      type: 'FRAME',
      layout: { display: 'flex', flexDirection: 'row', flexWrap: 'wrap' },
      visual: {},
      children: [
        {
          id: 'card',
          name: 'Card',
          className: 'card',
          tag: 'div',
          type: 'FRAME',
          layout: { flexGrow: 1, flexBasis: '360px', maxWidth: '360px' },
          visual: {},
          children: [],
        },
      ],
    };

    const css = generateCss(grid, responsiveOptions, false);
    expect(css).not.toContain('container-type');
    expect(css).not.toContain('@container');
    expect(nodeToTailwindClasses(grid)).not.toContain('@container');
  });

  it('emits no designed cap on a packed grid, so a wrapped card fills its line', () => {
    const card: IRNode = {
      id: 'card',
      name: 'Card',
      className: 'card',
      tag: 'div',
      type: 'FRAME',
      layout: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: '360px',
        maxWidth: '100%',
        minWidth: 'min(280px, 100%)',
      },
      visual: {},
      children: [],
    };

    const css = generateCss(card, responsiveOptions, false);
    expect(css).toContain('flex-basis: 360px;');
    expect(css).toContain('max-width: 100%;');
    // The designed cap is the only thing that would strand the card narrow.
    expect(css).not.toContain('max-width: 360px;');

    const tw = nodeToTailwindClasses(card);
    expect(tw).toContain('grow');
    expect(tw).toContain('basis-[360px]');
    expect(tw).toContain('max-w-full');
    expect(tw).not.toContain('max-w-[360px]');
  });

  it('expresses implicit fill as grow + basis 0, with no fixed width left behind', () => {
    const input: IRNode = {
      id: 'input',
      name: 'Search Input',
      className: 'search-input',
      tag: 'div',
      type: 'FRAME',
      layout: { flexGrow: 1, flexShrink: 1, flexBasis: '0%', minWidth: '0', maxWidth: '100%' },
      visual: {},
      children: [],
    };

    const css = generateCss(input, responsiveOptions, false);
    expect(css).toContain('flex-grow: 1;');
    expect(css).toContain('flex-basis: 0%;');
    expect(css).not.toContain('width: 600px;');

    const tw = nodeToTailwindClasses(input);
    expect(tw).toContain('grow');
    expect(tw).toContain('basis-[0%]');
    expect(tw).toContain('max-w-full');
  });

  it('pins a freeform band to both edges and gives it no width of its own', () => {
    const band: IRNode = {
      id: 'band',
      name: 'Hero',
      className: 'hero',
      tag: 'div',
      type: 'FRAME',
      layout: { position: 'absolute', left: '16px', right: '16px', height: '400px' },
      visual: {},
      children: [],
    };

    const css = generateCss(band, responsiveOptions, false);
    expect(css).toContain('.hero {\n  position: absolute;\n  left: 16px;\n  right: 16px;\n  height: 400px;\n}');

    const tw = nodeToTailwindClasses(band);
    expect(tw).toContain('absolute');
    expect(tw).toContain('left-[16px]');
    expect(tw).toContain('right-[16px]');
    expect(tw.some((c) => c.startsWith('w-'))).toBe(false);
  });

  it('carries a centre-relative offset through to both generators', () => {
    // A frame pinned 86px to the right of the modal's centre axis, with its own
    // centre pulled back by half its width. Renders at the drawn position and
    // keeps the offset when the modal is resized.
    const pinned: IRNode = {
      id: 'title',
      name: 'Card Title',
      className: 'card-title',
      tag: 'div',
      type: 'FRAME',
      layout: {
        position: 'absolute',
        left: 'calc(50% + 86px)',
        top: '24px',
        transform: 'translateX(-50%)',
        width: '164px',
      },
      visual: {},
      children: [],
    };

    const css = generateCss(pinned, responsiveOptions, false);
    expect(css).toContain('left: calc(50% + 86px);');
    expect(css).toContain('transform: translateX(-50%);');

    const tw = nodeToTailwindClasses(pinned);
    // Tailwind arbitrary values cannot hold raw spaces.
    expect(tw).toContain('left-[calc(50%_+_86px)]');
    expect(tw).toContain('-translate-x-1/2');
  });

  it('maps a fully centred layer onto Tailwind centring utilities', () => {
    const dialog: IRNode = {
      id: 'dialog',
      name: 'Dialog',
      className: 'dialog',
      tag: 'div',
      type: 'FRAME',
      layout: {
        position: 'absolute',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        width: '480px',
      },
      visual: {},
      children: [],
    };

    const css = generateCss(dialog, responsiveOptions, false);
    expect(css).toContain('left: 50%;');
    expect(css).toContain('top: 50%;');
    expect(css).toContain('transform: translate(-50%, -50%);');

    const tw = nodeToTailwindClasses(dialog);
    expect(tw).toContain('left-[50%]');
    expect(tw).toContain('top-[50%]');
    expect(tw).toContain('-translate-x-1/2');
    expect(tw).toContain('-translate-y-1/2');
  });
});
