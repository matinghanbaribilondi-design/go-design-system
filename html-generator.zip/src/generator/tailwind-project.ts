import { ConversionOptions, ConversionResult, CustomFontData } from '../plugin/types/ir';
import { generateFontFaceRules } from './css-generator';
import { escapeHtml, toFileSlug } from '../shared/style-utils';
import { FONT_STACK_LTR, FONT_STACK_RTL } from '../shared/constants';
import { referenceAssets, uniqueAssets } from '../shared/asset-references';

/**
 * Builds a complete, self-contained Tailwind CSS project from a conversion
 * result.
 *
 * The plugin's default ZIP ships separated HTML + CSS. This module produces the
 * alternative: the same markup expressed purely with Tailwind utility classes,
 * plus everything needed to build it.
 *
 * The token export uses `@theme`, which is Tailwind v4 syntax, so the project
 * targets v4. Two entry points are emitted on purpose:
 *
 * - `index.html` links `./dist/styles.css`, the file the CLI build produces.
 *   This is what you deploy.
 * - `preview.html` needs no install at all: it loads Tailwind's browser build
 *   and inlines the theme, so unzipping and double-clicking shows the real
 *   result immediately.
 */

/** A file to be written into the project archive. */
export interface ProjectFile {
  /** Path relative to the project root, using forward slashes. */
  path: string;
  content: string;
  /** When true, `content` is a base64 payload to be written as binary. */
  base64?: boolean;
}

/** Tailwind major version the generated project targets. */
export const TAILWIND_MAJOR_VERSION = 4;

/** Pinned range written into the generated `package.json`. */
const TAILWIND_DEPENDENCY_RANGE = '^4.0.0';

/** Tailwind's browser build, used by `preview.html`. */
const TAILWIND_BROWSER_CDN = `https://cdn.jsdelivr.net/npm/@tailwindcss/browser@${TAILWIND_MAJOR_VERSION}`;

/**
 * A slug that is safe to use as an npm package name: lowercase ASCII, no
 * spaces. Falls back to a generic name when the Figma layer name has no ASCII
 * characters to work with (e.g. a purely Persian frame name).
 */
export function toPackageName(name: string): string {
  const ascii = (name || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '');
  if (!ascii) return 'figma-tailwind-export';
  return /^[a-z]/.test(ascii) ? ascii : `figma-${ascii}`;
}

/**
 * The fonts the archive will contain. `result.customFonts` is the sandbox's
 * export payload and therefore authoritative; `options.customFonts` is only a
 * fallback for callers that build a result by hand.
 */
function resolveCustomFonts(result: ConversionResult, options: ConversionOptions): CustomFontData[] {
  if (result.customFonts && result.customFonts.length > 0) return result.customFonts;
  return options.customFonts ?? [];
}

/** One document in the generated project. */
interface ProjectPage {
  name: string;
  /** Tailwind utility markup for the page body. */
  html: string;
  isRtl: boolean;
  /** File name without extension; empty in the single-page layout. */
  slug: string;
}

/** Hands out a unique file name: two frames may both be called "Home". */
function allocateSlug(base: string, taken: Set<string>): string {
  let slug = base;
  let n = 2;
  while (taken.has(slug)) {
    slug = `${base}-${n}`;
    n += 1;
  }
  taken.add(slug);
  return slug;
}

/**
 * The documents the project contains.
 *
 * A multi-frame selection is one project with one HTML page per frame; a single
 * selection keeps the original `index.html` + `preview.html` pair, so its
 * output does not change.
 */
function resolveProjectPages(result: ConversionResult, isRtl: boolean): ProjectPage[] {
  const frames = result.frames && result.frames.length > 1 ? result.frames : null;
  if (!frames) {
    return [{ name: result.nodeName || 'Figma Export', html: result.tailwindHtml, isRtl, slug: '' }];
  }

  const taken = new Set<string>();
  return frames.map((frame) => ({
    name: frame.nodeName || 'Frame',
    html: frame.tailwindHtml,
    isRtl: frame.isRtl,
    slug: allocateSlug(toFileSlug(frame.nodeName, 'frame'), taken),
  }));
}

/**
 * The base layer, mirroring the plugin's CSS reset so the markup behaves the
 * same inside a Tailwind project as it does in the standalone HTML export.
 * Tailwind's preflight already covers the box model, buttons and images; what
 * it does not provide is the page-level flex column and the RTL direction.
 */
function buildBaseLayer(isRtl: boolean): string {
  const fontFamily = isRtl ? FONT_STACK_RTL : FONT_STACK_LTR;
  return `/* Page base — mirrors the exporter's reset so the markup lays out the
   same here as in the standalone HTML export. */
@layer base {
  html, body {
    width: 100%;
    min-height: 100%;
    background: transparent;
    font-family: ${fontFamily};
    -webkit-font-smoothing: antialiased;${isRtl ? '\n    direction: rtl;\n    text-align: right;' : ''}
  }
  body {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
    min-height: 100vh;
  }
}`;
}

/**
 * Everything that has to sit alongside Tailwind's own layers: the theme tokens,
 * the CSS variables they may be referenced by, the font faces and the base
 * layer. Reused verbatim by both `src/input.css` and `preview.html`, so the two
 * entry points can never drift apart.
 *
 * @param customFonts - The fonts the archive will actually contain. Callers
 *   pass `result.customFonts` (the sandbox's export payload) rather than
 *   `options.customFonts`, so the `@font-face` rules always point at files that
 *   are really in the ZIP.
 */
function buildOverridesCss(
  result: ConversionResult,
  options: ConversionOptions,
  isRtl: boolean,
  customFonts: CustomFontData[]
): string {
  const parts: string[] = [];

  const theme = (result.tokensTailwind || '').trim();
  if (theme) {
    parts.push(
      `/* Figma variables and styles, exported as Tailwind v4 theme tokens.\n` +
        `   These generate both the CSS variables and matching utilities. */\n${theme}`
    );
  }

  // The markup may reference variables by their plain CSS name as well as by
  // their `@theme` name, so the raw variable block is kept as a fallback.
  const variables = (result.variablesBlock || '').trim();
  if (variables) {
    parts.push(`/* Raw Figma variables — guarantees every var() reference resolves. */\n${variables}`);
  }

  const fontFaces = generateFontFaceRules({ ...options, customFonts }, true).trim();
  if (fontFaces) {
    parts.push(fontFaces);
  }

  parts.push(buildBaseLayer(isRtl));

  return parts.join('\n\n');
}

/**
 * A single self-contained HTML file that renders one page's Tailwind markup
 * with no build step: Tailwind's browser build plus the inlined theme.
 */
function buildPreviewDocument(
  result: ConversionResult,
  options: ConversionOptions,
  page: ProjectPage,
  inProject: boolean,
  productionFile: string = 'index.html'
): string {
  const overridesCss = buildOverridesCss(result, options, page.isRtl, resolveCustomFonts(result, options));
  const note = inProject
    ? `Zero-install preview: open this file to check the export.\n` +
      `       Ship ${productionFile} instead — it links the built stylesheet.`
    : "Self-contained preview: Tailwind's browser build compiles these\n" +
      '       classes on the fly. For production, use the Tailwind project ZIP.';
  return buildHtmlDocument({
    title: page.name || 'Figma Export',
    body: page.html,
    isRtl: page.isRtl,
    stylesheetHref: null,
    headExtra:
      `  <!-- ${note} -->\n` +
      `  <script src="${TAILWIND_BROWSER_CDN}"></script>\n` +
      `  <style type="text/tailwindcss">\n${overridesCss}\n  </style>`,
  });
}

/**
 * A single self-contained HTML file that renders the result with no build step.
 *
 * @param inProject - When true the file is the archive's `preview.html`, so the
 *   note points at `index.html`; otherwise it is a standalone download.
 */
export function buildTailwindPreviewHtml(
  result: ConversionResult,
  options: ConversionOptions,
  isRtl: boolean,
  inProject: boolean = false
): string {
  return buildPreviewDocument(
    result,
    options,
    { name: result.nodeName || 'Figma Export', html: result.tailwindHtml, isRtl, slug: '' },
    inProject
  );
}

interface HtmlDocumentInput {
  title: string;
  body: string;
  isRtl: boolean;
  /** Extra markup injected at the end of `<head>`. */
  headExtra?: string;
  /** Stylesheet href, or null to omit the link (the preview inlines instead). */
  stylesheetHref: string | null;
}

function buildHtmlDocument({ title, body, isRtl, headExtra, stylesheetHref }: HtmlDocumentInput): string {
  const htmlAttrs = isRtl ? ' lang="fa" dir="rtl"' : ' lang="en"';
  const fontLinks = isRtl
    ? '  <link rel="preconnect" href="https://fonts.googleapis.com">\n' +
      '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n' +
      '  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100..900&display=swap" rel="stylesheet">\n'
    : '';
  const styleLink = stylesheetHref ? `  <link rel="stylesheet" href="${stylesheetHref}">\n` : '';
  const extra = headExtra ? `${headExtra}\n` : '';

  return `<!DOCTYPE html>
<html${htmlAttrs}>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(title)}</title>
${fontLinks}${styleLink}${extra}</head>
<body>
${body}
</body>
</html>
`;
}

function buildPackageJson(packageName: string, title: string): string {
  const pkg = {
    name: packageName,
    version: '1.0.0',
    private: true,
    description: `Tailwind CSS project for "${title}", exported from Figma.`,
    scripts: {
      dev: 'tailwindcss -i ./src/input.css -o ./dist/styles.css --watch',
      build: 'tailwindcss -i ./src/input.css -o ./dist/styles.css --minify',
    },
    devDependencies: {
      '@tailwindcss/cli': TAILWIND_DEPENDENCY_RANGE,
      tailwindcss: TAILWIND_DEPENDENCY_RANGE,
    },
  };
  return `${JSON.stringify(pkg, null, 2)}\n`;
}

function buildReadme(
  title: string,
  hasAssets: boolean,
  hasFonts: boolean,
  pages?: ProjectPage[]
): string {
  const multi = pages !== undefined && pages.length > 1;

  if (multi) {
    const pageList = pages
      .map((page) => `- \`${page.slug}.html\` — ${page.name} (\`preview-${page.slug}.html\` needs no build)`)
      .join('\n');
    return `# ${title}

A Tailwind CSS project exported from Figma by **Pixel-Perfect HTML/CSS Exporter**.

The selection is one project with one Tailwind HTML document per frame — there is
no combined page. Every frame shares the same theme tokens and built stylesheet.

## Pages

${pageList}

## Preview without installing anything

Open any \`preview-<frame>.html\` in a browser. It loads Tailwind's browser build
and inlines the theme, so it renders the real result with no build step. Use it
to check the export; do not ship it.

## Build for production

\`\`\`bash
npm install
npm run build      # writes ./dist/styles.css (minified)
\`\`\`

Then open the frame documents, each of which links \`./dist/styles.css\`.

For a watching dev build:

\`\`\`bash
npm run dev
\`\`\`

Tailwind v4 needs no \`content\` array. The pages to scan are declared with
\`@source\` in \`src/input.css\`, so the build does not depend on automatic
source detection.

## Layout

\`\`\`
<frame>.html          one HTML document per frame (links ./dist/styles.css)
preview-<frame>.html  zero-install preview of one frame (Tailwind browser build)
src/input.css         Tailwind entry: @import "tailwindcss" + @theme tokens
package.json          build scripts and Tailwind dependencies
dist/                 build output (created by npm run build)
${hasAssets ? 'assets/               images and SVGs exported from Figma\n' : ''}${hasFonts ? 'fonts/                web fonts referenced by @font-face\n' : ''}\`\`\`

## Notes

- Each frame is its own HTML file; none of them contains another frame.
- Responsiveness is intrinsic: the markup relies on flexbox (\`flex-wrap\`,
  \`min-width\` floors, proportional \`flex\`) and on fluid \`clamp()\` lengths.
  There are no breakpoint overrides to maintain.
${hasAssets ? '- Images and SVGs are inlined as data URLs in the markup. The `assets/` folder\n  holds the same files if you prefer to reference them by path.\n' : ''}${hasFonts ? '- `@font-face` rules point at `./fonts/`, so keep that folder next to the\n  built stylesheet.\n' : ''}
---

ساخته‌شده با پلاگین **Pixel-Perfect HTML/CSS Exporter**.

برای پیش‌نمایش بدون نصب، یکی از فایل‌های \`preview-<frame>.html\` را باز کنید. برای نسخه‌ی نهایی:

\`\`\`bash
npm install
npm run build
\`\`\`

سپس یکی از فایل‌های HTML فریم‌ها را باز کنید.
`;
  }

  return `# ${title}

A Tailwind CSS project exported from Figma by **Pixel-Perfect HTML/CSS Exporter**.

The markup in \`index.html\` uses Tailwind utility classes only — there is no
hand-written component CSS. Design tokens from Figma (variables, paint/effect/
text styles) are exported as Tailwind v4 \`@theme\` tokens in \`src/input.css\`.

## Preview without installing anything

Open \`preview.html\` in a browser. It loads Tailwind's browser build and inlines
the theme, so it renders the real result with no build step. Use it to check the
export; do not ship it.

## Build for production

\`\`\`bash
npm install
npm run build      # writes ./dist/styles.css (minified)
\`\`\`

Then open \`index.html\`, which links \`./dist/styles.css\`.

For a watching dev build:

\`\`\`bash
npm run dev
\`\`\`

Tailwind v4 needs no \`content\` array. The pages to scan are declared with
\`@source\` in \`src/input.css\`, so the build does not depend on automatic
source detection.

## Layout

\`\`\`
index.html          production page (links ./dist/styles.css)
preview.html        zero-install preview (Tailwind browser build)
src/input.css       Tailwind entry: @import "tailwindcss" + @theme tokens
package.json        build scripts and Tailwind dependencies
dist/               build output (created by npm run build)
${hasAssets ? 'assets/             images and SVGs exported from Figma\n' : ''}${hasFonts ? 'fonts/              web fonts referenced by @font-face\n' : ''}\`\`\`

## Notes

- Responsiveness is intrinsic: the markup relies on flexbox (\`flex-wrap\`,
  \`min-width\` floors, proportional \`flex\`) and on fluid \`clamp()\` lengths.
  There are no breakpoint overrides to maintain.
${hasAssets ? '- Images and SVGs are inlined as data URLs in the markup. The `assets/` folder\n  holds the same files if you prefer to reference them by path.\n' : ''}${hasFonts ? '- `@font-face` rules point at `./fonts/`, so keep that folder next to the\n  built stylesheet.\n' : ''}
---

ساخته‌شده با پلاگین **Pixel-Perfect HTML/CSS Exporter**.

برای پیش‌نمایش بدون نصب، فایل \`preview.html\` را باز کنید. برای نسخه‌ی نهایی:

\`\`\`bash
npm install
npm run build
\`\`\`

سپس \`index.html\` را باز کنید.
`;
}

/**
 * Builds every file of the Tailwind project, including binary assets and fonts.
 *
 * @param result - The conversion result produced by the plugin sandbox
 * @param options - Conversion options (used for custom fonts and RTL fonts)
 * @param isRtl - Whether the markup reads right-to-left
 */
export function buildTailwindProjectFiles(
  result: ConversionResult,
  options: ConversionOptions,
  isRtl: boolean
): ProjectFile[] {
  const files: ProjectFile[] = [];
  const pages = resolveProjectPages(result, isRtl);
  const multi = pages.length > 1;
  const packageName = toPackageName(result.nodeName);
  const title = result.nodeName || 'Figma Export';

  const sharedIsRtl = pages.some((page) => page.isRtl);
  const overridesCss = buildOverridesCss(
    result,
    options,
    sharedIsRtl,
    resolveCustomFonts(result, options)
  );
  const customFonts = resolveCustomFonts(result, options);
  const assets = uniqueAssets(result.assets ?? []);

  // --- Markup -------------------------------------------------------------
  // Images live in `assets/`, so each page points at them instead of carrying
  // the same bytes inline. Previews are the exception: they are meant to be
  // opened on their own, without a build or a folder beside them.
  if (multi) {
    // One HTML document per frame, all linking the same built stylesheet.
    for (const page of pages) {
      files.push({
        path: `${page.slug}.html`,
        content: buildHtmlDocument({
          title: page.name,
          body: referenceAssets(page.html, assets),
          isRtl: page.isRtl,
          stylesheetHref: './dist/styles.css',
        }),
      });
    }
    // Previews stay at the root: the markup points at `./assets/`, and a file
    // in a subfolder would resolve that path differently.
    for (const page of pages) {
      files.push({
        path: `preview-${page.slug}.html`,
        content: buildPreviewDocument(result, options, page, true, `${page.slug}.html`),
      });
    }
  } else {
    files.push({
      path: 'index.html',
      content: buildHtmlDocument({
        title,
        body: referenceAssets(result.tailwindHtml, assets),
        isRtl,
        stylesheetHref: './dist/styles.css',
      }),
    });

    files.push({
      path: 'preview.html',
      content: buildTailwindPreviewHtml(result, options, isRtl, true),
    });
  }

  // --- Build setup --------------------------------------------------------
  // The sources are declared explicitly rather than left to automatic
  // detection: auto-detection respects .gitignore and depends on where the
  // project sits, so a page could silently lose all of its utilities.
  const sources = multi
    ? pages.flatMap((page) => [
        `@source "../${page.slug}.html";`,
        `@source "../preview-${page.slug}.html";`,
      ])
    : ['@source "../index.html";', '@source "../preview.html";'];

  files.push({
    path: 'src/input.css',
    content:
      `@import "tailwindcss";\n\n` +
      `/* The pages to scan for utility classes. Declared explicitly so the build\n` +
      `   never depends on automatic source detection. */\n` +
      `${sources.join('\n')}\n\n` +
      `${overridesCss}\n`,
  });

  files.push({ path: 'package.json', content: buildPackageJson(packageName, title) });

  files.push({
    path: '.gitignore',
    content: 'node_modules/\ndist/\n',
  });

  files.push({
    path: 'README.md',
    content: buildReadme(title, assets.length > 0, customFonts.length > 0, multi ? pages : undefined),
  });

  // --- Fonts --------------------------------------------------------------
  if (customFonts.length > 0) {
    for (const font of customFonts) {
      const rawBase64 = font.base64.includes(',') ? font.base64.split(',')[1] : font.base64;
      if (rawBase64) {
        files.push({ path: `fonts/${font.filename}`, content: rawBase64, base64: true });
      }
    }
  } else {
    files.push({
      path: 'fonts/README.txt',
      content:
        'Place your custom web fonts (.woff2, .woff, .ttf) here.\n' +
        'By default, Persian text falls back to Vazirmatn via the Google Fonts CDN.\n',
    });
  }

  // --- Assets -------------------------------------------------------------
  for (const asset of assets) {
    if (asset.type === 'svg') {
      files.push({ path: `assets/${asset.filename}`, content: asset.content });
    } else if (asset.type === 'image' && asset.content.startsWith('data:image/')) {
      const base64Data = asset.content.split(',')[1];
      if (base64Data) {
        files.push({ path: `assets/${asset.filename}`, content: base64Data, base64: true });
      }
    }
  }

  return files;
}
