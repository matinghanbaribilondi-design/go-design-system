import { describe, it, expect } from "vitest";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import { fileURLToPath } from "url";
import { convertNodeToIR } from "../plugin/converter/index";
import { generateFullHtmlDocument } from "./html-generator";
import { generateCss } from "./css-generator";

// The Figma fixture is vendored next to this test so the suite is portable —
// it used to be read from an absolute path outside the repository.
const HERE = path.dirname(fileURLToPath(import.meta.url));
const FIXTURE_PATH = path.join(HERE, "__fixtures__", "parsed_figma_nodes_new.json");

function buildSceneNode(nodeData: any, parent: any = null): any {
  const isText = nodeData.type === "TEXT";
  const styles = nodeData.styles || {};
  const width = parseFloat(styles.width) || 100;
  const height = styles.height !== undefined ? parseFloat(styles.height) : (nodeData.name === "Line" ? 0 : 100);
  
  const sn: any = {
    id: nodeData.id,
    name: nodeData.name || "Layer",
    type: nodeData.type,
    visible: true,
    width,
    height,
    x: 0,
    y: 0,
    parent,
    exportAsync: () => Promise.resolve("<svg></svg>"),
    children: []
  };

  if (styles.border) {
    const strokeMatch = styles.border.match(/^([\d.]+)px\s+solid\s+(#?[a-fA-F0-9]+)/);
    if (strokeMatch) {
      sn.strokeWeight = parseFloat(strokeMatch[1]);
      sn.strokes = [{ type: "SOLID", color: { r: 217 / 255, g: 228 / 255, b: 241 / 255 } }];
    }
  }

  if (styles.display === "flex") {
    sn.layoutMode = styles.flexDirection === "column" ? "VERTICAL" : "HORIZONTAL";
    sn.primaryAxisAlignItems = styles.justifyContent === "flex-end" ? "MAX" : (styles.justifyContent === "center" ? "CENTER" : (styles.justifyContent === "space-between" ? "SPACE_BETWEEN" : "MIN"));
    sn.counterAxisAlignItems = styles.alignItems === "flex-end" ? "MAX" : (styles.alignItems === "center" ? "CENTER" : "MIN");
    sn.itemSpacing = parseFloat(styles.gap) || 0;
    if (styles.padding) {
      const parts = styles.padding.split(" ").map((p: string) => parseFloat(p) || 0);
      if (parts.length === 4) {
        sn.paddingTop = parts[0];
        sn.paddingRight = parts[1];
        sn.paddingBottom = parts[2];
        sn.paddingLeft = parts[3];
      } else if (parts.length === 2) {
        sn.paddingTop = parts[0];
        sn.paddingBottom = parts[0];
        sn.paddingRight = parts[1];
        sn.paddingLeft = parts[1];
      }
    }
  } else {
    sn.layoutMode = "NONE";
  }

  // Sizing
  if (parent && parent.layoutMode) {
    sn.layoutSizingHorizontal = "HUG";
    sn.layoutSizingVertical = "HUG";
    if (styles.width && !isText && (Math.abs(width - 221) < 2 || width > 200)) {
      sn.layoutSizingHorizontal = "FILL";
      if (nodeData.name !== "Line") {
        sn.layoutGrow = 1;
      }
    }
  }

  if (nodeData.name === "Priority" || (nodeData.id && String(nodeData.id).includes("24024"))) {
    sn.layoutPositioning = "ABSOLUTE";
    sn.x = 228;
    sn.y = -3;
    sn.constraints = { horizontal: "MAX", vertical: "MIN" };
  }

  if (isText) {
    sn.characters = nodeData.text || nodeData.name || "";
    sn.fontSize = parseFloat(styles.fontSize) || 14;
    sn.fontName = { family: styles.fontFamily || "IRANYekanXVF", style: "Regular" };
    sn.textAlignHorizontal = styles.textAlign === "right" ? "RIGHT" : (styles.textAlign === "center" ? "CENTER" : "LEFT");
    sn.textAutoResize = "NONE";
    sn.layoutSizingHorizontal = "FIXED";
  }

  if (nodeData.children) {
    sn.children = nodeData.children.map((c: any) => buildSceneNode(c, sn));
  }

  return sn;
}

describe("Convert Tasks Card", () => {
  it("converts Top node and Line divider correctly", async () => {
    const raw = fs.readFileSync(FIXTURE_PATH, "utf8");
    const data = JSON.parse(raw);
    const rootNodeData = data.nodes[0];
    const mockTree = buildSceneNode(rootNodeData);

    const options = {
      outputMode: "pure-css" as const,
      useRem: false,
      baseFontSize: 16,
      includeReset: true,
      inlineAssets: true,
      semanticTags: true
    };

    const irRoot = (await convertNodeToIR(mockTree as any, null, options))!;
    const css = generateCss(irRoot, options);
    const fullHtml = generateFullHtmlDocument(irRoot, options);
    // Best-effort artifact dump for manual inspection; never fail the test on a
    // read-only or sandboxed filesystem, and never write into the repository.
    try {
      fs.writeFileSync(path.join(os.tmpdir(), "tasks_card.html"), fullHtml);
    } catch {
      /* ignore */
    }
    
    // Find Top IR node
    const topIr = irRoot.children[0]!;
    const priorityIr = topIr.children.find((c: any) => c.name === "Priority")!;

    expect(topIr.layout.position).toBe("relative");
    expect(priorityIr).toBeDefined();
    expect(priorityIr.layout.position).toBe("absolute");
    expect(priorityIr.layout.right).toBe("-15px");
    expect(priorityIr.layout.top).toBe("-3px");

    // Find Line divider IR node inside Content
    const contentIr = irRoot.children[1]!;
    const lineIr = contentIr.children.find((c: any) => c.name === "Line")!;
    expect(lineIr).toBeDefined();
    expect(lineIr.visual.borderTop).toBe("1px solid #d9e4f1");
    expect(lineIr.visual.border).toBeUndefined();
    expect(lineIr.asset).toBeUndefined(); // Must NOT be an SVG asset!
    expect(css).toContain("border-top: 1px solid #d9e4f1;");

    // Verify Avatar in Info -> Assignee
    const infoIr = contentIr.children.find((c: any) => c.name.startsWith("Info"))!;
    expect(infoIr).toBeDefined();
    const assigneeIr = infoIr.children.find((c: any) => c.name === "Assignee")!;
    expect(assigneeIr).toBeDefined();
    const avatarIr = assigneeIr.children[0]!;
    expect(avatarIr).toBeDefined();
    expect(avatarIr.layout.width).toBe("24px");
    expect(avatarIr.layout.height).toBe("24px");
    expect(avatarIr.layout.aspectRatio).toBe("1 / 1");
    expect(avatarIr.layout.alignSelf).toBeUndefined();
    expect(css).toContain("aspect-ratio: 1 / 1;");
  });
});
