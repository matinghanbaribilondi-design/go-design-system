import { describe, it, expect } from 'vitest';
import {
  buildTailwindProjectFiles,
  buildTailwindPreviewHtml,
  toPackageName,
  TAILWIND_MAJOR_VERSION,
} from './tailwind-project';
import type { ConversionOptions, ConversionResult } from '../plugin/types/ir';

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
};

function makeResult(over: Partial<ConversionResult> = {}): ConversionResult {
  return {
    nodeName: 'Pricing Card',
    width: 1200,
    height: 800,
    html: '<div class="pricing-card"></div>',
    css: '.pricing-card { display: flex; }',
    combinedHtml: '<!DOCTYPE html><html><body></body></html>',
    tailwindHtml: '<div class="flex flex-col gap-[clamp(21px,_2.67vw,_32px)]">Hello</div>',
    assets: [],
    ...over,
  };
}

const fileAt = (files: ReturnType<typeof buildTailwindProjectFiles>, path: string) =>
  files.find((f) => f.path === path);

describe('toPackageName', () => {
  it('lowercases and hyphenates a normal layer name', () => {
    expect(toPackageName('Pricing Card')).toBe('pricing-card');
    expect(toPackageName('Hero / Section 2')).toBe('hero-section-2');
  });

  it('falls back to a generic name when there is nothing ASCII to work with', () => {
    expect(toPackageName('کارت قیمت‌گذاری')).toBe('figma-tailwind-export');
    expect(toPackageName('')).toBe('figma-tailwind-export');
  });

  it('prefixes a name that would otherwise start with a digit', () => {
    expect(toPackageName('2 column grid')).toBe('figma-2-column-grid');
  });
});

describe('buildTailwindProjectFiles', () => {
  it('produces a complete project skeleton', () => {
    const files = buildTailwindProjectFiles(makeResult(), options, false);
    const paths = files.map((f) => f.path).sort();
    expect(paths).toEqual([
      '.gitignore',
      'README.md',
      'fonts/README.txt',
      'index.html',
      'package.json',
      'preview.html',
      'src/input.css',
    ]);
  });

  it('links the built stylesheet from index.html and keeps the utility markup', () => {
    const files = buildTailwindProjectFiles(makeResult(), options, false);
    const html = fileAt(files, 'index.html')!.content;
    expect(html).toContain('<link rel="stylesheet" href="./dist/styles.css">');
    expect(html).toContain('class="flex flex-col gap-[clamp(21px,_2.67vw,_32px)]"');
    // The HTML/CSS flavour must not leak in.
    expect(html).not.toContain('style.css');
    expect(html).not.toContain('.pricing-card');
  });

  it('ships a zero-install preview that needs no build', () => {
    const files = buildTailwindProjectFiles(makeResult(), options, false);
    const preview = fileAt(files, 'preview.html')!.content;
    expect(preview).toContain(`https://cdn.jsdelivr.net/npm/@tailwindcss/browser@${TAILWIND_MAJOR_VERSION}`);
    expect(preview).toContain('<style type="text/tailwindcss">');
    // The preview must not depend on a file the user has to build first.
    expect(preview).not.toContain('dist/styles.css');
  });

  it('writes a Tailwind v4 entry stylesheet importing the framework', () => {
    const files = buildTailwindProjectFiles(makeResult(), options, false);
    const css = fileAt(files, 'src/input.css')!.content;
    expect(css.startsWith('@import "tailwindcss";')).toBe(true);
    // Sources are declared explicitly so the build never relies on automatic
    // detection (which respects .gitignore and can silently find nothing).
    expect(css).toContain('@source "../index.html";');
    expect(css).toContain('@source "../preview.html";');
    expect(css).toContain('@layer base');
  });

  it('carries the Figma theme tokens and raw variables into the entry stylesheet', () => {
    const files = buildTailwindProjectFiles(
      makeResult({
        tokensTailwind: '@theme {\n  --color-brand: #2563eb;\n}',
        variablesBlock: ':root {\n  --brand: #2563eb;\n}',
      }),
      options,
      false
    );
    const css = fileAt(files, 'src/input.css')!.content;
    expect(css).toContain('@theme {');
    expect(css).toContain('--color-brand: #2563eb;');
    expect(css).toContain(':root {');
    expect(css).toContain('--brand: #2563eb;');
  });

  it('omits the theme block entirely when no tokens were collected', () => {
    const files = buildTailwindProjectFiles(makeResult(), options, false);
    const css = fileAt(files, 'src/input.css')!.content;
    expect(css).not.toContain('@theme {');
    expect(css).toContain('@import "tailwindcss";');
  });

  it('writes buildable scripts and Tailwind v4 dependencies', () => {
    const files = buildTailwindProjectFiles(makeResult(), options, false);
    const pkg = JSON.parse(fileAt(files, 'package.json')!.content);
    expect(pkg.name).toBe('pricing-card');
    expect(pkg.private).toBe(true);
    expect(pkg.scripts.build).toContain('tailwindcss -i ./src/input.css -o ./dist/styles.css');
    expect(pkg.scripts.dev).toContain('--watch');
    expect(pkg.devDependencies['@tailwindcss/cli']).toBeDefined();
    expect(pkg.devDependencies.tailwindcss).toBeDefined();
  });

  it('sets RTL direction on the document and in the base layer', () => {
    const files = buildTailwindProjectFiles(makeResult(), options, true);
    const html = fileAt(files, 'index.html')!.content;
    expect(html).toContain('lang="fa" dir="rtl"');
    expect(html).toContain('Vazirmatn');
    const css = fileAt(files, 'src/input.css')!.content;
    expect(css).toContain('direction: rtl;');
  });

  it('leaves LTR output free of RTL markers', () => {
    const files = buildTailwindProjectFiles(makeResult(), options, false);
    const html = fileAt(files, 'index.html')!.content;
    expect(html).toContain('lang="en"');
    expect(html).not.toContain('dir="rtl"');
    expect(fileAt(files, 'src/input.css')!.content).not.toContain('direction: rtl;');
  });

  it('stores custom fonts as binary and points @font-face at them', () => {
    const files = buildTailwindProjectFiles(
      makeResult({
        customFonts: [
          {
            id: 'f1',
            family: 'IRANYekanX',
            style: 'Regular',
            weight: 400,
            format: 'woff2',
            base64: 'data:font/woff2;base64,AAAA',
            filename: 'IRANYekanX.woff2',
          },
        ],
      }),
      options,
      true
    );
    const font = fileAt(files, 'fonts/IRANYekanX.woff2')!;
    expect(font.base64).toBe(true);
    expect(font.content).toBe('AAAA');
    const css = fileAt(files, 'src/input.css')!.content;
    expect(css).toContain("@font-face");
    expect(css).toContain("url('./fonts/IRANYekanX.woff2')");
  });

  it('splits assets into text SVGs and binary images', () => {
    const files = buildTailwindProjectFiles(
      makeResult({
        assets: [
          { filename: 'logo.svg', content: '<svg></svg>', type: 'svg' },
          { filename: 'photo.png', content: 'data:image/png;base64,BBBB', type: 'image' },
        ],
      }),
      options,
      false
    );
    expect(fileAt(files, 'assets/logo.svg')).toMatchObject({ content: '<svg></svg>' });
    expect(fileAt(files, 'assets/logo.svg')!.base64).toBeUndefined();
    expect(fileAt(files, 'assets/photo.png')).toMatchObject({ content: 'BBBB', base64: true });
  });

  it('escapes the layer name in the document title', () => {
    const files = buildTailwindProjectFiles(makeResult({ nodeName: 'A <b>& B' }), options, false);
    expect(fileAt(files, 'index.html')!.content).toContain('<title>A &lt;b&gt;&amp; B</title>');
  });

  it('points the page at assets/ instead of carrying the bytes twice', () => {
    const dataUrl = 'data:image/png;base64,iVBORw0KGgo=';
    const files = buildTailwindProjectFiles(
      makeResult({
        tailwindHtml: `<div><img class="block" src="${dataUrl}" alt="Logo" /></div>`,
        assets: [{ filename: 'logo.png', content: dataUrl, type: 'image' }],
      }),
      options,
      false
    );

    const html = fileAt(files, 'index.html')!.content;
    expect(html).toContain('src="./assets/logo.png"');
    expect(html).not.toContain('base64,iVBORw0KGgo=');
  });

  it('writes one file for a payload used by two layers', () => {
    const dataUrl = 'data:image/png;base64,iVBORw0KGgo=';
    const files = buildTailwindProjectFiles(
      makeResult({
        tailwindHtml: `<img src="${dataUrl}"><img src="${dataUrl}">`,
        assets: [
          { filename: 'logo.png', content: dataUrl, type: 'image' },
          { filename: 'logo.png', content: dataUrl, type: 'image' },
        ],
      }),
      options,
      false
    );

    expect(files.filter((f) => f.path.startsWith('assets/'))).toHaveLength(1);
  });

  it('writes one Tailwind page per frame in a multi-frame project', () => {
    const frame = (over: Record<string, unknown> = {}) => ({
      nodeName: 'Home',
      width: 1440,
      height: 900,
      isRtl: false,
      html: '<main class="home">Home</main>',
      combinedHtml: '<!DOCTYPE html><html><body><main class="home">Home</main></body></html>',
      tailwindHtml: '<main class="flex">Home</main>',
      ...over,
    });

    const files = buildTailwindProjectFiles(
      makeResult({
        nodeName: '2 frames',
        frames: [
          frame(),
          frame({ nodeName: 'Pricing', tailwindHtml: '<main class="grid">Pricing</main>' }),
        ],
      }),
      options,
      false
    );

    const paths = files.map((f) => f.path);
    expect(paths).toContain('home.html');
    expect(paths).toContain('pricing.html');
    expect(paths).toContain('preview-home.html');
    expect(paths).toContain('preview-pricing.html');
    expect(paths).not.toContain('index.html');
    expect(paths).not.toContain('preview.html');

    const home = fileAt(files, 'home.html')!.content;
    const pricing = fileAt(files, 'pricing.html')!.content;
    expect(home).toContain('<link rel="stylesheet" href="./dist/styles.css">');
    expect(home).toContain('class="flex"');
    expect(home).not.toContain('Pricing');
    expect(pricing).toContain('class="grid"');
    expect(pricing).not.toContain('>Home<');

    const preview = fileAt(files, 'preview-home.html')!.content;
    expect(preview).toContain('@tailwindcss/browser');
    expect(preview).toContain('Home');
    expect(preview).not.toContain('Pricing');

    const css = fileAt(files, 'src/input.css')!.content;
    expect(css).toContain('@source "../home.html";');
    expect(css).toContain('@source "../preview-home.html";');
    expect(css).toContain('@source "../pricing.html";');
    expect(css).toContain('@source "../preview-pricing.html";');
  });
});

describe('buildTailwindPreviewHtml', () => {
  it('returns a single self-contained document', () => {
    const html = buildTailwindPreviewHtml(makeResult(), options, false);
    expect(html.startsWith('<!DOCTYPE html>')).toBe(true);
    expect(html).toContain('@tailwindcss/browser');
    expect(html).toContain('class="flex flex-col gap-[clamp(21px,_2.67vw,_32px)]"');
  });
});
