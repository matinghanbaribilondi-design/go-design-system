import { IRNode } from '../plugin/types/ir';
import { escapeHtml, segmentToInlineStyle } from '../shared/style-utils';
import {
  formatTextContent,
  generateParagraphHtml,
  anchorHtml,
  htmlAttrs,
  PHRASING_TAGS,
  HtmlGenerationOptions,
} from './html-generator';

export type { HtmlGenerationOptions };

/**
 * Escapes characters for Tailwind arbitrary value brackets
 */
function toTwVal(val: string): string {
  return val.replace(/\s+/g, '_');
}

/**
 * Converts IRNode properties to a list of Tailwind CSS classes
 */
export function nodeToTailwindClasses(node: IRNode): string[] {
  const classes: string[] = [];
  const { layout, visual, typography } = node;

  // 1. Layout
  if (layout.marginInline === 'auto' || layout.margin === '0 auto') {
    classes.push('mx-auto');
  }
  if (layout.margin) classes.push(`m-[${toTwVal(layout.margin)}]`);
  if (layout.marginInline && layout.marginInline !== 'auto') {
    classes.push(`mx-[${toTwVal(layout.marginInline)}]`);
  }
  if (layout.marginLeft !== undefined) classes.push(`ml-[${toTwVal(layout.marginLeft)}]`);
  if (layout.marginRight !== undefined) classes.push(`mr-[${toTwVal(layout.marginRight)}]`);
  if (layout.marginTop !== undefined) classes.push(`mt-[${toTwVal(layout.marginTop)}]`);
  if (layout.marginBottom !== undefined) classes.push(`mb-[${toTwVal(layout.marginBottom)}]`);

  if (layout.boxSizing) classes.push(`[box-sizing:${toTwVal(layout.boxSizing)}]`);

  if (layout.display === 'flex') {
    classes.push('flex');
    if (layout.flexDirection === 'column') {
      classes.push('flex-col');
    } else if (layout.flexDirection === 'row') {
      classes.push('flex-row');
    }

    if (layout.flexWrap === 'wrap') classes.push('flex-wrap');

    // Justify
    if (layout.justifyContent === 'center') classes.push('justify-center');
    else if (layout.justifyContent === 'flex-end') classes.push('justify-end');
    else if (layout.justifyContent === 'space-between') classes.push('justify-between');
    else if (layout.justifyContent === 'space-around') classes.push('justify-around');
    else if (layout.justifyContent === 'flex-start') classes.push('justify-start');

    // Align Items
    if (layout.alignItems === 'center') classes.push('items-center');
    else if (layout.alignItems === 'flex-end') classes.push('items-end');
    else if (layout.alignItems === 'flex-start') classes.push('items-start');
    else if (layout.alignItems === 'stretch') classes.push('items-stretch');
    else if (layout.alignItems === 'baseline') classes.push('items-baseline');

    // Gap
    if (layout.gap) {
      classes.push(`gap-[${toTwVal(layout.gap)}]`);
    }
    if (layout.rowGap) classes.push(`gap-y-[${toTwVal(layout.rowGap)}]`);
    if (layout.columnGap) classes.push(`gap-x-[${toTwVal(layout.columnGap)}]`);
    if (layout.itemSpacing && layout.itemSpacing < 0) {
      const absVal = Math.abs(Math.round(layout.itemSpacing * 100) / 100);
      if (layout.flexDirection === 'column') {
        classes.push(`-space-y-[${absVal}px]`);
      } else {
        classes.push(`-space-x-[${absVal}px]`);
      }
    }

    // Direction
    if (layout.direction === 'ltr') classes.push('[direction:ltr]');
    else if (layout.direction === 'rtl') classes.push('[direction:rtl]');
  } else if (layout.display === 'grid') {
    classes.push('grid');
  } else if (layout.display === 'block') {
    classes.push('block');
  } else if (layout.display === 'inline-block') {
    classes.push('inline-block');
  }

  // Grid tracks and cell placement. A grid frame carries its own track list;
  // emitting only `grid` would collapse it to a single implicit column, which
  // is the same silent rewrite as flattening it into a flex row.
  if (layout.gridTemplateColumns) classes.push(`grid-cols-[${toTwVal(layout.gridTemplateColumns)}]`);
  if (layout.gridTemplateRows) classes.push(`grid-rows-[${toTwVal(layout.gridTemplateRows)}]`);
  if (layout.gridColumn) classes.push(`col-[${toTwVal(layout.gridColumn)}]`);
  if (layout.gridRow) classes.push(`row-[${toTwVal(layout.gridRow)}]`);
  // Per-axis gaps live outside the flex branch: a grid has two of them and no
  // shorthand `gap` in the IR, so they would otherwise never reach the markup.
  if (layout.display === 'grid') {
    if (layout.rowGap) classes.push(`gap-y-[${toTwVal(layout.rowGap)}]`);
    if (layout.columnGap) classes.push(`gap-x-[${toTwVal(layout.columnGap)}]`);
  }

  // Smart stacking. A regions row (a rail beside a body) is its own inline-size
  // query container, and each region fills its line once the row is too narrow
  // to hold them side by side. `@max-[…]` is Tailwind v4's max-width container
  // query variant, so this needs no breakpoint and no custom CSS.
  if (layout.containerType === 'inline-size') classes.push('@container');
  if (layout.stackFill) {
    const stacked = `@max-[${toTwVal(layout.stackFill.maxInlineSize)}]`;
    classes.push(`${stacked}:basis-full`, `${stacked}:max-w-full`);
  }

  if (node.tag === 'img') {
    classes.push(layout.objectFit ? `object-${layout.objectFit}` : 'object-cover', 'block');
  }
  if (node.tag === 'input' || node.tag === 'textarea') {
    // Strip the browser's own chrome; the design's box is the control's box.
    classes.push('appearance-none');
  }

  if (layout.aspectRatio) {
    if (layout.aspectRatio === '1 / 1' || layout.aspectRatio === '1/1') {
      classes.push('aspect-square');
    } else {
      classes.push(`aspect-[${toTwVal(layout.aspectRatio)}]`);
    }
  }

  // Padding. A value is either a raw px number or a fluid CSS string; the
  // arbitrary-value bracket takes the length as-is either way.
  if (layout.padding) {
    const { top, right, bottom, left } = layout.padding;
    const pad = (v: number | string) => (typeof v === 'string' ? toTwVal(v) : `${v}px`);
    const present = (v: number | string) => (typeof v === 'string' ? v.length > 0 : v > 0);
    if (top === bottom && right === left && top === right && present(top)) {
      classes.push(`p-[${pad(top)}]`);
    } else if (top === bottom && right === left) {
      if (present(right)) classes.push(`px-[${pad(right)}]`);
      if (present(top)) classes.push(`py-[${pad(top)}]`);
    } else {
      if (present(top)) classes.push(`pt-[${pad(top)}]`);
      if (present(right)) classes.push(`pr-[${pad(right)}]`);
      if (present(bottom)) classes.push(`pb-[${pad(bottom)}]`);
      if (present(left)) classes.push(`pl-[${pad(left)}]`);
    }
  }

  //positioning
  if (layout.position === 'absolute') {
    classes.push('absolute');
  } else if (layout.position === 'relative') {
    classes.push('relative');
  }
  if (layout.left !== undefined) classes.push(`left-[${toTwVal(layout.left)}]`);
  if (layout.top !== undefined) classes.push(`top-[${toTwVal(layout.top)}]`);
  if (layout.right !== undefined) classes.push(`right-[${toTwVal(layout.right)}]`);
  if (layout.bottom !== undefined) classes.push(`bottom-[${toTwVal(layout.bottom)}]`);

  if (layout.zIndex !== undefined) classes.push(`z-[${layout.zIndex}]`);

  // Dimensions
  if (layout.width === '100%') {
    classes.push('w-full');
  } else if (layout.width === 'fit-content') {
    classes.push('w-fit');
  } else if (layout.width) {
    classes.push(`w-[${toTwVal(layout.width)}]`);
  }

  if (layout.height === '100%') classes.push('h-full');
  else if (layout.height === 'auto') classes.push('h-auto');
  else if (layout.height === 'fit-content') classes.push('h-fit');
  else if (layout.height) classes.push(`h-[${toTwVal(layout.height)}]`);

  if (layout.minWidth) classes.push(`min-w-[${toTwVal(layout.minWidth)}]`);

  if (layout.maxWidth === '100%') classes.push('max-w-full');
  else if (layout.maxWidth) classes.push(`max-w-[${toTwVal(layout.maxWidth)}]`);

  if (layout.minHeight) classes.push(`min-h-[${toTwVal(layout.minHeight)}]`);

  if (layout.maxHeight === '100%') classes.push('max-h-full');
  else if (layout.maxHeight) classes.push(`max-h-[${toTwVal(layout.maxHeight)}]`);

  // Flex grow, shrink, basis & self
  if (layout.flexGrow) classes.push('grow');
  if (layout.flexShrink === 0) classes.push('shrink-0');
  else if (layout.flexShrink === 1 && !layout.flexGrow) classes.push('shrink');
  if (layout.flexBasis && layout.flexBasis !== 'auto') classes.push(`basis-[${toTwVal(layout.flexBasis)}]`);
  if (layout.alignSelf === 'stretch') classes.push('self-stretch');
  else if (layout.alignSelf === 'center') classes.push('self-center');
  else if (layout.alignSelf === 'flex-start') classes.push('self-start');
  else if (layout.alignSelf === 'flex-end') classes.push('self-end');
  else if (layout.alignSelf === 'baseline') classes.push('self-baseline');
  else if (layout.alignSelf === 'auto') classes.push('self-auto');

  // Overflow
  if (layout.overflow === 'hidden') classes.push('overflow-hidden');
  else if (layout.overflow === 'auto') classes.push('overflow-auto');
  else if (layout.overflow === 'visible') classes.push('overflow-visible');

  // 2. Visual Styles
  if (visual.background) {
    if (visual.background === 'transparent') classes.push('bg-transparent');
    else if (visual.background.startsWith('var(')) classes.push(`bg-[${toTwVal(visual.background)}]`);
    else if (visual.background.startsWith('linear-gradient') || visual.background.startsWith('radial-gradient'))
      classes.push(`bg-[${toTwVal(visual.background)}]`);
    else classes.push(`bg-[${toTwVal(visual.background)}]`);
  }
  if (visual.borderRadius) {
    if (visual.borderRadius === '50%' || visual.borderRadius === '9999px') {
      classes.push('rounded-full');
    } else if (visual.borderRadius === '0px') {
      classes.push('rounded-none');
    } else {
      classes.push(`rounded-[${toTwVal(visual.borderRadius)}]`);
    }
  }
  // Background layers. Without these a card image loses `cover` / `no-repeat`
  // and tiles instead of filling its box.
  if (visual.backgroundSize) classes.push(`bg-[length:${toTwVal(visual.backgroundSize)}]`);
  if (visual.backgroundRepeat) classes.push(`bg-[repeat:${toTwVal(visual.backgroundRepeat)}]`);
  if (visual.backgroundPosition) classes.push(`bg-[position:${toTwVal(visual.backgroundPosition)}]`);
  if (visual.boxSizing) classes.push(`[box-sizing:${toTwVal(visual.boxSizing)}]`);
  if (visual.border) {
    if (visual.border === 'none') classes.push('border-0');
    else classes.push(`border-[${toTwVal(visual.border)}]`);
  }
  if (visual.outline) {
    classes.push(`outline-[${toTwVal(visual.outline)}]`);
  }
  if (visual.outlineOffset) {
    classes.push(`outline-offset-[${toTwVal(visual.outlineOffset)}]`);
  }
  // Individual borders (grid of per-side weights)
  if (visual.borderTop) classes.push(`border-t-[${toTwVal(visual.borderTop)}]`);
  if (visual.borderRight) classes.push(`border-r-[${toTwVal(visual.borderRight)}]`);
  if (visual.borderBottom) classes.push(`border-b-[${toTwVal(visual.borderBottom)}]`);
  if (visual.borderLeft) classes.push(`border-l-[${toTwVal(visual.borderLeft)}]`);
  if (visual.boxShadow) {
    classes.push(`shadow-[${toTwVal(visual.boxShadow)}]`);
  }
  // A shadow on type is `text-shadow`, not `shadow-*`: Figma draws it from the
  // glyphs, so a box shadow would put a rectangle around the text block.
  if (visual.textShadow) classes.push(`[text-shadow:${toTwVal(visual.textShadow)}]`);
  if (visual.opacity !== undefined && visual.opacity < 1) {
    classes.push(`opacity-[${visual.opacity}]`);
  }
  if (visual.filter) classes.push(`[filter:${toTwVal(visual.filter)}]`);
  if (visual.backdropFilter) classes.push(`[backdrop-filter:${toTwVal(visual.backdropFilter)}]`);
  if (visual.mixBlendMode) classes.push(`[mix-blend-mode:${toTwVal(visual.mixBlendMode)}]`);
  if (visual.isolation) classes.push('isolate');
  if (visual.clipPath) classes.push(`[clip-path:${toTwVal(visual.clipPath)}]`);

  // A gradient stroke. The CSS export draws it as a masked ring on `::after`
  // (see `gradientBorderRule`) because `border-image` ignores `border-radius`;
  // these are the same declarations as `after:` variants, so both outputs keep
  // the corners of the shape they were drawn on.
  if (visual.gradientBorder) {
    const ring = visual.gradientBorder;
    if (!layout.position) classes.push('relative');
    classes.push(
      "after:content-['']",
      'after:absolute',
      'after:inset-0',
      'after:box-border',
      'after:rounded-[inherit]',
      'after:pointer-events-none',
      `after:p-[${toTwVal(ring.width)}]`,
      `after:[background:${toTwVal(ring.image)}]`,
      'after:[mask:linear-gradient(#000_0_0)_content-box,linear-gradient(#000_0_0)]',
      'after:[mask-composite:exclude]'
    );
  }

  // Transform. A node can carry two of them — the layout's centering translate
  // and the layer's own rotation — and both have to survive, exactly as the CSS
  // export merges them. Emitting only `visual.transform` dropped the centering.
  const transform = [layout.transform, visual.transform].filter(Boolean).join(' ');
  if (transform === 'translate(-50%, -50%)') {
    classes.push('-translate-x-1/2', '-translate-y-1/2');
  } else if (transform === 'translateX(-50%)') {
    classes.push('-translate-x-1/2');
  } else if (transform === 'translateY(-50%)') {
    classes.push('-translate-y-1/2');
  } else if (transform) {
    classes.push(`[transform:${toTwVal(transform)}]`);
  }

  // 3. Typography
  if (typography) {
    if (typography.fontFamily) {
      classes.push(`[font-family:${toTwVal(typography.fontFamily)}]`);
    }
    if (typography.fontSize) {
      classes.push(`text-[${toTwVal(typography.fontSize)}]`);
    }
    if (typography.color) classes.push(`text-[${toTwVal(typography.color)}]`);
    if (typography.fontStyle === 'italic') classes.push('italic');
    else if (typography.fontStyle === 'normal') classes.push('not-italic');
    // `tabular-nums` is the utility for `font-variant-numeric: tabular-nums`;
    // any other value has no named utility and is written out in full.
    if (typography.fontVariantNumeric === 'tabular-nums') classes.push('tabular-nums');
    else if (typography.fontVariantNumeric) {
      classes.push(`[font-variant-numeric:${toTwVal(typography.fontVariantNumeric)}]`);
    }
    if (typography.lineHeight && typography.lineHeight !== 'normal') {
      classes.push(`leading-[${toTwVal(typography.lineHeight)}]`);
    }
    if (typography.letterSpacing && typography.letterSpacing !== 'normal') {
      classes.push(`tracking-[${toTwVal(typography.letterSpacing)}]`);
    }
    if (typography.textAlign === 'center') classes.push('text-center');
    else if (typography.textAlign === 'right') classes.push('text-right');
    else if (typography.textAlign === 'justify') classes.push('text-justify');
    else if (typography.textAlign === 'left') classes.push('text-left');

    // Font weight
    if (typography.fontWeight) {
      const w = typography.fontWeight;
      if (w === 100) classes.push('font-thin');
      else if (w === 200) classes.push('font-extralight');
      else if (w === 300) classes.push('font-light');
      else if (w === 400) classes.push('font-normal');
      else if (w === 500) classes.push('font-medium');
      else if (w === 600) classes.push('font-semibold');
      else if (w === 700) classes.push('font-bold');
      else if (w === 800) classes.push('font-extrabold');
      else if (w === 900) classes.push('font-black');
      else classes.push(`font-[${w}]`);
    }

    if (typography.textDecoration === 'underline') classes.push('underline');
    else if (typography.textDecoration === 'line-through') classes.push('line-through');

    if (typography.textTransform === 'uppercase') classes.push('uppercase');
    else if (typography.textTransform === 'lowercase') classes.push('lowercase');
    else if (typography.textTransform === 'capitalize') classes.push('capitalize');

    if (typography.direction === 'rtl') {
      classes.push('[direction:rtl]');
      classes.push('[unicode-bidi:isolate]');
    } else if (typography.direction === 'ltr') {
      classes.push('[direction:ltr]');
      classes.push('[unicode-bidi:isolate]');
    }

    if (typography.whiteSpace === 'nowrap') classes.push('whitespace-nowrap');
    else if (typography.whiteSpace === 'pre-line') classes.push('whitespace-pre-line');
    else if (typography.whiteSpace === 'pre-wrap') classes.push('whitespace-pre-wrap');
    if (typography.overflowWrap === 'break-word') classes.push('break-words');
    else if (typography.overflowWrap === 'anywhere') classes.push('[overflow-wrap:anywhere]');
    if (typography.wordBreak) classes.push(`[word-break:${toTwVal(typography.wordBreak)}]`);
    if (typography.textOverflow === 'ellipsis') classes.push('text-ellipsis');
    else if (typography.textOverflow === 'clip') classes.push('text-clip');
    else if (typography.textOverflow) classes.push(`[text-overflow:${toTwVal(typography.textOverflow)}]`);

    // Truncation. The CSS export clamps to N lines with the legacy flexbox
    // properties; Tailwind's `line-clamp-*` is the same mechanism, and without
    // it every line the designer cut off shows up and the box grows.
    if (typography.webkitLineClamp !== undefined) {
      classes.push(`line-clamp-${typography.webkitLineClamp}`);
    }
    if (typography.webkitBoxOrient) {
      classes.push(`[box-orient:${toTwVal(typography.webkitBoxOrient)}]`);
    }
    if (typography.display) classes.push(`[display:${toTwVal(typography.display)}]`);
    if (typography.overflow) classes.push(`[overflow:${toTwVal(typography.overflow)}]`);

    // A list is emitted as `list-style: none` + a flex column in the CSS export,
    // so its bullets come from `::before` — which utilities cannot express. The
    // Tailwind markup keeps the bullet character in the text instead (see
    // `generateTailwindHtml`), so the column and its gap are all that is left.
    if (typography.isList) {
      classes.push('list-none', 'flex', 'flex-col');
      if (typography.listGap) classes.push(`gap-[${toTwVal(typography.listGap)}]`);
    }
  }

  return classes;
}

/**
 * `data-figma-id="1:42"`, or nothing when the option is off. Same rule as the
 * HTML export: the id is already on the node, the emitter was dropping it, and
 * a pixel diff cannot name a layer it cannot see.
 */
function figmaIdAttr(node: IRNode, options: HtmlGenerationOptions): string {
  if (!options.debugFigmaIds || !node.id) return '';
  return ` data-figma-id="${escapeHtml(node.id)}"`;
}

/**
 * Recursively generates HTML with Tailwind CSS classes
 *
 * @param extraClasses - Classes the parent imposes on this node. Figma's
 *   "first on top" stacking order is a per-child `z-index` that the CSS export
 *   writes as a rule on the child; here it has to travel as a class, so the
 *   parent passes it down. It replaces the child's own `z-index`, which is what
 *   the cascade does in the CSS export too.
 */
export function generateTailwindHtml(
  node: IRNode,
  indentLevel: number = 0,
  insidePhrasing: boolean = false,
  extraClasses: string[] = [],
  options: HtmlGenerationOptions = {}
): string {
  const indent = '  '.repeat(indentLevel);
  let tag = node.tag;
  if (insidePhrasing) {
    if (tag === 'button' || !PHRASING_TAGS.has(tag)) tag = 'span';
  }
  const isPhrasingContainer = tag === 'button' || tag === 'label';
  const nextInsidePhrasing = insidePhrasing || isPhrasingContainer;

  const own = nodeToTailwindClasses(node);
  const overridesZ = extraClasses.some((cls) => cls.startsWith('z-'));
  const classes = (overridesZ ? own.filter((cls) => !cls.startsWith('z-')) : own)
    .concat(extraClasses)
    .join(' ');
  const classAttr = classes ? ` class="${classes}"` : '';
  const figmaAttr = figmaIdAttr(node, options);
  const extraAttrs = htmlAttrs(node);

  // SVG Asset
  if (node.asset && node.asset.type === 'svg') {
    let cleanSvg = node.asset.content.trim();
    cleanSvg = cleanSvg.replace(/<svg\b([^>]*)>/i, (match, attrs) => {
      if (attrs.includes('style=')) {
        return match.replace(/style="([^"]*)"/i, 'style="width: 100%; height: 100%; display: block; $1"');
      }
      return `<svg style="width: 100%; height: 100%; display: block;"${attrs}>`;
    });
    const wrapperTag = insidePhrasing ? 'span' : 'div';
    return `${indent}<${wrapperTag}${classAttr}${figmaAttr}${extraAttrs}>\n${indent}  ${cleanSvg}\n${indent}</${wrapperTag}>`;
  }

  // Image Asset (only when semantic tag is 'img')
  if (node.asset && node.asset.type === 'image' && tag === 'img') {
    return `${indent}<img${classAttr}${figmaAttr}${extraAttrs} src="${node.asset.content}" alt="${escapeHtml(node.name)}" />`;
  }

  // Native form controls. Same rule as the HTML export: the placeholder is an
  // attribute, not a paragraph, and the control cannot have children.
  if (tag === 'input') {
    return `${indent}<input${classAttr}${figmaAttr}${extraAttrs} />`;
  }
  if (tag === 'textarea') {
    return `${indent}<textarea${classAttr}${figmaAttr}${extraAttrs}>${escapeHtml(node.text ?? '')}</textarea>`;
  }
  if (tag === 'option') {
    const label = escapeHtml((node.text ?? '').replace(/\s+/g, ' ').trim());
    return `${indent}<option${classAttr}${figmaAttr}${extraAttrs}>${label}</option>`;
  }

  // Text (preserve segments + lists, escape content)
  if (node.type === 'TEXT') {
    const isRtl = node.typography?.direction === 'rtl';
    const dirAttr = isRtl ? ' dir="rtl"' : '';

    if (node.typography?.isList) {
      // The bullet stays in the text. The CSS export strips it and draws it
      // with `::before`, which utilities cannot express; keeping the character
      // gives the same marker without a pseudo-element.
      const items = (node.text || '')
        .split('\n')
        .map((l) => l.trim())
        .filter(Boolean)
        .map((l) => `${indent}  <li>${formatTextContent(l)}</li>`)
        .join('\n');
      return `${indent}<${tag}${classAttr}${figmaAttr}${extraAttrs}${dirAttr}>\n${items}\n${indent}</${tag}>`;
    }
    const link = (inner: string) => anchorHtml(node.href, inner);
    if (node.typography?.segments && node.typography.segments.length > 1) {
      const inner = node.typography.segments
        .map((seg) => {
          const inline = segmentToInlineStyle(seg);
          const span = `<span${inline ? ` style="${inline}"` : ''}>${formatTextContent(seg.text)}</span>`;
          return node.href ? span : anchorHtml(seg.href, span);
        })
        .join('');
      return `${indent}<${tag}${classAttr}${figmaAttr}${extraAttrs}${dirAttr}>${link(inner)}</${tag}>`;
    }
    // Paragraph spacing needs paragraph boxes. The blocks carry the same inline
    // declarations as the CSS export, so both outputs break in the same places.
    if (node.typography?.paragraphSpacing) {
      return `${indent}<${tag}${classAttr}${figmaAttr}${extraAttrs}${dirAttr}>${link(`\n${generateParagraphHtml(node, indent)}\n${indent}`)}</${tag}>`;
    }
    // `formatTextContent` is the HTML export's own text pipeline: it escapes,
    // keeps line breaks and isolates bidirectional phone numbers. Reusing it is
    // what keeps the two outputs identical for the same layer.
    return `${indent}<${tag}${classAttr}${figmaAttr}${extraAttrs}${dirAttr}>${link(formatTextContent(node.text || ''))}</${tag}>`;
  }

  // Container with children
  if (node.children && node.children.length > 0) {
    // Figma's canvas stacking order ('First on top'): the last child paints
    // lowest. The CSS export writes it as a `z-index` rule on each child; here
    // it travels down as a class.
    const count = node.children.length;
    const reverseZ = node.layout.itemReverseZIndex && count > 1;
    const childrenHtml = node.children
      .map((child, index) =>
        generateTailwindHtml(
          child,
          indentLevel + 1,
          nextInsidePhrasing,
          reverseZ ? [`z-[${count - index}]`] : [],
          options
        )
      )
      .join('\n');
    return `${indent}<${tag}${classAttr}${figmaAttr}${extraAttrs}>\n${childrenHtml}\n${indent}</${tag}>`;
  }

  // Leaf container
  return `${indent}<${tag}${classAttr}${figmaAttr}${extraAttrs}></${tag}>`;
}
