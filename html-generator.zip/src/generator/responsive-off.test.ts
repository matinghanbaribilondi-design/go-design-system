import { describe, it, expect } from 'vitest';
import { extractLayout } from '../plugin/converter/layout';
import { generateCss, generateCssForRoots } from './css-generator';
import { generateFullHtmlDocument } from './html-generator';
import { generateTailwindHtml, nodeToTailwindClasses } from './tailwind-generator';
import { fluidLength, wrapFloor } from '../shared/fluid';
import { responsiveEnabled, intrinsicReflowEnabled } from '../shared/responsive';
import type { ConversionOptions, IRNode } from '../plugin/types/ir';

/**
 * The master switch has to be total.
 *
 * With `responsive: false` the export is a fixed-size reproduction of the
 * frame: no `clamp()`, no `vw`, no `flex-wrap`, no `@container`, no `min()`
 * floors, nothing that lets the layout decide its own size. These tests walk a
 * tree that exercises every adaptive path — a regions row, a big gap, a big
 * padding, a display heading — and assert that not one of them fires.
 */

const off: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: true, // deliberately still true: the master switch wins
  designWidth: 1200,
};

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: (over.width as number) ?? 100,
    height: (over.height as number) ?? 100,
    x: 0,
    y: 0,
    layoutMode: (over.layoutMode as string) ?? 'NONE',
    children: (over.children as any[]) ?? [],
    ...over,
  };
}

let counter = 0;

/** The converter's own path: `extractLayout` per node, then an IR tree. */
function toIR(node: any, parent: any, options: ConversionOptions): IRNode {
  const className = `n${counter++}`;
  const layout = extractLayout(node, parent, options);
  const ir: IRNode = {
    id: node.id,
    name: node.name,
    className,
    tag: 'div',
    type: node.type,
    layout,
    visual: {},
    children: [],
  };
  const kids = (node.children ?? []).filter((c: any) => c.visible !== false);
  ir.children = kids.map((c: any) => toIR(c, node, options));
  if (kids.length === 0 && node.type === 'TEXT') {
    ir.type = 'TEXT';
    ir.tag = 'p';
    ir.text = node.characters ?? '';
    ir.typography = { fontSize: '48px', color: '#111' };
  }
  return ir;
}

/** A page with a regions shell, a big gap, a big padding and a display heading. */
function richPage(): any {
  const rail = mk({ id: 'rail', name: 'Sidebar', width: 280, height: 800, layoutMode: 'VERTICAL' });
  const body = mk({ id: 'body', name: 'Main', width: 760, height: 800, layoutMode: 'VERTICAL' });
  const shell = mk({
    id: 'shell',
    name: 'App Shell',
    layoutMode: 'HORIZONTAL',
    width: 1072,
    height: 800,
    itemSpacing: 32,
    children: [rail, body],
  });
  const heading = mk({
    id: 'h',
    name: 'Heading',
    type: 'TEXT',
    characters: 'A display heading that would scale',
    width: 1072,
    height: 64,
    fontSize: 48,
  });
  return mk({
    id: 'root',
    name: 'Page',
    layoutMode: 'VERTICAL',
    width: 1200,
    height: 1024,
    itemSpacing: 32,
    paddingTop: 64,
    paddingRight: 64,
    paddingBottom: 64,
    paddingLeft: 64,
    children: [heading, shell],
  });
}

describe('responsive: false — the switch is total', () => {
  it('reports itself off, and keeps intrinsic reflow subordinate to it', () => {
    expect(responsiveEnabled(off)).toBe(false);
    expect(intrinsicReflowEnabled(off)).toBe(false);
    expect(responsiveEnabled({ ...off, responsive: true })).toBe(true);
    expect(intrinsicReflowEnabled({ ...off, responsive: true })).toBe(true);
  });

  it('emits no fluid value from the helpers themselves', () => {
    // The choke point: every clamp() in the output is built here.
    expect(fluidLength(48, 1200, off)).toBeNull();
    expect(wrapFloor(280, off)).toBe('280px');
  });

  it('emits no adaptive declaration anywhere in the stylesheet', () => {
    const css = generateCss(toIR(richPage(), null, off), off, false);

    expect(css).not.toContain('clamp(');
    expect(css).not.toMatch(/\d(?:\.\d+)?vw/);
    expect(css).not.toContain('container-type');
    expect(css).not.toContain('@container');
    expect(css).not.toContain('flex-wrap: wrap');
    expect(css).not.toContain('min-width: min(');
    expect(css).not.toContain('flex-shrink: 1');

    // The only `max-width: 100%` left is the reset's image guard, which is a
    // safety net rather than a layout decision — and an image's own rule
    // overrides it anyway.
    expect(css.match(/max-width: 100%/g) ?? []).toHaveLength(1);
  });

  it('keeps the design’s own measurements', () => {
    const ir = toIR(richPage(), null, off);
    const css = generateCss(ir, off, false);

    // Root is the frame, not a fluid container.
    expect(css).toContain('width: 1200px;');
    expect(css).toContain('height: 1024px;');
    expect(css).not.toContain('margin-inline: auto;');

    // Big padding and gap stay exactly as drawn.
    expect(css).toContain('padding: 64px;');
    expect(css).toContain('gap: 32px;');

    // Every child holds its size instead of shrinking into the viewport.
    expect(css).toContain('flex-shrink: 0;');
  });

  it('emits no adaptive utility class', () => {
    const ir = toIR(richPage(), null, off);
    const root = nodeToTailwindClasses(ir);
    const all = [
      root,
      ...ir.children.map((child) => nodeToTailwindClasses(child)),
      ...ir.children.flatMap((child) => child.children.map((grandchild) => nodeToTailwindClasses(grandchild))),
    ].join(' ');

    // The root is the frame itself, not a `w-full` container.
    expect(root).toContain('w-[1200px]');
    expect(root).not.toContain('w-full');
    expect(root).not.toContain('max-w-[1200px]');

    expect(all).not.toContain('@container');
    expect(all).not.toContain('clamp(');
    expect(all).not.toContain('max-w-full');
    expect(all).not.toContain('basis-0');
    expect(all).toContain('shrink-0');
  });

  /**
   * The whole-file export is a *different* entry point — `generateCssForRoots`
   * rather than `generateCss` — and it is the one people actually use. Nothing
   * above proves it respects the switch, so this does, on two frames at once.
   */
  it('is total on the whole-file path too: one stylesheet, several roots', () => {
    const roots = [
      toIR(richPage(), null, off),
      toIR(mk({ id: 'card', name: 'Card', width: 360, height: 200, layoutMode: 'VERTICAL' }), null, off),
    ];
    const css = generateCssForRoots(roots, off, false, '', true);

    const forbidden = [
      'clamp(',
      '@container',
      'container-type',
      'flex-wrap',
      'min-width: min(',
      'flex-shrink: 1',
      '@media',
      'minmax(',
      'auto-fit',
      'auto-fill',
    ];
    for (const token of forbidden) {
      expect(css, `styles.css must not contain ${token}`).not.toContain(token);
    }
    // No viewport-relative length may come from the design — and none from the
    // reset either: a fixed export must not mention the window it is opened in.
    expect(css).not.toMatch(/\d(?:\.\d+)?(?:vw|vh|svw|svh|lvw|lvh|dvw|dvh)/);
  });

  it('leaves exactly one parent-relative safety net, and no viewport unit', () => {
    const css = generateCssForRoots([toIR(richPage(), null, off)], off, false, '', true);

    // The reset's image guard is parent-relative (`max-width: 100%`), not
    // viewport-relative: it stops an image overflowing its own box, and in a
    // fixed export it never actually fires. Anything else matching this
    // pattern would be an adaptive rule that leaked through.
    const matches = css.match(/[^\n]*(?:\d(?:\.\d+)?(?:vh|vw)|max-width: 100%)[^\n]*/g) ?? [];
    expect(matches).toEqual(['  max-width: 100%;']);
  });

  it('is total in the standalone HTML document and in the Tailwind markup', () => {
    const ir = toIR(richPage(), null, off);

    const doc = generateFullHtmlDocument(ir, off);
    expect(doc).not.toContain('clamp(');
    expect(doc).not.toContain('@container');
    expect(doc).not.toContain('container-type');
    expect(doc).not.toContain('flex-wrap');
    // No responsive breakpoint prefix anywhere in the class attributes.
    expect(doc).not.toMatch(/\b(?:sm|md|lg|xl|2xl):/);

    const tw = generateTailwindHtml(ir);
    expect(tw).not.toContain('@container');
    expect(tw).not.toContain('max-w-full');
    expect(tw).not.toContain('basis-0');
    expect(tw).not.toMatch(/\b(?:sm|md|lg|xl|2xl):/);
  });
});
