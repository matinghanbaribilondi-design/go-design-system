import { describe, it, expect } from 'vitest';
import { dedupeComponents } from './component-registry';
import { generateCssForRoots } from '../generator/css-generator';
import { generateHtml } from '../generator/html-generator';
import type {
  ConversionOptions,
  IRNode,
  LayoutStyles,
  TypographyStyles,
  VisualStyles,
} from '../plugin/types/ir';

/**
 * Component reuse has exactly one job, and it is not "produce less CSS".
 *
 * It is "produce less CSS *without changing what anything looks like*". So the
 * central test here is not a snapshot of the output — it is an equivalence
 * proof: for every node in a document, the declarations the browser ends up
 * applying after deduping must be identical to the declarations it applied
 * before. Anything less and the optimisation is a regression waiting to happen.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: false,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  designWidth: 1200,
};

/** `class { prop: value; … }` rules, keyed by class, ignoring @container blocks. */
function parseClassRules(css: string): Map<string, Record<string, string>> {
  const out = new Map<string, Record<string, string>>();
  const rule = /^\.([A-Za-z0-9_-]+)\s*\{([\s\S]*?)\n\}/gm;
  let match: RegExpExecArray | null = rule.exec(css);
  while (match) {
    const name = match[1];
    const body = match[2];
    if (name && body !== undefined) {
      const declarations: Record<string, string> = {};
      for (const chunk of body.split(';')) {
        const colon = chunk.indexOf(':');
        if (colon < 0) continue;
        const property = chunk.slice(0, colon).trim();
        if (property) declarations[property] = chunk.slice(colon + 1).trim();
      }
      out.set(name, declarations);
    }
    match = rule.exec(css);
  }
  return out;
}

/** Every node, in document order — the two trees stay in lockstep. */
function flatten(node: IRNode, out: IRNode[] = []): IRNode[] {
  out.push(node);
  for (const child of node.children) flatten(child, out);
  return out;
}

interface ButtonOverrides {
  /** The class the converter would have given this node before deduping. */
  className: string;
  background?: string;
  padding?: number;
  label?: string;
  /** An extra visual property, which makes the shape differ. */
  boxShadow?: string;
}

function button(over: ButtonOverrides): IRNode {
  const layout: LayoutStyles = {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: '8px',
    padding: { top: 12, right: 24, bottom: 12, left: 24 },
  };
  const pad = over.padding;
  if (pad !== undefined) {
    layout.padding = { top: pad, right: pad, bottom: pad, left: pad };
  }

  const visual: VisualStyles = { background: over.background ?? '#2563eb', borderRadius: '8px' };
  if (over.boxShadow) visual.boxShadow = over.boxShadow;

  const typography: TypographyStyles = {
    fontSize: '14px',
    fontWeight: 600,
    lineHeight: '1.4',
    color: '#ffffff',
  };

  return {
    id: over.className,
    name: 'Button',
    className: over.className,
    tag: 'button',
    type: 'INSTANCE',
    componentRef: { id: 'master-button', name: 'Button' },
    layout,
    visual,
    children: [
      {
        id: `${over.className}-label`,
        name: 'Label',
        className: `${over.className}__label`,
        tag: 'span',
        type: 'TEXT',
        layout: { display: 'block' },
        visual: {},
        typography,
        text: over.label ?? 'Continue',
        children: [],
      },
    ],
  };
}

/** A page holding the three buttons: identical, overridden, and a different shape. */
function buildPage(): IRNode[] {
  return [
    button({ className: 'button' }),
    button({ className: 'button-ab12', background: '#1d4ed8', padding: 20, label: 'Cancel' }),
    button({ className: 'button-cd34', boxShadow: '0 1px 2px rgba(0,0,0,0.3)' }),
  ];
}

describe('component reuse', () => {
  it('makes the first instance the definition and rewrites later ones onto it', () => {
    const roots = buildPage();
    const report = dedupeComponents(roots);

    expect(report.definitions).toHaveLength(1);
    expect(report.definitions[0]?.className).toBe('button');
    expect(report.definitions[0]?.uses).toBe(2); // the defining instance + one reusable
    expect(report.merged).toBe(1);
    // The third button carries a property the definition does not have, so it
    // cannot be expressed as an override — CSS cannot un-set a declaration.
    expect(report.standalone).toBe(1);

    const [first, second, third] = roots;
    expect(first?.className).toBe('button');
    expect(first?.componentOverride).toBeUndefined();

    expect(second?.className).toBe('button');
    expect(second?.componentOverride).toBeDefined();
    // Only what changed travels in the modifier.
    expect(Object.keys(second?.componentOverride?.visual ?? {})).toEqual(['background']);
    expect(Object.keys(second?.componentOverride?.layout ?? {})).toEqual(['padding']);

    expect(third?.className).toBe('button-cd34');
    expect(third?.componentOverride).toBeUndefined();
  });

  it('keeps each instance’s own text even though they share a class', () => {
    const roots = buildPage();
    dedupeComponents(roots);

    const firstHtml = generateHtml(roots[0]!);
    const secondHtml = generateHtml(roots[1]!);

    expect(firstHtml).toContain('>Continue<');
    expect(secondHtml).toContain('>Cancel<');
    // Both roots carry the shared class; the second also carries its modifier.
    expect(firstHtml).toContain('class="button"');
    expect(secondHtml).toMatch(/class="button button--v2_0"/);
  });

  it('marks every component node with the id that links it to components/*.html', () => {
    const roots = buildPage();
    dedupeComponents(roots);

    const marked = generateHtml(roots[1]!, 0, false, { componentMarkers: true });

    // Both the shared class and the component identity: the first is what the
    // browser styles, the second is what makes the archive's component file a
    // dependency rather than a look-alike.
    expect(marked).toContain('class="button button--v2_0"');
    expect(marked).toContain('data-component="Button"');
    expect(marked).toContain('data-component-id="master-button"');
  });

  it('leaves the single-frame output byte-identical when markers are off', () => {
    // The selection export must not grow an attribute it never asked for.
    const roots = buildPage();
    dedupeComponents(roots);

    const plain = generateHtml(roots[1]!);
    expect(plain).not.toContain('data-component');
    expect(plain).toBe(generateHtml(roots[1]!, 0, false, {}));
  });

  it('emits the component once and each override once', () => {
    const roots = buildPage();
    dedupeComponents(roots);
    const css = generateCssForRoots(roots, options);

    const shared = css.match(/^\.button\s*\{/gm) ?? [];
    expect(shared).toHaveLength(1);
    expect(css).toContain('.button--v2_0 {');
    // The third button is standalone, so it keeps its own full rule set.
    expect(css).toContain('.button-cd34 {');
  });

  it('applies the same declarations before and after deduping, node for node', () => {
    const before = buildPage();
    const after = buildPage();

    const beforeCss = parseClassRules(generateCssForRoots(before, options));
    dedupeComponents(after);
    const afterCss = parseClassRules(generateCssForRoots(after, options));

    // Guard against a vacuous pass: if the parser stopped finding rules, every
    // comparison below would be `{}` versus `{}` and prove nothing.
    expect(beforeCss.size).toBeGreaterThanOrEqual(4);
    expect(Object.keys(beforeCss.get('button-ab12') ?? {})).toContain('padding');
    expect(afterCss.get('button--v2_0')?.background).toBe('#1d4ed8');

    const beforeNodes = before.flatMap((root) => flatten(root));
    const afterNodes = after.flatMap((root) => flatten(root));
    expect(afterNodes).toHaveLength(beforeNodes.length);

    for (let i = 0; i < beforeNodes.length; i += 1) {
      const was = beforeNodes[i]!;
      const now = afterNodes[i]!;

      // What the browser resolved for this node before deduping: its own class.
      const resolvedBefore = beforeCss.get(was.className) ?? {};

      // And after: the shared class, then the modifier on top — CSS cascade
      // order is what makes the override win, exactly as it would in a
      // hand-written stylesheet.
      const resolvedAfter = {
        ...(afterCss.get(now.className) ?? {}),
        ...(now.componentOverride ? afterCss.get(now.componentOverride.className) ?? {} : {}),
      };

      expect(resolvedAfter, `declarations changed for ${was.className}`).toEqual(resolvedBefore);
    }
  });

  it('leaves a document with no instances exactly as it found it', () => {
    const plain: IRNode = {
      id: 'frame',
      name: 'Frame',
      className: 'frame',
      tag: 'div',
      type: 'FRAME',
      layout: { display: 'flex', flexDirection: 'column', gap: '12px' },
      visual: {},
      children: [
        {
          id: 'title',
          name: 'Title',
          className: 'title',
          tag: 'h1',
          type: 'TEXT',
          layout: { display: 'block' },
          visual: {},
          typography: { fontSize: '24px' },
          text: 'Hello',
          children: [],
        },
      ],
    };
    const cssBefore = generateCssForRoots([plain], options);
    const report = dedupeComponents([plain]);

    expect(report.definitions).toHaveLength(0);
    expect(report.merged).toBe(0);
    expect(generateCssForRoots([plain], options)).toBe(cssBefore);
  });

  it('shares one definition across pages instead of one per page', () => {
    // Two pages, each with its own instance of the same master.
    const pageOne = [button({ className: 'button' })];
    const pageTwo = [button({ className: 'button-99zz' })];

    const report = dedupeComponents([...pageOne, ...pageTwo]);
    const css = generateCssForRoots([...pageOne, ...pageTwo], options);

    expect(report.definitions).toHaveLength(1);
    expect(report.merged).toBe(1);
    expect(pageTwo[0]?.className).toBe('button');
    // One rule set for both pages, which is the whole point of a shared sheet.
    expect((css.match(/^\.button\s*\{/gm) ?? [])).toHaveLength(1);
  });
});
