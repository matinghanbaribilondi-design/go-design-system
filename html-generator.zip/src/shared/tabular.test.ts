import { describe, it, expect } from 'vitest';
import { isNumericText, looksTabular, textOf } from './tabular';
import type { IRNode, StyledTextSegment } from '../plugin/types/ir';

/**
 * Tabular figures.
 *
 * Figma has no table node, so a table is drawn as a frame of rows of cells. Set
 * in a proportional font, the digits of a column do not line up: a `1` is
 * narrower than a `4`, and the column stops reading as a column.
 * `font-variant-numeric: tabular-nums` fixes it — but it makes running text
 * loose, so it is only ever applied to a container that is recognisably a
 * table. These tests pin down what "recognisably" means.
 */

let counter = 0;

function node(partial: Partial<IRNode> = {}): IRNode {
  counter += 1;
  return {
    id: `n${counter}`,
    name: `node-${counter}`,
    className: `c${counter}`,
    tag: 'div',
    type: 'FRAME',
    layout: {},
    visual: {},
    children: [],
    ...partial,
  };
}

/** A styled run, filled in well enough to type-check. */
function segment(text: string): StyledTextSegment {
  return { text, fontSize: '14px', fontWeight: 400, fontFamily: 'sans-serif', lineHeight: '20px', letterSpacing: 'normal', color: '#000' };
}

/** A cell of a fixed width, holding one string. */
function cell(width: string, text: string): IRNode {
  return node({ type: 'TEXT', layout: { width }, text });
}

/** A row of fixed width, holding the given cells. */
function row(width: string, cells: IRNode[]): IRNode {
  return node({ layout: { display: 'flex', width }, children: cells });
}

/** A frame of rows, stacked the way a table is drawn. */
function table(rows: IRNode[], layout: IRNode['layout'] = { display: 'flex', flexDirection: 'column' }): IRNode {
  return node({ layout, children: rows });
}

/** A 3×3 table of prices: equal rows, equal cells, numbers in every one. */
function priceTable(): IRNode {
  return table([
    row('600px', [cell('180px', '1,240'), cell('180px', '2,310'), cell('180px', '980')]),
    row('600px', [cell('180px', '1,110'), cell('180px', '4,050'), cell('180px', '7,600')]),
    row('600px', [cell('180px', '3,470'), cell('180px', '90'), cell('180px', '1,005')]),
  ]);
}

/* ------------------------------------------------------------------ *
 * What counts as a number
 * ------------------------------------------------------------------ */

describe('reading a cell as a number', () => {
  it('accepts a plain integer', () => {
    expect(isNumericText('1240')).toBe(true);
  });

  it('accepts thousands separators', () => {
    expect(isNumericText('1,240')).toBe(true);
  });

  it('accepts a decimal', () => {
    expect(isNumericText('3.99')).toBe(true);
  });

  it('accepts a currency sign', () => {
    expect(isNumericText('$45.00')).toBe(true);
  });

  it('accepts a percentage', () => {
    expect(isNumericText('12.5%')).toBe(true);
  });

  it('accepts a negative value', () => {
    expect(isNumericText('-120')).toBe(true);
  });

  it('accepts Persian digits', () => {
    expect(isNumericText('۱۲۳')).toBe(true);
  });

  it('accepts Arabic-Indic digits', () => {
    expect(isNumericText('٤٥٦')).toBe(true);
  });

  it('accepts a date written as numbers', () => {
    expect(isNumericText('2026/10/19')).toBe(true);
  });

  it('rejects prose', () => {
    expect(isNumericText('2 items')).toBe(false);
  });

  it('rejects a word', () => {
    expect(isNumericText('Total')).toBe(false);
  });

  it('rejects a dash, which is a value but not a number', () => {
    expect(isNumericText('—')).toBe(false);
  });

  it('rejects empty text', () => {
    expect(isNumericText('')).toBe(false);
    expect(isNumericText(undefined)).toBe(false);
  });
});

/* ------------------------------------------------------------------ *
 * Finding the text of a layer
 * ------------------------------------------------------------------ */

describe('the text a layer paints', () => {
  it('is the plain string of a simple layer', () => {
    expect(textOf(node({ text: 'Hello' }))).toBe('Hello');
  });

  it('is the runs of a styled layer joined back together', () => {
    const styled = node({
      typography: { segments: [segment('Hello '), segment('world')] },
    });

    expect(textOf(styled)).toBe('Hello world');
  });

  it('is empty for a layer that paints nothing', () => {
    expect(textOf(node())).toBe('');
  });
});

/* ------------------------------------------------------------------ *
 * Recognising a table
 * ------------------------------------------------------------------ */

describe('a frame shaped like a table', () => {
  it('is recognised', () => {
    expect(looksTabular(priceTable())).toBe(true);
  });

  it('is recognised when it is a grid rather than a column', () => {
    expect(looksTabular(table(priceTable().children, { display: 'grid' }))).toBe(true);
  });

  it('is not a single row, which is a strip and not a table', () => {
    expect(looksTabular(table([row('600px', [cell('180px', '1'), cell('180px', '2')])]))).toBe(false);
  });

  it('is not a single column, which is a list', () => {
    const rows = [row('600px', [cell('180px', '1')]), row('600px', [cell('180px', '2')])];

    expect(looksTabular(table(rows))).toBe(false);
  });

  it('is not a horizontal strip of boxes', () => {
    const flat = table([cell('100px', '1'), cell('100px', '2'), cell('100px', '3')], {
      display: 'flex',
      flexDirection: 'row',
    });

    expect(looksTabular(flat)).toBe(false);
  });

  it('is not a stack of prose, however evenly it is laid out', () => {
    const prose = table([
      row('600px', [cell('180px', 'Ship faster'), cell('180px', 'Then rest')]),
      row('600px', [cell('180px', 'Read the docs'), cell('180px', 'And the blog')]),
    ]);

    expect(looksTabular(prose)).toBe(false);
  });

  it('is not rows of different widths, because then the columns do not line up', () => {
    const ragged = table([
      row('600px', [cell('180px', '1'), cell('180px', '2')]),
      row('640px', [cell('180px', '3'), cell('180px', '4')]),
    ]);

    expect(looksTabular(ragged)).toBe(false);
  });

  it('is not cells of different widths inside one column', () => {
    const ragged = table([
      row('600px', [cell('180px', '1'), cell('180px', '2')]),
      row('600px', [cell('240px', '3'), cell('180px', '4')]),
    ]);

    expect(looksTabular(ragged)).toBe(false);
  });

  it('is not rows with different numbers of cells', () => {
    const ragged = table([
      row('600px', [cell('180px', '1'), cell('180px', '2')]),
      row('600px', [cell('180px', '3')]),
    ]);

    expect(looksTabular(ragged)).toBe(false);
  });

  it('is not a table whose cells have no width to compare', () => {
    const unsized = table([
      row('600px', [node({ type: 'TEXT', text: '1' }), node({ type: 'TEXT', text: '2' })]),
      row('600px', [node({ type: 'TEXT', text: '3' }), node({ type: 'TEXT', text: '4' })]),
    ]);

    expect(looksTabular(unsized)).toBe(false);
  });

  it('is not a table whose rows have no width', () => {
    const unsized = table([
      node({ children: [cell('180px', '1'), cell('180px', '2')] }),
      node({ children: [cell('180px', '3'), cell('180px', '4')] }),
    ]);

    expect(looksTabular(unsized)).toBe(false);
  });

  it('is not an empty frame', () => {
    expect(looksTabular(node({ layout: { display: 'flex', flexDirection: 'column' } }))).toBe(false);
  });

  it('is not a table of empty cells, which has no figures to pin', () => {
    const blank = table([
      row('600px', [cell('180px', ''), cell('180px', '')]),
      row('600px', [cell('180px', ''), cell('180px', '')]),
    ]);

    expect(looksTabular(blank)).toBe(false);
  });
});

describe('how much of a table has to be numeric', () => {
  it('accepts a label column beside two numeric ones', () => {
    const mixed = table([
      row('600px', [cell('200px', 'Total'), cell('200px', '1,240'), cell('200px', '2,310')]),
      row('600px', [cell('200px', 'Fees'), cell('200px', '110'), cell('200px', '405')]),
    ]);

    expect(looksTabular(mixed)).toBe(true);
  });

  it('rejects a table that is mostly words', () => {
    const mostlyWords = table([
      row('600px', [cell('200px', 'Total'), cell('200px', 'Fees'), cell('200px', '1,240')]),
      row('600px', [cell('200px', 'Tax'), cell('200px', 'Due'), cell('200px', '405')]),
    ]);

    expect(looksTabular(mostlyWords)).toBe(false);
  });

  it('counts the text inside a cell frame, not just a bare text layer', () => {
    const nested = table([
      row('600px', [
        node({ layout: { width: '200px' }, children: [cell('80px', '1,240')] }),
        node({ layout: { width: '200px' }, children: [cell('80px', '2,310')] }),
      ]),
      row('600px', [
        node({ layout: { width: '200px' }, children: [cell('80px', '980')] }),
        node({ layout: { width: '200px' }, children: [cell('80px', '1,110')] }),
      ]),
    ]);

    expect(looksTabular(nested)).toBe(true);
  });

  it('reads a styled cell through its runs', () => {
    const styled = table([
      row('600px', [
        node({ layout: { width: '200px' }, typography: { segments: [segment('1,'), segment('240')] } }),
        cell('200px', '2,310'),
      ]),
      row('600px', [cell('200px', '980'), cell('200px', '1,110')]),
    ]);

    expect(looksTabular(styled)).toBe(true);
  });
});
