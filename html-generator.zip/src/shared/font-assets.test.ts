import { describe, expect, it } from 'vitest';
import {
  createCustomFont,
  getFormatFromFilename,
  isSupportedFontFile,
  parseFontInfoFromFilename,
  safeFontFilename,
  withCustomFont,
} from './font-assets';

describe('font assets', () => {
  it('reads a weight and style out of a filename', () => {
    expect(parseFontInfoFromFilename('IRANYekanX-Bold.woff2')).toMatchObject({
      family: 'IRANYekanX',
      style: 'Bold',
      weight: 700,
      isVariable: false,
    });
    expect(parseFontInfoFromFilename('Dana-SemiBold.ttf')).toMatchObject({
      family: 'Dana',
      style: 'SemiBold',
      weight: 600,
    });
    expect(parseFontInfoFromFilename('Vazirmatn-Regular.woff')).toMatchObject({
      family: 'Vazirmatn',
      style: 'Regular',
      weight: 400,
    });
  });

  it('recognises a variable font and keeps its weight range', () => {
    expect(parseFontInfoFromFilename('YekanBakh-VF.woff2')).toMatchObject({
      family: 'Yekan Bakh VF',
      style: 'Variable',
      weight: '100 1000',
      isVariable: true,
    });
  });

  it('matches the filename against the families the document uses before guessing', () => {
    const used = [{ family: 'Yekan Bakh' }, { family: 'IRANYekanXVF' }];
    expect(parseFontInfoFromFilename('iranyekanx-bold.woff2', used).family).toBe('IRANYekanXVF');
  });

  it('lets the layer being attached decide the family', () => {
    expect(parseFontInfoFromFilename('Dana-Bold.woff2', [], 'IRANYekanX').family).toBe('IRANYekanX');
  });

  it('maps extensions to CSS formats', () => {
    expect(getFormatFromFilename('a.woff2')).toBe('woff2');
    expect(getFormatFromFilename('a.woff')).toBe('woff');
    expect(getFormatFromFilename('a.ttf')).toBe('truetype');
    expect(getFormatFromFilename('a.otf')).toBe('opentype');
    expect(isSupportedFontFile('a.otf')).toBe(true);
    expect(isSupportedFontFile('a.TTF')).toBe(true);
    expect(isSupportedFontFile('a.png')).toBe(false);
  });

  it('keeps the filename inside the fonts folder', () => {
    expect(safeFontFilename('../../Vazirmatn Bold.woff2')).toBe('Vazirmatn-Bold.woff2');
    expect(safeFontFilename('fonts\\Dana.woff')).toBe('Dana.woff');
  });

  it('builds a font record and replaces the same family and weight', () => {
    const first = createCustomFont('IRANYekanX-Bold.woff2', 'data:font/woff2;base64,AAAA');
    const second = createCustomFont('IRANYekanX-Bold.woff2', 'data:font/woff2;base64,BBBB');

    expect(first).not.toBeNull();
    expect(first).toMatchObject({
      family: 'IRANYekanX',
      style: 'Bold',
      weight: 700,
      format: 'woff2',
      filename: 'IRANYekanX-Bold.woff2',
    });

    const merged = withCustomFont([first!], second!);
    expect(merged).toHaveLength(1);
    expect(merged[0]!.base64).toContain('BBBB');
  });

  it('refuses a file that is not a font', () => {
    expect(createCustomFont('hero.png', 'data:image/png;base64,AAAA')).toBeNull();
  });
});
