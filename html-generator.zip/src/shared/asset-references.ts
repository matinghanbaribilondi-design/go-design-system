/**
 * Assets, written once and pointed at.
 *
 * A conversion inlines every image as a base64 data URL, because that is what
 * a single self-contained HTML file needs. The archive is a different shape:
 * it has an `assets/` folder, so carrying the same bytes twice — once as a
 * data URL inside `index.html`, once as `assets/photo.png` — doubles the file
 * for no gain, and a page with a dozen photos goes from megabytes to tens of
 * megabytes.
 *
 * This module is the rewrite: every payload that now lives in `assets/` is
 * replaced in the markup and the stylesheet by the path to that file. Nothing
 * else in the document is touched, and an asset that is not actually referenced
 * anywhere is left alone rather than invented.
 */

/** One file that will be written into the archive's `assets/` folder. */
export interface AssetFile {
  filename: string;
  content: string;
  type: string;
}

/** Prefix of an inlined image payload. */
const DATA_URL = /^data:[^;,]+;base64,/;

/**
 * Points `document` at the files instead of repeating their bytes.
 *
 * `base` is relative on purpose: the archive is meant to be unzipped and opened
 * from disk, where an absolute path would point at the machine that built it.
 */
export function referenceAssets(
  document: string,
  assets: readonly AssetFile[],
  base: string = './assets/'
): string {
  let result = document;

  for (const asset of assets) {
    // Only images are inlined. An SVG is written into the markup as markup, so
    // there is no data URL to replace — and its file in `assets/` is a source
    // copy, not a duplicate of anything the page loads.
    if (asset.type !== 'image' || !DATA_URL.test(asset.content)) continue;
    if (!result.includes(asset.content)) continue;
    result = result.split(asset.content).join(`${base}${asset.filename}`);
  }

  return result;
}

/**
 * The same assets, with repeated payloads collapsed to one file.
 *
 * Two layers can hold byte-identical images — a logo repeated on every card is
 * exported once per node — and writing all of them would put the same file in
 * the archive forty times. Filenames are made unique at the same time, so a
 * deduplicated file never silently overwrites a different one.
 */
export function uniqueAssets(assets: readonly AssetFile[]): AssetFile[] {
  const byContent = new Map<string, AssetFile>();
  const taken = new Set<string>();

  for (const asset of assets) {
    if (byContent.has(asset.content)) continue;

    let filename = asset.filename;
    let n = 2;
    while (taken.has(filename)) {
      const dot = asset.filename.lastIndexOf('.');
      filename =
        dot > 0 ? `${asset.filename.slice(0, dot)}-${n}${asset.filename.slice(dot)}` : `${asset.filename}-${n}`;
      n += 1;
    }

    taken.add(filename);
    byContent.set(asset.content, { ...asset, filename });
  }

  return Array.from(byContent.values());
}
