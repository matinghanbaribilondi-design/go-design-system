import { describe, it, expect } from 'vitest';
import {
  buildWholeFileExport,
  wholeFileArchiveName,
  type WholeFileExportPayload,
} from './whole-file-export';

/**
 * The archive's shape is a promise: a developer opens it and finds a stylesheet
 * every page shares, one canvas per page with the frames where Figma put them,
 * one document per frame, one file per component, and a manifest that is
 * actually true.
 *
 * The manifest assertion is the interesting one. A hand-maintained manifest
 * drifts the moment a file is renamed, so these tests check the manifest
 * against the files that were written, not against a literal.
 */

function payload(over: Partial<WholeFileExportPayload> = {}): WholeFileExportPayload {
  return {
    fileName: 'Acme Dashboard',
    generatedAt: '2026-10-17T10:00:00.000Z',
    responsive: true,
    css: '/* tokens */\n.root { color: red; }',
    pages: [
      {
        name: 'Home',
        frames: [
          {
            name: 'Hero',
            width: 1440,
            height: 720,
            x: 120,
            y: 0,
            html: '  <div class="hero"></div>',
          },
          {
            name: 'Board',
            width: 1440,
            height: 600,
            x: 120,
            y: 900,
            html: '  <div class="board"></div>',
          },
        ],
        isRtl: false,
        components: ['1:1', '1:2'],
      },
      {
        name: 'Account Settings',
        frames: [
          {
            name: 'Settings',
            width: 1024,
            height: 800,
            x: 0,
            y: 0,
            html: '  <div class="settings"></div>',
          },
        ],
        isRtl: false,
        components: ['1:2'],
      },
    ],
    components: [
      { id: '1:1', name: 'Button', className: 'button', uses: 12, html: '  <button class="button"></button>' },
      { id: '1:2', name: 'Card', className: 'card', uses: 3, html: '  <div class="card"></div>' },
    ],
    assets: [],
    dedupe: { merged: 11, standalone: 2 },
    skipped: [],
    ...over,
  };
}

const paths = (files: { path: string }[]) => files.map((f) => f.path);
const file = (files: { path: string; content: string }[], path: string) =>
  files.find((f) => f.path === path)!.content;

/** Selector text of every rule in a stylesheet, comments removed, at-rules skipped. */
function selectorsOf(css: string): string[] {
  const clean = css.replace(/\/\*[\s\S]*?\*\//g, '');
  return clean
    .split('}')
    .map((rule) => rule.split('{')[0] ?? '')
    .flatMap((sel) => sel.split(','))
    .map((sel) => sel.trim())
    .filter((sel) => sel.length > 0 && !sel.startsWith('@'));
}

describe('whole-file archive', () => {
  it('writes one stylesheet, one canvas per page, one file per frame, plus index and manifest', () => {
    const files = buildWholeFileExport(payload());

    expect(paths(files)).toEqual([
      'styles.css',
      'canvas.css',
      'canvas.js',
      'nav.js',
      'pages/home.html',
      'pages/account-settings.html',
      'frames/hero.html',
      'frames/board.html',
      'frames/settings.html',
      'components/button.html',
      'components/card.html',
      'README.md',
      'index.html',
      'manifest.json',
    ]);
  });

  it('links the shared stylesheet and the shared chrome, and inlines neither', () => {
    const files = buildWholeFileExport(payload());
    const page = file(files, 'pages/home.html');
    const frame = file(files, 'frames/hero.html');

    expect(page).toContain('<link rel="stylesheet" href="../styles.css">');
    expect(page).toContain('<link rel="stylesheet" href="../canvas.css">');
    expect(page).toContain('<script src="../nav.js"></script>');
    expect(page).toContain('<script src="../canvas.js"></script>');
    expect(frame).toContain('<link rel="stylesheet" href="../styles.css">');

    // Chrome used to be inlined into all nine pages: nine copies of the same
    // 9 KB, nine places to fix a bug, and nothing cacheable. A page with no
    // inline style or script is the invariant that keeps that from coming
    // back.
    expect(page).not.toContain('<style');
    expect(page).not.toContain('<script>');
    expect(page).not.toContain('.hero {');
    expect(frame).not.toContain('<style');
  });

  it('places each frame at the coordinates Figma gave it', () => {
    const page = file(buildWholeFileExport(payload()), 'pages/home.html');

    // Bounding box is x 120..1560, y 0..1500, so the plane is that plus the
    // canvas margin on both sides (80px), and every frame is offset by the
    // box's origin.
    expect(page).toContain('data-w="1600"');
    expect(page).toContain('data-h="1660"');
    expect(page).toContain('left:80px;top:80px;width:1440px;height:720px');
    expect(page).toContain('left:80px;top:980px;width:1440px;height:600px');
  });

  it('normalises negative coordinates instead of pushing frames off the canvas', () => {
    const page = file(
      buildWholeFileExport(
        payload({
          pages: [
            {
              name: 'Home',
              frames: [
                { name: 'Left', width: 400, height: 300, x: -600, y: -200, html: '<div></div>' },
                { name: 'Right', width: 400, height: 300, x: 0, y: 0, html: '<div></div>' },
              ],
              isRtl: false,
              components: [],
            },
          ],
        })
      ),
      'pages/home.html'
    );

    // The leftmost frame is the origin, so it lands on the margin; the one at
    // 0,0 is 600 right of it and 200 below it.
    expect(page).toContain('left:80px;top:80px;width:400px;height:300px');
    expect(page).toContain('left:680px;top:280px;width:400px;height:300px');
    expect(page).toContain('data-w="1160"');
    expect(page).toContain('data-h="660"');
  });

  it('links every frame on the canvas to its own document, in a new tab', () => {
    const page = file(buildWholeFileExport(payload()), 'pages/home.html');

    expect(page).toContain('href="../frames/hero.html" target="_blank" rel="noopener"');
    expect(page).toContain('href="../frames/board.html" target="_blank" rel="noopener"');
  });

  it('gives the canvas the geometry it needs to decide what to mount', () => {
    const page = file(buildWholeFileExport(payload()), 'pages/home.html');

    // The canvas script never reads layout per frame — that read is the cost
    // it exists to remove — so the placement is repeated as data attributes
    // and the on-screen test is arithmetic.
    expect(page).toContain('data-x="80" data-y="80" data-w="1440" data-h="720"');
    expect(page).toContain('data-x="80" data-y="980" data-w="1440" data-h="600"');
  });

  it('paints an unmounted frame with its own background, and leaves a transparent one alone', () => {
    const page = file(
      buildWholeFileExport(
        payload({
          pages: [
            {
              name: 'Home',
              frames: [
                {
                  name: 'Dark',
                  width: 400,
                  height: 300,
                  x: 0,
                  y: 0,
                  html: '<div></div>',
                  background: '#0b0b0c',
                },
                { name: 'Clear', width: 400, height: 300, x: 500, y: 0, html: '<div></div>' },
              ],
              isRtl: false,
              components: [],
            },
          ],
        })
      ),
      'pages/home.html'
    );

    expect(page).toContain('<div class="__canvas-body" style="background:#0b0b0c">');
    // A frame with no fill shows the canvas through it, in the browser as in
    // Figma; inventing white here would be a lie the canvas cannot take back.
    expect(page).toContain('<div class="__canvas-body">\n<div></div>');
    // The same fill, repeated as data: the minimap draws into a <canvas> and
    // cannot read a computed style, and a style read per frame is the cost
    // this canvas exists to remove. An empty value is "no fill", not "white".
    expect(page).toContain('data-bg="#0b0b0c"');
    expect(page).toContain('data-bg=""');
  });

  it('offers the hand tool the way Figma does', () => {
    const page = file(buildWholeFileExport(payload()), 'pages/home.html');

    expect(page).toContain('data-act="hand"');
    expect(page).toContain('aria-pressed="false"');
  });

  it('ships a minimap, hidden until the page is bigger than the window', () => {
    const page = file(buildWholeFileExport(payload()), 'pages/home.html');

    // It starts hidden on purpose: at fit zoom the whole page is on screen, so
    // a scaled copy of it would be a rectangle restating what is already
    // visible. The script removes the class once something is off screen.
    expect(page).toContain('class="__canvas-mini __canvas-mini-off"');
    expect(page).toContain('id="__canvas-mini"');
    expect(page).toContain('id="__canvas-mini-c"');
    // A pointer shortcut to navigation the keyboard already has: it stays out
    // of the tab order rather than becoming a second way to get lost.
    expect(page).toContain('aria-hidden="true"');
  });

  it('offers every page in a switcher, and marks the one you are on', () => {
    const files = buildWholeFileExport(payload());
    const home = file(files, 'pages/home.html');
    const settings = file(files, 'pages/account-settings.html');

    // Before this, the only way off a page was "← index" and then a second
    // click. A file with nine pages needs the list itself.
    expect(home).toContain('href="../pages/account-settings.html"');
    expect(home).toContain('href="../pages/home.html" aria-current="page"');
    expect(settings).toContain('href="../pages/account-settings.html" aria-current="page"');
  });

  it('lists the page frames beside the canvas, each a real link', () => {
    const page = file(buildWholeFileExport(payload()), 'pages/home.html');

    // The row is an anchor to the frame document, so the list works with
    // scripting off; the script turns a plain click into "zoom to it here".
    expect(page).toContain('data-goto="hero"');
    expect(page).toContain('href="../frames/hero.html" data-goto="hero"');
    expect(page).toContain('data-goto="board"');
    expect(page).toContain('<span class="__canvas-row-size">1440×720</span>');
  });

  it('keeps 274 invisible frame links out of the tab order', () => {
    const page = file(buildWholeFileExport(payload()), 'pages/home.html');

    // The canvas hit area is a click target, not a navigation control: a
    // keyboard user reaches the frame list instead of tabbing through every
    // frame on the page and landing nowhere.
    expect(page).toContain('draggable="false" tabindex="-1"');
  });

  it('ships the navigation table the palette searches', () => {
    const nav = file(buildWholeFileExport(payload()), 'nav.js');
    const json = nav.slice(nav.indexOf('window.__CANVAS_NAV = ') + 21, nav.lastIndexOf(';'));
    const parsed = JSON.parse(json) as {
      base: string;
      pages: { name: string; slug: string; file: string; frames: { name: string; slug: string }[] }[];
    };

    // A script, not JSON: `fetch` is blocked on file://, and an archive that
    // needs a web server is not an archive.
    expect(parsed.base).toBe('../');
    expect(parsed.pages.map((p) => p.slug)).toEqual(['home', 'account-settings']);
    expect(parsed.pages[0]!.frames.map((f) => f.slug)).toEqual(['hero', 'board']);
    expect(parsed.pages[0]!.frames[0]!.name).toBe('Hero');
    expect(nav).toContain('window.__CANVAS_NAV');
  });

  it('records node ids and Figma links when the file has a key', () => {
    const files = buildWholeFileExport(
      payload({
        fileKey: 'AbC123',
        pages: [
          {
            name: 'Home',
            nodeId: '0:1',
            frames: [
              { name: 'Hero', nodeId: '1:2', width: 100, height: 100, x: 0, y: 0, html: '<div></div>' },
            ],
            isRtl: false,
            components: [],
          },
        ],
      })
    );
    const manifest = JSON.parse(file(files, 'manifest.json')) as {
      fileKey: string;
      pages: { nodeId: string; url: string; frames: { nodeId: string; url: string }[] }[];
    };

    expect(manifest.fileKey).toBe('AbC123');
    expect(manifest.pages[0]!.nodeId).toBe('0:1');
    // Figma spells a node id with a hyphen in URLs; `1:2` that stayed a colon
    // would land on nothing.
    expect(manifest.pages[0]!.frames[0]!.url).toBe(
      'https://www.figma.com/design/AbC123?node-id=1-2'
    );
    expect(file(files, 'pages/home.html')).toContain('https://www.figma.com/design/AbC123?node-id=0-1');
  });

  it('omits Figma links rather than pointing them at nothing', () => {
    const manifest = JSON.parse(file(buildWholeFileExport(payload()), 'manifest.json')) as {
      fileKey?: string;
      pages: { url?: string; frames: { url?: string }[] }[];
    };

    // A local or untitled file has no key, and a link to `undefined` is worse
    // than no link.
    expect(manifest.fileKey).toBeUndefined();
    expect(manifest.pages[0]!.url).toBeUndefined();
    expect(manifest.pages[0]!.frames[0]!.url).toBeUndefined();
  });

  it('counts what it wrote, and says how big it is', () => {
    const files = buildWholeFileExport(payload());
    const manifest = JSON.parse(file(files, 'manifest.json')) as {
      stats: { pages: number; frames: number; components: number; contentBytes: number };
      canvas: { stylesheet: string; script: string; nav: string };
    };

    expect(manifest.stats.pages).toBe(2);
    expect(manifest.stats.frames).toBe(3);
    expect(manifest.stats.components).toBe(2);
    expect(manifest.stats.contentBytes).toBeGreaterThan(1000);
    expect(manifest.canvas).toEqual({ stylesheet: 'canvas.css', script: 'canvas.js', nav: 'nav.js' });
  });

  it('ships a README, because the ZIP has to explain itself', () => {
    const readme = file(buildWholeFileExport(payload()), 'README.md');

    // Whoever opens the archive has no access to the plugin's own README, so
    // the structure, the shortcuts and the two honest caveats live here.
    expect(readme).toContain('pages/<page>.html');
    expect(readme).toContain('frames/<frame>.html');
    expect(readme).toContain('⌘K');
    expect(readme).toContain('appears twice');
    expect(readme).toContain('Acme Dashboard');
  });

  it('ships each frame as a standalone document, not a fragment', () => {
    const frame = file(buildWholeFileExport(payload()), 'frames/hero.html');

    expect(frame).toContain('<!DOCTYPE html>');
    expect(frame).toContain('<div class="hero"></div>');
    // A frame document is the frame, not a second canvas.
    expect(frame).not.toContain('__canvas');
  });

  it('keeps the canvas chrome out of the design namespace', () => {
    const css = file(buildWholeFileExport(payload()), 'canvas.css');
    const selectors = selectorsOf(css);

    expect(selectors.length).toBeGreaterThan(30);
    // The design's reset styles `html`, `body` and `button`, and this page
    // links that stylesheet. A single unprefixed selector here would let the
    // canvas fight the design, so every one of them is namespaced.
    for (const selector of selectors) {
      expect(selector.startsWith('.__canvas')).toBe(true);
    }
  });

  it('restores the design direction on the frame, not on the canvas', () => {
    const files = buildWholeFileExport(
      payload({
        pages: [
          {
            name: 'خانه',
            frames: [{ name: 'Hero', width: 1440, height: 720, x: 0, y: 0, html: '<div></div>' }],
            isRtl: true,
            components: [],
          },
        ],
      })
    );
    // Persian page names keep their own slug, so the file is not `home.html`.
    const rtl = files.find((f) => f.path.startsWith('pages/'))!.content;

    // The canvas itself is LTR — coordinates are a coordinate system, not a
    // paragraph — so the frame has to carry the design's own direction back.
    // An attribute rather than a per-page rule, because the page has no
    // stylesheet of its own any more.
    expect(rtl).toContain('dir="rtl"');
  });

  it('ships each component as a copyable fragment, not a second document', () => {
    const files = buildWholeFileExport(payload());
    const component = file(files, 'components/button.html');

    expect(component).toContain('<button class="button"></button>');
    expect(component).toContain('12 uses');
    // The file a developer copies from must be the markup itself: a document
    // shell would have to be stripped before it could be pasted anywhere, and
    // it would also claim to be a page that can be opened on its own.
    expect(component).not.toContain('<!DOCTYPE');
    expect(component).not.toContain('<link');
  });

  it('points every component file at the ids its instances carry', () => {
    const component = file(buildWholeFileExport(payload()), 'components/button.html');

    // The one link a static HTML file can actually carry: the id, which the
    // markup of every instance repeats as data-component-id.
    expect(component).toContain('data-component-id="1:1"');
  });

  it('records which components each page uses, and renders it in the index', () => {
    const files = buildWholeFileExport(payload());
    const manifest = JSON.parse(file(files, 'manifest.json')) as {
      pages: { name: string; components: string[] }[];
      components: { id: string; name: string }[];
    };

    expect(manifest.pages[0]!.components).toEqual(['1:1', '1:2']);
    expect(manifest.pages[1]!.components).toEqual(['1:2']);
    expect(manifest.components.map((c) => c.id)).toEqual(['1:1', '1:2']);

    // The index resolves those ids to names, so "where is Button used?" is
    // answered by reading one page instead of grepping the archive.
    const index = file(files, 'index.html');
    expect(index).toContain('<span class="chip">Button</span>');
    expect(index).toContain('<span class="chip">Card</span>');
  });

  it('shows the canonical markup inline in the index', () => {
    const index = file(buildWholeFileExport(payload()), 'index.html');

    expect(index).toContain('<summary>canonical markup</summary>');
    expect(index).toContain('&lt;button class=&quot;button&quot;&gt;');
  });

  it('lists every frame in the index, linking to its document', () => {
    const index = file(buildWholeFileExport(payload()), 'index.html');

    expect(index).toContain('<a href="frames/hero.html">Hero</a>');
    expect(index).toContain('<a href="frames/settings.html">Settings</a>');
  });

  it('derives the manifest from the files it actually wrote', () => {
    const files = buildWholeFileExport(payload());
    const manifest = JSON.parse(file(files, 'manifest.json')) as {
      pages: {
        name: string;
        file: string;
        frames: { name: string; file: string; x: number; y: number }[];
      }[];
      components: { name: string; file: string }[];
      dedupe: { definitions: number; merged: number; standalone: number };
      stylesheet: string;
    };

    const written = new Set(paths(files));
    for (const page of manifest.pages) {
      expect(written.has(page.file)).toBe(true);
      for (const frame of page.frames) expect(written.has(frame.file)).toBe(true);
    }
    for (const component of manifest.components) expect(written.has(component.file)).toBe(true);
    expect(written.has(manifest.stylesheet)).toBe(true);

    // The manifest carries the geometry the canvas was built from, so a
    // consumer can rebuild the layout without parsing HTML.
    expect(manifest.pages[0]!.frames).toEqual([
      { name: 'Hero', width: 1440, height: 720, x: 120, y: 0, file: 'frames/hero.html' },
      { name: 'Board', width: 1440, height: 600, x: 120, y: 900, file: 'frames/board.html' },
    ]);

    expect(manifest.pages).toHaveLength(2);
    expect(manifest.components).toHaveLength(2);
    expect(manifest.dedupe).toEqual({ definitions: 2, merged: 11, standalone: 2 });
  });

  it('disambiguates pages and frames that share a name instead of overwriting one', () => {
    const files = buildWholeFileExport(
      payload({
        pages: [
          {
            name: 'Home',
            frames: [
              { name: 'Hero', width: 100, height: 100, x: 0, y: 0, html: '<div></div>' },
              { name: 'Hero', width: 100, height: 100, x: 200, y: 0, html: '<div></div>' },
            ],
            isRtl: false,
            components: [],
          },
          {
            name: 'Home',
            frames: [{ name: 'Hero', width: 100, height: 100, x: 0, y: 0, html: '<div></div>' }],
            isRtl: false,
            components: [],
          },
          { name: 'home!', frames: [], isRtl: false, components: [] },
        ],
      })
    );

    expect(paths(files).filter((p) => p.startsWith('pages/'))).toEqual([
      'pages/home.html',
      'pages/home-2.html',
      'pages/home-3.html',
    ]);
    // Frames live in one folder, so a "Hero" on page 1 and a "Hero" on page 2
    // are different files rather than one file that overwrote the other.
    expect(paths(files).filter((p) => p.startsWith('frames/'))).toEqual([
      'frames/hero.html',
      'frames/hero-2.html',
      'frames/hero-3.html',
    ]);
  });

  it('still writes a canvas for a page whose frames were all skipped', () => {
    const page = file(
      buildWholeFileExport(
        payload({ pages: [{ name: 'Empty', frames: [], isRtl: false, components: [] }] })
      ),
      'pages/empty.html'
    );

    expect(page).toContain('data-w="160"');
    expect(page).toContain('0 frames');
    expect(page).not.toContain('class="__canvas-item"');
  });

  it('reports what it could not export, in the index and the manifest', () => {
    const files = buildWholeFileExport(
      payload({
        skipped: [{ name: 'Legacy', reason: 'page could not be loaded' }],
      })
    );

    const index = file(files, 'index.html');
    const manifest = file(files, 'manifest.json');

    expect(index).toContain('Legacy');
    expect(index).toContain('page could not be loaded');
    expect(JSON.parse(manifest).skipped).toEqual([
      { name: 'Legacy', reason: 'page could not be loaded' },
    ]);
  });

  it('writes binary assets and fonts as base64, and svg as text', () => {
    const files = buildWholeFileExport(
      payload({
        assets: [
          { filename: 'logo.svg', content: '<svg></svg>', type: 'svg' },
          { filename: 'photo.png', content: 'data:image/png;base64,AAAA', type: 'image' },
        ],
        customFonts: [
          {
            id: 'font-1',
            family: 'Vazirmatn',
            filename: 'vazirmatn.woff2',
            base64: 'data:font/woff2;base64,BBBB',
            format: 'woff2',
            weight: 400,
            style: 'normal',
          },
        ],
      })
    );

    const svg = files.find((f) => f.path === 'assets/logo.svg');
    const png = files.find((f) => f.path === 'assets/photo.png');
    const font = files.find((f) => f.path === 'fonts/vazirmatn.woff2');

    expect(svg?.content).toBe('<svg></svg>');
    expect(svg?.base64).toBeUndefined();
    expect(png?.content).toBe('AAAA');
    expect(png?.base64).toBe(true);
    expect(font?.content).toBe('BBBB');
    expect(font?.base64).toBe(true);
  });

  it('records which responsive mode the archive was exported in', () => {
    // A responsive ZIP and a fixed-size ZIP are indistinguishable in a file
    // listing and behave completely differently in a browser, so the archive
    // has to say which one it is.
    const responsive = buildWholeFileExport(payload({ responsive: true }));
    const fixed = buildWholeFileExport(payload({ responsive: false }));

    const manifestOf = (files: { path: string; content: string }[]) =>
      JSON.parse(file(files, 'manifest.json')) as { responsive: boolean };

    expect(manifestOf(responsive).responsive).toBe(true);
    expect(manifestOf(fixed).responsive).toBe(false);
    expect(file(responsive, 'index.html')).toContain('>responsive<');
    expect(file(fixed, 'index.html')).toContain('>fixed size<');
  });

  it('names the archive after the file, not after the selection', () => {
    expect(wholeFileArchiveName('Acme Dashboard')).toBe('acme-dashboard-export.zip');
    expect(wholeFileArchiveName('')).toBe('figma-file-export.zip');
  });
});
