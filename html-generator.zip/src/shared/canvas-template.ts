/**
 * The canvas chrome: the toolbar, the panels and the script that turns a page
 * of absolutely-positioned frames into something that behaves like Figma.
 *
 * It is a separate module because it is shipped as two files (`canvas.css` and
 * `canvas.js`) that every page shares. Nothing in here knows about the export
 * pipeline; the page document provides geometry as data attributes, layer trees
 * as JSON, and links to each frame's own document.
 *
 * Two rules hold the design together:
 *
 * 1. Every selector is namespaced `.__canvas-*`. The page also links the
 *    design's `styles.css`, so an unnamespaced rule could restyle the design.
 * 2. The camera is a transform, not a scroll position. Panning and zooming
 *    update `translate3d(...) scale(k)` on one element, so the compositor can
 *    do the work without laying out hundreds of frames. Frames are mounted
 *    only while they are near the viewport.
 */

export const CANVAS_CSS = `.__canvas-root {
  --__canvas-bg: #1e1e1e;
  --__canvas-panel: #2c2c2c;
  --__canvas-panel-2: #383838;
  --__canvas-panel-3: #454545;
  --__canvas-line: #444444;
  --__canvas-line-soft: #363636;
  --__canvas-ink: #ffffff;
  --__canvas-mute: #b3b3b3;
  --__canvas-faint: #8a8a8a;
  --__canvas-accent: #0d99ff;
  --__canvas-accent-soft: rgba(13, 153, 255, 0.24);
  --__canvas-shadow: 0 10px 28px rgba(0, 0, 0, 0.45);
  --__canvas-label-shadow: rgba(30, 30, 30, 0.92);
  --__canvas-side: 248px;
  --__canvas-inspect: 248px;
  --__canvas-top: 48px;
  height: 100%;
  color-scheme: dark;
}
.__canvas-root[data-theme="light"] {
  --__canvas-bg: #f5f5f5;
  --__canvas-panel: #ffffff;
  --__canvas-panel-2: #f1f1f1;
  --__canvas-panel-3: #e4e4e4;
  --__canvas-line: #e0e0e0;
  --__canvas-line-soft: #ececec;
  --__canvas-ink: #1e1e1e;
  --__canvas-mute: #666666;
  --__canvas-faint: #8c8c8c;
  --__canvas-accent-soft: rgba(13, 153, 255, 0.14);
  --__canvas-shadow: 0 10px 28px rgba(0, 0, 0, 0.16);
  --__canvas-label-shadow: rgba(245, 245, 245, 0.92);
  color-scheme: light;
}
.__canvas-root, .__canvas-doc {
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%;
}
.__canvas-doc {
  overflow: hidden;
  background: var(--__canvas-bg);
  color: var(--__canvas-ink);
  direction: ltr;
  -webkit-font-smoothing: antialiased;
}

/* ── top bar ─────────────────────────────────────────────────────────────── */
.__canvas-top {
  position: fixed;
  z-index: 40;
  top: 0;
  left: 0;
  right: 0;
  height: var(--__canvas-top);
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 0 10px;
  background: var(--__canvas-panel);
  border-bottom: 1px solid var(--__canvas-line);
  box-sizing: border-box;
  direction: ltr;
  font: 12px/1.4 Inter, "SF Pro Text", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  color: var(--__canvas-ink);
  user-select: none;
}
.__canvas-brand {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 6px;
  color: var(--__canvas-ink);
  text-decoration: none;
  flex: none;
}
.__canvas-brand:hover { background: var(--__canvas-panel-2); }
.__canvas-brand svg { display: block; }
.__canvas-sep {
  flex: none;
  width: 1px;
  height: 20px;
  margin: 0 6px;
  background: var(--__canvas-line);
}
.__canvas-tools { display: flex; align-items: center; gap: 2px; }
.__canvas-tool {
  appearance: none;
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  padding: 0;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--__canvas-mute);
  font: inherit;
  cursor: pointer;
}
.__canvas-tool:hover { background: var(--__canvas-panel-2); color: var(--__canvas-ink); }
.__canvas-tool[aria-pressed="true"] { background: var(--__canvas-accent); color: #ffffff; }
.__canvas-tool svg { display: block; }
.__canvas-file {
  max-width: 26ch;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--__canvas-mute);
  text-decoration: none;
  padding: 3px 4px;
  border-radius: 4px;
}
.__canvas-file:hover { color: var(--__canvas-ink); background: var(--__canvas-panel-2); }
.__canvas-crumb { color: var(--__canvas-faint); flex: none; }
.__canvas-page {
  max-width: 30ch;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
  color: var(--__canvas-ink);
  padding: 3px 4px;
}
.__canvas-grow { flex: 1; }
.__canvas-search {
  appearance: none;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 28px;
  padding: 0 9px;
  border: 1px solid var(--__canvas-line);
  border-radius: 6px;
  background: var(--__canvas-panel-2);
  color: var(--__canvas-mute);
  font: inherit;
  cursor: pointer;
}
.__canvas-search:hover { color: var(--__canvas-ink); background: var(--__canvas-panel-3); }
.__canvas-search svg { display: block; flex: none; }
.__canvas-search kbd {
  font: 10px/1 ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 2px 4px;
  border: 1px solid var(--__canvas-line);
  border-radius: 3px;
  color: var(--__canvas-faint);
}
.__canvas-count {
  flex: none;
  color: var(--__canvas-faint);
  font-size: 11px;
  padding: 0 4px;
}
.__canvas-iconbtn {
  appearance: none;
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  padding: 0;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--__canvas-mute);
  cursor: pointer;
}
.__canvas-iconbtn:hover { background: var(--__canvas-panel-2); color: var(--__canvas-ink); }
.__canvas-iconbtn svg { display: block; }
.__canvas-icon-moon { display: none; }
.__canvas-root[data-theme="light"] .__canvas-icon-sun { display: none; }
.__canvas-root[data-theme="light"] .__canvas-icon-moon { display: block; }
.__canvas-figma {
  flex: none;
  color: var(--__canvas-accent);
  text-decoration: none;
  padding: 4px 6px;
  border-radius: 4px;
  font-weight: 500;
}
.__canvas-figma:hover { background: var(--__canvas-accent-soft); }

/* ── left panel: pages above, layers below ───────────────────────────────── */
.__canvas-side {
  position: fixed;
  z-index: 30;
  top: var(--__canvas-top);
  left: 0;
  bottom: 0;
  width: var(--__canvas-side);
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  background: var(--__canvas-panel);
  border-right: 1px solid var(--__canvas-line);
  direction: ltr;
  font: 12px/1.4 Inter, "SF Pro Text", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  color: var(--__canvas-ink);
  user-select: none;
}
.__canvas-panel-head {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: none;
  padding: 10px 12px 6px;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.01em;
  color: var(--__canvas-mute);
}
.__canvas-panel-head span { margin-left: auto; font-weight: 400; color: var(--__canvas-faint); }
.__canvas-pages {
  flex: none;
  max-height: 34%;
  overflow: auto;
  overscroll-behavior: contain;
  margin: 0;
  padding: 0 6px 6px;
  list-style: none;
}
.__canvas-pages a {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 5px 8px;
  border-radius: 5px;
  color: var(--__canvas-ink);
  text-decoration: none;
  font-size: 12px;
  min-height: 26px;
  box-sizing: border-box;
}
.__canvas-pages a:hover { background: var(--__canvas-panel-2); }
.__canvas-pages a[aria-current="page"] { background: var(--__canvas-accent-soft); color: var(--__canvas-ink); font-weight: 500; }
.__canvas-pages svg { flex: none; color: var(--__canvas-mute); }
.__canvas-pages a[aria-current="page"] svg { color: var(--__canvas-accent); }
.__canvas-page-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.__canvas-page-count { margin-left: auto; font-size: 10px; color: var(--__canvas-faint); font-variant-numeric: tabular-nums; }
.__canvas-layers-head {
  border-top: 1px solid var(--__canvas-line);
  padding-top: 11px;
}
.__canvas-list {
  flex: 1;
  overflow: auto;
  overscroll-behavior: contain;
  margin: 0;
  padding: 0 6px 24px;
  list-style: none;
}
.__canvas-layer { margin: 0; padding: 0; }
.__canvas-line { display: flex; align-items: center; min-width: 0; }
.__canvas-caret {
  appearance: none;
  flex: none;
  display: grid;
  place-items: center;
  width: 16px;
  height: 26px;
  padding: 0;
  border: 0;
  border-radius: 3px;
  background: transparent;
  color: var(--__canvas-faint);
  cursor: pointer;
}
.__canvas-caret:hover { color: var(--__canvas-ink); background: var(--__canvas-panel-2); }
.__canvas-caret svg { display: block; transition: transform 0.12s ease; }
.__canvas-caret[aria-expanded="true"] svg { transform: rotate(90deg); }
.__canvas-caret-empty { cursor: default; pointer-events: none; }
.__canvas-row {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
  min-height: 26px;
  margin: 0;
  padding: 3px 6px 3px 2px;
  box-sizing: border-box;
  border: 0;
  border-radius: 5px;
  background: transparent;
  color: var(--__canvas-ink);
  font: inherit;
  text-align: left;
  text-decoration: none;
  cursor: default;
}
.__canvas-row:hover { background: var(--__canvas-panel-2); }
.__canvas-row[aria-current="true"], .__canvas-layer.__canvas-selected > .__canvas-line > .__canvas-row {
  background: var(--__canvas-accent);
  color: #ffffff;
}
.__canvas-row-icon { flex: none; display: grid; place-items: center; width: 12px; height: 12px; color: var(--__canvas-mute); }
.__canvas-row[aria-current="true"] .__canvas-row-icon, .__canvas-layer.__canvas-selected > .__canvas-line > .__canvas-row-icon { color: #ffffff; }
.__canvas-row-icon svg { display: block; }
.__canvas-row-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; min-width: 0; }
.__canvas-row-size {
  flex: none;
  font-size: 10px;
  line-height: 1;
  color: var(--__canvas-faint);
  font-variant-numeric: tabular-nums;
  opacity: 0;
}
.__canvas-line:hover .__canvas-row-size { opacity: 1; }
.__canvas-row[aria-current="true"] .__canvas-row-size, .__canvas-layer.__canvas-selected > .__canvas-line > .__canvas-row-size { color: rgba(255, 255, 255, 0.8); opacity: 1; }
.__canvas-children { list-style: none; margin: 0; padding: 0 0 0 12px; }
.__canvas-children[hidden] { display: none; }
.__canvas-hidden-layer .__canvas-row-name { color: var(--__canvas-faint); }
.__canvas-eye { flex: none; display: grid; place-items: center; color: var(--__canvas-faint); }
.__canvas-eye svg { display: block; }
.__canvas-side-note { padding: 6px 9px; font-size: 11px; color: var(--__canvas-faint); }

/* ── the canvas viewport ─────────────────────────────────────────────────── */
/* Without the script the viewport scrolls and the frames are simply placed.
   With it, the camera owns the transform and the viewport never scrolls. */
.__canvas-vp {
  position: fixed;
  z-index: 1;
  top: var(--__canvas-top);
  left: var(--__canvas-side);
  right: 0;
  bottom: 0;
  overflow: auto;
  display: grid;
  box-sizing: border-box;
  direction: ltr;
  background: var(--__canvas-bg);
  overscroll-behavior: contain;
  outline: none;
}
.__canvas-vp:focus-visible { outline: 2px solid var(--__canvas-accent); outline-offset: -2px; }
.__canvas-sizer { margin: auto; position: relative; }
.__canvas-plane { position: absolute; top: 0; left: 0; transform-origin: 0 0; contain: layout style; }
.__canvas-js .__canvas-vp {
  overflow: hidden;
  display: block;
  touch-action: none;
  cursor: default;
}
.__canvas-js .__canvas-inspect { display: flex; }
.__canvas-js .__canvas-vp { right: var(--__canvas-inspect); }
.__canvas-js .__canvas-sizer { margin: 0; }

/* ── frames ──────────────────────────────────────────────────────────────── */
.__canvas-item {
  position: absolute;
  contain: layout style;
  outline-color: transparent;
  outline-style: solid;
  outline-width: calc(1px * var(--__canvas-inv, 1));
  outline-offset: 0;
}
.__canvas-item:hover { outline-color: rgba(13, 153, 255, 0.7); }
.__canvas-item.__canvas-selected { outline-color: var(--__canvas-accent); }
/* Below the LOD threshold frame bodies are detached for speed. The frame's
   own fill keeps the overview readable instead of leaving holes in the canvas. */
.__canvas-item.__canvas-lod {
  background-color: rgba(255, 255, 255, 0.055);
  outline-color: rgba(255, 255, 255, 0.1);
}
.__canvas-root[data-theme="light"] .__canvas-item.__canvas-lod {
  background-color: rgba(0, 0, 0, 0.055);
  outline-color: rgba(0, 0, 0, 0.1);
}
.__canvas-name {
  position: absolute;
  z-index: 3;
  left: 0;
  bottom: 100%;
  margin-bottom: calc(7px * var(--__canvas-inv, 1));
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  direction: ltr;
  font: 500 11px/1.2 Inter, "SF Pro Text", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  color: var(--__canvas-mute);
  text-shadow: 0 0 3px var(--__canvas-label-shadow), 0 0 3px var(--__canvas-label-shadow);
  transform: scale(var(--__canvas-inv, 1));
  transform-origin: left bottom;
  pointer-events: none;
  user-select: none;
}
.__canvas-item:hover .__canvas-name { color: var(--__canvas-accent); }
.__canvas-item.__canvas-selected .__canvas-name, .__canvas-item.__canvas-active .__canvas-name { color: var(--__canvas-accent); }
.__canvas-hit {
  position: absolute;
  inset: calc(-26px * var(--__canvas-inv, 1)) 0 0 0;
  z-index: 2;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.__canvas-body {
  position: absolute;
  inset: 0;
  overflow: hidden;
  pointer-events: none;
}
.__canvas-lod .__canvas-body { box-shadow: inset 0 0 0 calc(1px * var(--__canvas-inv, 1)) rgba(127, 127, 127, 0.32); }
.__canvas-lowzoom .__canvas-name { display: none; }
.__canvas-vp.__canvas-hand { cursor: grab; }
.__canvas-vp.__canvas-grabbing, .__canvas-grabbing .__canvas-hit { cursor: grabbing; }
.__canvas-hand .__canvas-hit { cursor: grab; }
.__canvas-vp.__canvas-hand .__canvas-hit { cursor: grab; }

/* ── selection ───────────────────────────────────────────────────────────── */
.__canvas-sel {
  position: absolute;
  z-index: 5;
  box-sizing: border-box;
  border: calc(1px * var(--__canvas-inv, 1)) solid var(--__canvas-accent);
  pointer-events: none;
}
.__canvas-sel[hidden] { display: none; }
.__canvas-sel-frame { border-width: calc(1px * var(--__canvas-inv, 1)); }
.__canvas-sel-handle {
  position: absolute;
  width: calc(7px * var(--__canvas-inv, 1));
  height: calc(7px * var(--__canvas-inv, 1));
  box-sizing: border-box;
  background: #ffffff;
  border: calc(1px * var(--__canvas-inv, 1)) solid var(--__canvas-accent);
}
.__canvas-sel-handle-nw { left: calc(-3.5px * var(--__canvas-inv, 1)); top: calc(-3.5px * var(--__canvas-inv, 1)); }
.__canvas-sel-handle-ne { right: calc(-3.5px * var(--__canvas-inv, 1)); top: calc(-3.5px * var(--__canvas-inv, 1)); }
.__canvas-sel-handle-sw { left: calc(-3.5px * var(--__canvas-inv, 1)); bottom: calc(-3.5px * var(--__canvas-inv, 1)); }
.__canvas-sel-handle-se { right: calc(-3.5px * var(--__canvas-inv, 1)); bottom: calc(-3.5px * var(--__canvas-inv, 1)); }
.__canvas-sel-tag {
  position: absolute;
  left: 50%;
  top: 100%;
  margin-top: calc(6px * var(--__canvas-inv, 1));
  transform: translateX(-50%) scale(var(--__canvas-inv, 1));
  transform-origin: center top;
  display: block;
  max-width: 60vw;
  padding: 2px 5px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  border-radius: calc(3px * var(--__canvas-inv, 1));
  background: var(--__canvas-accent);
  color: #ffffff;
  font: 500 10px/1.3 Inter, "SF Pro Text", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
}
.__canvas-marquee {
  position: absolute;
  z-index: 6;
  box-sizing: border-box;
  border: calc(1px * var(--__canvas-inv, 1)) solid var(--__canvas-accent);
  background: rgba(13, 153, 255, 0.08);
  pointer-events: none;
}
.__canvas-marquee[hidden] { display: none; }

/* ── inspector ───────────────────────────────────────────────────────────── */
.__canvas-inspect {
  position: fixed;
  z-index: 30;
  top: var(--__canvas-top);
  right: 0;
  bottom: 0;
  width: var(--__canvas-inspect);
  display: none;
  flex-direction: column;
  box-sizing: border-box;
  background: var(--__canvas-panel);
  border-left: 1px solid var(--__canvas-line);
  direction: ltr;
  font: 12px/1.4 Inter, "SF Pro Text", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  color: var(--__canvas-ink);
  overflow: auto;
  user-select: none;
}
.__canvas-inspect-empty { display: flex; flex-direction: column; align-items: center; justify-content: center; flex: 1; gap: 8px; padding: 24px 20px; text-align: center; color: var(--__canvas-faint); }
.__canvas-inspect-empty[hidden] { display: none; }
.__canvas-inspect-empty svg { color: var(--__canvas-panel-3); }
.__canvas-inspect-title { margin: 0; font-size: 12px; color: var(--__canvas-mute); }
.__canvas-inspect-hint { margin: 0; font-size: 11px; line-height: 1.5; color: var(--__canvas-faint); }
.__canvas-inspect-body { padding: 14px 12px 20px; }
.__canvas-inspect-body[hidden] { display: none; }
.__canvas-inspect-head { padding: 2px 2px 12px; border-bottom: 1px solid var(--__canvas-line-soft); margin-bottom: 12px; }
.__canvas-inspect-kind { font-size: 10px; letter-spacing: 0.06em; text-transform: uppercase; color: var(--__canvas-faint); }
.__canvas-inspect-name { margin-top: 3px; font-size: 13px; font-weight: 600; color: var(--__canvas-ink); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.__canvas-inspect-section { margin: 0 0 14px; }
.__canvas-inspect-section[hidden] { display: none; }
.__canvas-inspect-heading { margin: 0 0 6px; font-size: 10px; font-weight: 500; color: var(--__canvas-faint); }
.__canvas-fields { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.__canvas-field {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 26px;
  padding: 0 7px;
  box-sizing: border-box;
  border: 1px solid var(--__canvas-line);
  border-radius: 4px;
  background: var(--__canvas-panel-2);
  font-size: 11px;
  font-variant-numeric: tabular-nums;
  color: var(--__canvas-ink);
  overflow: hidden;
}
.__canvas-field span { flex: none; color: var(--__canvas-faint); font-size: 10px; }
.__canvas-field b { font-weight: 400; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.__canvas-swatch {
  width: 14px;
  height: 14px;
  flex: none;
  border-radius: 3px;
  border: 1px solid rgba(127, 127, 127, 0.45);
  box-sizing: border-box;
  background-image: linear-gradient(45deg, rgba(127, 127, 127, 0.35) 25%, transparent 25%, transparent 75%, rgba(127, 127, 127, 0.35) 75%), linear-gradient(45deg, rgba(127, 127, 127, 0.35) 25%, transparent 25%, transparent 75%, rgba(127, 127, 127, 0.35) 75%);
  background-size: 8px 8px;
  background-position: 0 0, 4px 4px;
}
.__canvas-fill {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 28px;
  padding: 0 8px;
  border: 1px solid var(--__canvas-line);
  border-radius: 4px;
  background: var(--__canvas-panel-2);
  font: 11px/1 ui-monospace, SFMono-Regular, Menlo, monospace;
  color: var(--__canvas-mute);
}
.__canvas-text-preview {
  margin: 0;
  padding: 8px;
  max-height: 110px;
  overflow: auto;
  border: 1px solid var(--__canvas-line);
  border-radius: 4px;
  background: var(--__canvas-panel-2);
  font-size: 11px;
  line-height: 1.5;
  color: var(--__canvas-mute);
  white-space: pre-wrap;
  word-break: break-word;
}
.__canvas-open {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 30px;
  margin-top: 4px;
  border-radius: 6px;
  background: var(--__canvas-accent);
  color: #ffffff;
  text-decoration: none;
  font-weight: 500;
  font-size: 12px;
}
.__canvas-open:hover { filter: brightness(1.08); }
.__canvas-open[hidden] { display: none; }
.__canvas-open svg { display: block; }
.__canvas-inspect-note {
  margin: 10px 2px 0;
  font-size: 11px;
  line-height: 1.5;
  color: var(--__canvas-faint);
}

/* ── HUD, minimap, palette ───────────────────────────────────────────────── */
.__canvas-hud {
  position: fixed;
  z-index: 35;
  right: 16px;
  bottom: 16px;
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 3px;
  box-sizing: border-box;
  background: var(--__canvas-panel);
  border: 1px solid var(--__canvas-line);
  border-radius: 8px;
  box-shadow: var(--__canvas-shadow);
  direction: ltr;
  font: 11px/1.4 Inter, "SF Pro Text", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  color: var(--__canvas-mute);
}
.__canvas-js .__canvas-hud { right: calc(var(--__canvas-inspect) + 16px); }
.__canvas-hud button {
  appearance: none;
  min-width: 26px;
  height: 26px;
  padding: 0 7px;
  border: 0;
  border-radius: 5px;
  background: transparent;
  color: inherit;
  font: inherit;
  cursor: pointer;
}
.__canvas-hud button:hover { background: var(--__canvas-panel-2); color: var(--__canvas-ink); }
.__canvas-hud button:active { background: var(--__canvas-panel-3); }
.__canvas-hud .__canvas-sep { height: 14px; margin: 0 2px; background: var(--__canvas-line); }
.__canvas-hud .__canvas-zoom { min-width: 48px; font-variant-numeric: tabular-nums; color: var(--__canvas-ink); }
.__canvas-mini {
  position: fixed;
  z-index: 34;
  left: calc(var(--__canvas-side) + 16px);
  bottom: 16px;
  padding: 6px;
  box-sizing: border-box;
  background: var(--__canvas-panel);
  border: 1px solid var(--__canvas-line);
  border-radius: 8px;
  box-shadow: var(--__canvas-shadow);
  line-height: 0;
}
.__canvas-mini canvas { display: block; border-radius: 4px; cursor: pointer; touch-action: none; }
.__canvas-mini-off { display: none; }
.__canvas-palette {
  position: fixed;
  top: 64px;
  left: 50%;
  margin: 0;
  transform: translateX(-50%);
  width: min(560px, calc(100vw - 48px));
  max-height: calc(100vh - 96px);
  padding: 0;
  border: 1px solid var(--__canvas-line);
  border-radius: 10px;
  background: var(--__canvas-panel);
  color: var(--__canvas-ink);
  font: 13px/1.5 Inter, "SF Pro Text", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  direction: ltr;
  box-shadow: var(--__canvas-shadow);
}
/* Figma floats the palette over the canvas; a dimmed backdrop would make the
   design being searched look selected. No scrim — only the panel. */
.__canvas-q {
  display: block;
  width: 100%;
  margin: 0;
  padding: 13px 15px;
  box-sizing: border-box;
  border: 0;
  border-bottom: 1px solid var(--__canvas-line);
  border-radius: 10px 10px 0 0;
  background: transparent;
  color: inherit;
  font: inherit;
  outline: none;
}
.__canvas-q::placeholder { color: var(--__canvas-faint); }
.__canvas-results { max-height: 330px; overflow: auto; margin: 0; padding: 4px; list-style: none; }
.__canvas-results li {
  display: flex;
  align-items: baseline;
  gap: 10px;
  padding: 7px 9px;
  border-radius: 6px;
  cursor: pointer;
}
.__canvas-results li[aria-selected="true"] { background: var(--__canvas-accent-soft); }
.__canvas-result-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.__canvas-result-sub { margin-left: auto; font-size: 11px; color: var(--__canvas-faint); white-space: nowrap; }
.__canvas-empty { color: var(--__canvas-faint); cursor: default; }
.__canvas-hint {
  margin: 0;
  padding: 8px 12px;
  border-top: 1px solid var(--__canvas-line);
  border-radius: 0 0 10px 10px;
  font-size: 11px;
  color: var(--__canvas-faint);
}
.__canvas-hint kbd {
  font: 10px/1 ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 1px 4px;
  border: 1px solid var(--__canvas-line);
  border-radius: 3px;
  background: var(--__canvas-panel-2);
  color: var(--__canvas-mute);
}

/* ── focus ───────────────────────────────────────────────────────────────── */
.__canvas-brand:focus-visible,
.__canvas-tool:focus-visible,
.__canvas-file:focus-visible,
.__canvas-search:focus-visible,
.__canvas-iconbtn:focus-visible,
.__canvas-figma:focus-visible,
.__canvas-pages a:focus-visible,
.__canvas-caret:focus-visible,
.__canvas-row:focus-visible,
.__canvas-hud button:focus-visible,
.__canvas-open:focus-visible {
  outline: 2px solid var(--__canvas-accent);
  outline-offset: 1px;
}

/* ── narrow windows: the archive stays usable, the panels give way ────────── */
@media (max-width: 1180px) {
  .__canvas-js .__canvas-vp { right: 0; }
  .__canvas-js .__canvas-hud { right: 16px; }
  .__canvas-inspect { display: none !important; }
}
@media (max-width: 820px) {
  .__canvas-root { --__canvas-side: 0px; }
  .__canvas-side { display: none; }
  .__canvas-mini { left: 16px; }
  .__canvas-search kbd { display: none; }
  .__canvas-file, .__canvas-crumb { display: none; }
}
`;

/**
 * The canvas script.
 *
 * The camera is the whole performance story. Scroll-based canvases have to
 * resize a "sizer" on every zoom and let the browser lay the page out again;
 * this one keeps a single transform and never lays out a frame to move the
 * camera. Frames themselves are mounted lazily: their markup is lifted out of
 * the document at boot and only put back when the frame is near the viewport.
 *
 * The script also owns selection, the layers tree, the inspector, the minimap
 * and the palette. Everything it needs is in the document as data or in
 * `window.__CANVAS_NAV`; it never fetches, so the archive works from file://.
 *
 * The page still works without it: frames are laid out by CSS and every frame
 * link is a real link. The script only adds the camera and the chrome around
 * them.
 */
export const CANVAS_SCRIPT = `(function () {
  var root = document.documentElement;
  var vp = document.getElementById('__canvas-vp');
  var plane = document.getElementById('__canvas-plane');
  var sizer = document.getElementById('__canvas-sizer');
  var readout = document.getElementById('__canvas-zoom');
  var handBtn = document.getElementById('__canvas-hand');
  var selectBtn = document.querySelector('[data-act="select"]');
  var themeBtn = document.getElementById('__canvas-theme');
  var mini = document.getElementById('__canvas-mini');
  var miniC = document.getElementById('__canvas-mini-c');
  var miniCtx = miniC && miniC.getContext ? miniC.getContext('2d') : null;
  var selBox = document.getElementById('__canvas-sel');
  var selTag = document.getElementById('__canvas-sel-tag');
  var marqueeEl = document.getElementById('__canvas-marquee');
  if (!vp || !plane || !readout) return;

  var MIN = 0.02;
  var MAX = 4;
  var LOD = 0.16;
  var SMALL_PAGE = 8;
  var MAX_MOUNTED = 48;
  var MAX_CHILD_ROWS = 250;

  var W = Number(plane.getAttribute('data-w')) || 1;
  var H = Number(plane.getAttribute('data-h')) || 1;
  var pageSlug = document.body.getAttribute('data-page') || '';
  var nav = window.__CANVAS_NAV || null;

  root.classList.add('__canvas-js');
  if (sizer) {
    sizer.style.width = '0px';
    sizer.style.height = '0px';
  }

  var cam = { x: 0, y: 0, k: 1 };
  var fitK = 1;
  var viewW = 1;
  var viewH = 1;
  var vpRect = null;

  function measure() {
    viewW = vp.clientWidth || 1;
    viewH = vp.clientHeight || 1;
    vpRect = null;
  }

  function viewportBox() {
    if (!vpRect) vpRect = vp.getBoundingClientRect();
    return vpRect;
  }

  function clamp(value, lo, hi) {
    if (!isFinite(value)) return lo;
    return value < lo ? lo : value > hi ? hi : value;
  }

  // ── frames ───────────────────────────────────────────────────────────────
  var layerData = {};
  var layerJson = document.getElementById('__canvas-layers');
  if (layerJson) {
    try {
      var parsedLayers = JSON.parse(layerJson.textContent || '{}');
      layerData = (parsedLayers && parsedLayers.frames) || {};
    } catch (err) {
      layerData = {};
    }
  }

  var rowBySlug = {};
  var rowLinks = document.querySelectorAll('.__canvas-list a[data-goto]');
  for (var r0 = 0; r0 < rowLinks.length; r0++) {
    rowBySlug[rowLinks[r0].getAttribute('data-goto')] = rowLinks[r0];
  }

  var frames = [];
  var bySlug = {};
  var els = plane.querySelectorAll('.__canvas-item');
  for (var i = 0; i < els.length; i++) {
    var el = els[i];
    var body = el.querySelector('.__canvas-body');
    if (!body) continue;
    var kids = [];
    while (body.firstChild) kids.push(body.removeChild(body.firstChild));
    el.classList.add('__canvas-lod');
    var slug = el.getAttribute('data-slug') || '';
    var row = rowBySlug[slug] || null;
    var f = {
      el: el,
      body: body,
      kids: kids,
      slug: slug,
      name: el.getAttribute('data-name') || slug,
      bg: el.getAttribute('data-bg') || '',
      fill: '',
      x: Number(el.getAttribute('data-x')) || 0,
      y: Number(el.getAttribute('data-y')) || 0,
      px: Number(el.getAttribute('data-fx')) || 0,
      py: Number(el.getAttribute('data-fy')) || 0,
      w: Number(el.getAttribute('data-w')) || 0,
      h: Number(el.getAttribute('data-h')) || 0,
      on: false,
      layers: layerData[slug] || null,
      row: row,
      rowLi: row ? row.closest('.__canvas-layer') : null
    };
    frames.push(f);
    bySlug[slug] = f;
    if (f.rowLi) {
      f.rowLi.__canvasLayer = f.layers;
      f.rowLi.__canvasFrame = f;
    }
  }

  function frameAt(slug) {
    return bySlug[slug] || null;
  }

  function mount(f, on) {
    if (f.on === on) return;
    f.on = on;
    if (on) {
      f.body.append.apply(f.body, f.kids);
      f.el.classList.remove('__canvas-lod');
      f.el.style.backgroundColor = '';
    } else {
      f.body.replaceChildren();
      f.el.classList.add('__canvas-lod');
      f.el.style.backgroundColor = f.fill || '';
    }
  }

  // ── camera ───────────────────────────────────────────────────────────────
  function view() {
    var k = cam.k;
    return {
      l: -cam.x / k,
      t: -cam.y / k,
      r: (-cam.x + viewW) / k,
      b: (-cam.y + viewH) / k,
      vw: viewW,
      vh: viewH
    };
  }

  function applyCamera() {
    plane.style.transform = 'translate3d(' + cam.x + 'px,' + cam.y + 'px,0) scale(' + cam.k + ')';
    plane.style.setProperty('--__canvas-inv', String(1 / cam.k));
    readout.textContent = Math.round(cam.k * 100) + '%';
  }

  var updateQueued = false;
  function requestUpdate() {
    if (updateQueued) return;
    updateQueued = true;
    requestAnimationFrame(function () {
      updateQueued = false;
      update();
    });
  }

  function update() {
    var v = view();
    var map = miniWanted(v);
    if (mini) mini.classList.toggle('__canvas-mini-off', !map);
    root.classList.toggle('__canvas-lowzoom', cam.k < 0.22);
    if (map) drawMini(v);
    if (!frames.length) return;

    if (frames.length > SMALL_PAGE && cam.k < LOD) {
      for (var a = 0; a < frames.length; a++) mount(frames[a], false);
      return;
    }

    var padX = (v.r - v.l) * 0.6;
    var padY = (v.b - v.t) * 0.6;
    var l = v.l - padX;
    var rr = v.r + padX;
    var t = v.t - padY;
    var b = v.b + padY;
    var kl = v.l - padX * 3;
    var kr = v.r + padX * 3;
    var kt = v.t - padY * 3;
    var kb = v.b + padY * 3;

    var want = [];
    for (var j = 0; j < frames.length; j++) {
      var fr = frames[j];
      if (fr.x < rr && fr.x + fr.w > l && fr.y < b && fr.y + fr.h > t) {
        want.push(fr);
      } else if (fr.on && !(fr.x < kr && fr.x + fr.w > kl && fr.y < kb && fr.y + fr.h > kt)) {
        mount(fr, false);
      }
    }

    if (want.length > MAX_MOUNTED) {
      var cx = (v.l + v.r) / 2;
      var cy = (v.t + v.b) / 2;
      want.sort(function (a, c) {
        var da = Math.abs(a.x + a.w / 2 - cx) + Math.abs(a.y + a.h / 2 - cy);
        var dc = Math.abs(c.x + c.w / 2 - cx) + Math.abs(c.y + c.h / 2 - cy);
        return da - dc;
      });
      for (var k2 = MAX_MOUNTED; k2 < want.length; k2++) mount(want[k2], false);
      want.length = MAX_MOUNTED;
    }
    for (var m = 0; m < want.length; m++) mount(want[m], true);
  }

  // ── minimap ──────────────────────────────────────────────────────────────
  var MINI_W = 168;
  var miniW = 0;
  var miniH = 0;
  var miniScale = 1;
  var miniOx = 0;
  var miniOy = 0;
  var miniBase = null;

  function lightTheme() {
    return root.getAttribute('data-theme') === 'light';
  }

  // A frame fill can be a var(--token) reference. The browser resolves that for
  // the DOM, but a 2D canvas would silently fall back to black, so the minimap
  // gets the computed colour on the few occasions it redraws its base — never
  // per frame during a scroll.
  var miniProbe = null;
  function resolvePaint(value) {
    if (!value) return '';
    if (value.indexOf('var(') < 0) return value;
    if (!miniProbe) {
      miniProbe = document.createElement('span');
      miniProbe.style.cssText =
        'position:absolute;left:-9999px;top:-9999px;width:0;height:0;pointer-events:none;';
      document.body.appendChild(miniProbe);
    }
    miniProbe.style.background = value;
    var paint = getComputedStyle(miniProbe).backgroundColor;
    miniProbe.style.background = '';
    return paint && paint !== 'rgba(0, 0, 0, 0)' ? paint : '';
  }

  function buildMini() {
    if (!miniCtx || !miniC) return;
    var dpr = Math.min(2, window.devicePixelRatio || 1);
    miniW = MINI_W;
    miniH = Math.round(Math.max(60, Math.min(124, (MINI_W * H) / W)));
    miniC.style.width = miniW + 'px';
    miniC.style.height = miniH + 'px';
    miniC.width = Math.round(miniW * dpr);
    miniC.height = Math.round(miniH * dpr);
    miniCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    miniCtx.clearRect(0, 0, miniW, miniH);

    miniScale = Math.min(miniW / W, miniH / H);
    miniOx = (miniW - W * miniScale) / 2;
    miniOy = (miniH - H * miniScale) / 2;

    var base = document.createElement('canvas');
    base.width = miniC.width;
    base.height = miniC.height;
    var ctx = base.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var fallback = lightTheme() ? '#e4e4e4' : '#3a3a3a';
    var stroke = lightTheme() ? 'rgba(0, 0, 0, 0.12)' : 'rgba(255, 255, 255, 0.12)';

    for (var i = 0; i < frames.length; i++) {
      var f = frames[i];
      var x = miniOx + f.x * miniScale;
      var y = miniOy + f.y * miniScale;
      var w = Math.max(1, f.w * miniScale);
      var h = Math.max(1, f.h * miniScale);
      ctx.fillStyle = resolvePaint(f.bg) || fallback;
      ctx.fillRect(x, y, w, h);
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 0.5;
      ctx.strokeRect(x + 0.25, y + 0.25, Math.max(0.5, w - 0.5), Math.max(0.5, h - 0.5));
    }
    miniBase = base;
  }

  function drawMini(v) {
    if (!miniCtx || !miniBase) return;
    miniCtx.clearRect(0, 0, miniW, miniH);
    miniCtx.drawImage(miniBase, 0, 0, miniW, miniH);

    if (selection.frame) {
      var f = selection.frame;
      miniCtx.strokeStyle = '#0d99ff';
      miniCtx.lineWidth = 1;
      miniCtx.strokeRect(
        miniOx + f.x * miniScale + 0.5,
        miniOy + f.y * miniScale + 0.5,
        Math.max(1, f.w * miniScale - 1),
        Math.max(1, f.h * miniScale - 1)
      );
    }

    var x = miniOx + v.l * miniScale;
    var y = miniOy + v.t * miniScale;
    var w = (v.r - v.l) * miniScale;
    var h = (v.b - v.t) * miniScale;
    miniCtx.fillStyle = 'rgba(13, 153, 255, 0.16)';
    miniCtx.fillRect(x, y, w, h);
    miniCtx.strokeStyle = '#0d99ff';
    miniCtx.lineWidth = 1;
    miniCtx.strokeRect(x + 0.5, y + 0.5, Math.max(1, w - 1), Math.max(1, h - 1));
  }

  function miniWanted(v) {
    return frames.length > 0 && (W * cam.k > v.vw * 1.02 || H * cam.k > v.vh * 1.02);
  }

  function centerPlaneAt(px, py) {
    cam.x = viewW / 2 - px * cam.k;
    cam.y = viewH / 2 - py * cam.k;
    applyCamera();
    requestUpdate();
  }

  if (miniC) {
    var miniDrag = false;
    var miniJump = function (e) {
      var box = miniC.getBoundingClientRect();
      centerPlaneAt(
        (e.clientX - box.left - miniOx) / miniScale,
        (e.clientY - box.top - miniOy) / miniScale
      );
    };
    miniC.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      miniDrag = true;
      try { miniC.setPointerCapture(e.pointerId); } catch (err) {}
      miniJump(e);
    });
    miniC.addEventListener('pointermove', function (e) {
      if (miniDrag) miniJump(e);
    });
    miniC.addEventListener('pointerup', function () { miniDrag = false; });
    miniC.addEventListener('pointercancel', function () { miniDrag = false; });
  }

  // ── zoom and fit ─────────────────────────────────────────────────────────
  function zoomAt(next, vx, vy) {
    next = clamp(next, MIN, MAX);
    if (vx === undefined) vx = viewW / 2;
    if (vy === undefined) vy = viewH / 2;
    var wx = (vx - cam.x) / cam.k;
    var wy = (vy - cam.y) / cam.k;
    cam.k = next;
    cam.x = vx - wx * next;
    cam.y = vy - wy * next;
    applyCamera();
    requestUpdate();
  }

  function fit() {
    var pad = 72;
    var s = Math.min((viewW - pad * 2) / W, (viewH - pad * 2) / H, 1);
    fitK = Math.max(MIN, s);
    cam.k = fitK;
    cam.x = (viewW - W * fitK) / 2;
    cam.y = (viewH - H * fitK) / 2;
    applyCamera();
    requestUpdate();
  }

  // ── selection ────────────────────────────────────────────────────────────
  var selection = { frames: [], frame: null, layer: null, path: null };
  var TOP_ICON = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><path d="M3.5 1v10M8.5 1v10M1 3.5h10M1 8.5h10"/></svg>';

  function isSelectedFrame(f) {
    for (var i = 0; i < selection.frames.length; i++) {
      if (selection.frames[i] === f) return true;
    }
    return false;
  }

  function hashSlug() {
    var h = (location.hash || '').replace(/^#/, '');
    try { return decodeURIComponent(h); } catch (err) { return h; }
  }

  function writeHash(slug) {
    if (!window.history || !history.replaceState) return;
    try { history.replaceState(null, '', '#' + slug); } catch (err) {}
  }

  function placeSelection() {
    if (!selBox) return;
    if (selection.frames.length !== 1) {
      selBox.hidden = true;
      return;
    }
    var f = selection.frame;
    var l = selection.layer;
    var x = f.x + (l ? l.x : 0);
    var y = f.y + (l ? l.y : 0);
    var w = l ? l.width : f.w;
    var h = l ? l.height : f.h;
    if (!(w > 0)) w = 1;
    if (!(h > 0)) h = 1;
    selBox.hidden = false;
    selBox.style.left = x + 'px';
    selBox.style.top = y + 'px';
    selBox.style.width = w + 'px';
    selBox.style.height = h + 'px';
    if (selTag) {
      selTag.textContent = (l ? l.name : f.name) + '  ' + Math.round(w) + ' × ' + Math.round(h);
    }
  }

  function findLayer(node, id, chain) {
    if (!node) return null;
    var path = chain.concat([node]);
    if (node.id === id) return { layer: node, path: path };
    var kids = node.children || [];
    for (var i = 0; i < kids.length; i++) {
      var found = findLayer(kids[i], id, path);
      if (found) return found;
    }
    return null;
  }

  // Topmost leaf under a canvas point, walking children back to front. Returns
  // the frame's own layer when the point is inside the frame but on no child.
  function deepestAt(f, px, py) {
    if (!f.layers) return null;
    var rootLayer = f.layers;
    var found = null;
    function inside(node) {
      return px >= node.x && py >= node.y && px <= node.x + node.width && py <= node.y + node.height;
    }
    function walk(node, chain) {
      if (found) return;
      if (node.visible === false) return;
      var path = chain.concat([node]);
      var kids = node.children || [];
      for (var i = kids.length - 1; i >= 0; i--) {
        if (inside(kids[i])) {
          walk(kids[i], path);
          if (found) return;
        }
      }
      if (node !== rootLayer) found = { layer: node, path: path };
    }
    walk(rootLayer, []);
    return found;
  }

  // ── layers panel ─────────────────────────────────────────────────────────
  var ICONS = {
    frame: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><path d="M3.5 1v10M8.5 1v10M1 3.5h10M1 8.5h10"/></svg>',
    group: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><path d="M1.5 3.5h3l1-1.5h4.5v7h-8.5z"/></svg>',
    component: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><path d="M6 1.2l4.8 4.8L6 10.8 1.2 6z"/></svg>',
    instance: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><path d="M6 1.2l4.8 4.8L6 10.8 1.2 6z"/><path d="M6 3.4l2.6 2.6L6 8.6 3.4 6z"/></svg>',
    text: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><path d="M2 2.2h8M6 2.2v7.6M4.4 9.8h3.2"/></svg>',
    image: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><rect x="1.5" y="2.5" width="9" height="7" rx="1"/><path d="M1.5 8l2.5-2 2 1.5 2-2 2.5 2"/></svg>',
    vector: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><path d="M2 9l3-6 5 3-3 4z"/></svg>',
    ellipse: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><circle cx="6" cy="6" r="4.5"/></svg>',
    rectangle: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><rect x="1.5" y="2.5" width="9" height="7" rx="1"/></svg>',
    layer: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><rect x="2" y="2" width="8" height="8" rx="1.5"/></svg>',
    eyeoff: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><path d="M1.5 6s1.6-2.8 4.5-2.8S10.5 6 10.5 6 8.9 8.8 6 8.8 1.5 6 1.5 6z"/><path d="M1.5 1.5l9 9"/></svg>'
  };

  function iconKey(type) {
    var t = String(type || '').toUpperCase();
    if (t === 'FRAME' || t === 'SECTION') return 'frame';
    if (t === 'GROUP') return 'group';
    if (t === 'COMPONENT' || t === 'COMPONENT_SET') return 'component';
    if (t === 'INSTANCE') return 'instance';
    if (t === 'TEXT') return 'text';
    if (t === 'IMAGE') return 'image';
    if (t === 'ELLIPSE') return 'ellipse';
    if (t === 'RECTANGLE') return 'rectangle';
    if (t === 'VECTOR' || t === 'LINE' || t === 'STAR' || t === 'POLYGON' || t === 'BOOLEAN_OPERATION') return 'vector';
    return 'layer';
  }

  function makeCaret() {
    var caret = document.createElement('button');
    caret.type = 'button';
    caret.className = '__canvas-caret';
    caret.setAttribute('aria-expanded', 'false');
    caret.setAttribute('aria-label', 'Show layers');
    caret.innerHTML = '<svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 2l3.5 3-3.5 3"/></svg>';
    return caret;
  }

  function makeLayerRow(f, layer) {
    var li = document.createElement('li');
    li.className = '__canvas-layer';
    li.__canvasLayer = layer;
    li.__canvasFrame = f;

    var line = document.createElement('div');
    line.className = '__canvas-line';

    var kids = layer.children || [];
    var caret = kids.length ? makeCaret() : document.createElement('span');
    if (!kids.length) {
      caret.className = '__canvas-caret __canvas-caret-empty';
      caret.setAttribute('aria-hidden', 'true');
    }

    var row = document.createElement('button');
    row.type = 'button';
    row.className = '__canvas-row __canvas-row-btn';
    row.setAttribute('data-select-layer', layer.id);
    row.setAttribute('data-frame', f.slug);
    row.title = layer.name;

    var icon = document.createElement('span');
    icon.className = '__canvas-row-icon';
    icon.innerHTML = ICONS[iconKey(layer.type)] || ICONS.layer;

    var name = document.createElement('span');
    name.className = '__canvas-row-name';
    name.textContent = layer.name;

    var size = document.createElement('span');
    size.className = '__canvas-row-size';
    size.textContent = Math.round(layer.width) + '×' + Math.round(layer.height);

    row.appendChild(icon);
    row.appendChild(name);
    row.appendChild(size);

    if (layer.visible === false) {
      li.classList.add('__canvas-hidden-layer');
      var eye = document.createElement('span');
      eye.className = '__canvas-eye';
      eye.title = 'Hidden in Figma';
      eye.innerHTML = ICONS.eyeoff;
      row.appendChild(eye);
    }

    line.appendChild(caret);
    line.appendChild(row);
    li.appendChild(line);

    if (kids.length) {
      var childList = document.createElement('ul');
      childList.className = '__canvas-children';
      childList.hidden = true;
      li.appendChild(childList);
    }
    return li;
  }

  function childListOf(li) {
    var ulEl = li.querySelector('.__canvas-children');
    return ulEl || null;
  }

  function toggleLayer(li, on) {
    if (!li) return;
    var ulEl = childListOf(li);
    if (!ulEl) return;
    var caret = li.querySelector('.__canvas-caret');
    if (on && ulEl.getAttribute('data-built') !== '1') {
      var node = li.__canvasLayer;
      var f = li.__canvasFrame;
      var kids = (node && node.children) || [];
      for (var i = 0; i < kids.length && i < MAX_CHILD_ROWS; i++) {
        ulEl.appendChild(makeLayerRow(f, kids[i]));
      }
      if (kids.length > MAX_CHILD_ROWS) {
        var more = document.createElement('li');
        more.className = '__canvas-side-note';
        more.textContent = '+' + (kids.length - MAX_CHILD_ROWS) + ' more layers';
        ulEl.appendChild(more);
      }
      ulEl.setAttribute('data-built', '1');
    }
    ulEl.hidden = !on;
    if (caret && caret.classList.contains('__canvas-caret')) {
      caret.setAttribute('aria-expanded', on ? 'true' : 'false');
    }
  }

  function expandFrameRow(f) {
    if (f.rowLi && f.layers && f.layers.children && f.layers.children.length) {
      toggleLayer(f.rowLi, true);
    }
  }

  function revealPath(f, path) {
    if (!path || !path.length || !f.rowLi) return null;
    var li = f.rowLi;
    for (var i = 1; i < path.length; i++) {
      toggleLayer(li, true);
      var ulEl = childListOf(li);
      if (!ulEl) return null;
      var next = null;
      for (var j = 0; j < ulEl.children.length; j++) {
        var candidate = ulEl.children[j];
        if (candidate.__canvasLayer && candidate.__canvasLayer.id === path[i].id) {
          next = candidate;
          break;
        }
      }
      if (!next) return null;
      li = next;
    }
    try { li.scrollIntoView({ block: 'nearest' }); } catch (err) {}
    return li;
  }

  function ensureLayerInView(f, layer) {
    var v = view();
    var lx = f.x + layer.x;
    var ly = f.y + layer.y;
    var rx = lx + layer.width;
    var ry = ly + layer.height;
    var padX = (v.r - v.l) * 0.15;
    var padY = (v.b - v.t) * 0.15;
    if (lx >= v.l + padX && rx <= v.r - padX && ly >= v.t + padY && ry <= v.b - padY) return;
    cam.x = viewW / 2 - (lx + layer.width / 2) * cam.k;
    cam.y = viewH / 2 - (ly + layer.height / 2) * cam.k;
    applyCamera();
    requestUpdate();
  }

  // ── inspector ────────────────────────────────────────────────────────────
  var inspEmpty = document.getElementById('__canvas-inspect-empty');
  var inspBody = document.getElementById('__canvas-inspect-body');
  var inspKind = document.getElementById('__canvas-inspect-kind');
  var inspName = document.getElementById('__canvas-inspect-name');
  var inspFields = document.getElementById('__canvas-inspect-fields');
  var inspFillSec = document.getElementById('__canvas-inspect-fill');
  var inspFillValue = document.getElementById('__canvas-inspect-fill-value');
  var inspSwatch = document.getElementById('__canvas-inspect-swatch');
  var inspTextSec = document.getElementById('__canvas-inspect-text');
  var inspTextValue = document.getElementById('__canvas-inspect-text-value');
  var inspOpen = document.getElementById('__canvas-inspect-open');
  var inspNote = document.getElementById('__canvas-inspect-note');
  var fieldX = document.getElementById('__canvas-field-x');
  var fieldY = document.getElementById('__canvas-field-y');
  var fieldW = document.getElementById('__canvas-field-w');
  var fieldH = document.getElementById('__canvas-field-h');

  function coord(value) {
    var n = Math.round(value * 100) / 100;
    return String(n);
  }

  function prettyType(type) {
    var s = String(type || 'layer').toLowerCase().replace(/_/g, ' ');
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  function updateInspector() {
    if (!inspBody || !inspEmpty) return;
    if (!selection.frames.length) {
      inspEmpty.hidden = false;
      inspBody.hidden = true;
      return;
    }
    inspEmpty.hidden = true;
    inspBody.hidden = false;
    var multi = selection.frames.length > 1;
    var f = selection.frame;
    var l = selection.layer;
    if (!f) return;

    if (multi) {
      if (inspKind) inspKind.textContent = 'Selection';
      if (inspName) inspName.textContent = selection.frames.length + ' frames';
      if (inspFields) inspFields.hidden = true;
      if (inspFillSec) inspFillSec.hidden = true;
      if (inspTextSec) inspTextSec.hidden = true;
      if (inspOpen) inspOpen.hidden = true;
      if (inspNote) {
        inspNote.hidden = false;
        inspNote.textContent = 'Drag on empty canvas to select several frames. Click one frame to inspect it.';
      }
      return;
    }

    var path = selection.path || [];
    var parent = path.length > 1 ? path[path.length - 2] : null;
    var x = l ? l.x - (parent ? parent.x : 0) : f.px;
    var y = l ? l.y - (parent ? parent.y : 0) : f.py;
    var w = l ? l.width : f.w;
    var h = l ? l.height : f.h;
    var fill = l ? l.fill : f.bg;

    if (inspKind) inspKind.textContent = l ? prettyType(l.type) : 'Frame';
    if (inspName) inspName.textContent = l ? l.name : f.name;
    if (inspFields) inspFields.hidden = false;
    if (fieldX) fieldX.textContent = coord(x);
    if (fieldY) fieldY.textContent = coord(y);
    if (fieldW) fieldW.textContent = coord(w);
    if (fieldH) fieldH.textContent = coord(h);

    if (inspFillSec) inspFillSec.hidden = !fill;
    if (fill) {
      if (inspFillValue) inspFillValue.textContent = fill;
      if (inspSwatch) inspSwatch.style.backgroundColor = fill;
    }

    if (inspTextSec) inspTextSec.hidden = !(l && l.text);
    if (l && l.text && inspTextValue) inspTextValue.textContent = l.text;

    if (inspOpen) {
      inspOpen.hidden = false;
      inspOpen.href = '../frames/' + f.slug + '.html';
    }
    if (inspNote) {
      inspNote.hidden = true;
      inspNote.textContent = '';
    }
  }

  function updateSelectionUI() {
    var oldRows = document.querySelectorAll('.__canvas-list .__canvas-layer.__canvas-selected');
    for (var s = 0; s < oldRows.length; s++) oldRows[s].classList.remove('__canvas-selected');

    for (var i = 0; i < frames.length; i++) {
      var f = frames[i];
      var inMulti = selection.frames.length > 1 && isSelectedFrame(f);
      f.el.classList.toggle('__canvas-selected', inMulti);
      f.el.classList.toggle('__canvas-active', selection.frames.length === 1 && selection.frame === f);
      if (f.row) {
        var current = selection.frames.length === 1 && selection.frame === f && !selection.layer;
        f.row.setAttribute('aria-current', current ? 'true' : 'false');
      }
      if (f.rowLi) f.rowLi.classList.remove('__canvas-selected');
    }

    if (selection.frames.length === 1 && selection.frame) {
      var f1 = selection.frame;
      if (!selection.layer) {
        if (f1.rowLi) f1.rowLi.classList.add('__canvas-selected');
        expandFrameRow(f1);
        if (f1.row) {
          try { f1.row.scrollIntoView({ block: 'nearest' }); } catch (err) {}
        }
      } else if (selection.path) {
        var target = revealPath(f1, selection.path);
        if (target) target.classList.add('__canvas-selected');
      }
    }

    placeSelection();
    updateInspector();
    if (mini && !mini.classList.contains('__canvas-mini-off')) drawMini(view());
  }

  function selectFrame(f, silent) {
    selection.frames = [f];
    selection.frame = f;
    selection.layer = null;
    selection.path = null;
    updateSelectionUI();
    if (!silent) writeHash(f.slug);
  }

  function selectLayer(f, layer, path) {
    selection.frames = [f];
    selection.frame = f;
    selection.layer = layer;
    selection.path = path;
    updateSelectionUI();
    writeHash(f.slug);
    ensureLayerInView(f, layer);
  }

  function selectFrames(list) {
    selection.frames = list;
    selection.frame = list.length ? list[0] : null;
    selection.layer = null;
    selection.path = null;
    updateSelectionUI();
    if (list.length === 1) writeHash(list[0].slug);
  }

  function clearSelection() {
    selection.frames = [];
    selection.frame = null;
    selection.layer = null;
    selection.path = null;
    updateSelectionUI();
  }

  // ── theme ────────────────────────────────────────────────────────────────
  var THEME_KEY = 'figma-archive-theme';
  function readTheme() {
    try {
      var value = localStorage.getItem(THEME_KEY);
      if (value === 'light' || value === 'dark') return value;
    } catch (err) {}
    return 'dark';
  }
  function applyTheme(theme) {
    root.setAttribute('data-theme', theme);
    if (themeBtn) {
      themeBtn.setAttribute('aria-pressed', theme === 'light' ? 'true' : 'false');
      themeBtn.title = theme === 'light' ? 'Switch to dark theme' : 'Switch to light theme';
    }
  }
  function toggleTheme() {
    var next = lightTheme() ? 'dark' : 'light';
    applyTheme(next);
    try { localStorage.setItem(THEME_KEY, next); } catch (err) {}
    buildMini();
    if (mini && !mini.classList.contains('__canvas-mini-off')) drawMini(view());
  }

  // ── hand tool ────────────────────────────────────────────────────────────
  var hand = false;
  var space = false;
  var moved = false;
  var suppressClick = false;

  function setHand(on) {
    hand = on;
    vp.classList.toggle('__canvas-hand', hand || space);
    if (handBtn) handBtn.setAttribute('aria-pressed', hand ? 'true' : 'false');
    if (selectBtn) selectBtn.setAttribute('aria-pressed', hand ? 'false' : 'true');
  }

  function setSpace(on) {
    space = on;
    if (hand) return;
    vp.classList.toggle('__canvas-hand', space);
  }

  // ── one frame ────────────────────────────────────────────────────────────
  function focusFrame(slug, silent) {
    var f = frameAt(slug);
    if (!f) return false;
    var pad = 120;
    var next = Math.min(
      (viewW - pad) / Math.max(1, f.w),
      (viewH - pad) / Math.max(1, f.h),
      1
    );
    cam.k = clamp(next, MIN, MAX);
    cam.x = viewW / 2 - (f.x + f.w / 2) * cam.k;
    cam.y = viewH / 2 - (f.y + f.h / 2) * cam.k;
    applyCamera();
    selectFrame(f, silent);
    requestUpdate();
    return true;
  }

  // ── pointer input ────────────────────────────────────────────────────────
  var drag = null;
  var pointers = {};

  function marqueeTo(clientX, clientY) {
    if (!drag || drag.mode !== 'marquee') return;
    var rect = vp.getBoundingClientRect();
    var x1 = (drag.x - rect.left - cam.x) / cam.k;
    var y1 = (drag.y - rect.top - cam.y) / cam.k;
    var x2 = (clientX - rect.left - cam.x) / cam.k;
    var y2 = (clientY - rect.top - cam.y) / cam.k;
    var l = Math.min(x1, x2);
    var t = Math.min(y1, y2);
    var w = Math.abs(x2 - x1);
    var h = Math.abs(y2 - y1);
    drag.plane = { l: l, t: t, r: l + w, b: t + h, w: w, h: h };
    if (marqueeEl) {
      marqueeEl.hidden = false;
      marqueeEl.style.left = l + 'px';
      marqueeEl.style.top = t + 'px';
      marqueeEl.style.width = w + 'px';
      marqueeEl.style.height = h + 'px';
    }
  }

  function hideMarquee() {
    if (marqueeEl) marqueeEl.hidden = true;
  }

  function selectInRect(rect) {
    var list = [];
    for (var i = 0; i < frames.length; i++) {
      var f = frames[i];
      if (f.x < rect.r && f.x + f.w > rect.l && f.y < rect.b && f.y + f.h > rect.t) {
        list.push(f);
      }
    }
    if (list.length) selectFrames(list);
    else clearSelection();
  }

  vp.addEventListener('pointerdown', function (e) {
    var target = e.target;
    if (e.pointerType === 'touch') {
      pointers[e.pointerId] = { x: e.clientX, y: e.clientY };
      try { vp.setPointerCapture(e.pointerId); } catch (err) {}
      var ids = Object.keys(pointers);
      if (ids.length === 1) {
        drag = { mode: 'pan', x: e.clientX, y: e.clientY, camX: cam.x, camY: cam.y, touch: true };
        moved = false;
      } else if (ids.length === 2) {
        var a = pointers[ids[0]];
        var b = pointers[ids[1]];
        drag = {
          mode: 'pinch',
          touch: true,
          d: Math.max(1, Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y))),
          mx: (a.x + b.x) / 2,
          my: (a.y + b.y) / 2,
          camX: cam.x,
          camY: cam.y,
          k: cam.k
        };
        moved = true;
      }
      return;
    }
    if (e.button !== 0 && e.button !== 1) return;
    if (e.button === 1 || hand || space) {
      drag = { mode: 'pan', x: e.clientX, y: e.clientY, camX: cam.x, camY: cam.y };
      moved = false;
      vp.classList.add('__canvas-grabbing');
      try { vp.setPointerCapture(e.pointerId); } catch (err) {}
      e.preventDefault();
      return;
    }
    var item = target.closest ? target.closest('.__canvas-item') : null;
    if (item) {
      // No pointer capture and no preventDefault yet: this may still become a
      // click, and a captured pointer would retarget it away from the frame.
      drag = { mode: 'press', x: e.clientX, y: e.clientY, camX: cam.x, camY: cam.y, pointerId: e.pointerId };
      moved = false;
    } else {
      drag = { mode: 'marquee', x: e.clientX, y: e.clientY };
      moved = false;
      hideMarquee();
      try { vp.setPointerCapture(e.pointerId); } catch (err) {}
      e.preventDefault();
    }
  });

  vp.addEventListener('pointermove', function (e) {
    if (e.pointerType === 'touch' && pointers[e.pointerId]) {
      pointers[e.pointerId] = { x: e.clientX, y: e.clientY };
    }
    if (!drag) return;

    if (drag.mode === 'pinch') {
      var ids = Object.keys(pointers);
      if (ids.length < 2) return;
      var a = pointers[ids[0]];
      var b = pointers[ids[1]];
      var dist = Math.max(1, Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)));
      var mx = (a.x + b.x) / 2;
      var my = (a.y + b.y) / 2;
      var wx = (drag.mx - drag.camX) / drag.k;
      var wy = (drag.my - drag.camY) / drag.k;
      cam.k = clamp(drag.k * (dist / drag.d), MIN, MAX);
      cam.x = mx - wx * cam.k;
      cam.y = my - wy * cam.k;
      moved = true;
      applyCamera();
      requestUpdate();
      e.preventDefault();
      return;
    }

    var dx = e.clientX - drag.x;
    var dy = e.clientY - drag.y;
    if (!moved && (dx > 4 || dx < -4 || dy > 4 || dy < -4)) {
      moved = true;
      if (drag.mode === 'press') {
        drag.mode = 'pan';
        vp.classList.add('__canvas-grabbing');
        // Only take the pointer once this is a drag; a click keeps its target.
        try { vp.setPointerCapture(drag.pointerId); } catch (err) {}
      }
    }

    if (drag.mode === 'pan') {
      cam.x = drag.camX + dx;
      cam.y = drag.camY + dy;
      applyCamera();
      requestUpdate();
      e.preventDefault();
      return;
    }

    if (drag.mode === 'marquee') {
      marqueeTo(e.clientX, e.clientY);
      e.preventDefault();
    }
  });

  function endDrag(e) {
    if (!drag) return;
    var mode = drag.mode;
    var info = drag;
    drag = null;
    vp.classList.remove('__canvas-grabbing');
    hideMarquee();
    if (e && e.pointerType === 'touch' && pointers[e.pointerId]) {
      delete pointers[e.pointerId];
    }
    if (mode === 'marquee') {
      if (info.plane && info.plane.w > 2 && info.plane.h > 2) selectInRect(info.plane);
      else clearSelection();
    }
    if (moved) {
      suppressClick = true;
      window.setTimeout(function () { suppressClick = false; moved = false; }, 0);
    } else {
      moved = false;
    }
    if (mode === 'pinch') suppressClick = true;
  }

  vp.addEventListener('pointerup', endDrag);
  vp.addEventListener('pointercancel', endDrag);

  // ── clicks, links and tools ──────────────────────────────────────────────
  document.addEventListener('click', function (e) {
    var target = e.target;
    if (!target || !target.closest) return;

    var caret = target.closest('.__canvas-caret');
    if (caret && caret.getAttribute('aria-expanded') !== null) {
      e.preventDefault();
      var li = caret.closest('.__canvas-layer');
      var open = caret.getAttribute('aria-expanded') === 'true';
      toggleLayer(li, !open);
      return;
    }

    var sub = target.closest('[data-select-layer]');
    if (sub) {
      e.preventDefault();
      var sf = frameAt(sub.getAttribute('data-frame'));
      if (!sf) return;
      var located = findLayer(sf.layers, sub.getAttribute('data-select-layer'), []);
      if (located) selectLayer(sf, located.layer, located.path);
      return;
    }

    var row = target.closest('.__canvas-row[data-goto]');
    if (row) {
      if (e.metaKey || e.ctrlKey || e.shiftKey) return;
      e.preventDefault();
      focusFrame(row.getAttribute('data-goto'));
      return;
    }

    var btn = target.closest('[data-act]');
    if (btn) {
      var act = btn.getAttribute('data-act');
      e.preventDefault();
      if (act === 'in') zoomAt(cam.k * 1.2);
      else if (act === 'out') zoomAt(cam.k / 1.2);
      else if (act === 'reset') zoomAt(1);
      else if (act === 'fit') fit();
      else if (act === 'hand') setHand(!hand);
      else if (act === 'select') setHand(false);
      else if (act === 'jump') openPalette();
      else if (act === 'theme') toggleTheme();
      return;
    }

    var hit = target.closest('.__canvas-hit');
    if (hit) {
      if (e.metaKey || e.ctrlKey || e.shiftKey) return;
      e.preventDefault();
      e.stopPropagation();
      if (hand || space || suppressClick) {
        suppressClick = false;
        return;
      }
      var item = hit.closest('.__canvas-item');
      var f = item ? frameAt(item.getAttribute('data-slug')) : null;
      if (f) selectFrame(f);
      return;
    }
  }, true);

  vp.addEventListener('dblclick', function (e) {
    var hit = e.target.closest ? e.target.closest('.__canvas-hit') : null;
    if (!hit || hand || space) return;
    var item = hit.closest('.__canvas-item');
    var f = item ? frameAt(item.getAttribute('data-slug')) : null;
    if (!f || !f.layers) return;
    e.preventDefault();
    var box = item.getBoundingClientRect();
    var px = (e.clientX - box.left) / cam.k;
    var py = (e.clientY - box.top) / cam.k;
    var found = deepestAt(f, px, py);
    if (found) selectLayer(f, found.layer, found.path);
    else selectFrame(f);
  });

  // ── wheel and keyboard ───────────────────────────────────────────────────
  vp.addEventListener('wheel', function (e) {
    var box = viewportBox();
    var vx = e.clientX - box.left;
    var vy = e.clientY - box.top;
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      var factor = Math.exp(-e.deltaY * 0.0035);
      zoomAt(cam.k * factor, vx, vy);
      return;
    }
    e.preventDefault();
    var dx = e.deltaX;
    var dy = e.deltaY;
    if (e.deltaMode === 1) {
      dx *= 16;
      dy *= 16;
    } else if (e.deltaMode === 2) {
      dx *= viewW;
      dy *= viewH;
    }
    if (e.shiftKey && !dx) {
      dx = dy;
      dy = 0;
    }
    cam.x -= dx;
    cam.y -= dy;
    applyCamera();
    requestUpdate();
  }, { passive: false });

  document.addEventListener('keydown', function (e) {
    var t = e.target;
    var typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
    var control = t && t.closest && t.closest('button, a, summary, input, textarea, select');

    if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) {
      e.preventDefault();
      openPalette();
      return;
    }
    if (typing) return;

    if (!e.metaKey && !e.ctrlKey && (e.key === '+' || e.key === '=')) {
      e.preventDefault();
      zoomAt(cam.k * 1.2);
      return;
    }
    if (!e.metaKey && !e.ctrlKey && (e.key === '-' || e.key === '_')) {
      e.preventDefault();
      zoomAt(cam.k / 1.2);
      return;
    }

    if (e.key === 'h' || e.key === 'H') { e.preventDefault(); setHand(!hand); }
    else if (e.key === 'v' || e.key === 'V') { setHand(false); }
    else if (e.key === 'Escape') {
      if (dlg && dlg.open) return;
      setHand(false);
      clearSelection();
    }
    else if (e.code === 'Space') {
      // A focused button still activates with Space; only the canvas borrows it.
      if (control) return;
      if (!space) setSpace(true);
      e.preventDefault();
    }
    else if (e.shiftKey && e.code === 'Digit1') { e.preventDefault(); fit(); }
    else if (e.shiftKey && e.code === 'Digit0') { e.preventDefault(); zoomAt(1); }
    else if (e.key && e.key.indexOf('Arrow') === 0) {
      if (control) return;
      if (e.altKey && (e.key === 'ArrowLeft' || e.key === 'ArrowRight') && nav && nav.pages) {
        var at = -1;
        for (var p = 0; p < nav.pages.length; p++) {
          if (nav.pages[p].slug === pageSlug) at = p;
        }
        var to = at + (e.key === 'ArrowRight' ? 1 : -1);
        if (at >= 0 && to >= 0 && to < nav.pages.length) {
          e.preventDefault();
          location.href = (nav.base || '') + nav.pages[to].file;
          return;
        }
      }
      var step = e.shiftKey ? 320 : 80;
      if (e.key === 'ArrowLeft') cam.x += step;
      else if (e.key === 'ArrowRight') cam.x -= step;
      else if (e.key === 'ArrowUp') cam.y += step;
      else if (e.key === 'ArrowDown') cam.y -= step;
      applyCamera();
      requestUpdate();
      e.preventDefault();
    }
  });

  document.addEventListener('keyup', function (e) {
    if (e.code !== 'Space') return;
    setSpace(false);
  });

  // ── palette ──────────────────────────────────────────────────────────────
  var dlg = document.getElementById('__canvas-palette');
  var q = document.getElementById('__canvas-q');
  var results = document.getElementById('__canvas-results');
  var paletteItems = [];
  var paletteShown = [];
  var paletteActive = 0;

  if (nav && nav.pages) {
    for (var pi = 0; pi < nav.pages.length; pi++) {
      var pg = nav.pages[pi];
      paletteItems.push({
        kind: 'page',
        name: pg.name,
        page: pg.name,
        pageSlug: pg.slug,
        file: pg.file,
        hay: pg.name.toLowerCase()
      });
      for (var fi = 0; fi < pg.frames.length; fi++) {
        var fr = pg.frames[fi];
        paletteItems.push({
          kind: 'frame',
          name: fr.name,
          page: pg.name,
          pageSlug: pg.slug,
          slug: fr.slug,
          file: fr.file,
          size: fr.w + '×' + fr.h,
          hay: (pg.name + ' ' + fr.name).toLowerCase()
        });
      }
    }
  }

  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function paintPalette(query) {
    if (!results) return;
    var needle = (query || '').trim().toLowerCase();
    paletteShown = [];
    for (var i = 0; i < paletteItems.length && paletteShown.length < 40; i++) {
      if (!needle || paletteItems[i].hay.indexOf(needle) >= 0) paletteShown.push(paletteItems[i]);
    }
    paletteActive = 0;
    var html = '';
    for (var j = 0; j < paletteShown.length; j++) {
      var it = paletteShown[j];
      var sub = it.kind === 'page' ? 'page' : it.page + (it.size ? ' · ' + it.size : '');
      html +=
        '<li role="option" aria-selected="' + (j === 0 ? 'true' : 'false') + '" data-i="' + j + '">' +
        '<span class="__canvas-result-name">' + esc(it.name) + '</span>' +
        '<span class="__canvas-result-sub">' + esc(sub) + '</span></li>';
    }
    results.innerHTML = html || '<li class="__canvas-empty">Nothing matches</li>';
  }

  function setPaletteActive(n) {
    if (!paletteShown.length || !results) return;
    paletteActive = (n + paletteShown.length) % paletteShown.length;
    var nodes = results.querySelectorAll('li[data-i]');
    for (var i = 0; i < nodes.length; i++) {
      var on = Number(nodes[i].getAttribute('data-i')) === paletteActive;
      nodes[i].setAttribute('aria-selected', on ? 'true' : 'false');
      if (on && nodes[i].scrollIntoView) nodes[i].scrollIntoView({ block: 'nearest' });
    }
  }

  function choosePalette(it) {
    if (!it) return;
    closePalette();
    var base = (nav && nav.base) || '';
    if (it.kind === 'page') {
      if (it.pageSlug !== pageSlug) location.href = base + it.file;
      return;
    }
    if (it.pageSlug === pageSlug) focusFrame(it.slug);
    else location.href = base + it.file + '#' + it.slug;
  }

  function openPalette() {
    if (!dlg) return;
    if (dlg.open) {
      if (q) q.focus();
      return;
    }
    if (typeof dlg.showModal === 'function') {
      try { dlg.showModal(); } catch (err) {}
    } else {
      dlg.setAttribute('open', '');
    }
    if (q) {
      q.value = '';
      q.focus();
    }
    paintPalette('');
  }

  function closePalette() {
    if (!dlg) return;
    if (typeof dlg.close === 'function' && dlg.open) dlg.close();
    else dlg.removeAttribute('open');
  }

  if (q) {
    q.addEventListener('input', function () { paintPalette(q.value); });
  }
  if (results) {
    results.addEventListener('click', function (e) {
      var li = e.target && e.target.closest ? e.target.closest('li[data-i]') : null;
      if (!li) return;
      choosePalette(paletteShown[Number(li.getAttribute('data-i'))]);
    });
  }
  if (dlg) {
    dlg.addEventListener('click', function (e) {
      if (e.target === dlg) closePalette();
    });
    dlg.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setPaletteActive(paletteActive + 1);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setPaletteActive(paletteActive - 1);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        choosePalette(paletteShown[paletteActive]);
      }
    });
  }

  // ── boot ─────────────────────────────────────────────────────────────────
  applyTheme(readTheme());

  function boot() {
    measure();
    for (var fi = 0; fi < frames.length; fi++) {
      frames[fi].fill = resolvePaint(frames[fi].bg);
      frames[fi].el.style.backgroundColor = frames[fi].fill || '';
    }
    buildMini();

    window.addEventListener('hashchange', function () {
      var slug = hashSlug();
      if (slug) focusFrame(slug, true);
    });

    var initial = hashSlug();
    if (!initial || !focusFrame(initial, true)) fit();
    measure();
    update();
    watchResize();
  }

  function watchResize() {
    var lastW = viewW;
    var lastH = viewH;
    function resize() {
      var oldW = lastW;
      var oldH = lastH;
      measure();
      if (viewW === oldW && viewH === oldH) return;
      cam.x += (viewW - oldW) / 2;
      cam.y += (viewH - oldH) / 2;
      lastW = viewW;
      lastH = viewH;
      if (Math.abs(cam.k - fitK) < 0.001) fit();
      else {
        applyCamera();
        requestUpdate();
      }
      buildMini();
    }
    if (typeof ResizeObserver !== 'undefined') new ResizeObserver(resize).observe(vp);
    else window.addEventListener('resize', resize);
  }

  // A background tab can measure 0×0 when this runs, and fitting a page into
  // an empty box pins the camera to the minimum zoom. Wait for real geometry;
  // the ResizeObserver above catches the case where the tab is still hidden
  // when the deferred frames run.
  if (vp.clientWidth > 1 && vp.clientHeight > 1) boot();
  else requestAnimationFrame(function () { requestAnimationFrame(boot); });
})();`;
