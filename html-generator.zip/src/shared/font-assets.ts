import type { CustomFontData, UsedFont } from '../plugin/types/ir';

export const FONT_FILE_EXTENSIONS = ['.woff2', '.woff', '.ttf', '.otf'] as const;

export type FontFileFormat = CustomFontData['format'];

export function isSupportedFontFile(filename: string): boolean {
  const lower = filename.toLowerCase();
  return FONT_FILE_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

export function getFormatFromFilename(filename: string): FontFileFormat {
  const lower = filename.toLowerCase();
  if (lower.endsWith('.woff2')) return 'woff2';
  if (lower.endsWith('.woff')) return 'woff';
  if (lower.endsWith('.otf')) return 'opentype';
  return 'truetype';
}

export interface FontInfo {
  family: string;
  style: string;
  weight: number | string;
  isVariable: boolean;
}

/**
 * Reads a font's family and weight out of its filename.
 *
 * The file name is the only metadata a browser gives us before the font is
 * loaded, so this mirrors what a designer sees in their font folder. An
 * explicit family (the layer font being attached) always wins; otherwise the
 * name is matched against the families the document actually uses, then
 * against a few common Persian families, then split on `-`/`_`/space.
 */
export function parseFontInfoFromFilename(
  filename: string,
  usedFonts: ReadonlyArray<Pick<UsedFont, 'family'>> = [],
  explicitFamily?: string | null
): FontInfo {
  const cleanName = filename.replace(/\.(woff2|woff|ttf|otf)$/i, '');
  const isVariable =
    /(-|_|\b)(vf|variable)(\b|_|-|$)/i.test(cleanName) ||
    /yekanbakh.*vf/i.test(cleanName) ||
    /iranyekan.*vf/i.test(cleanName) ||
    (Boolean(explicitFamily) && /(-|_|\b)(vf|variable)(\b|_|-|$)/i.test(explicitFamily!));

  let family = explicitFamily || '';

  if (!family) {
    const normClean = cleanName.toLowerCase().replace(/[^a-z0-9]/g, '');
    const baseNormClean = normClean.replace(/vf|variable|fanum/g, '');

    for (const used of usedFonts) {
      const normUsed = used.family.toLowerCase().replace(/[^a-z0-9]/g, '');
      const baseNormUsed = normUsed.replace(/vf|variable/g, '');
      if (
        normClean === normUsed ||
        (baseNormClean &&
          baseNormUsed &&
          (baseNormClean === baseNormUsed || normClean.includes(baseNormUsed)))
      ) {
        family = used.family;
        break;
      }
    }
  }

  if (!family) {
    const lower = cleanName.toLowerCase();
    if (lower.includes('yekanbakh') || lower.includes('yekan-bakh') || lower.includes('yekan_bakh')) {
      family = isVariable ? 'Yekan Bakh VF' : 'Yekan Bakh';
    } else if (lower.includes('iranyekan') || lower.includes('iran-yekan') || lower.includes('iran_yekan')) {
      family = isVariable ? 'IRANYekanXVF' : 'IRANYekanX';
    } else if (lower.includes('dana')) {
      family = 'Dana';
    } else if (lower.includes('shabnam')) {
      family = 'Shabnam';
    } else {
      const parts = cleanName.split(/[-_ ]/);
      family = (parts[0] || 'CustomFont').replace(/([a-z])([A-Z])/g, '$1 $2');
    }
  }

  const styleCandidate = (cleanName.split(/[-_ ]/).slice(1).join(' ') || 'Regular').toLowerCase();

  let style = isVariable ? 'Variable' : 'Regular';
  let weight: number | string = isVariable ? '100 1000' : 400;

  if (!isVariable) {
    if (styleCandidate.includes('thin') || styleCandidate.includes('100')) {
      style = 'Thin';
      weight = 100;
    } else if (
      styleCandidate.includes('extralight') ||
      styleCandidate.includes('extra-light') ||
      styleCandidate.includes('200')
    ) {
      style = 'ExtraLight';
      weight = 200;
    } else if (styleCandidate.includes('light') || styleCandidate.includes('300')) {
      style = 'Light';
      weight = 300;
    } else if (styleCandidate.includes('medium') || styleCandidate.includes('500')) {
      style = 'Medium';
      weight = 500;
    } else if (
      styleCandidate.includes('semibold') ||
      styleCandidate.includes('semi-bold') ||
      styleCandidate.includes('600')
    ) {
      style = 'SemiBold';
      weight = 600;
    } else if (
      styleCandidate.includes('extrabold') ||
      styleCandidate.includes('extra-bold') ||
      styleCandidate.includes('800')
    ) {
      style = 'ExtraBold';
      weight = 800;
    } else if (
      styleCandidate.includes('extrablack') ||
      styleCandidate.includes('extra-black') ||
      styleCandidate.includes('950')
    ) {
      style = 'ExtraBlack';
      weight = 950;
    } else if (styleCandidate.includes('black') || styleCandidate.includes('900')) {
      style = 'Black';
      weight = 900;
    } else if (styleCandidate.includes('bold') || styleCandidate.includes('700')) {
      style = 'Bold';
      weight = 700;
    }
  }

  return { family, style, weight, isVariable };
}

/** Keeps a font copy's name usable in a URL and safe to join onto `fonts/`. */
export function safeFontFilename(filename: string): string {
  const base = filename.split(/[\\/]/).pop() || 'font.woff2';
  return base.replace(/[\u0000-\u001f"']/g, '').replace(/\s+/g, '-');
}

let fontSequence = 0;

/** One uploaded font file, described the way the converters expect it. */
export function createCustomFont(
  filename: string,
  base64: string,
  options: { usedFonts?: ReadonlyArray<Pick<UsedFont, 'family'>>; explicitFamily?: string | null } = {}
): CustomFontData | null {
  if (!isSupportedFontFile(filename)) return null;
  const safeName = safeFontFilename(filename);
  const info = parseFontInfoFromFilename(safeName, options.usedFonts, options.explicitFamily);
  fontSequence += 1;
  return {
    id: `${info.family}-${info.style}-${Date.now()}-${fontSequence}`,
    family: info.family,
    style: info.style,
    weight: info.weight,
    format: getFormatFromFilename(safeName),
    base64,
    filename: safeName,
    isVariable: info.isVariable,
  };
}

/** Replacing a family+weight variant is what a second upload of it means. */
export function withCustomFont(fonts: CustomFontData[], font: CustomFontData): CustomFontData[] {
  return [
    ...fonts.filter(
      (f) => !(f.family.toLowerCase() === font.family.toLowerCase() && String(f.weight) === String(font.weight))
    ),
    font,
  ];
}
