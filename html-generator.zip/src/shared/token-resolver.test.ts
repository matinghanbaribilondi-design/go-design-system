import { describe, it, expect } from 'vitest';
import { TokenResolver } from './token-resolver';
import type { ExportedToken } from '../plugin/variables/variable-collector';

/**
 * A style/variable id on a node is a naming hint, not a colour. The reported
 * bug: a background bound to the paint style "Background/N5" came out as
 * `#fee2e2` — the style's paint — while the node's own fill was `#f2f2f2`
 * (edited after the style was applied). resolveColor must only emit the
 * token when the token's value is the paint on the node; otherwise the
 * exported colour drifts away from the design with no error anywhere.
 */
const registry = new Map<string, ExportedToken>([
  [
    'style-n5',
    {
      id: 'style-n5',
      name: 'Background/N5',
      cssVarName: '--color-background-n5',
      type: 'color',
      value: '#fee2e2',
      collectionName: 'Paint Styles',
    },
  ],
  [
    'var-n4',
    {
      id: 'var-n4',
      name: 'Background/N4',
      cssVarName: '--color-background-n4',
      type: 'color',
      value: '#f2f2f2',
      collectionName: 'Variables',
    },
  ],
]);

const resolver = new TokenResolver(registry);
const F2F2F2 = { r: 242 / 255, g: 242 / 255, b: 242 / 255 };
const FEE2E2 = { r: 254 / 255, g: 226 / 255, b: 226 / 255 };

describe('TokenResolver.resolveColor — token honesty', () => {
  it('uses the style token when the node paint is the style paint', () => {
    expect(resolver.resolveColor(FEE2E2, 1, null, 'style-n5')).toBe('var(--color-background-n5)');
  });

  it('ignores the style binding when the node paint differs from the style', () => {
    expect(resolver.resolveColor(F2F2F2, 1, null, 'style-n5')).toBe('#f2f2f2');
  });

  it('uses the variable token when the mode/default value matches the paint', () => {
    expect(resolver.resolveColor(F2F2F2, 1, 'var-n4', null)).toBe('var(--color-background-n4)');
  });

  it('ignores the variable binding when the paint came from another mode', () => {
    expect(resolver.resolveColor(FEE2E2, 1, 'var-n4', null)).toBe('#fee2e2');
  });

  it('ignores the binding when the opacity differs from the token value', () => {
    expect(resolver.resolveColor(F2F2F2, 0.5, 'var-n4', null)).toBe('rgba(242, 242, 242, 0.5)');
  });

  it('still falls back to a literal hex when nothing matches', () => {
    expect(resolver.resolveColor(FEE2E2, 1, null, null)).toBe('#fee2e2');
  });
});
