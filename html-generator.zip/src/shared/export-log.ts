/**
 * The export's voice.
 *
 * A whole-file export can run for a minute on a real file. A bare `3/274`
 * counter cannot tell you whether that minute is being spent working or is
 * being spent dead — and the difference decides whether you wait or restart.
 *
 * So the sandbox narrates: every stage transition and every frame produces an
 * event, each stamped with how far along it is and how long it took. The UI
 * renders that narration as a log, and — because the *absence* of a message is
 * itself information — measures the silence between events to say "this frame
 * has been running for 9s" rather than leaving a frozen number on screen.
 *
 * Everything here is pure so both sides can share it and tests can pin it.
 */

export type ExportStage =
  | 'scan' // reading pages, counting frames
  | 'variables' // collecting Figma variables and paint/effect styles
  | 'convert' // the per-frame loop
  | 'dedupe' // one pass over the whole document
  | 'render' // HTML per page, one stylesheet
  | 'archive' // handing the payload to the UI
  | 'done';

export type ExportLevel = 'info' | 'good' | 'warn' | 'error';

export interface ExportLogEvent {
  /** Monotonic within one export; lets the UI dedupe and sort. */
  seq: number;
  stage: ExportStage;
  level: ExportLevel;
  message: string;
  /** Frames finished when this event was raised. */
  done: number;
  /** Frames to convert in total. 0 until the scan has finished. */
  total: number;
  /** Milliseconds since the export started. */
  at: number;
  /** How long the frame named below took, when the event is about one frame. */
  frameMs?: number;
  nodeName?: string;
}

/** What a caller supplies; `seq` and `at` are stamped by the log itself. */
export type ExportLogDraft = Omit<ExportLogEvent, 'seq' | 'at'>;

export interface ExportLogReporter {
  /** Stamps and forwards one event. Safe to call with no sink attached. */
  report: (draft: ExportLogDraft) => void;
  /** Everything reported so far, in order. */
  events: ExportLogEvent[];
  startedAt: number;
}

/**
 * Builds a reporter. `startedAt` is the export's own clock, so `at` means
 * "seconds into this export" rather than a wall-clock time the UI would have
 * to subtract.
 */
export function createExportLog(
  sink?: (event: ExportLogEvent) => void,
  startedAt: number = Date.now()
): ExportLogReporter {
  const events: ExportLogEvent[] = [];
  let seq = 0;

  return {
    startedAt,
    events,
    report(draft) {
      const event: ExportLogEvent = { ...draft, seq: seq++, at: Date.now() - startedAt };
      events.push(event);
      sink?.(event);
    },
  };
}

/** `840` → `"840ms"`, `12400` → `"12.4s"`, `95000` → `"1m 35s"`. */
export function formatDuration(ms: number): string {
  if (!Number.isFinite(ms) || ms < 0) return '—';
  if (ms < 1000) return `${Math.round(ms)}ms`;
  if (ms < 10_000) return `${(ms / 1000).toFixed(1)}s`;
  if (ms < 60_000) return `${Math.round(ms / 1000)}s`;
  const minutes = Math.floor(ms / 60_000);
  const seconds = Math.round((ms % 60_000) / 1000);
  return seconds === 0 ? `${minutes}m` : `${minutes}m ${String(seconds).padStart(2, '0')}s`;
}

/** `4_509_715` → `"4.3 MB"`. Used for the payload handed to the UI. */
export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '—';
  if (bytes < 1024) return `${Math.round(bytes)} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/** Silence after which an export is "slow" rather than merely "working". */
export const SILENCE_SLOW_MS = 3_000;
/** Silence after which an export looks dead and the log says so plainly. */
export const SILENCE_STALLED_MS = 15_000;

export type ExportState = 'idle' | 'working' | 'slow' | 'stalled' | 'done' | 'failed';

export interface ExportStatus {
  state: ExportState;
  /** How long since the last event, or since the export started. */
  silenceMs: number;
  /** Short human label for the status pill. */
  label: string;
  /** The event the status is derived from; the UI shows its stage. */
  last: ExportLogEvent | null;
}

/**
 * Reads a run's health off its events plus the current time.
 *
 * `now` must be on the *same clock* as `ExportLogEvent.at` — that is, elapsed
 * since the export started, not `Date.now()`. Mixing the two silently reports
 * a fresh export as decades of silence.
 *
 * `running` is passed in rather than inferred: an export that has finished
 * successfully also stops sending events, and confusing "quiet because done"
 * with "quiet because hung" is exactly the mistake this exists to prevent.
 */
export function describeExport(
  events: readonly ExportLogEvent[],
  now: number,
  running: boolean,
  startedAt?: number
): ExportStatus {
  const last = events.length > 0 ? events[events.length - 1]! : null;

  if (!running) {
    if (!last) return { state: 'idle', silenceMs: 0, label: 'Idle', last: null };
    if (events.some((event) => event.level === 'error')) {
      return { state: 'failed', silenceMs: 0, label: 'Failed', last };
    }
    if (last.stage === 'done') {
      return { state: 'done', silenceMs: 0, label: 'Finished', last };
    }
    return { state: 'idle', silenceMs: 0, label: 'Stopped', last };
  }

  const since = last ? now - last.at : startedAt !== undefined ? now - startedAt : 0;
  const silenceMs = Math.max(0, since);

  if (silenceMs >= SILENCE_STALLED_MS) {
    return { state: 'stalled', silenceMs, label: 'No news', last };
  }
  if (silenceMs >= SILENCE_SLOW_MS) {
    return { state: 'slow', silenceMs, label: 'Waiting', last };
  }
  return { state: 'working', silenceMs, label: 'Working', last };
}

/** The one-word stage name for the status pill's second half. */
export function stageLabel(stage: ExportStage): string {
  switch (stage) {
    case 'scan':
      return 'scanning pages';
    case 'variables':
      return 'reading variables';
    case 'convert':
      return 'converting frames';
    case 'dedupe':
      return 'merging components';
    case 'render':
      return 'writing HTML';
    case 'archive':
      return 'packing archive';
    case 'done':
      return 'done';
  }
}

/** Renders one event as the single line the log viewer shows. */
export function formatLogLine(event: ExportLogEvent): string {
  const stamp = formatDuration(event.at).padStart(6, ' ');
  const where =
    event.total > 0 && event.stage === 'convert'
      ? `${event.done}/${event.total}`
      : event.total > 0
        ? `${event.done}/${event.total}`
        : '   —  ';
  const took = event.frameMs !== undefined ? ` (${formatDuration(event.frameMs)})` : '';
  return `${stamp}  ${where.padStart(7, ' ')}  ${event.message}${took}`;
}
