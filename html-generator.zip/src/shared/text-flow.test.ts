import { describe, it, expect } from 'vitest';
import { hasParagraphBreak, paragraphsOf, paragraphsOfRuns } from './text-flow';
import { extractTypography } from '../plugin/converter/typography';
import { generateHtml } from '../generator/html-generator';
import { generateTailwindHtml } from '../generator/tailwind-generator';
import type { ConversionOptions, IRNode } from '../plugin/types/ir';

/**
 * Paragraphs.
 *
 * `paragraphSpacing` used to be read as a list gap and nothing else, so in
 * ordinary multi-paragraph copy it had no effect: every newline became a
 * `<br />`, and a line break inside a block has no boundary a margin can
 * attach to.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: false,
  designWidth: 400,
};

function textNode(over: Record<string, unknown> = {}): any {
  return {
    id: 'text',
    name: 'Body',
    type: 'TEXT',
    visible: true,
    width: 300,
    height: 120,
    x: 0,
    y: 0,
    characters: 'First paragraph.\nSecond paragraph.',
    fontSize: 14,
    fontName: { family: 'Inter', style: 'Regular' },
    lineHeight: { unit: 'PERCENT', value: 150 },
    letterSpacing: { unit: 'PERCENT', value: 0 },
    textAlignHorizontal: 'LEFT',
    textAlignVertical: 'TOP',
    textAutoResize: 'HEIGHT',
    fills: [{ type: 'SOLID', visible: true, opacity: 1, color: { r: 0, g: 0, b: 0, a: 1 } }],
    paragraphSpacing: 12,
    ...over,
  };
}

const irNode = (typography: IRNode['typography'], text: string): IRNode => ({
  id: 't',
  name: 'Body',
  className: 'body',
  tag: 'p',
  type: 'TEXT',
  layout: {},
  visual: {},
  typography,
  text,
  children: [],
});

describe('splitting text into paragraphs', () => {
  it('splits on every kind of line ending', () => {
    expect(paragraphsOf('a\nb')).toEqual(['a', 'b']);
    expect(paragraphsOf('a\r\nb')).toEqual(['a', 'b']);
    expect(paragraphsOf('a\rb')).toEqual(['a', 'b']);
  });

  it('keeps an empty paragraph, because a blank line is a line the designer drew', () => {
    expect(paragraphsOf('a\n\nb')).toEqual(['a', '', 'b']);
  });

  it('knows when there is no paragraph break', () => {
    expect(hasParagraphBreak('one line')).toBe(false);
    expect(hasParagraphBreak('two\nlines')).toBe(true);
  });

  it('cuts a styled run at the break and keeps its style on both sides', () => {
    const paragraphs = paragraphsOfRuns([{ text: 'link end\nlink start', styleAttr: 'color: red' }]);

    expect(paragraphs).toHaveLength(2);
    expect(paragraphs[0]).toEqual([{ text: 'link end', styleAttr: 'color: red' }]);
    expect(paragraphs[1]).toEqual([{ text: 'link start', styleAttr: 'color: red' }]);
  });

  it('regroups runs that belong to the same paragraph', () => {
    const paragraphs = paragraphsOfRuns([
      { text: 'bold', styleAttr: 'font-weight: 700' },
      { text: ' plain\nsecond' },
    ]);

    expect(paragraphs).toHaveLength(2);
    expect(paragraphs[0]).toHaveLength(2);
    expect(paragraphs[1]).toEqual([{ text: 'second' }]);
  });
});

describe('paragraph spacing reaches the IR', () => {
  it('carries the spacing of a multi-paragraph layer', () => {
    const typography = extractTypography(textNode(), options);
    expect(typography.paragraphSpacing).toBe('12px');
  });

  it('leaves a single-paragraph layer alone', () => {
    const typography = extractTypography(textNode({ characters: 'One paragraph only.' }), options);
    expect(typography.paragraphSpacing).toBeUndefined();
  });

  it('does not fight a list, which uses the same value as its item gap', () => {
    const typography = extractTypography(
      textNode({
        characters: '• One\n• Two',
        getRangeListOptions: () => ({ type: 'UNORDERED' }),
      }),
      options
    );

    expect(typography.isList).toBe(true);
    expect(typography.listGap).toBe('12px');
    expect(typography.paragraphSpacing).toBeUndefined();
  });

  it('ignores a zero spacing', () => {
    expect(extractTypography(textNode({ paragraphSpacing: 0 }), options).paragraphSpacing).toBeUndefined();
  });
});

describe('the markup gets a box per paragraph', () => {
  const html = generateHtml(irNode({ paragraphSpacing: '12px' }, 'First\nSecond'));
  const tailwind = generateTailwindHtml(irNode({ paragraphSpacing: '12px' }, 'First\nSecond'));

  it('writes one block per paragraph', () => {
    expect(html.match(/display: block/g)).toHaveLength(2);
  });

  it('puts the gap between the paragraphs and not after the last', () => {
    expect(html).toContain('margin-bottom: 12px');
    expect(html.match(/margin-bottom/g)).toHaveLength(1);
  });

  it('no longer needs a line break', () => {
    expect(html).not.toContain('<br />');
  });

  it('says the same thing in the Tailwind markup', () => {
    expect(tailwind.match(/display: block/g)).toHaveLength(2);
    expect(tailwind).toContain('margin-bottom: 12px');
  });

  it('keeps an empty paragraph on its own line', () => {
    const spaced = generateHtml(irNode({ paragraphSpacing: '8px' }, 'One\n\nThree'));
    expect(spaced).toContain('<br />');
  });

  it('leaves text without paragraph spacing on the <br /> path', () => {
    const plain = generateHtml(irNode({}, 'First\nSecond'));
    expect(plain).toContain('<br />');
    expect(plain).not.toContain('display: block');
  });
});
