import { describe, it, expect } from 'vitest';
import {
  base64ToBytes,
  fallbackFaceCss,
  fallbackFamily,
  fontFamilyWithFallback,
  isEmbeddedFamily,
  metricOverrides,
  overridesFor,
  parseFontMetrics,
} from './font-metrics';

/**
 * Measuring a font, so its fallback can stand in its place.
 *
 * A custom font is embedded, but it is still fetched, decoded and only then
 * painted. Until it is, the browser uses the next family in the stack — and
 * that family has different vertical metrics, so every line box changes height
 * and the design jumps. The fix is a second `@font-face`, a *named fallback*
 * carrying the real font's own numbers.
 *
 * The numbers are read straight out of the font file: `head` holds the units
 * per em, `hhea` the ascender/descender/line gap, `OS/2` the average character
 * width. These tests build those tables by hand, so every assertion is about
 * the arithmetic and not about a font that happens to be installed.
 */

/* ------------------------------------------------------------------ *
 * A font file, built by hand
 * ------------------------------------------------------------------ */

function be16(value: number): number[] {
  return [(value >> 8) & 0xff, value & 0xff];
}

function be32(value: number): number[] {
  return [(value >>> 24) & 0xff, (value >>> 16) & 0xff, (value >>> 8) & 0xff, value & 0xff];
}

function ascii(text: string): number[] {
  return [...text].map((char) => char.charCodeAt(0));
}

/** `head` — only the units-per-em field is read, but the table is 54 bytes. */
function head(unitsPerEm: number): number[] {
  const bytes = new Array(54).fill(0);
  bytes.splice(18, 2, ...be16(unitsPerEm));
  return bytes;
}

/** `hhea` — ascender, descender and line gap, as signed 16-bit values. */
function hhea(ascender: number, descender: number, lineGap: number): number[] {
  const bytes = new Array(36).fill(0);
  bytes.splice(4, 2, ...be16(ascender & 0xffff));
  bytes.splice(6, 2, ...be16(descender & 0xffff));
  bytes.splice(8, 2, ...be16(lineGap & 0xffff));
  return bytes;
}

/** `OS/2` — `xAvgCharWidth` is the second field. */
function os2(avgCharWidth: number): number[] {
  const bytes = new Array(32).fill(0);
  bytes.splice(2, 2, ...be16(avgCharWidth & 0xffff));
  return bytes;
}

/** Assembles a table directory around the given tables, at 4-byte-aligned offsets. */
function sfnt(tables: Record<string, number[]>, signature: number[] = [0x00, 0x01, 0x00, 0x00]): Uint8Array {
  const entries = Object.entries(tables);
  const header = [...signature, ...be16(entries.length), 0, 0, 0, 0, 0, 0];
  const directory: number[] = [];
  let offset = header.length + entries.length * 16;
  const bodies: number[] = [];

  for (const [name, body] of entries) {
    // A table tag is always four bytes, padded with spaces.
    directory.push(...ascii(name.padEnd(4, ' ').slice(0, 4)), ...be32(0), ...be32(offset), ...be32(body.length));
    bodies.push(...body);
    const padding = (4 - (body.length % 4)) % 4;
    bodies.push(...new Array(padding).fill(0));
    offset += body.length + padding;
  }

  return Uint8Array.from([...header, ...directory, ...bodies]);
}

/** A TrueType font whose metrics are exactly the ones given. */
function font(metrics: {
  unitsPerEm?: number;
  ascender?: number;
  descender?: number;
  lineGap?: number;
  avgCharWidth?: number;
}): Uint8Array {
  const {
    unitsPerEm = 2048,
    ascender = 1854,
    descender = -434,
    lineGap = 67,
    avgCharWidth = 904,
  } = metrics;
  return sfnt({
    'OS/2': os2(avgCharWidth),
    head: head(unitsPerEm),
    hhea: hhea(ascender, descender, lineGap),
  });
}

function base64(bytes: Uint8Array): string {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const a = bytes[i]!;
    const b = bytes[i + 1];
    const c = bytes[i + 2];
    out += alphabet[a >> 2];
    out += alphabet[((a & 0x03) << 4) | ((b ?? 0) >> 4)];
    out += b === undefined ? '=' : alphabet[((b & 0x0f) << 2) | ((c ?? 0) >> 6)];
    out += c === undefined ? '=' : alphabet[c & 0x3f];
  }
  return out;
}

/* ------------------------------------------------------------------ *
 * Reading the file
 * ------------------------------------------------------------------ */

describe('reading a font file', () => {
  it('decodes base64 to bytes', () => {
    expect([...base64ToBytes('AAECAw==')]).toEqual([0, 1, 2, 3]);
  });

  it('decodes a data URL by skipping its prefix', () => {
    expect([...base64ToBytes('data:font/ttf;base64,AAECAw==')]).toEqual([0, 1, 2, 3]);
  });

  it('ignores whitespace inside the payload', () => {
    expect([...base64ToBytes('AAEC\n Aw==')]).toEqual([0, 1, 2, 3]);
  });

  it('reads the units per em out of `head`', () => {
    expect(parseFontMetrics(font({ unitsPerEm: 1000 }))?.unitsPerEm).toBe(1000);
  });

  it('reads ascender, descender and line gap out of `hhea`', () => {
    const metrics = parseFontMetrics(font({ ascender: 800, descender: -200, lineGap: 40 }));

    expect(metrics).toMatchObject({ ascender: 800, descender: 200, lineGap: 40 });
  });

  it('reports the descender as a magnitude, because the overrides are unsigned', () => {
    expect(parseFontMetrics(font({ descender: -320 }))?.descender).toBe(320);
  });

  it('clamps a negative line gap to zero', () => {
    expect(parseFontMetrics(font({ lineGap: -50 }))?.lineGap).toBe(0);
  });

  it('reads the average character width out of `OS/2`', () => {
    expect(parseFontMetrics(font({ avgCharWidth: 512 }))?.avgCharWidth).toBe(512);
  });

  it('reports no average width when the font has no `OS/2` table', () => {
    const bytes = sfnt({ head: head(2048), hhea: hhea(1854, -434, 67) });

    expect(parseFontMetrics(bytes)?.avgCharWidth).toBeNull();
  });

  it('reports no average width when the field is not filled in', () => {
    expect(parseFontMetrics(font({ avgCharWidth: 0 }))?.avgCharWidth).toBeNull();
  });
});

/* ------------------------------------------------------------------ *
 * Refusing what it cannot read
 * ------------------------------------------------------------------ */

describe('refusing a file it cannot measure', () => {
  it('rejects a WOFF container, whose tables are deflated', () => {
    const bytes = sfnt({ head: head(2048), hhea: hhea(1854, -434, 67) }, ascii('wOFF'));

    expect(parseFontMetrics(bytes)).toBeNull();
  });

  it('rejects a WOFF2 container, whose tables are brotli-compressed', () => {
    const bytes = sfnt({ head: head(2048), hhea: hhea(1854, -434, 67) }, ascii('wOF2'));

    expect(parseFontMetrics(bytes)).toBeNull();
  });

  it('rejects a collection, which holds several fonts', () => {
    const bytes = sfnt({ head: head(2048), hhea: hhea(1854, -434, 67) }, ascii('ttcf'));

    expect(parseFontMetrics(bytes)).toBeNull();
  });

  it('rejects a buffer too short to hold a header', () => {
    expect(parseFontMetrics(Uint8Array.from([0, 1, 0, 0, 0, 2]))).toBeNull();
  });

  it('rejects a font with no `hhea`', () => {
    expect(parseFontMetrics(sfnt({ head: head(2048) }))).toBeNull();
  });

  it('rejects a font with no `head`', () => {
    expect(parseFontMetrics(sfnt({ hhea: hhea(1854, -434, 67) }))).toBeNull();
  });

  it('rejects a units-per-em of zero', () => {
    expect(parseFontMetrics(font({ unitsPerEm: 0 }))).toBeNull();
  });

  it('rejects an impossible units-per-em', () => {
    expect(parseFontMetrics(font({ unitsPerEm: 20000 }))).toBeNull();
  });

  it('rejects a font that claims no vertical extent at all', () => {
    expect(parseFontMetrics(font({ ascender: 0, descender: 0 }))).toBeNull();
  });

  it('accepts a CFF font, which is an OpenType file like any other', () => {
    const bytes = sfnt({ head: head(1000), hhea: hhea(800, -200, 0) }, ascii('OTTO'));

    expect(parseFontMetrics(bytes)?.unitsPerEm).toBe(1000);
  });
});

/* ------------------------------------------------------------------ *
 * The overrides
 * ------------------------------------------------------------------ */

describe('the four descriptors', () => {
  it('leaves a font that already measures like the reference at 100%', () => {
    expect(metricOverrides(parseFontMetrics(font({}))!)).toEqual({
      sizeAdjust: 100,
      ascentOverride: 90.53,
      descentOverride: 21.19,
      lineGapOverride: 3.27,
    });
  });

  it('scales the size by how wide the average glyph is', () => {
    // Half of Arial's average width at the same units per em: the fallback is
    // shrunk to half, so a line breaks in the same place.
    const overrides = metricOverrides(parseFontMetrics(font({ avgCharWidth: 452 }))!);

    expect(overrides.sizeAdjust).toBe(50);
  });

  it('divides the vertical metrics by the size it just applied', () => {
    // 50% size-adjust has already halved the fallback's line box, so the ascent
    // has to be stated against that smaller em, not the original one.
    const overrides = metricOverrides(parseFontMetrics(font({ avgCharWidth: 452 }))!);

    expect(overrides.ascentOverride).toBe(181.05);
    expect(overrides.descentOverride).toBe(42.38);
  });

  it('uses the font’s own units per em, not the reference one', () => {
    // The same proportions as the reference, expressed at 1024 units per em
    // instead of 2048: nothing about the file's scale changes the result.
    const metrics = parseFontMetrics(
      font({ unitsPerEm: 1024, ascender: 926, descender: -217, lineGap: 33, avgCharWidth: 452 })
    )!;
    const overrides = metricOverrides(metrics);

    expect(overrides.sizeAdjust).toBe(100);
    expect(overrides.ascentOverride).toBe(90.43);
    expect(overrides.lineGapOverride).toBe(3.22);
  });

  it('keeps the size at 100% when the font states no average width', () => {
    const overrides = metricOverrides(parseFontMetrics(font({ avgCharWidth: 0 }))!);

    expect(overrides.sizeAdjust).toBe(100);
  });

  it('rounds to two decimals, because a longer number is noise in a stylesheet', () => {
    const overrides = metricOverrides(parseFontMetrics(font({ unitsPerEm: 1000, avgCharWidth: 401 }))!);

    expect(String(overrides.sizeAdjust)).toMatch(/^\d+(\.\d{1,2})?$/);
  });
});

/* ------------------------------------------------------------------ *
 * Naming the fallback
 * ------------------------------------------------------------------ */

describe('naming the fallback', () => {
  it('gives it a family of its own beside the real one', () => {
    expect(fallbackFamily('Inter')).toBe('Inter Fallback');
  });

  it('names it in the stack, right after the real family', () => {
    expect(fontFamilyWithFallback('Inter', 'sans-serif')).toBe("'Inter', 'Inter Fallback', sans-serif");
  });

  it('keeps a space in the family name intact', () => {
    expect(fontFamilyWithFallback('Noto Sans', 'sans-serif')).toContain("'Noto Sans Fallback'");
  });

  it('escapes a quote in the family name', () => {
    expect(fontFamilyWithFallback("D'Angelo", 'sans-serif')).toContain("'D\\'Angelo Fallback'");
  });

  it('falls back to the plain chain when there is no family', () => {
    expect(fontFamilyWithFallback('  ', 'sans-serif')).toBe('sans-serif');
  });

  it('knows which families the export actually embeds', () => {
    expect(isEmbeddedFamily('Inter', [{ family: 'Inter' }])).toBe(true);
    expect(isEmbeddedFamily('Inter', [{ family: 'Roboto' }])).toBe(false);
    expect(isEmbeddedFamily('Inter', undefined)).toBe(false);
    expect(isEmbeddedFamily('Inter', [])).toBe(false);
  });

  it('matches a family regardless of stray whitespace', () => {
    expect(isEmbeddedFamily(' Inter ', [{ family: 'Inter ' }])).toBe(true);
  });
});

/* ------------------------------------------------------------------ *
 * The block the stylesheet gets
 * ------------------------------------------------------------------ */

describe('the @font-face block', () => {
  const css = fallbackFaceCss('Inter', {
    sizeAdjust: 96.5,
    ascentOverride: 93.8,
    descentOverride: 22.4,
    lineGapOverride: 0,
  });

  it('registers the fallback family', () => {
    expect(css).toContain("font-family: 'Inter Fallback';");
  });

  it('downloads nothing, using the machine’s own sans instead', () => {
    expect(css).toContain("src: local('Arial')");
    expect(css).not.toContain('url(');
  });

  it('carries all four descriptors', () => {
    expect(css).toContain('size-adjust: 96.5%;');
    expect(css).toContain('ascent-override: 93.8%;');
    expect(css).toContain('descent-override: 22.4%;');
    expect(css).toContain('line-gap-override: 0%;');
  });
});

/* ------------------------------------------------------------------ *
 * Doing it once
 * ------------------------------------------------------------------ */

describe('measuring a font once', () => {
  it('returns the same object for the same font', () => {
    const payload = base64(font({ unitsPerEm: 1000 }));

    expect(overridesFor('Memo Sans', payload)).toBe(overridesFor('Memo Sans', payload));
  });

  it('returns nothing for a font it cannot read', () => {
    const payload = base64(sfnt({ head: head(2048) }, ascii('wOFF')));

    expect(overridesFor('Compressed Sans', payload)).toBeNull();
  });

  it('measures an embedded font end to end', () => {
    const payload = base64(font({ unitsPerEm: 1000, ascender: 900, descender: -300, avgCharWidth: 500 }));

    expect(overridesFor('End To End', payload)).toMatchObject({ sizeAdjust: 113.27 });
  });
});
