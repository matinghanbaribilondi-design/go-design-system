import { describe, it, expect } from 'vitest';
import { referenceAssets, uniqueAssets } from './asset-references';

/**
 * Assets in the archive.
 *
 * The single-file export inlines images, which is right for one HTML file. The
 * archive has an `assets/` folder, and it was writing the same bytes twice: the
 * file, and the data URL still sitting in `index.html` and `style.css`.
 */

const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUg==';
const OTHER = 'data:image/png;base64,AAAABBBBCCCCDDDD';

const image = (filename: string, content = PNG) => ({ filename, content, type: 'image' });

describe('pointing the document at its files', () => {
  it('replaces an inlined payload with the path to its file', () => {
    const html = `<img src="${PNG}" alt="Logo" />`;

    expect(referenceAssets(html, [image('logo.png')])).toBe('<img src="./assets/logo.png" alt="Logo" />');
  });

  it('replaces it in a stylesheet too', () => {
    const css = `.card { background: url("${PNG}") center / cover no-repeat; }`;

    expect(referenceAssets(css, [image('hero.png')])).toContain('url("./assets/hero.png")');
  });

  it('replaces every occurrence, not just the first', () => {
    const html = `<img src="${PNG}"><img src="${PNG}">`;

    expect(referenceAssets(html, [image('logo.png')]).match(/assets\/logo\.png/g)).toHaveLength(2);
  });

  it('leaves an asset the page never mentions alone', () => {
    const html = '<p>No images here</p>';

    expect(referenceAssets(html, [image('unused.png')])).toBe(html);
  });

  it('does not touch SVG, which is written into the markup as markup', () => {
    const html = '<div><svg><path d="M0 0" /></svg></div>';
    const svg = { filename: 'icon.svg', content: '<svg><path d="M0 0" /></svg>', type: 'svg' };

    expect(referenceAssets(html, [svg])).toBe(html);
  });

  it('keeps a relative base, so an unzipped archive opens from disk', () => {
    const html = `<img src="${PNG}">`;

    expect(referenceAssets(html, [image('logo.png')])).toContain('src="./assets/logo.png"');
  });
});

describe('one file per payload', () => {
  it('collapses identical bytes into a single file', () => {
    const assets = uniqueAssets([image('logo.png'), image('logo.png'), image('logo.png')]);

    expect(assets).toHaveLength(1);
    expect(assets[0]?.filename).toBe('logo.png');
  });

  it('keeps different payloads apart', () => {
    const assets = uniqueAssets([image('logo.png'), image('photo.png', OTHER)]);

    expect(assets).toHaveLength(2);
  });

  it('makes a colliding filename unique instead of overwriting it', () => {
    const assets = uniqueAssets([image('image.png'), image('image.png', OTHER)]);

    expect(assets.map((a) => a.filename)).toEqual(['image.png', 'image-2.png']);
  });

  it('keeps the extension when it renames', () => {
    const assets = uniqueAssets([image('logo.svg.png'), image('logo.svg.png', OTHER)]);

    expect(assets[1]?.filename).toBe('logo.svg-2.png');
  });
});
