import { describe, it, expect, vi } from 'vitest';
import {
  SILENCE_SLOW_MS,
  SILENCE_STALLED_MS,
  createExportLog,
  describeExport,
  formatBytes,
  formatDuration,
  stageLabel,
  type ExportLogEvent,
  type ExportStage,
} from './export-log';

/**
 * The log exists to answer one question — "is this working or is it dead?" —
 * and the only thing that can answer it is the silence between events. So the
 * status tests are the important ones: they pin the thresholds and, more
 * importantly, they pin that a *finished* export is never reported as stalled.
 */

function event(over: Partial<ExportLogEvent> = {}): ExportLogEvent {
  return {
    seq: 0,
    stage: 'convert',
    level: 'info',
    message: 'Converting "Hero"',
    done: 0,
    total: 10,
    at: 0,
    ...over,
  };
}

describe('createExportLog', () => {
  it('stamps increasing sequence numbers and times relative to the start', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-10-17T10:00:00.000Z'));

    const seen: ExportLogEvent[] = [];
    const log = createExportLog((e) => seen.push(e));
    log.report({ stage: 'scan', level: 'info', message: 'Reading pages…', done: 0, total: 0 });

    vi.advanceTimersByTime(1_500);
    log.report({ stage: 'convert', level: 'info', message: 'Converting', done: 1, total: 10 });

    expect(log.events).toHaveLength(2);
    expect(log.events[0]!.seq).toBe(0);
    expect(log.events[1]!.seq).toBe(1);
    expect(log.events[0]!.at).toBe(0);
    expect(log.events[1]!.at).toBe(1_500);
    // The sink and the buffer must agree; the UI reads one, tests read the other.
    expect(seen).toEqual(log.events);

    vi.useRealTimers();
  });

  it('works with no sink attached', () => {
    const log = createExportLog();
    expect(() =>
      log.report({ stage: 'scan', level: 'info', message: 'x', done: 0, total: 0 })
    ).not.toThrow();
    expect(log.events).toHaveLength(1);
  });
});

describe('describeExport', () => {
  it('is idle with no events', () => {
    expect(describeExport([], Date.now(), false).state).toBe('idle');
  });

  it('is working while events are arriving', () => {
    const status = describeExport([event({ at: 1_000 })], 1_000 + 200, true);
    expect(status.state).toBe('working');
    expect(status.silenceMs).toBe(200);
  });

  it('turns slow once the silence passes the threshold', () => {
    const status = describeExport([event({ at: 1_000 })], 1_000 + SILENCE_SLOW_MS, true);
    expect(status.state).toBe('slow');
    expect(status.label).toBe('Waiting');
  });

  it('turns stalled once the silence is long enough to look dead', () => {
    const status = describeExport([event({ at: 1_000 })], 1_000 + SILENCE_STALLED_MS, true);
    expect(status.state).toBe('stalled');
    expect(status.label).toBe('No news');
  });

  it('never calls a finished export stalled, however long ago it finished', () => {
    // This is the bug the whole module is here to avoid: silence after success
    // is indistinguishable from silence after a hang unless `running` is used.
    const events = [event({ stage: 'done', level: 'good', at: 1_000 })];
    const status = describeExport(events, 1_000 + 600_000, false);
    expect(status.state).toBe('done');
    expect(status.label).toBe('Finished');
  });

  it('reports failed when any event was an error, even if the run stopped quietly', () => {
    const events = [
      event({ seq: 0, level: 'info', at: 100 }),
      event({ seq: 1, level: 'error', message: 'Gave up on "Hero"', at: 900 }),
    ];
    expect(describeExport(events, 5_000, false).state).toBe('failed');
  });

  it('counts silence from the start when nothing has been reported yet', () => {
    const status = describeExport([], 5_000, true, 1_000);
    expect(status.silenceMs).toBe(4_000);
    expect(status.state).toBe('slow');
  });

  it('hands back the last event so the UI can name the stage', () => {
    const last = event({ stage: 'dedupe', message: 'Merging repeated components…' });
    expect(describeExport([last], 10, true).last).toBe(last);
  });
});

describe('formatDuration', () => {
  it('scales from milliseconds to minutes', () => {
    expect(formatDuration(0)).toBe('0ms');
    expect(formatDuration(840)).toBe('840ms');
    expect(formatDuration(1_240)).toBe('1.2s');
    expect(formatDuration(12_400)).toBe('12s');
    expect(formatDuration(95_000)).toBe('1m 35s');
    expect(formatDuration(120_000)).toBe('2m');
  });

  it('refuses nonsense rather than printing NaN', () => {
    expect(formatDuration(Number.NaN)).toBe('—');
    expect(formatDuration(-1)).toBe('—');
  });
});

describe('formatBytes', () => {
  it('scales from bytes to megabytes', () => {
    expect(formatBytes(512)).toBe('512 B');
    expect(formatBytes(4_096)).toBe('4.0 KB');
    expect(formatBytes(4_509_715)).toBe('4.3 MB');
  });
});

describe('stageLabel', () => {
  it('has a label for every stage', () => {
    const stages: ExportStage[] = ['scan', 'variables', 'convert', 'dedupe', 'render', 'archive', 'done'];
    for (const stage of stages) {
      expect(stageLabel(stage).length).toBeGreaterThan(0);
    }
  });
});
