import { escapeHtml, toFileSlug } from './style-utils';
import { CANVAS_CSS, CANVAS_SCRIPT } from './canvas-template';
import type { CustomFontData } from '../plugin/types/ir';

/**
 * Whole-file export.
 *
 * The plugin's normal export answers "give me this frame". This one answers
 * "give me the file": every page, every top-level frame, and one stylesheet
 * they all share.
 *
 * The shape it produces is the shape a developer would have built by hand:
 *
 *     index.html               the pages, and what was deduped
 *     pages/<page>.html        that page's canvas — frames where Figma put them
 *     frames/<frame>.html      one frame, alone, as its own document
 *     components/<name>.html   the canonical markup of each component
 *     styles.css               tokens + reset + one rule set per class
 *     manifest.json            the file's own table of contents
 *
 * Three properties make it trustworthy, and all three are testable:
 *
 * 1. **One stylesheet.** A component used on nine pages is written once, so
 *    editing `styles.css` edits the component everywhere. That is the whole
 *    point of deduping; a rule set per page would quietly undo it. The canvas
 *    chrome is page-local CSS, namespaced `.__canvas-*`, so it can never leak
 *    into the design's rules.
 * 2. **The page is a place, not a list.** Figma's canvas is a coordinate
 *    system: a frame's x/y is part of the design. `pages/<page>.html`
 *    reproduces that — every frame absolutely positioned at its own x/y and
 *    its own size — so opening the page looks like opening the canvas, and a
 *    frame that sits beside another in Figma sits beside it in the browser.
 *    Clicking a frame selects it; its own document opens from the inspector.
 * 3. **The manifest is derived, never declared.** It is built from the files
 *    actually written, in the same pass, so it cannot drift from the archive.
 */

export interface WholeFileFrame {
  name: string;
  /**
   * The Figma node id (`1:2`).
   *
   * Only used to build a link back to the source: an archive that can open the
   * frame in Figma is a review tool, not a screenshot. Optional because the
   * harness builds frames without a document behind them.
   */
  nodeId?: string;
  width: number;
  height: number;
  /**
   * Where Figma put the frame on the page, in page coordinates.
   *
   * Page coordinates can be negative and are not normalised by Figma, so the
   * canvas subtracts the bounding box's origin before placing anything — a
   * frame at x = -1200 belongs left of the others, not off the document.
   */
  x: number;
  y: number;
  /** The frame's own markup — the same bytes `frames/<slug>.html` carries. */
  html: string;
  /**
   * The same markup with `data-figma-id` on every layer.
   *
   * Only the canvas needs ids: they are what the Layers panel outlines. Frame
   * documents stay lean, so the two copies of a frame are not forced to carry
   * a debugging attribute they never read.
   */
  canvasHtml?: string;
  /**
   * The frame's layer tree, names and bounds exactly as Figma reports them.
   *
   * The canvas renders this in its Layers panel and uses the ids to outline a
   * selected layer on the frame. Absent on hand-built payloads, where the
   * frame's own row is all there is to show.
   */
  layers?: CanvasLayer;
  /**
   * The frame root's own background, as a CSS value.
   *
   * Used for the canvas placeholder: at the zoom levels where a frame's
   * content is not mounted, a block in the frame's own colour still reads as
   * "a frame", while a block in the wrong colour reads as a bug. Absent when
   * the frame is transparent — then the canvas shows through, exactly as
   * Figma does.
   */
  background?: string;
}

/** One row in the canvas's Layers panel. Coordinates are frame-local. */
export interface CanvasLayer {
  /** Figma node id, repeated as `data-figma-id` in the canvas markup. */
  id: string;
  name: string;
  type: string;
  x: number;
  y: number;
  width: number;
  height: number;
  /** Only present when the layer is hidden in Figma. */
  visible?: false;
  /** Solid fill as a CSS colour, for the inspector's swatch. */
  fill?: string;
  /** A short text preview, for text layers. */
  text?: string;
  children?: CanvasLayer[];
}

export interface WholeFilePage {
  name: string;
  /** The Figma page node id, for the "open in Figma" link. */
  nodeId?: string;
  /**
   * The page's frames, in Figma's own order.
   *
   * The page's markup is composed from these by `buildPageDocument`; the
   * payload never carries the composed page as well, so a frame's markup
   * crosses the plugin boundary exactly once.
   */
  frames: WholeFileFrame[];
  isRtl: boolean;
  /**
   * Component ids used on this page, in first-use order.
   *
   * This is the answer to "which page uses which component" — the page markup
   * carries the same ids as `data-component-id`, so the manifest and the HTML
   * can be joined in either direction.
   */
  components: string[];
}

export interface WholeFileComponent {
  id: string;
  name: string;
  /** The shared class the definition owns. */
  className: string;
  /** How many instances use it, the defining one included. */
  uses: number;
  /** Canonical markup, exactly as the defining instance renders. */
  html: string;
}

export interface WholeFileAsset {
  filename: string;
  content: string;
  type: string;
}

export interface WholeFileSkipped {
  name: string;
  reason: string;
}

export interface WholeFileExportPayload {
  /** Figma file name, used for the archive and the index title. */
  fileName: string;
  /**
   * Figma's key for the file, when the API exposes it.
   *
   * With it, every page and frame can carry a link back to the frame it came
   * from (`figma.com/design/<key>?node-id=…`). Without it — a local copy, an
   * untitled file — the links are simply omitted rather than pointing at
   * nothing.
   */
  fileKey?: string;
  /** ISO timestamp; injected so the output stays deterministic in tests. */
  generatedAt: string;
  /**
   * Whether this archive was exported with responsiveness on.
   *
   * Recorded because the two outputs look identical in a file listing and
   * completely different in a browser: one reflows, one holds the frame's own
   * pixel size. Whoever opens the ZIP should not have to read the CSS to find
   * out which they got.
   */
  responsive: boolean;
  /** One stylesheet for the whole document. */
  css: string;
  pages: WholeFilePage[];
  components: WholeFileComponent[];
  assets: WholeFileAsset[];
  customFonts?: CustomFontData[];
  dedupe: { merged: number; standalone: number };
  skipped: WholeFileSkipped[];
}

/** A frame as the manifest lists it: where it is, and where to open it. */
export interface ManifestFrame {
  name: string;
  width: number;
  height: number;
  x: number;
  y: number;
  file: string;
  nodeId?: string;
  /** Deep link back to this frame in Figma; absent when the file key is. */
  url?: string;
}

export interface WholeFileManifest {
  file: string;
  fileKey?: string;
  generatedAt: string;
  responsive: boolean;
  stylesheet: string;
  /** The canvas's own CSS and script, shared by every page. */
  canvas: { stylesheet: string; script: string; nav: string };
  pages: {
    name: string;
    file: string;
    nodeId?: string;
    url?: string;
    frames: ManifestFrame[];
    components: string[];
  }[];
  components: { id: string; name: string; file: string; className: string; uses: number }[];
  dedupe: { definitions: number; merged: number; standalone: number };
  assets: string[];
  skipped: WholeFileSkipped[];
  stats: {
    pages: number;
    frames: number;
    components: number;
    /** Bytes of everything in the archive except `manifest.json` itself. */
    contentBytes: number;
  };
}

/** One entry in the archive. `base64` marks binary content (fonts, images). */
export interface ExportFile {
  path: string;
  content: string;
  base64?: boolean;
}

/** `styles.css` sits at the archive root; page files link back up to it. */
const STYLESHEET = 'styles.css';
/**
 * The canvas is chrome, and chrome is shared.
 *
 * It used to be inlined into every page, which meant nine copies of the same
 * 9 KB and nine places to fix one bug. It also meant a page could never be
 * cached between visits. Three files at the root instead: the stylesheet, the
 * script, and the navigation data the script needs (see `buildNavScript`).
 */
const CANVAS_STYLESHEET = 'canvas.css';
const CANVAS_SCRIPT_FILE = 'canvas.js';
const CANVAS_NAV_FILE = 'nav.js';
const README_FILE = 'README.md';
const PAGES_DIR = 'pages';
const FRAMES_DIR = 'frames';
const COMPONENTS_DIR = 'components';

/**
 * A node's address inside Figma.
 *
 * Figma spells a node id with a hyphen in URLs (`1:2` becomes `1-2`), and a
 * link that lands on the wrong node is worse than no link, so the translation
 * lives in one place.
 */
function figmaNodeUrl(fileKey: string, nodeId: string): string {
  return `https://www.figma.com/design/${fileKey}?node-id=${nodeId.replace(/:/g, '-')}`;
}

/** JSON that is safe to paste into a script file, `</script>` included. */
function safeJson(value: unknown): string {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

/**
 * Empty margin around the page's bounding box, in design pixels.
 *
 * A canvas whose frames touch the window edge reads as a cropped screenshot;
 * the margin is what makes it read as a canvas.
 */
const CANVAS_PADDING = 80;

/**
 * Hands out a unique slug.
 *
 * Figma happily names two pages "Home", and two components "Button" — a ZIP
 * cannot, so the second becomes `home-2`. Allocation is order-dependent but
 * deterministic, which is all a generated archive needs.
 */
function allocateSlug(base: string, taken: Set<string>): string {
  let slug = base;
  let n = 2;
  while (taken.has(slug)) {
    slug = `${base}-${n}`;
    n += 1;
  }
  taken.add(slug);
  return slug;
}

/** A standalone document that links the shared stylesheet. */
function documentShell(options: {
  title: string;
  isRtl: boolean;
  body: string;
  comment?: string;
}): string {
  const { title, isRtl, body, comment } = options;
  const htmlAttrs = isRtl ? ' lang="fa" dir="rtl"' : ' lang="en"';
  const note = comment ? `\n<!-- ${comment} -->` : '';
  return `<!DOCTYPE html>
<html${htmlAttrs}>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(title)}</title>
  <link rel="stylesheet" href="../${STYLESHEET}">
</head>
<body>${note}
${body}
</body>
</html>
`;
}

/** Snippet shown inline in the index; longer components link out instead. */
const INLINE_SNIPPET_MAX = 2_400;

/**
 * The index: what is in this archive, and which page uses which component.
 *
 * Deliberately self-contained — it links no stylesheet, so it still reads
 * correctly if someone deletes `styles.css` to start over.
 */
function buildIndexHtml(payload: WholeFileExportPayload, entries: {
  pages: {
    name: string;
    slug: string;
    nodeId?: string;
    frames: { frame: WholeFileFrame; slug: string }[];
    components: string[];
  }[];
  components: { id: string; name: string; slug: string; uses: number; className: string; html: string }[];
}): string {
  const { pages, components } = entries;
  const frameCount = pages.reduce((sum, p) => sum + p.frames.length, 0);
  const nameById = new Map(components.map((c) => [c.id, c.name]));

  const pageItems = pages
    .map((page) => {
      // Frames link to their own documents: the index is the second way in,
      // for anyone who would rather read a list than hunt on a canvas.
      const frames = page.frames
        .map(
          ({ frame, slug }) =>
            `<li><a href="${FRAMES_DIR}/${slug}.html">${escapeHtml(frame.name)}</a> <span class="dim">${
              frame.width
            }×${frame.height}</span></li>`
        )
        .join('\n            ');
      // The components this page actually contains — the manifest's
      // `pages[].components`, rendered. It is the one line that answers
      // "where is this button used?" without grepping.
      const used = page.components
        .map((id) => nameById.get(id) ?? id)
        .map((name) => `<span class="chip">${escapeHtml(name)}</span>`)
        .join(' ');
      // One link per page back to the source. Per frame would be 274 links;
      // the page is the thing you came from, and the canvas finds the frame.
      const figma =
        payload.fileKey && page.nodeId
          ? ` <a class="dim" href="${figmaNodeUrl(
              payload.fileKey,
              page.nodeId
            )}" target="_blank" rel="noopener" title="Open this page in Figma">figma ↗</a>`
          : '';
      return `      <li>
        <a href="${PAGES_DIR}/${page.slug}.html">${escapeHtml(page.name)}</a>
        <span class="dim">${page.frames.length} frame${page.frames.length === 1 ? '' : 's'}</span>${figma}
        <ul class="frames">
            ${frames}
        </ul>
        ${used ? `<div class="uses">${used}</div>` : ''}
      </li>`;
    })
    .join('\n');

  const componentItems = components
    .map((c) => {
      const snippet =
        c.html.length > INLINE_SNIPPET_MAX
          ? `${c.html.slice(0, INLINE_SNIPPET_MAX)}\n… truncated, see ${COMPONENTS_DIR}/${c.slug}.html`
          : c.html;
      return `      <li>
        <a href="${COMPONENTS_DIR}/${c.slug}.html">${escapeHtml(c.name)}</a>
        <span class="dim">${c.uses} use${c.uses === 1 ? '' : 's'} · <code>.${escapeHtml(
          c.className
        )}</code></span>
        <details>
          <summary>canonical markup</summary>
          <pre><code>${escapeHtml(snippet)}</code></pre>
        </details>
      </li>`;
    })
    .join('\n');

  const skippedBlock =
    payload.skipped.length > 0
      ? `\n  <h2>Skipped (${payload.skipped.length})</h2>\n  <ul>\n${payload.skipped
          .map((s) => `    <li>${escapeHtml(s.name)} <span class="dim">${escapeHtml(s.reason)}</span></li>`)
          .join('\n')}\n  </ul>`
      : '';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(payload.fileName)} — export</title>
  <style>
    :root { color-scheme: light; }
    body {
      margin: 0;
      padding: 48px 24px;
      font: 14px/1.6 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
      color: #1f2328;
      background: #f6f7f9;
    }
    main { max-width: 720px; margin: 0 auto; }
    h1 { font-size: 22px; margin: 0 0 4px; letter-spacing: -0.01em; }
    h2 { font-size: 13px; text-transform: uppercase; letter-spacing: 0.06em; color: #59636e; margin: 32px 0 8px; }
    .meta { color: #59636e; margin: 0 0 8px; }
    .mode { font-size: 11px; padding: 1px 8px; border-radius: 999px; font-weight: 600;
            background: #eef1f4; color: #44505c; border: 1px solid #dde3ea; }
    .summary { display: flex; gap: 20px; flex-wrap: wrap; margin: 20px 0 0; padding: 14px 16px;
               background: #fff; border: 1px solid #d8dee4; border-radius: 10px; }
    .summary div { font-size: 12px; color: #59636e; }
    .summary strong { display: block; font-size: 18px; color: #1f2328; }
    ul { list-style: none; margin: 0; padding: 0; }
    li { padding: 7px 0; border-bottom: 1px solid #e6e9ed; }
    li:last-child { border-bottom: 0; }
    a { color: #0969da; text-decoration: none; font-weight: 500; }
    a:hover { text-decoration: underline; }
    .dim { color: #6e7781; font-size: 12px; margin-left: 6px; }
    .frames { margin: 4px 0 0 14px; }
    .frames li { border: 0; padding: 1px 0; font-size: 12px; color: #59636e; }
    .frames a { font-weight: 400; }
    .uses { margin-top: 6px; display: flex; flex-wrap: wrap; gap: 4px; }
    .chip { font-size: 11px; padding: 1px 7px; border-radius: 999px;
            background: #eef1f4; color: #44505c; border: 1px solid #dde3ea; }
    details { margin-top: 6px; }
    summary { font-size: 12px; color: #0969da; cursor: pointer; }
    pre { margin: 6px 0 0; padding: 10px 12px; background: #fff; border: 1px solid #d8dee4;
          border-radius: 8px; overflow-x: auto; }
    pre code { background: none; padding: 0; font-size: 11px; line-height: 1.5; }
    code { font: 12px ui-monospace, SFMono-Regular, Menlo, monospace; background: #eef1f4;
           padding: 1px 5px; border-radius: 4px; }
  </style>
</head>
<body>
  <main>
    <h1>${escapeHtml(payload.fileName)}</h1>
    <p class="meta">
      Exported ${escapeHtml(payload.generatedAt)} ·
      <span class="mode">${payload.responsive ? 'responsive' : 'fixed size'}</span>
    </p>

    <div class="summary">
      <div><strong>${pages.length}</strong>page${pages.length === 1 ? '' : 's'}</div>
      <div><strong>${frameCount}</strong>frame${frameCount === 1 ? '' : 's'}</div>
      <div><strong>${components.length}</strong>component${components.length === 1 ? '' : 's'}</div>
      <div><strong>${payload.dedupe.merged}</strong>instance${payload.dedupe.merged === 1 ? '' : 's'} reused</div>
    </div>

    <h2>Pages</h2>
    <ul>
${pageItems}
    </ul>

    <h2>Components</h2>
    <ul>
${componentItems}
    </ul>
${skippedBlock}

    <h2>Files</h2>
    <ul>
      <li><code>${STYLESHEET}</code> <span class="dim">tokens, reset and every rule, shared by all pages</span></li>
      <li><code>${CANVAS_STYLESHEET}</code> <code>${CANVAS_SCRIPT_FILE}</code> <code>${CANVAS_NAV_FILE}</code> <span class="dim">the canvas chrome, shared and cacheable</span></li>
      <li><code>manifest.json</code> <span class="dim">this listing, machine-readable</span></li>
      <li><code>${README_FILE}</code> <span class="dim">the same explanation, for whoever opens the ZIP</span></li>
      <li><code>${PAGES_DIR}/</code> <span class="dim">one canvas per Figma page — frames at their own x/y</span></li>
      <li><code>${FRAMES_DIR}/</code> <span class="dim">one document per frame, opened by clicking it on the canvas</span></li>
      <li><code>${COMPONENTS_DIR}/</code> <span class="dim">the canonical markup of each component, as a copyable fragment</span></li>
      <li><code>assets/</code> <code>fonts/</code> <span class="dim">file copies of what the markup inlines</span></li>
    </ul>
  </main>
</body>
</html>
`;
}

/**
 * A page after slug allocation.
 *
 * Both the page document and the manifest are built from this, so they cannot
 * disagree about a filename.
 */
interface PageEntry {
  page: WholeFilePage;
  slug: string;
  frames: { frame: WholeFileFrame; slug: string }[];
}

/**
 * One page, as a canvas.
 *
 * Frames keep their Figma coordinates minus the bounding box's origin, so a
 * page whose frames start at x = 1200 does not open on 1200px of nothing.
 * Negative coordinates work the same way: the bounding box is the origin, not
 * the page's 0,0.
 *
 * The page is *only* the canvas and its chrome. Its CSS and its script live at
 * the archive root and are linked, so this file carries no inline style or
 * script at all — the same rule that keeps `styles.css` shared, applied to the
 * canvas itself. The direction of the design comes back as a `dir` attribute
 * on each frame rather than a per-page `<style>` block.
 */
function buildPageDocument(
  payload: WholeFileExportPayload,
  entry: PageEntry,
  allPages: PageEntry[]
): string {
  const { page, frames, slug: pageSlug } = entry;

  let minX = 0;
  let minY = 0;
  let maxX = 0;
  let maxY = 0;
  if (frames.length > 0) {
    minX = Math.min(...frames.map(({ frame }) => frame.x));
    minY = Math.min(...frames.map(({ frame }) => frame.y));
    maxX = Math.max(...frames.map(({ frame }) => frame.x + frame.width));
    maxY = Math.max(...frames.map(({ frame }) => frame.y + frame.height));
  }

  const planeWidth = maxX - minX + CANVAS_PADDING * 2;
  const planeHeight = maxY - minY + CANVAS_PADDING * 2;

  // The canvas is LTR (coordinates are a coordinate system, not a paragraph),
  // so the design's own direction is restored on each frame.
  const frameDirection = page.isRtl ? 'rtl' : 'ltr';

  const FRAME_ICON =
    '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><path d="M3.5 1v10M8.5 1v10M1 3.5h10M1 8.5h10"/></svg>';
  const PAGE_ICON =
    '<svg width="13" height="13" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round" aria-hidden="true"><path d="M3 1.5h5.5L11 4v8.5H3z"/><path d="M8.5 1.5V4H11"/></svg>';
  const CARET_ICON =
    '<svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 2l3.5 3-3.5 3"/></svg>';
  const CURSOR_ICON =
    '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round" aria-hidden="true"><path d="M3 2l10 5.4-4.2 1.2-1.3 4.4z"/></svg>';
  const HAND_ICON =
    '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 11V6a2 2 0 0 0-4 0v5"/><path d="M14 10V4a2 2 0 0 0-4 0v6"/><path d="M10 10.5V6a2 2 0 0 0-4 0v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/></svg>';
  const SEARCH_ICON =
    '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" aria-hidden="true"><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5L14 14"/></svg>';
  const SUN_ICON =
    '<svg class="__canvas-icon-sun" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" aria-hidden="true"><circle cx="8" cy="8" r="3"/><path d="M8 1.2v1.6M8 13.2v1.6M1.2 8h1.6M13.2 8h1.6M3.2 3.2l1.1 1.1M11.7 11.7l1.1 1.1M12.8 3.2l-1.1 1.1M4.3 11.7l-1.1 1.1"/></svg>';
  const MOON_ICON =
    '<svg class="__canvas-icon-moon" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.4 9.7A5.8 5.8 0 0 1 6.3 2.6a5.8 5.8 0 1 0 7.1 7.1z"/></svg>';
  const EXTERNAL_ICON =
    '<svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 2H2v8h8V7"/><path d="M7 2h3v3M10 2L5 7"/></svg>';
  const BRAND_ICON =
    '<svg width="16" height="16" viewBox="0 0 18 18" fill="none" aria-hidden="true"><rect x="1.5" y="1.5" width="6" height="6" rx="1.4" fill="#f24e1e"/><rect x="10.5" y="1.5" width="6" height="6" rx="1.4" fill="#ff7262"/><rect x="1.5" y="10.5" width="6" height="6" rx="1.4" fill="#0d99ff"/><rect x="10.5" y="10.5" width="6" height="6" rx="1.4" fill="#1abcfe"/></svg>';
  const EMPTY_ICON =
    '<svg width="34" height="34" viewBox="0 0 34 34" fill="none" stroke="currentColor" stroke-width="1.1" aria-hidden="true"><rect x="4.5" y="4.5" width="18" height="18" rx="2"/><rect x="11.5" y="11.5" width="18" height="18" rx="2"/></svg>';

  const items = frames
    .map(({ frame, slug }) => {
      const left = frame.x - minX + CANVAS_PADDING;
      const top = frame.y - minY + CANVAS_PADDING;
      const label = `${frame.name} — ${frame.width}×${frame.height}`;
      // The geometry is repeated as data attributes so the camera can decide
      // what to mount with arithmetic instead of a layout read per frame.
      // The fill is repeated as `data-bg` so the minimap can paint a frame
      // without asking the browser for a computed style.
      const bg = frame.background ? escapeHtml(frame.background) : '';
      const fill = bg ? ` style="background:${bg}"` : '';
      const rootId = frame.layers
        ? ` data-id="${escapeHtml(frame.layers.id)}" data-type="${escapeHtml(frame.layers.type)}"`
        : '';
      const bodyHtml = frame.canvasHtml ?? frame.html;
      return `    <div class="__canvas-item" data-slug="${slug}" data-name="${escapeHtml(
        frame.name
      )}" data-bg="${bg}" data-x="${left}" data-y="${top}" data-w="${frame.width}" data-h="${
        frame.height
      }"${rootId} data-fx="${frame.x}" data-fy="${frame.y}" dir="${frameDirection}" style="left:${left}px;top:${top}px;width:${
        frame.width
      }px;height:${frame.height}px">
      <span class="__canvas-name">${escapeHtml(frame.name)}</span>
      <a class="__canvas-hit" href="../${FRAMES_DIR}/${slug}.html" target="_blank" rel="noopener" draggable="false" tabindex="-1" title="Select ${escapeHtml(
        label
      )} — ⌘/Ctrl-click to open it on its own"></a>
      <div class="__canvas-body"${fill}>
${bodyHtml}
      </div>
    </div>`;
    })
    .join('\n');

  // Layers. Every top-level row is still a real link to the frame's document,
  // so the panel works with scripting off; the script turns a plain click into
  // "select this frame" and leaves a modified click alone.
  const sideItems = frames.length
    ? frames
        .map(({ frame, slug }) => {
          const layer = frame.layers ?? null;
          const hasChildren = Boolean(layer && layer.children && layer.children.length > 0);
          const caret = hasChildren
            ? `<button type="button" class="__canvas-caret" data-expand="${slug}" aria-expanded="false" aria-label="Show layers in ${escapeHtml(
                frame.name
              )}">${CARET_ICON}</button>`
            : `<span class="__canvas-caret __canvas-caret-empty" aria-hidden="true"></span>`;
          return `      <li class="__canvas-layer" data-slug="${slug}">
        <div class="__canvas-line">${caret}<a class="__canvas-row" href="../${FRAMES_DIR}/${slug}.html" data-goto="${slug}"${
          layer ? ` data-layer-id="${escapeHtml(layer.id)}"` : ''
        } title="Select ${escapeHtml(
          frame.name
        )} — ⌘/Ctrl-click to open it on its own"><span class="__canvas-row-icon" aria-hidden="true">${FRAME_ICON}</span><span class="__canvas-row-name">${escapeHtml(
          frame.name
        )}</span><span class="__canvas-row-size">${frame.width}×${frame.height}</span></a></div>
        <ul class="__canvas-children" hidden></ul>
      </li>`;
        })
        .join('\n')
    : '      <li class="__canvas-side-note">This page has no visible frames.</li>';

  const layerFrames: Record<string, CanvasLayer> = {};
  for (const { frame, slug } of frames) {
    if (frame.layers) layerFrames[slug] = frame.layers;
  }
  const layersScript = Object.keys(layerFrames).length
    ? `<script type="application/json" id="__canvas-layers">${safeJson({
        frames: layerFrames,
      })}</script>\n`
    : '';

  const pageItems = allPages
    .map(
      (p) =>
        `      <li><a href="../${PAGES_DIR}/${p.slug}.html"${
          p.slug === pageSlug ? ' aria-current="page"' : ''
        }><span class="__canvas-page-icon" aria-hidden="true">${PAGE_ICON}</span><span class="__canvas-page-name">${escapeHtml(
          p.page.name
        )}</span><span class="__canvas-page-count">${p.frames.length}</span></a></li>`
    )
    .join('\n');

  const count = frames.length;
  const frameLabel = `${count} frame${count === 1 ? '' : 's'}`;
  const figmaUrl =
    payload.fileKey && page.nodeId ? figmaNodeUrl(payload.fileKey, page.nodeId) : null;

  return `<!DOCTYPE html>
<html lang="en" class="__canvas-root">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(page.name)} — ${escapeHtml(payload.fileName)}</title>
  <link rel="stylesheet" href="../${STYLESHEET}">
  <link rel="stylesheet" href="../${CANVAS_STYLESHEET}">
</head>
<body class="__canvas-doc" data-page="${escapeHtml(pageSlug)}">
<!-- ${escapeHtml(page.name)} — the page's canvas. Every frame sits at Figma's
     coordinates; layers and pages keep their Figma names. Click a frame to
     select it, double-click it to select a layer inside, or open it on its own
     from the inspector. -->
<header class="__canvas-top" dir="ltr">
  <a class="__canvas-brand" href="../index.html" title="Back to the file index" aria-label="Back to the file index">${BRAND_ICON}</a>
  <span class="__canvas-sep"></span>
  <div class="__canvas-tools" role="group" aria-label="Tools">
    <button type="button" class="__canvas-tool" data-act="select" aria-pressed="true" aria-label="Move tool (V)" title="Move tool — V">${CURSOR_ICON}</button>
    <button type="button" class="__canvas-tool" data-act="hand" id="__canvas-hand" aria-pressed="false" aria-label="Hand tool (H)" title="Hand tool — H (hold space to borrow it)">${HAND_ICON}</button>
  </div>
  <span class="__canvas-sep"></span>
  <a class="__canvas-file" href="../index.html" title="Back to the file index">${escapeHtml(payload.fileName)}</a>
  <span class="__canvas-crumb">/</span>
  <span class="__canvas-page" title="${escapeHtml(page.name)}">${escapeHtml(page.name)}</span>
  <span class="__canvas-grow"></span>
  <button type="button" class="__canvas-search" data-act="jump" title="Search every page and frame (⌘K / Ctrl-K)">${SEARCH_ICON}<span>Search</span><kbd>⌘K</kbd></button>
  <span class="__canvas-count">${frameLabel}</span>
  <button type="button" class="__canvas-iconbtn" id="__canvas-theme" data-act="theme" aria-pressed="false" aria-label="Toggle theme" title="Switch to light theme">${SUN_ICON}${MOON_ICON}</button>${
    figmaUrl
      ? `\n  <a class="__canvas-figma" href="${figmaUrl}" target="_blank" rel="noopener" title="Open this page in Figma">Figma ↗</a>`
      : ''
  }
</header>

<aside class="__canvas-side" aria-label="Pages and layers">
  <div class="__canvas-panel-head">Pages <span>${allPages.length}</span></div>
  <ul class="__canvas-pages">
${pageItems}
  </ul>
  <div class="__canvas-panel-head __canvas-layers-head">Layers <span>${count}</span></div>
  <ul class="__canvas-list">
${sideItems}
  </ul>
</aside>

<div class="__canvas-vp" id="__canvas-vp" role="region" tabindex="0" aria-label="Canvas: ${escapeHtml(
    page.name
  )}">
  <div class="__canvas-sizer" id="__canvas-sizer" style="width:${planeWidth}px;height:${planeHeight}px">
    <div class="__canvas-plane" id="__canvas-plane" data-w="${planeWidth}" data-h="${planeHeight}" style="width:${planeWidth}px;height:${planeHeight}px">
${items}

      <div class="__canvas-sel" id="__canvas-sel" hidden aria-hidden="true">
        <span class="__canvas-sel-tag" id="__canvas-sel-tag"></span>
        <i class="__canvas-sel-handle __canvas-sel-handle-nw"></i>
        <i class="__canvas-sel-handle __canvas-sel-handle-ne"></i>
        <i class="__canvas-sel-handle __canvas-sel-handle-sw"></i>
        <i class="__canvas-sel-handle __canvas-sel-handle-se"></i>
      </div>
      <div class="__canvas-marquee" id="__canvas-marquee" hidden aria-hidden="true"></div>
    </div>
  </div>
</div>

<aside class="__canvas-inspect" id="__canvas-inspect" aria-label="Selection">
  <div class="__canvas-inspect-empty" id="__canvas-inspect-empty">
    ${EMPTY_ICON}
    <p class="__canvas-inspect-title">Nothing selected</p>
    <p class="__canvas-inspect-hint">Click a frame to inspect it. Double-click a frame to select a layer inside it.</p>
  </div>
  <div class="__canvas-inspect-body" id="__canvas-inspect-body" hidden>
    <div class="__canvas-inspect-head">
      <div class="__canvas-inspect-kind" id="__canvas-inspect-kind">Frame</div>
      <div class="__canvas-inspect-name" id="__canvas-inspect-name">Frame</div>
    </div>
    <section class="__canvas-inspect-section" id="__canvas-inspect-fields">
      <h3 class="__canvas-inspect-heading">Position</h3>
      <div class="__canvas-fields">
        <div class="__canvas-field"><span>X</span><b id="__canvas-field-x">0</b></div>
        <div class="__canvas-field"><span>Y</span><b id="__canvas-field-y">0</b></div>
        <div class="__canvas-field"><span>W</span><b id="__canvas-field-w">0</b></div>
        <div class="__canvas-field"><span>H</span><b id="__canvas-field-h">0</b></div>
      </div>
    </section>
    <section class="__canvas-inspect-section" id="__canvas-inspect-fill" hidden>
      <h3 class="__canvas-inspect-heading">Fill</h3>
      <div class="__canvas-fill"><span class="__canvas-swatch" id="__canvas-inspect-swatch"></span><span id="__canvas-inspect-fill-value">—</span></div>
    </section>
    <section class="__canvas-inspect-section" id="__canvas-inspect-text" hidden>
      <h3 class="__canvas-inspect-heading">Text</h3>
      <p class="__canvas-text-preview" id="__canvas-inspect-text-value"></p>
    </section>
    <a class="__canvas-open" id="__canvas-inspect-open" href="#" target="_blank" rel="noopener">Open frame ${EXTERNAL_ICON}</a>
    <p class="__canvas-inspect-note" id="__canvas-inspect-note" hidden></p>
  </div>
</aside>

<div class="__canvas-mini __canvas-mini-off" id="__canvas-mini" aria-hidden="true" title="Minimap — click or drag to move the view">
  <canvas id="__canvas-mini-c" width="176" height="120"></canvas>
</div>

<div class="__canvas-hud" dir="ltr" role="group" aria-label="Canvas controls">
  <button type="button" data-act="out" aria-label="Zoom out">−</button>
  <button type="button" data-act="reset" class="__canvas-zoom" id="__canvas-zoom" aria-label="Reset to 100%">100%</button>
  <button type="button" data-act="in" aria-label="Zoom in">+</button>
  <span class="__canvas-sep"></span>
  <button type="button" data-act="fit" aria-label="Zoom to fit">Fit</button>
</div>

<dialog class="__canvas-palette" id="__canvas-palette" aria-label="Jump to a frame or page">
  <input class="__canvas-q" id="__canvas-q" type="search" placeholder="Jump to a frame or page…" autocomplete="off" spellcheck="false" aria-controls="__canvas-results">
  <ul class="__canvas-results" id="__canvas-results" role="listbox" aria-label="Results"></ul>
  <p class="__canvas-hint"><kbd>↑</kbd><kbd>↓</kbd> move · <kbd>↵</kbd> open · <kbd>esc</kbd> close</p>
</dialog>

<script src="../${CANVAS_NAV_FILE}"></script>
${layersScript}<script src="../${CANVAS_SCRIPT_FILE}"></script>
</body>
</html>
`;
}

/**
 * The table of contents the palette searches.
 *
 * A script file rather than JSON because `fetch` is blocked on `file://`, and
 * an archive that only works behind a web server is not an archive. One copy
 * for the whole file, so a ninth page does not make the other eight bigger.
 */
function buildNavScript(payload: WholeFileExportPayload, pages: PageEntry[]): string {
  const nav = {
    // Every canvas lives in `pages/`, so one level up is the archive root.
    base: '../',
    file: payload.fileName,
    index: 'index.html',
    pages: pages.map((entry) => ({
      name: entry.page.name,
      slug: entry.slug,
      file: `${PAGES_DIR}/${entry.slug}.html`,
      frames: entry.frames.map(({ frame, slug }) => ({
        name: frame.name,
        slug,
        file: `${FRAMES_DIR}/${slug}.html`,
        w: frame.width,
        h: frame.height,
      })),
    })),
  };
  return `/* Generated with the archive. The canvas palette reads this; nothing else
   does. It is a script rather than JSON so the archive works from file://. */
window.__CANVAS_NAV = ${safeJson(nav)};
`;
}

/** Bytes of one archive entry. Base64 is 4 characters per 3 bytes. */
function byteLength(file: ExportFile): number {
  if (file.base64) return Math.floor((file.content.length * 3) / 4);
  return new TextEncoder().encode(file.content).length;
}

/**
 * The note that ships with the archive.
 *
 * Built from strings rather than a template literal because it is Markdown and
 * Markdown is mostly backticks. Someone opening this ZIP has no access to the
 * plugin's README, so everything they need to know has to be here.
 */
function buildReadme(
  payload: WholeFileExportPayload,
  pages: PageEntry[],
  componentCount: number
): string {
  const frameCount = pages.reduce((sum, entry) => sum + entry.frames.length, 0);
  const plural = (n: number, word: string) => `${n} ${word}${n === 1 ? '' : 's'}`;
  const lines = [
    `# ${payload.fileName} — export`,
    '',
    `Exported ${payload.generatedAt} · ${
      payload.responsive ? 'responsive' : 'fixed size'
    } · ${plural(pages.length, 'page')} · ${plural(frameCount, 'frame')} · ${plural(
      componentCount,
      'component'
    )}`,
    '',
    'Open `index.html` first: it lists every page, frame and component.',
    '',
    '## What is here',
    '',
    '| path | what it is |',
    '| --- | --- |',
    '| `index.html` | The table of contents. Self-contained: it links no stylesheet. |',
    '| `pages/<page>.html` | A page as a canvas: every frame at the coordinates Figma gave it. |',
    '| `frames/<frame>.html` | One frame, alone, as its own document. |',
    '| `components/<name>.html` | The canonical markup of one component, as a copyable fragment. |',
    '| `styles.css` | Tokens, reset and one rule set per class, shared by every page. |',
    '| `canvas.css`, `canvas.js`, `nav.js` | The canvas chrome. Not part of the design. |',
    '| `manifest.json` | The same listing, machine-readable, with geometry and Figma node ids. |',
    '| `assets/`, `fonts/` | File copies of what the markup already inlines. |',
    '',
    '## Using it',
    '',
    'There is no build step and no server. Open `index.html` from the file system.',
    '',
    '- Click a frame to select it; the inspector shows its type, position, size and fill.',
    '- Double-click a frame to select the topmost layer under the cursor. The layers',
    '  panel keeps Figma\'s names and nesting, and follows the selection.',
    '- `⌘`/`Ctrl`-click a frame, or use **Open frame** in the inspector, to open that',
    '  frame as its own document in a new tab.',
    '- The pages panel switches between Figma pages; frame links still work with the',
    '  canvas script turned off.',
    '- Drag to pan, scroll to pan, and pinch or `⌘`/`Ctrl`-scroll to zoom. Hold',
    '  `space` (or `H`) for the hand tool; `Shift+1` fits, `Shift+0` is 100%.',
    '- `⌘K` / `Ctrl-K` searches every page and frame in the file.',
    '- `Alt+←` / `Alt+→` moves between pages.',
    '- The address bar carries the frame: `pages/home.html#hero` links to one frame on its canvas.',
    '',
    '## Notes',
    '',
    '- `styles.css` is shared on purpose. Editing a class changes every page that',
    '  uses it — that is what component reuse bought, and it is what makes this',
    '  archive editable rather than a set of screenshots.',
    "- A frame's markup appears twice: once on its page's canvas, once in",
    '  `frames/`. HTML has no include, and a canvas that showed placeholders',
    '  instead of the design would not be a canvas.',
    '- The canvas mounts only the frames near the viewport, so a large file opens',
    '  without laying out every frame at once.',
    '- Canvas chrome is namespaced `.__canvas-*`, so it can never leak into the',
    "  design's own rules.",
  ];

  if (payload.skipped.length > 0) {
    lines.push('', '## Skipped', '');
    for (const item of payload.skipped) lines.push(`- **${item.name}** — ${item.reason}`);
  }

  return `${lines.join('\n')}\n`;
}

/** One frame, alone, as a document of its own. */
function buildFrameDocument(payload: WholeFileExportPayload, frame: WholeFileFrame): string {
  return documentShell({
    title: `${frame.name} — ${payload.fileName}`,
    isRtl: false,
    body: frame.html,
    comment: `${frame.name} — ${frame.width}×${frame.height}, exported on its own. The page it sits on is one level up.`,
  });
}

/**
 * Turns a converted document into the archive's file list.
 *
 * Pure on purpose: no Figma, no JSZip, no clock. Everything that varies per run
 * arrives in the payload, so the archive can be asserted on exactly.
 */
export function buildWholeFileExport(payload: WholeFileExportPayload): ExportFile[] {
  const files: ExportFile[] = [];
  const pageSlugs = new Set<string>();
  const frameSlugs = new Set<string>();
  const componentSlugs = new Set<string>();

  // Frame files share one folder, so their slugs are unique across the whole
  // archive rather than per page: two pages can each own a "Home / Desktop".
  const pages: PageEntry[] = payload.pages.map((page) => ({
    page,
    slug: allocateSlug(toFileSlug(page.name, 'page'), pageSlugs),
    frames: page.frames.map((frame) => ({
      frame,
      slug: allocateSlug(toFileSlug(frame.name, 'frame'), frameSlugs),
    })),
  }));

  const components = payload.components.map((component) => ({
    component,
    slug: allocateSlug(toFileSlug(component.name, 'component'), componentSlugs),
  }));

  // 1. One stylesheet for the whole document, and one copy of the chrome.
  files.push({ path: STYLESHEET, content: payload.css });
  files.push({ path: CANVAS_STYLESHEET, content: CANVAS_CSS });
  files.push({ path: CANVAS_SCRIPT_FILE, content: CANVAS_SCRIPT });
  //    The palette searches the whole file, and it has to do that without
  //    reading nine documents, so the table of contents ships as data.
  files.push({ path: CANVAS_NAV_FILE, content: buildNavScript(payload, pages) });

  // 2. One canvas per page, then one document per frame.
  for (const entry of pages) {
    files.push({
      path: `${PAGES_DIR}/${entry.slug}.html`,
      content: buildPageDocument(payload, entry, pages),
    });
  }
  for (const entry of pages) {
    for (const { frame, slug } of entry.frames) {
      files.push({ path: `${FRAMES_DIR}/${slug}.html`, content: buildFrameDocument(payload, frame) });
    }
  }

  // 3. One file per component: the canonical *fragment*, not a document.
  //
  //    This is the file a developer copies from, so it has to be the markup
  //    itself — wrapping it in <html>/<head>/<link> would make it a preview
  //    page that has to be stripped before use. The link back to the pages is
  //    `data-component-id`, which every instance in pages/ also carries.
  for (const { component, slug } of components) {
    files.push({
      path: `${COMPONENTS_DIR}/${slug}.html`,
      content: `<!-- ${component.name} — canonical markup, ${component.uses} use${
        component.uses === 1 ? '' : 's'
      } in this file. -->
<!-- Every instance in pages/ carries data-component-id="${component.id}" and the shared class .${component.className}. -->
${component.html}
`,
    });
  }

  // 4. Assets and fonts. Both are already inlined in the markup; these copies
  //    exist so an image can be swapped for a real file without re-exporting.
  for (const asset of payload.assets) {
    const isDataUrl = asset.content.startsWith('data:');
    if (asset.type === 'svg') {
      files.push({ path: `assets/${asset.filename}`, content: asset.content });
    } else if (isDataUrl) {
      const base64 = asset.content.split(',')[1];
      if (base64) {
        files.push({ path: `assets/${asset.filename}`, content: base64, base64: true });
      }
    }
  }

  for (const font of payload.customFonts ?? []) {
    const base64 = font.base64.includes(',') ? font.base64.split(',')[1] : font.base64;
    if (base64) {
      files.push({ path: `fonts/${font.filename}`, content: base64, base64: true });
    }
  }

  // 5. The README. The archive is a handoff, and a handoff without a note is a
  //    puzzle: `__canvas-*` and `frames/` make sense only if someone says so.
  files.push({ path: README_FILE, content: buildReadme(payload, pages, components.length) });

  // 6. The index and the manifest, both derived from the entries above.
  files.push({
    path: 'index.html',
    content: buildIndexHtml(payload, {
      pages: pages.map((entry) => ({
        name: entry.page.name,
        slug: entry.slug,
        nodeId: entry.page.nodeId,
        frames: entry.frames,
        components: entry.page.components,
      })),
      components: components.map(({ component, slug }) => ({
        id: component.id,
        name: component.name,
        slug,
        uses: component.uses,
        className: component.className,
        html: component.html,
      })),
    }),
  });

  const frameCount = pages.reduce((sum, entry) => sum + entry.frames.length, 0);
  const manifest: WholeFileManifest = {
    file: payload.fileName,
    ...(payload.fileKey ? { fileKey: payload.fileKey } : {}),
    generatedAt: payload.generatedAt,
    responsive: payload.responsive,
    stylesheet: STYLESHEET,
    canvas: {
      stylesheet: CANVAS_STYLESHEET,
      script: CANVAS_SCRIPT_FILE,
      nav: CANVAS_NAV_FILE,
    },
    pages: pages.map((entry) => ({
      name: entry.page.name,
      file: `${PAGES_DIR}/${entry.slug}.html`,
      ...(entry.page.nodeId ? { nodeId: entry.page.nodeId } : {}),
      ...(payload.fileKey && entry.page.nodeId
        ? { url: figmaNodeUrl(payload.fileKey, entry.page.nodeId) }
        : {}),
      frames: entry.frames.map(({ frame, slug }) => ({
        name: frame.name,
        width: frame.width,
        height: frame.height,
        x: frame.x,
        y: frame.y,
        file: `${FRAMES_DIR}/${slug}.html`,
        ...(frame.nodeId ? { nodeId: frame.nodeId } : {}),
        ...(payload.fileKey && frame.nodeId
          ? { url: figmaNodeUrl(payload.fileKey, frame.nodeId) }
          : {}),
      })),
      components: entry.page.components,
    })),
    components: components.map(({ component, slug }) => ({
      id: component.id,
      name: component.name,
      file: `${COMPONENTS_DIR}/${slug}.html`,
      className: component.className,
      uses: component.uses,
    })),
    dedupe: {
      definitions: payload.components.length,
      merged: payload.dedupe.merged,
      standalone: payload.dedupe.standalone,
    },
    assets: payload.assets.map((asset) => `assets/${asset.filename}`),
    skipped: payload.skipped,
    stats: {
      pages: pages.length,
      frames: frameCount,
      components: components.length,
      // Everything except the manifest itself — a file cannot honestly report
      // a size that includes the digits reporting it.
      contentBytes: files.reduce((sum, entry) => sum + byteLength(entry), 0),
    },
  };

  files.push({ path: 'manifest.json', content: `${JSON.stringify(manifest, null, 2)}\n` });

  return files;
}

/** Archive name for a whole-file export, e.g. `my-design-whole-file.zip`. */
export function wholeFileArchiveName(fileName: string): string {
  return `${toFileSlug(fileName, 'figma-file')}-export.zip`;
}
