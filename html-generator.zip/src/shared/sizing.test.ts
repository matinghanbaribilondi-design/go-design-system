import { describe, it, expect } from 'vitest';
import { applyMainAxis, mainAxisBox, type MainAxisSizing } from './sizing';
import type { ConversionOptions } from '../plugin/types/ir';

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
  designWidth: 1200,
};

const box = (sizing: MainAxisSizing, over: Partial<ConversionOptions> = {}) =>
  mainAxisBox(sizing, { ...options, ...over });

/** The number in a `min-width` value, whatever wrapper it came in. */
function floorOf(value: string | undefined): number | null {
  if (!value) return null;
  const match = value.match(/(\d+(?:\.\d+)?)/);
  return match ? Number(match[1]) : null;
}

describe('mainAxisBox — fixed', () => {
  it('keeps the drawn width and takes the item out of the shrink pass', () => {
    expect(box({ role: 'fixed', drawnPx: 40, grow: false })).toEqual({
      width: '40px',
      maxWidth: '100%',
      flexGrow: 0,
      flexShrink: 0,
    });
  });

  it('states no min-width: a control is already rigid through shrink 0', () => {
    expect(box({ role: 'fixed', drawnPx: 40, grow: false }).minWidth).toBeUndefined();
  });
});

describe('mainAxisBox — fill', () => {
  it('is sized by what is left over, with no floor of its own', () => {
    expect(box({ role: 'fill', drawnPx: 600, grow: true })).toEqual({
      flexGrow: 1,
      flexShrink: 1,
      flexBasis: '0%',
      minWidth: '0',
      maxWidth: '100%',
    });
  });

  it('takes a floor when its row reflows, so it can wrap instead of collapsing', () => {
    const sized = box({ role: 'fill', drawnPx: 600, grow: true, floorPx: 280 });
    expect(sized.minWidth).toBe('min(280px, 100%)');
    // A filling column is not given its drawn width: that would pin it.
    expect(sized.width).toBeUndefined();
    expect(sized.flexBasis).toBe('0%');
  });

  /**
   * A flex line breaks on each item's *hypothetical* size — basis clamped by
   * min/max — and it decides that before any shrinking is considered. So the
   * basis is not "how wide should this be", it is "how wide must the line be
   * for this item to count as fitting". A slot that states its drawn width
   * therefore breaks the line it would have been happy to compress into.
   */
  it('caps a slot at its drawn width without using that width as its basis', () => {
    const slot = box({ role: 'fill', drawnPx: 700, grow: true, floorPx: 180, cap: 'drawn' });
    expect(slot.flexBasis).toBe('0%');
    expect(slot.maxWidth).toBe('700px');
    // The only thing the line is measured against is the floor.
    expect(slot.minWidth).toBe('min(180px, 100%)');
  });

  it('fills the line when the row has no alignment slack to protect', () => {
    expect(box({ role: 'fill', drawnPx: 700, grow: true, cap: 'full' }).maxWidth).toBe('100%');
  });
});

describe('mainAxisBox — share', () => {
  it('starts at the drawn width, shrinks, and is capped at the design', () => {
    expect(box({ role: 'share', drawnPx: 360, grow: false })).toEqual({
      flexGrow: 0,
      flexShrink: 1,
      flexBasis: '360px',
      minWidth: '0',
      maxWidth: '360px',
    });
  });

  it('drops the designed cap when the item may fill the line it wrapped onto', () => {
    expect(box({ role: 'share', drawnPx: 360, grow: true, cap: 'full' }).maxWidth).toBe('100%');
  });

  it('grows only when the row asked it to', () => {
    expect(box({ role: 'share', drawnPx: 360, grow: true }).flexGrow).toBe(1);
    expect(box({ role: 'share', drawnPx: 360, grow: false }).flexGrow).toBe(0);
  });
});

/**
 * The invariant the module exists for. Every branch used to be able to write a
 * `min-width`, and the last writer won — which was the drawn width, applied to
 * items whose `flex-basis` had just been lowered. A floor at or above the basis
 * makes the item incompressible, so the row overflows instead of reflowing.
 */
describe('mainAxisBox — a floor can never exceed the drawn width', () => {
  const cases: MainAxisSizing[] = [
    { role: 'fixed', drawnPx: 360, grow: false },
    { role: 'fill', drawnPx: 360, grow: true },
    { role: 'fill', drawnPx: 360, grow: true, floorPx: 234 },
    { role: 'share', drawnPx: 360, grow: false },
    { role: 'share', drawnPx: 360, grow: true, floorPx: 234, cap: 'full' },
    { role: 'share', drawnPx: 40, grow: false, floorPx: 180 },
  ];

  it.each(cases.map((c) => [c.role, c.drawnPx, c] as const))(
    'holds for %s at %ipx',
    (_role, drawnPx, sizing) => {
      const floor = floorOf(box(sizing).minWidth);
      if (floor !== null) expect(floor).toBeLessThanOrEqual(drawnPx);
    }
  );

  it('never states a width on an item that is sized by its basis', () => {
    for (const sizing of cases.filter((c) => c.role !== 'fixed')) {
      expect(box(sizing).width).toBeUndefined();
    }
  });
});

describe('mainAxisBox — units', () => {
  it('expresses every length in rem when asked', () => {
    const rem = { useRem: true, baseFontSize: 16 };
    expect(box({ role: 'share', drawnPx: 320, grow: false }, rem).flexBasis).toBe('20rem');
    expect(box({ role: 'fill', drawnPx: 320, grow: true, floorPx: 280 }, rem).minWidth).toBe(
      'min(17.5rem, 100%)'
    );
  });
});

describe('applyMainAxis', () => {
  it('removes the declarations the box replaces, so no stale width fights the basis', () => {
    const layout = {
      width: '640px',
      minWidth: '640px',
      maxWidth: '640px',
      flexGrow: 0,
      flexShrink: 1,
      flexBasis: '640px',
      height: '40px',
    };

    applyMainAxis(layout, box({ role: 'fill', drawnPx: 640, grow: true }));

    expect(layout.width).toBeUndefined();
    expect(layout.minWidth).toBe('0');
    expect(layout.maxWidth).toBe('100%');
    expect(layout.flexBasis).toBe('0%');
    // Everything the box does not own is left alone.
    expect(layout.height).toBe('40px');
  });
});
