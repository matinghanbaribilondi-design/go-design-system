import { describe, it, expect, vi, afterEach } from 'vitest';
import { TIMED_OUT, guard, isTimedOut } from './async';

/**
 * `guard` is the difference between a stuck frame and a stuck export.
 *
 * These tests are deliberately about the two things that can go wrong in a
 * timeout helper: it fires when the work was merely slow (bad — content is
 * dropped for no reason), and it leaves timers behind after it returns (bad —
 * a 274-frame export would accumulate 548 live timers).
 */

afterEach(() => {
  vi.useRealTimers();
});

/** A promise that never settles — the pathological frame. */
function never<T>(): Promise<T> {
  return new Promise<T>(() => {
    /* deliberately nothing */
  });
}

describe('guard', () => {
  it('returns the value when the work finishes in time', async () => {
    await expect(guard(Promise.resolve(42), { timeoutMs: 1_000 })).resolves.toBe(42);
  });

  it('returns TIMED_OUT rather than hanging when the work never settles', async () => {
    vi.useFakeTimers();
    const promise = guard(never<string>(), { timeoutMs: 300 });
    await vi.advanceTimersByTimeAsync(400);
    await expect(promise).resolves.toBe(TIMED_OUT);
  });

  it('does not time out work that is slow but finishes inside the limit', async () => {
    vi.useFakeTimers();
    const work = new Promise<string>((resolve) => {
      setTimeout(() => resolve('late but fine'), 200);
    });
    const promise = guard(work, { timeoutMs: 1_000 });
    await vi.advanceTimersByTimeAsync(250);
    await expect(promise).resolves.toBe('late but fine');
  });

  it('fires onSlow once, while the work is still running', async () => {
    vi.useFakeTimers();
    const onSlow = vi.fn();
    const work = new Promise<string>((resolve) => {
      setTimeout(() => resolve('done'), 900);
    });
    const promise = guard(work, { timeoutMs: 5_000, slowAfterMs: 100, onSlow });

    await vi.advanceTimersByTimeAsync(150);
    expect(onSlow).toHaveBeenCalledTimes(1);
    // The work has not finished yet — this is the whole point of the callback.
    expect(onSlow.mock.calls[0]![0]).toBeGreaterThanOrEqual(100);

    await vi.advanceTimersByTimeAsync(800);
    await expect(promise).resolves.toBe('done');
    expect(onSlow).toHaveBeenCalledTimes(1);
  });

  it('never calls onSlow when the work beats the threshold', async () => {
    vi.useFakeTimers();
    const onSlow = vi.fn();
    const work = new Promise<string>((resolve) => {
      setTimeout(() => resolve('quick'), 10);
    });
    const promise = guard(work, { timeoutMs: 5_000, slowAfterMs: 500, onSlow });
    await vi.advanceTimersByTimeAsync(50);
    await expect(promise).resolves.toBe('quick');
    expect(onSlow).not.toHaveBeenCalled();
  });

  it('leaves no timers behind once it returns', async () => {
    vi.useFakeTimers();
    await guard(Promise.resolve('ok'), {
      timeoutMs: 10_000,
      slowAfterMs: 5_000,
      onSlow: () => {},
    });
    expect(vi.getTimerCount()).toBe(0);
  });

  it('leaves no timers behind after a timeout either', async () => {
    vi.useFakeTimers();
    const promise = guard(never<string>(), {
      timeoutMs: 100,
      slowAfterMs: 50,
      onSlow: () => {},
    });
    await vi.advanceTimersByTimeAsync(150);
    await promise;
    expect(vi.getTimerCount()).toBe(0);
  });

  it('treats a non-positive or infinite timeout as "wait as long as it takes"', async () => {
    await expect(guard(Promise.resolve('a'), { timeoutMs: 0 })).resolves.toBe('a');
    await expect(guard(Promise.resolve('b'), { timeoutMs: Number.POSITIVE_INFINITY })).resolves.toBe(
      'b'
    );
  });

  it('one hung frame costs one frame, not the export', async () => {
    // The real loop: three frames, the middle one never returns.
    const frames: (() => Promise<string>)[] = [
      () => Promise.resolve('first'),
      () => never<string>(),
      () => Promise.resolve('third'),
    ];

    const results: string[] = [];
    for (const frame of frames) {
      const result = await guard(frame(), { timeoutMs: 40 });
      results.push(isTimedOut(result) ? 'TIMED OUT' : result);
    }

    expect(results).toEqual(['first', 'TIMED OUT', 'third']);
  });

  it('isTimedOut narrows the union', async () => {
    const timedOut = await guard(never<string>(), { timeoutMs: 10 });
    expect(isTimedOut(timedOut)).toBe(true);
    if (!isTimedOut(timedOut)) throw new Error('unreachable');
    expect(timedOut).toBe(TIMED_OUT);

    const value = await guard(Promise.resolve('v'), { timeoutMs: 1_000 });
    expect(isTimedOut(value)).toBe(false);
    if (isTimedOut(value)) throw new Error('unreachable');
    expect(value).toBe('v');
  });
});
