/**
 * Guarded awaits.
 *
 * A Figma document is user data: some layer somewhere will be pathological — a
 * frame with thousands of children, an instance whose master lives in a library
 * that never resolves, a vector export that simply does not come back. Any one
 * of those can stall a loop that awaits it, and the whole export stops moving
 * with no way to tell whether it is working or wedged.
 *
 * So every frame conversion is awaited through `guard`, which does two things:
 *
 * 1. reports that the work is taking a long time, once, while it is still
 *    running — the difference between "slow" and "hung" has to be visible;
 * 2. gives up after a hard limit, so one bad frame costs one frame instead of
 *    the entire export.
 */

/** Returned instead of a value when the work ran out of time. */
export const TIMED_OUT = Symbol('timed-out');
export type TimeoutResult = typeof TIMED_OUT;

export interface GuardOptions {
  /** Hard limit. Past this the work is abandoned and `TIMED_OUT` returned. */
  timeoutMs: number;
  /** Fire `onSlow` once, this long in, if the work is still running. */
  slowAfterMs?: number;
  /** Called once with the elapsed time when the work crosses `slowAfterMs`. */
  onSlow?: (elapsedMs: number) => void;
}

/**
 * Awaits `work`, but never longer than `options.timeoutMs`.
 *
 * The abandoned promise is not cancelled — nothing can cancel a promise in
 * JavaScript — but its result is discarded and the caller moves on. A frame
 * that never returns therefore costs its timeout and nothing more.
 */
export async function guard<T>(work: Promise<T>, options: GuardOptions): Promise<T | TimeoutResult> {
  const { timeoutMs, slowAfterMs = 0, onSlow } = options;
  const startedAt = Date.now();

  let slowTimer: ReturnType<typeof setTimeout> | undefined;
  if (onSlow && slowAfterMs > 0) {
    slowTimer = setTimeout(() => onSlow(Date.now() - startedAt), slowAfterMs);
  }

  let timeoutTimer: ReturnType<typeof setTimeout> | undefined;
  const timeout =
    Number.isFinite(timeoutMs) && timeoutMs > 0
      ? new Promise<TimeoutResult>((resolve) => {
          timeoutTimer = setTimeout(() => resolve(TIMED_OUT), timeoutMs);
        })
      : null;

  try {
    return timeout ? await Promise.race([work, timeout]) : await work;
  } finally {
    if (slowTimer !== undefined) clearTimeout(slowTimer);
    if (timeoutTimer !== undefined) clearTimeout(timeoutTimer);
  }
}

/** `true` when `guard` gave up rather than returning a value. */
export function isTimedOut<T>(result: T | TimeoutResult): result is TimeoutResult {
  return result === TIMED_OUT;
}
