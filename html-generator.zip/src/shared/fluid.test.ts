import { describe, it, expect } from 'vitest';
import {
  columnFloorPx,
  fluidFloor,
  fluidLength,
  fluidOrFixed,
  fluidPercent,
  fluidTypeOrFixed,
  fluidTypeSize,
  wrapFloor,
} from './fluid';
import { FLUID_MIN_RATIO } from './constants';
import type { ConversionOptions } from '../plugin/types/ir';

const base: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
};

const opts = (over: Partial<ConversionOptions> = {}): ConversionOptions => ({ ...base, ...over });

describe('fluidLength', () => {
  it('builds a clamp() whose ceiling is the design value and whose middle is a share of the box that sizes it', () => {
    // 48px designed in a 1200px box → 4% of that box, floor = round(48 * 0.65) = 31px
    expect(fluidLength(48, 1200, opts())).toBe('clamp(31px, 4%, 48px)');
  });

  it('rounds the percentage to two decimals', () => {
    // 32px in 1200px → 2.6666…% → 2.67%
    expect(fluidLength(32, 1200, opts())).toBe('clamp(21px, 2.67%, 32px)');
  });

  it('expresses the bounds in rem when useRem is enabled', () => {
    expect(fluidLength(48, 1200, opts({ useRem: true }))).toBe('clamp(1.938rem, 4%, 3rem)');
  });

  it('tracks the reference, not the viewport', () => {
    // The same 48px padding inside a 600px card is 8% of *that* card, so it
    // renders at 48px there too — the reference is what makes the value
    // intrinsic rather than window-relative.
    expect(fluidLength(48, 600, opts())).toBe('clamp(31px, 8%, 48px)');
  });

  it('returns null when no reference width is known', () => {
    expect(fluidLength(48, 0, opts())).toBeNull();
    expect(fluidLength(48, Number.NaN, opts())).toBeNull();
  });

  it('returns null for non-positive or non-finite values', () => {
    expect(fluidLength(0, 1200, opts())).toBeNull();
    expect(fluidLength(-4, 1200, opts())).toBeNull();
    expect(fluidLength(Number.NaN, 1200, opts())).toBeNull();
  });

  it('returns null when the floor is too close to the value to be worth a clamp', () => {
    // 2px → floor 1px → only 1px of travel
    expect(fluidLength(2, 1200, opts())).toBeNull();
  });

  it('returns null when responsiveness is off, whatever the reference', () => {
    expect(fluidLength(48, 1200, opts({ responsive: false }))).toBeNull();
  });

  it('honours a custom min ratio', () => {
    expect(fluidLength(100, 1000, opts(), 0.5)).toBe('clamp(50px, 10%, 100px)');
    expect(FLUID_MIN_RATIO).toBe(0.65);
  });
});

describe('fluidTypeSize', () => {
  it('expresses type as a share of the query container that will resolve it', () => {
    expect(fluidTypeSize(48, 1200, opts())).toBe('clamp(31px, 4cqi, 48px)');
  });

  it('uses the container width, not the page width, for type inside a rail', () => {
    // A 48px heading inside a 300px rail is 16% of that rail: it renders at
    // 48px at the design width and shrinks with the rail, not with the page.
    expect(fluidTypeSize(48, 300, opts())).toBe('clamp(31px, 16cqi, 48px)');
  });

  it('returns null without a container to measure against', () => {
    expect(fluidTypeSize(48, 0, opts())).toBeNull();
  });
});

describe('fluidPercent', () => {
  it('is the value as a share of the reference, to two decimals', () => {
    expect(fluidPercent(24, 1200)).toBe(2);
    expect(fluidPercent(1, 3)).toBe(33.33);
    expect(fluidPercent(0, 1200)).toBe(0);
    expect(fluidPercent(24, 0)).toBe(0);
  });
});

describe('fluidOrFixed', () => {
  it('keeps values below the threshold fixed', () => {
    expect(fluidOrFixed(16, 1200, opts(), 32)).toBe('16px');
  });

  it('fluidises values at or above the threshold', () => {
    expect(fluidOrFixed(48, 1200, opts(), 32)).toBe('clamp(31px, 4%, 48px)');
  });

  it('falls back to a fixed value when no reference width is available', () => {
    expect(fluidOrFixed(48, 0, opts(), 32)).toBe('48px');
  });
});

describe('fluidTypeOrFixed', () => {
  it('leaves body copy at its designed size', () => {
    expect(fluidTypeOrFixed(16, 1200, opts(), 28)).toBe('16px');
  });

  it('fluidises display type against its container', () => {
    expect(fluidTypeOrFixed(48, 1200, opts(), 28)).toBe('clamp(31px, 4cqi, 48px)');
  });
});

describe('fluidFloor', () => {
  it('is the ratio of the design value', () => {
    expect(fluidFloor(48)).toBe(31);
    expect(fluidFloor(48, 0.5)).toBe(24);
  });
});

describe('columnFloorPx', () => {
  it('is a fraction of the drawn width, capped at the minimum comfortable column', () => {
    expect(columnFloorPx(360)).toBe(234);
    expect(columnFloorPx(1200)).toBe(280);
    expect(columnFloorPx(0)).toBe(0);
  });
});

describe('wrapFloor', () => {
  it('emits a min() floor so a wrapping column can never exceed its container', () => {
    expect(wrapFloor(280, opts())).toBe('min(280px, 100%)');
  });

  it('respects the rem setting', () => {
    expect(wrapFloor(320, opts({ useRem: true }))).toBe('min(20rem, 100%)');
  });

  it('emits a plain length when responsiveness is off', () => {
    expect(wrapFloor(280, opts({ responsive: false }))).toBe('280px');
  });
});
