import { useState, useCallback } from 'react';

/**
 * Shared clipboard hook with legacy fallback.
 * Replaces duplicated `navigator.clipboard` + `execCommand` blocks.
 */
export function useClipboard(timeoutMs = 2000) {
  const [copied, setCopied] = useState(false);

  const copy = useCallback(
    async (text: string, onDone?: (ok: boolean) => void) => {
      let ok = true;
      try {
        await navigator.clipboard.writeText(text);
      } catch {
        try {
          const textarea = document.createElement('textarea');
          textarea.value = text;
          textarea.style.position = 'fixed';
          textarea.style.opacity = '0';
          document.body.appendChild(textarea);
          textarea.select();
          ok = document.execCommand('copy');
          document.body.removeChild(textarea);
        } catch {
          ok = false;
        }
      }
      if (ok) {
        setCopied(true);
        window.setTimeout(() => setCopied(false), timeoutMs);
      }
      onDone?.(ok);
      return ok;
    },
    [timeoutMs]
  );

  return { copied, copy };
}
