import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Eye } from 'lucide-react';
import { Header } from './components/Header';
import { SelectionStatus } from './components/SelectionStatus';
import { PreviewFrame } from './components/PreviewFrame';
import { CodeViewer } from './components/CodeViewer';
import { ActionToolbar } from './components/ActionToolbar';
import { SettingsModal } from './components/SettingsModal';
import { FontManagerModal } from './components/FontManagerModal';
import { ExportLogModal } from './components/ExportLogModal';
import { ConversionOptions, ConversionResult, CustomFontData } from '../plugin/types/ir';
import type { WholeFileExportPayload } from '../shared/whole-file-export';
import { wholeFileArchiveName } from '../shared/whole-file-export';
import { formatBytes, type ExportLogDraft, type ExportLogEvent } from '../shared/export-log';
import {
  buildWholeFileZip,
  downloadBlob,
  summariseWholeFileExport,
} from './lib/whole-file-zip';

/** Debounce for settings -> sandbox round-trips (prevents Figma freezes). */
const RECONVERT_DEBOUNCE_MS = 350;

/**
 * One whole-file export run.
 *
 * The events are kept in the UI rather than read back from the sandbox because
 * the log is also a post-mortem: after an export finishes, or fails, or is
 * closed and reopened, the lines have to still be there.
 */
interface ExportRun {
  running: boolean;
  events: ExportLogEvent[];
  startedAt: number;
}

/** Stable identity, so the log modal's memo is not invalidated every render. */
const EMPTY_EVENTS: ExportLogEvent[] = [];

type PluginMessage =
  | { type: 'INIT' }
  | { type: 'RECONVERT'; options: ConversionOptions }
  | { type: 'EXPORT_DOCUMENT'; options: ConversionOptions }
  | { type: 'CANCEL_DOCUMENT_EXPORT' }
  | { type: 'NOTIFY'; message: string; timeout?: number }
  | { type: 'RESIZE_UI'; width: number; height: number }
  | { type: 'SAVE_CUSTOM_FONTS'; fonts: CustomFontData[] };

export const App: React.FC = () => {
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [nodeName, setNodeName] = useState<string | null>(null);
  const [width, setWidth] = useState<number | undefined>(undefined);
  const [height, setHeight] = useState<number | undefined>(undefined);
  /** Which frame of a multi-frame result the preview and code views show. */
  const [activeFrameIndex, setActiveFrameIndex] = useState<number>(0);
  const [isConverting, setIsConverting] = useState<boolean>(false);
  const [isEmpty, setIsEmpty] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isFontManagerOpen, setIsFontManagerOpen] = useState<boolean>(false);
  const [customFonts, setCustomFonts] = useState<CustomFontData[]>([]);
  // Export preference, not a conversion one: it only changes what the ZIP
  // contains, so it lives here instead of in ConversionOptions (which would
  // otherwise round-trip to the sandbox and trigger a needless reconvert).
  const [tailwindZip, setTailwindZip] = useState<boolean>(false);
  // The preview's own fullscreen, for hosts that will not grant the real thing.
  // The chrome is hidden with CSS rather than unmounted, so the preview keeps
  // its zoom, pan and sizing mode across the toggle.
  const [isImmersive, setIsImmersive] = useState<boolean>(false);
  // Whole-file export: a separate job from the selection preview, with its own
  // log, because it runs for as long as the document is big.
  const [exportRun, setExportRun] = useState<ExportRun | null>(null);
  const [isExportLogOpen, setIsExportLogOpen] = useState<boolean>(false);
  const [isStoppingExport, setIsStoppingExport] = useState<boolean>(false);

  const [options, setOptions] = useState<ConversionOptions>({
    outputMode: 'pure-css',
    useRem: false,
    baseFontSize: 16,
    includeReset: true,
    inlineAssets: true,
    semanticTags: true,
    embedFontsBase64: true,
    // Off by default: the plugin's promise is a pixel-exact reproduction of
    // the frame. Adaptive output is opt-in, so nobody gets a reflowing layout
    // they did not ask for.
    responsive: false,
    intrinsicReflow: true,
  });

  const postToFigma = (message: PluginMessage) => {
    parent.postMessage({ pluginMessage: message }, '*');
  };

  const handleNotify = (message: string) => {
    postToFigma({ type: 'NOTIFY', message });
  };

  const handleRefresh = () => {
    setIsConverting(true);
    postToFigma({ type: 'RECONVERT', options });
  };

  // Whole-file export. Nothing about the current selection or preview changes:
  // this only asks the sandbox for one payload and turns it into an archive.
  const handleExportDocument = () => {
    // Pressing the button again while a run is live must not start a second
    // one — it opens the log instead, which is what the user was reaching for.
    if (exportRun?.running) {
      setIsExportLogOpen(true);
      return;
    }
    setExportRun({ running: true, events: [], startedAt: Date.now() });
    setIsStoppingExport(false);
    setIsExportLogOpen(true);
    postToFigma({ type: 'EXPORT_DOCUMENT', options });
  };

  /**
   * Appends a line the UI itself produced (archive packing, save, failure).
   * `done`/`total` are inherited from the last event so the progress bar does
   * not fall back to zero when the work moves to this side of the boundary.
   */
  const appendExportEvent = (
    draft: Omit<ExportLogDraft, 'done' | 'total'> & { done?: number; total?: number }
  ) => {
    setExportRun((prev) => {
      if (!prev) return prev;
      const last = prev.events.length > 0 ? prev.events[prev.events.length - 1]! : null;
      const event: ExportLogEvent = {
        done: draft.done ?? last?.done ?? 0,
        total: draft.total ?? last?.total ?? 0,
        stage: draft.stage,
        level: draft.level,
        message: draft.message,
        frameMs: draft.frameMs,
        nodeName: draft.nodeName,
        seq: last ? last.seq + 1 : 0,
        at: Date.now() - prev.startedAt,
      };
      return { ...prev, events: [...prev.events, event] };
    });
  };

  /**
   * Stops the run at the next frame boundary. The sandbox cannot pre-empt a
   * frame that is already mid-conversion, so this is a request rather than a
   * kill — and it says so, instead of pretending the export has stopped.
   */
  const handleStopExport = () => {
    if (!exportRun?.running || isStoppingExport) return;
    setIsStoppingExport(true);
    appendExportEvent({
      stage: 'convert',
      level: 'warn',
      message: 'Stop requested — will stop after the frame in progress',
    });
    postToFigma({ type: 'CANCEL_DOCUMENT_EXPORT' });
  };

  const handleCustomFontsChange = (newFonts: CustomFontData[]) => {
    setCustomFonts(newFonts);
    const updatedOptions = { ...options, customFonts: newFonts };
    setOptions(updatedOptions);
    postToFigma({ type: 'SAVE_CUSTOM_FONTS', fonts: newFonts });
  };

  // Debounced reconvert: settings sliders/toggles must not spam the sandbox
  const reconvertTimer = useRef<number | null>(null);
  const handleOptionsChange = (newOptions: ConversionOptions) => {
    setOptions(newOptions);
    setIsConverting(true);
    if (reconvertTimer.current) window.clearTimeout(reconvertTimer.current);
    reconvertTimer.current = window.setTimeout(() => {
      postToFigma({ type: 'RECONVERT', options: newOptions });
    }, RECONVERT_DEBOUNCE_MS);
  };

  useEffect(() => {
    // Notify plugin sandbox that UI is ready
    postToFigma({ type: 'INIT' });

    // Listen for messages from Figma sandbox
    const handleMessage = (event: MessageEvent) => {
      const msg = event.data?.pluginMessage;
      if (!msg) return;

      switch (msg.type) {
        case 'CUSTOM_FONTS_LOADED':
          if (Array.isArray(msg.fonts)) {
            setCustomFonts(msg.fonts);
            setOptions((prev) => ({ ...prev, customFonts: msg.fonts }));
          }
          break;

        case 'SELECTION_EMPTY':
          setIsEmpty(true);
          setResult(null);
          setNodeName(null);
          setActiveFrameIndex(0);
          setIsConverting(false);
          setError(null);
          break;

        case 'CONVERTING_START':
          setIsConverting(true);
          setNodeName(msg.nodeName);
          setWidth(msg.width);
          setHeight(msg.height);
          setIsEmpty(false);
          setError(null);
          break;

        case 'CONVERT_SUCCESS': {
          const payload = msg.payload as ConversionResult;
          const firstFrame = payload.frames?.[0];
          setIsConverting(false);
          setResult(payload);
          setActiveFrameIndex(0);
          // A multi-frame result names the active frame, not the count.
          setNodeName(firstFrame?.nodeName ?? payload.nodeName);
          setWidth(firstFrame?.width ?? payload.width);
          setHeight(firstFrame?.height ?? payload.height);
          setIsEmpty(false);
          setError(null);
          break;
        }

        case 'CONVERT_ERROR':
          setIsConverting(false);
          setError(msg.error);
          break;

        case 'EXPORT_DOCUMENT_LOG': {
          const event = msg.event as ExportLogEvent | undefined;
          if (!event) break;
          setExportRun((prev) =>
            prev
              ? { ...prev, events: [...prev.events, event] }
              : // A log with no run attached means the UI was reloaded mid-export.
                { running: true, events: [event], startedAt: Date.now() - event.at }
          );
          break;
        }

        case 'EXPORT_DOCUMENT_SUCCESS': {
          setExportRun((prev) => (prev ? { ...prev, running: false } : prev));
          setIsStoppingExport(false);
          const payload = msg.payload as WholeFileExportPayload;
          appendExportEvent({
            stage: 'archive',
            level: 'info',
            message: `Packing ${payload.pages.length} page(s) into an archive…`,
          });
          void (async () => {
            try {
              const blob = await buildWholeFileZip(payload);
              const name = wholeFileArchiveName(payload.fileName);
              downloadBlob(blob, name);
              appendExportEvent({
                stage: 'done',
                level: payload.skipped.length > 0 ? 'warn' : 'good',
                message: `Saved ${name} (${formatBytes(blob.size)})${
                  payload.skipped.length > 0
                    ? ` — ${payload.skipped.length} item(s) skipped, see manifest.json`
                    : ''
                }`,
              });
              postToFigma({
                type: 'NOTIFY',
                message: payload.skipped.length
                  ? `Exported ${summariseWholeFileExport(payload)}. ${
                      payload.skipped.length
                    } item${payload.skipped.length === 1 ? '' : 's'} skipped — see manifest.json.`
                  : `Exported ${summariseWholeFileExport(payload)}.`,
              });
            } catch (err) {
              console.error(err);
              appendExportEvent({
                stage: 'done',
                level: 'error',
                message: 'Failed to build the export archive.',
              });
              postToFigma({ type: 'NOTIFY', message: 'Failed to build the export archive.' });
            }
          })();
          break;
        }

        case 'EXPORT_DOCUMENT_ERROR':
          setExportRun((prev) => (prev ? { ...prev, running: false } : prev));
          setIsStoppingExport(false);
          appendExportEvent({
            stage: 'done',
            level: 'error',
            message: String(msg.error ?? 'The whole-file export failed.'),
          });
          postToFigma({ type: 'NOTIFY', message: msg.error });
          break;
      }
    };

    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
      if (reconvertTimer.current) window.clearTimeout(reconvertTimer.current);
    };
  }, []);

  // Immersive mode hides the chrome, which is where every other control lives —
  // including the one that would turn it off. So it has to drop whenever there
  // is nothing to present, or the user would be left looking at an empty panel
  // with no way back.
  useEffect(() => {
    if (!result || viewMode !== 'preview') setIsImmersive(false);
  }, [result, viewMode]);

  /** Clipboard is unreliable inside the plugin iframe; fall back to a temp field. */
  const copyToClipboard = async (text: string) => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
        return;
      }
    } catch {
      // Permission denied — the fallback below still works.
    }
    const area = document.createElement('textarea');
    area.value = text;
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();
    try {
      document.execCommand('copy');
    } finally {
      document.body.removeChild(area);
    }
  };

  const lastExportEvent =
    exportRun && exportRun.events.length > 0
      ? exportRun.events[exportRun.events.length - 1]!
      : null;

  // A multi-frame result carries every document; the views show one of them at
  // a time. Spreading the frame over the shared result keeps `css`, tokens,
  // fonts and assets available to the code viewer.
  const activeFrame = useMemo(() => {
    if (!result) return null;
    const frames = result.frames;
    if (!frames || frames.length <= 1) return result;
    const frame = frames[Math.min(activeFrameIndex, frames.length - 1)]!;
    return { ...result, ...frame };
  }, [result, activeFrameIndex]);

  // While a conversion is running the status line describes the new selection,
  // not the previous result still on screen.
  const frameNames =
    !isConverting && result?.frames && result.frames.length > 1
      ? result.frames.map((frame) => frame.nodeName)
      : undefined;
  const statusName = frameNames && activeFrame ? activeFrame.nodeName : nodeName;
  const statusWidth = frameNames && activeFrame ? activeFrame.width : width;
  const statusHeight = frameNames && activeFrame ? activeFrame.height : height;

  return (
    <div
      className={`app-root flex flex-col h-screen w-screen overflow-hidden bg-[#1e1e1e] text-[#f5f5f5] ${
        isImmersive ? 'is-immersive' : ''
      }`}
    >
      {/* Plugin Header */}
      <Header
        onRefresh={handleRefresh}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenFontManager={() => setIsFontManagerOpen(true)}
        onExportDocument={handleExportDocument}
        onOpenExportLog={() => setIsExportLogOpen(true)}
        isConverting={isConverting}
        isExportingDocument={exportRun?.running ?? false}
        exportProgress={
          lastExportEvent && lastExportEvent.total > 0
            ? { done: lastExportEvent.done, total: lastExportEvent.total }
            : null
        }
        fontCount={result?.usedFonts?.length || 0}
        hasCustomFonts={customFonts.length > 0}
      />

      {/* Selection line: what is selected, and preview/code — one bar, not two */}
      <SelectionStatus
        nodeName={statusName}
        width={statusWidth}
        height={statusHeight}
        isConverting={isConverting}
        isEmpty={isEmpty}
        error={error}
        frameNames={frameNames}
        activeFrameIndex={activeFrameIndex}
        onSelectFrame={frameNames ? setActiveFrameIndex : undefined}
        viewMode={result ? viewMode : undefined}
        onViewModeChange={result ? setViewMode : undefined}
      />

      {/* Main View Area */}
      <div className="preview-host flex-1 overflow-hidden relative">
        {activeFrame ? (
          viewMode === 'preview' ? (
            <PreviewFrame
              htmlContent={activeFrame.combinedHtml}
              width={activeFrame.width}
              height={activeFrame.height}
              isImmersive={isImmersive}
              onToggleImmersive={() => setIsImmersive((v) => !v)}
            />
          ) : (
            <CodeViewer result={activeFrame} onNotify={handleNotify} />
          )
        ) : (
          <div className="flex flex-col items-center justify-center h-full p-8 text-center text-[#8e8e8e]">
            <div className="w-10 h-10 rounded-xl bg-[#252526] border border-[#3e3e42] flex items-center justify-center text-blue-400/80 mb-3">
              <Eye size={20} />
            </div>
            <p className="text-xs font-medium text-[#c8c8c8] mb-1">No frame selected</p>
            <p className="text-[11px] text-[#7f7f7f] max-w-[220px] leading-relaxed">
              Select a frame or component in Figma to convert it.
            </p>
          </div>
        )}
      </div>

      {/* Bottom Action Toolbar */}
      <ActionToolbar
        result={result}
        activeFrame={activeFrame}
        options={options}
        tailwindZip={tailwindZip}
        onNotify={handleNotify}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        options={options}
        onOptionsChange={handleOptionsChange}
        tailwindZip={tailwindZip}
        onTailwindZipChange={setTailwindZip}
      />

      {/* Font Manager Modal */}
      <FontManagerModal
        isOpen={isFontManagerOpen}
        onClose={() => setIsFontManagerOpen(false)}
        usedFonts={result?.usedFonts}
        customFonts={customFonts}
        onCustomFontsChange={handleCustomFontsChange}
        options={options}
        onOptionsChange={handleOptionsChange}
        onNotify={handleNotify}
      />

      {/* Whole-file export log — opens by itself when an export starts, and
          stays readable afterwards so a failure can be copied out. */}
      <ExportLogModal
        isOpen={isExportLogOpen}
        onClose={() => setIsExportLogOpen(false)}
        running={exportRun?.running ?? false}
        events={exportRun?.events ?? EMPTY_EVENTS}
        startedAt={exportRun?.startedAt ?? null}
        onCopy={(text) => {
          void copyToClipboard(text);
        }}
        onStop={handleStopExport}
        stopping={isStoppingExport}
      />
    </div>
  );
};

export default App;
