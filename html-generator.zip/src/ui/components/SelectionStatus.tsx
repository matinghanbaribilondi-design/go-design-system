import React from 'react';
import { Frame, AlertCircle, Loader2, Eye, Code2 } from 'lucide-react';

interface SelectionStatusProps {
  nodeName: string | null;
  width?: number;
  height?: number;
  isConverting: boolean;
  isEmpty: boolean;
  error?: string | null;
  /** Every selected frame, when the result contains more than one. */
  frameNames?: string[];
  activeFrameIndex?: number;
  onSelectFrame?: (index: number) => void;
  /** Present only when there is a result to switch between. */
  viewMode?: 'preview' | 'code';
  onViewModeChange?: (mode: 'preview' | 'code') => void;
}

/**
 * One line about the current selection, and the preview/code switch.
 *
 * This used to be a bordered card plus a second full-width row holding the view
 * switch — two bars, roughly 80px of chrome, saying "Home / Hero · 328 × 150 ·
 * Ready" and nothing else. The dimensions also appeared a third time in the
 * preview toolbar. It is one line now, and the switch lives on it.
 */
export const SelectionStatus: React.FC<SelectionStatusProps> = ({
  nodeName,
  width,
  height,
  isConverting,
  isEmpty,
  error,
  frameNames,
  activeFrameIndex,
  onSelectFrame,
  viewMode,
  onViewModeChange,
}) => {
  const showSwitch = Boolean(viewMode && onViewModeChange && !isEmpty && !error && nodeName);
  const multi = Boolean(frameNames && frameNames.length > 1 && onSelectFrame);

  return (
    <div className="flex items-center justify-between gap-3 h-8 px-3 border-b border-[#3e3e42] bg-[#1e1e1e] text-[11px] shrink-0">
      <div className="flex items-center gap-1.5 min-w-0">
        {error ? (
          <>
            <AlertCircle size={12} className="shrink-0 text-red-400" />
            <span className="truncate text-red-300" title={error}>
              {error}
            </span>
          </>
        ) : isEmpty || !nodeName ? (
          <>
            <AlertCircle size={12} className="shrink-0 text-amber-400/80" />
            {/* Short on purpose: the stage already explains what to do. */}
            <span className="truncate text-[#8e8e8e]">No selection</span>
          </>
        ) : (
          <>
            <Frame size={12} className="shrink-0 text-blue-400" />
            {multi ? (
              <>
                <select
                  value={activeFrameIndex ?? 0}
                  onChange={(event) => onSelectFrame?.(Number(event.target.value))}
                  title="Switch the frame shown in the preview and code view"
                  className="min-w-0 max-w-[170px] cursor-pointer truncate bg-transparent text-[11px] font-medium text-white outline-none"
                >
                  {frameNames!.map((name, index) => (
                    <option key={`${name}-${index}`} value={index} className="bg-[#252526] text-white">
                      {name}
                    </option>
                  ))}
                </select>
                <span className="shrink-0 font-mono text-[10px] text-[#7f7f7f]">
                  {(activeFrameIndex ?? 0) + 1}/{frameNames!.length}
                </span>
              </>
            ) : (
              <span className="truncate text-white font-medium" title={nodeName}>
                {nodeName}
              </span>
            )}
            {width !== undefined && height !== undefined && (
              <span className="shrink-0 font-mono text-[#7f7f7f]">
                {width}×{height}
              </span>
            )}
            {isConverting ? (
              <Loader2 size={11} className="shrink-0 animate-spin text-blue-400" />
            ) : (
              <span className="shrink-0 w-1.5 h-1.5 rounded-full bg-emerald-500/80" />
            )}
          </>
        )}
      </div>

      {showSwitch && (
        <div className="flex items-center bg-[#252526] rounded-md p-0.5 border border-[#3e3e42] shrink-0">
          <button
            onClick={() => onViewModeChange?.('preview')}
            title="Live preview"
            aria-pressed={viewMode === 'preview'}
            className={`p-1 rounded transition ${
              viewMode === 'preview'
                ? 'bg-blue-600 text-white'
                : 'text-[#9e9e9e] hover:text-white'
            }`}
          >
            <Eye size={11} />
          </button>
          <button
            onClick={() => onViewModeChange?.('code')}
            title="Exported code"
            aria-pressed={viewMode === 'code'}
            className={`p-1 rounded transition ${
              viewMode === 'code'
                ? 'bg-blue-600 text-white'
                : 'text-[#9e9e9e] hover:text-white'
            }`}
          >
            <Code2 size={11} />
          </button>
        </div>
      )}
    </div>
  );
};
