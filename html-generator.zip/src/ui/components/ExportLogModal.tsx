import React, { useEffect, useMemo, useRef, useState } from 'react';
import { X, Copy, Check, AlertTriangle, CircleCheck, CircleSlash, Loader2 } from 'lucide-react';
import {
  describeExport,
  formatDuration,
  stageLabel,
  type ExportLogEvent,
  type ExportState,
} from '../../shared/export-log';

interface ExportLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  running: boolean;
  events: ExportLogEvent[];
  /** When the run began, so the clock has something to count from. */
  startedAt: number | null;
  onCopy: (text: string) => void;
  /** Asks the sandbox to stop after the frame it is on. */
  onStop: () => void;
  /** True once Stop has been pressed, so the button cannot be pressed twice. */
  stopping?: boolean;
}

/** How many lines are painted. A 2,000-frame export must not melt the UI. */
const MAX_RENDERED_LINES = 400;
/** How often the clock and the silence counter refresh. */
const TICK_MS = 250;

const STATE_STYLES: Record<ExportState, { pill: string; text: string }> = {
  idle: { pill: 'bg-[#333333] text-[#9e9e9e] border-[#444444]', text: 'text-[#9e9e9e]' },
  working: { pill: 'bg-blue-500/15 text-blue-300 border-blue-500/40', text: 'text-blue-300' },
  slow: { pill: 'bg-amber-500/15 text-amber-300 border-amber-500/40', text: 'text-amber-300' },
  stalled: { pill: 'bg-red-500/15 text-red-300 border-red-500/40', text: 'text-red-300' },
  done: { pill: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40', text: 'text-emerald-300' },
  failed: { pill: 'bg-red-500/15 text-red-300 border-red-500/40', text: 'text-red-300' },
};

const LEVEL_STYLES: Record<ExportLogEvent['level'], string> = {
  info: 'text-[#c8c8c8]',
  good: 'text-emerald-300',
  warn: 'text-amber-300',
  error: 'text-red-300',
};

function StateIcon({ state }: { state: ExportState }) {
  if (state === 'working') return <Loader2 size={12} className="animate-spin" />;
  if (state === 'slow') return <Loader2 size={12} className="animate-spin" />;
  if (state === 'stalled' || state === 'failed') return <CircleSlash size={12} />;
  if (state === 'done') return <CircleCheck size={12} />;
  return <AlertTriangle size={12} />;
}

export const ExportLogModal: React.FC<ExportLogModalProps> = ({
  isOpen,
  onClose,
  running,
  events,
  startedAt,
  onCopy,
  onStop,
  stopping = false,
}) => {
  // The clock is not decoration. An export that has stopped talking still needs
  // the screen to keep moving, otherwise a frozen log is indistinguishable from
  // a frozen plugin.
  const [now, setNow] = useState<number>(() => Date.now());
  const [copied, setCopied] = useState<boolean>(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  // Auto-follow only while the reader is already at the bottom; scrolling up to
  // read an earlier line must not be yanked away by the next frame.
  const followRef = useRef<boolean>(true);

  useEffect(() => {
    if (!isOpen) return;
    setNow(Date.now());
    const timer = window.setInterval(() => setNow(Date.now()), TICK_MS);
    return () => window.clearInterval(timer);
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    if (!followRef.current) return;
    const node = scrollRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [isOpen, events.length, now]);

  const visible = useMemo(
    () => (events.length > MAX_RENDERED_LINES ? events.slice(-MAX_RENDERED_LINES) : events),
    [events]
  );
  const hidden = events.length - visible.length;

  const last = events.length > 0 ? events[events.length - 1]! : null;
  const done = last?.done ?? 0;
  const total = last?.total ?? 0;
  const percent = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;

  // Everything downstream works on the export's own clock. `at` is elapsed-since-
  // start, so `now` has to be too — passing `Date.now()` here would compare an
  // absolute timestamp against a relative one.
  const elapsed = startedAt !== null ? Math.max(0, now - startedAt) : 0;

  const status = describeExport(events, elapsed, running, 0);
  const styles = STATE_STYLES[status.state];

  const handleScroll = () => {
    const node = scrollRef.current;
    if (!node) return;
    const atBottom = node.scrollHeight - node.scrollTop - node.clientHeight < 24;
    followRef.current = atBottom;
  };

  const handleCopy = () => {
    const text = events
      .map((event) => {
        const took = event.frameMs !== undefined ? ` (${formatDuration(event.frameMs)})` : '';
        const where = event.total > 0 ? `${event.done}/${event.total}` : '—';
        return `${formatDuration(event.at).padStart(7)}  ${where.padStart(9)}  [${
          event.stage
        }] ${event.message}${took}`;
      })
      .join('\n');
    onCopy(text);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-3">
      <div className="bg-[#252526] border border-[#3e3e42] rounded-lg shadow-2xl w-full max-w-2xl h-[min(80vh,560px)] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-3 py-2 border-b border-[#3e3e42] bg-[#2d2d2d]">
          <div className="flex items-center gap-2 min-w-0">
            <h2 className="text-xs font-semibold text-white shrink-0">Whole-File Export</h2>
            <span
              className={`flex items-center gap-1 px-1.5 py-0.5 rounded border text-[10px] font-medium shrink-0 ${styles.pill}`}
            >
              <StateIcon state={status.state} />
              {status.label}
            </span>
            <span className="text-[10px] text-[#8e8e8e] truncate">
              {stageLabel(last?.stage ?? 'scan')}
            </span>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <span className="text-[10px] tabular-nums text-[#9e9e9e] font-mono">
              {formatDuration(elapsed)}
            </span>
            <button
              onClick={onClose}
              className="p-1 rounded text-[#9e9e9e] hover:text-white hover:bg-[#3e3e42] transition"
            >
              <X size={14} />
            </button>
          </div>
        </div>

        {/* Progress */}
        <div className="px-3 pt-2.5 pb-2 border-b border-[#3e3e42]/60 bg-[#252526]">
          <div className="flex items-center justify-between text-[10px] text-[#9e9e9e] mb-1">
            <span className="tabular-nums">
              {total > 0 ? `${done} / ${total} frames` : 'Enumerating frames…'}
            </span>
            <span className="tabular-nums">{total > 0 ? `${percent}%` : ''}</span>
          </div>
          <div className="h-1 rounded-full bg-[#1e1e1e] overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                status.state === 'stalled' || status.state === 'failed'
                  ? 'bg-red-500'
                  : status.state === 'slow'
                    ? 'bg-amber-400'
                    : status.state === 'done'
                      ? 'bg-emerald-500'
                      : 'bg-blue-500'
              }`}
              style={{ width: `${percent}%` }}
            />
          </div>
          {/* The silence readout: the only line that tells "slow" from "dead". */}
          {running && status.silenceMs >= 3_000 && (
            <div className={`mt-1.5 text-[10px] leading-relaxed ${styles.text}`}>
              No news for {formatDuration(status.silenceMs)}
              {last && (
                <>
                  {' — last activity: '}
                  <span className="text-[#d8d8d8]">{last.message}</span>
                </>
              )}
              {status.state === 'stalled'
                ? '. The sandbox may be wedged on this frame; each frame is abandoned after 30s.'
                : '. A large frame can take a while — this line is still moving.'}
            </div>
          )}
        </div>

        {/* Log */}
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto bg-[#1e1e1e] px-3 py-2 font-mono text-[10px] leading-[1.55]"
        >
          {events.length === 0 && (
            <div className="text-[#7f7f7f]">Waiting for the sandbox to report…</div>
          )}
          {hidden > 0 && (
            <div className="text-[#6f6f6f] mb-1">… {hidden} earlier line(s) not shown</div>
          )}
          {visible.map((event) => (
            <div key={event.seq} className="flex gap-2 whitespace-pre-wrap break-words">
              <span className="text-[#6f6f6f] tabular-nums shrink-0 w-[52px] text-right">
                {formatDuration(event.at)}
              </span>
              <span className="text-[#5a5a5a] tabular-nums shrink-0 w-[62px] text-right">
                {event.total > 0 ? `${event.done}/${event.total}` : '—'}
              </span>
              <span className={`flex-1 ${LEVEL_STYLES[event.level]}`}>
                {event.message}
                {event.frameMs !== undefined && (
                  <span className="text-[#7f7f7f]"> · {formatDuration(event.frameMs)}</span>
                )}
              </span>
            </div>
          ))}
          {running && (
            <div className="text-[#5a5a5a] animate-pulse">
              <span className="inline-block w-[52px]" />
              <span className="inline-block w-[62px]" />
              ▌
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-3 py-2 border-t border-[#3e3e42] bg-[#2d2d2d] flex items-center justify-between">
          <span className="text-[10px] text-[#7f7f7f]">
            {events.length} event{events.length === 1 ? '' : 's'}
            {total > 0 && running ? ' — safe to close, the export keeps running' : ''}
          </span>
          <div className="flex items-center gap-1.5">
            {running && (
              <button
                onClick={onStop}
                disabled={stopping}
                title="Stop after the frame currently being converted"
                className="flex items-center gap-1 px-2 py-1 rounded bg-[#3a2626] hover:bg-[#4a2e2e] text-red-300 text-[10px] font-medium transition disabled:opacity-50"
              >
                <CircleSlash size={11} />
                {stopping ? 'Stopping…' : 'Stop'}
              </button>
            )}
            <button
              onClick={handleCopy}
              disabled={events.length === 0}
              className="flex items-center gap-1 px-2 py-1 rounded bg-[#333333] hover:bg-[#3e3e42] text-[#c8c8c8] text-[10px] font-medium transition disabled:opacity-40"
            >
              {copied ? <Check size={11} /> : <Copy size={11} />}
              {copied ? 'Copied' : 'Copy log'}
            </button>
            <button
              onClick={onClose}
              className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-medium transition"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
