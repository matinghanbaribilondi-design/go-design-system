import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Maximize2, Maximize, Minimize, Sun, Moon, Grid, Hand, MousePointer } from 'lucide-react';
import { PREVIEW_STAGE_BG } from '../../shared/constants';
import { canPresentFullscreen, fullscreenRoute } from '../lib/fullscreen';
import {
  PreviewSizeMode,
  SIZE_MODE_HINTS,
  SIZE_MODE_LABELS,
  MAX_SCALE,
  MAX_VIEWPORT_WIDTH,
  MIN_SCALE,
  MIN_VIEWPORT_WIDTH,
  STAGE_PADDING,
  clamp,
  computeFrameSize,
  computeTargetScale,
  nextSizeMode,
} from '../lib/preview-size';

/** Common viewport widths, one click away in responsive mode. */
const WIDTH_PRESETS = [320, 768, 1024, 1440];

/** Stage backgrounds, cycled by one button instead of three. */
const BG_MODES = ['checker', 'dark', 'light'] as const;
type BgMode = (typeof BG_MODES)[number];
const BG_MODE_LABELS: Record<BgMode, string> = {
  checker: 'pattern',
  dark: 'dark',
  light: 'light',
};

interface PreviewFrameProps {
  htmlContent: string;
  width?: number;
  height?: number;
  /** The panel-filling fallback, owned by App because it hides App's chrome. */
  isImmersive?: boolean;
  onToggleImmersive?: () => void;
}

export const PreviewFrame: React.FC<PreviewFrameProps> = ({
  htmlContent,
  width = 360,
  height = 640,
  isImmersive = false,
  onToggleImmersive,
}) => {
  const rootRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState<number>(1);
  /** When true the scale is derived from the active size mode. */
  const [autoScale, setAutoScale] = useState<boolean>(true);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [bgMode, setBgMode] = useState<'dark' | 'light' | 'checker'>('checker');
  const [activeTool, setActiveTool] = useState<'select' | 'hand'>('hand');
  const [sizeMode, setSizeMode] = useState<PreviewSizeMode>(() => (height > width * 1.2 ? 'full-width' : 'full-both'));
  /** Explicit responsive viewport width; null means "follow the panel". */
  const [responsiveWidth, setResponsiveWidth] = useState<number | null>(null);
  const [stage, setStage] = useState<{ w: number; h: number }>({ w: 0, h: 0 });
  const [isSpacePressed, setIsSpacePressed] = useState<boolean>(false);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  /** True while the browser itself is presenting the preview fullscreen. */
  const [isNativeFullscreen, setIsNativeFullscreen] = useState<boolean>(false);

  const usableWidth = Math.max(0, stage.w - STAGE_PADDING);
  const usableHeight = Math.max(0, stage.h - STAGE_PADDING);

  const { width: effectiveWidth, height: effectiveHeight } = computeFrameSize(
    sizeMode,
    width,
    height,
    usableWidth,
    responsiveWidth
  );

  const injectedHtmlContent = React.useMemo(() => {
    const wheelScript = `<script>
(function() {
  window.addEventListener('wheel', function(e) {
    window.parent.postMessage({
      type: '__PREVIEW_IFRAME_WHEEL__',
      deltaX: e.deltaX,
      deltaY: e.deltaY,
      ctrlKey: e.ctrlKey,
      metaKey: e.metaKey,
      clientX: e.clientX,
      clientY: e.clientY
    }, '*');
  }, { passive: true });
})();
</script>`;
    if (htmlContent.includes('</body>')) {
      return htmlContent.replace('</body>', `${wheelScript}</body>`);
    }
    return htmlContent + wheelScript;
  }, [htmlContent]);

  const isDraggingRef = useRef<boolean>(false);
  const dragStartRef = useRef<{ startX: number; startY: number; initialPanX: number; initialPanY: number }>({
    startX: 0,
    startY: 0,
    initialPanX: 0,
    initialPanY: 0,
  });
  const scaleRef = useRef<number>(scale);
  const panRef = useRef<{ x: number; y: number }>(pan);

  useEffect(() => {
    scaleRef.current = scale;
  }, [scale]);

  useEffect(() => {
    panRef.current = pan;
  }, [pan]);

  const targetScaleFor = useCallback(
    (mode: PreviewSizeMode): number =>
      computeTargetScale(mode, {
        usableWidth,
        usableHeight,
        frameWidth: effectiveWidth,
        frameHeight: effectiveHeight,
      }),
    [usableWidth, usableHeight, effectiveWidth, effectiveHeight]
  );

  // Derive the zoom from the active mode. Re-running as the viewport width
  // changes keeps a swept viewport fully visible, which a direct numeric
  // control can do safely (unlike a pointer-relative drag).
  useEffect(() => {
    if (!autoScale) return;
    setScale(clamp(targetScaleFor(sizeMode), MIN_SCALE, MAX_SCALE));
  }, [autoScale, sizeMode, targetScaleFor]);

  // Track the stage size so the modes can size themselves against it.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const measure = () => setStage({ w: el.clientWidth, h: el.clientHeight });
    measure();
    if (typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  /** Re-fit and hand control back to the active mode. */
  const handleFit = useCallback(() => {
    setAutoScale(true);
    setPan({ x: 0, y: 0 });
    setScale(clamp(targetScaleFor(sizeMode), MIN_SCALE, MAX_SCALE));
  }, [targetScaleFor, sizeMode]);

  const cycleSizeMode = useCallback(() => {
    setSizeMode((current) => nextSizeMode(current));
    // Each mode owns the zoom until the user zooms by hand.
    setAutoScale(true);
    setPan({ x: 0, y: 0 });
  }, []);

  // Manual zoom detaches from the mode so the user's choice sticks.
  const handleZoomIn = () => {
    setAutoScale(false);
    setScale((s) => clamp(Math.round((s + 0.15) * 100) / 100, MIN_SCALE, MAX_SCALE));
  };
  const handleZoomOut = () => {
    setAutoScale(false);
    setScale((s) => clamp(Math.round((s - 0.15) * 100) / 100, MIN_SCALE, MAX_SCALE));
  };
  const handleResetZoom = () => {
    setAutoScale(false);
    setScale(1);
    setPan({ x: 0, y: 0 });
  };

  const isFullscreen = isNativeFullscreen || isImmersive;

  // Leaving fullscreen by any route — Escape, the browser's own affordance, the
  // button — has to bring the icon back, so the browser's state is mirrored
  // rather than guessed at.
  useEffect(() => {
    const onFullscreenChange = () => {
      setIsNativeFullscreen(document.fullscreenElement === rootRef.current);
    };
    document.addEventListener('fullscreenchange', onFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', onFullscreenChange);
  }, []);

  /**
   * Fullscreen, by whichever route this host allows.
   *
   * The real Fullscreen API gives the whole screen, but it needs the host to
   * have granted the plugin iframe permission for it, which Figma does not
   * always do — so a rejection is expected rather than exceptional, and the
   * preview falls back to filling the panel instead.
   *
   * The whole preview is presented, toolbar included, so the button that got
   * the user in is still there to get them out.
   */
  const handleToggleFullscreen = useCallback(async () => {
    const el = rootRef.current;
    const route = fullscreenRoute({
      isNativeFullscreen: isNativeFullscreen,
      canGoNative: canPresentFullscreen(document.fullscreenEnabled, el),
    });

    if (route === 'exit') {
      await document.exitFullscreen().catch(() => undefined);
      return;
    }

    if (route === 'native' && el) {
      try {
        await el.requestFullscreen();
        return;
      } catch {
        // Not permitted after all; fall through to the in-panel presentation.
      }
    }

    onToggleImmersive?.();
  }, [isNativeFullscreen, onToggleImmersive]);

  const processWheel = useCallback((e: { deltaX: number; deltaY: number; ctrlKey: boolean; metaKey: boolean; clientX: number; clientY: number }) => {
    const el = containerRef.current;
    if (!el) return;

    if (e.ctrlKey || e.metaKey) {
      // Zooming centered on mouse pointer (Figma-style)
      const rect = el.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;

      const currentScale = scaleRef.current;
      const currentPan = panRef.current;

      const zoomDelta = -e.deltaY * 0.005;
      const factor = Math.min(Math.max(Math.exp(zoomDelta), 0.5), 2.0);
      const nextScale = clamp(Math.round(currentScale * factor * 100) / 100, MIN_SCALE, MAX_SCALE);

      if (nextScale === currentScale) return;

      const ratio = nextScale / currentScale;
      const dx = mouseX - centerX;
      const dy = mouseY - centerY;
      const nextPanX = Math.round(dx - (dx - currentPan.x) * ratio);
      const nextPanY = Math.round(dy - (dy - currentPan.y) * ratio);

      setAutoScale(false);
      setScale(nextScale);
      setPan({ x: nextPanX, y: nextPanY });
    } else {
      // Regular wheel / two-finger trackpad panning
      setPan((prev) => ({
        x: Math.round(prev.x - e.deltaX),
        y: Math.round(prev.y - e.deltaY),
      }));
    }
  }, []);

  // Wheel listener: Ctrl/Meta + wheel zooms towards cursor, regular wheel pans
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      processWheel(e);
    };

    const onMessage = (e: MessageEvent) => {
      if (e.data && e.data.type === '__PREVIEW_IFRAME_WHEEL__') {
        processWheel(e.data);
      }
    };

    el.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('message', onMessage);
    return () => {
      el.removeEventListener('wheel', onWheel);
      window.removeEventListener('message', onMessage);
    };
  }, [processWheel]);

  // Keyboard shortcuts: Z cycles the sizing mode, Space pans, H/V pick a tool
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable)
      ) {
        return;
      }

      if (e.code === 'Space' && !e.repeat) {
        setIsSpacePressed(true);
        e.preventDefault();
      } else if (e.key === 'h' || e.key === 'H') {
        setActiveTool('hand');
      } else if (e.key === 'v' || e.key === 'V') {
        setActiveTool('select');
      } else if ((e.key === 'z' || e.key === 'Z') && !e.repeat) {
        cycleSizeMode();
      } else if ((e.key === 'f' || e.key === 'F') && !e.repeat) {
        void handleToggleFullscreen();
      } else if (e.key === 'Escape' && isImmersive) {
        // Escape leaves the browser's own fullscreen without help; this is for
        // the in-panel fallback, which the browser knows nothing about.
        onToggleImmersive?.();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        setIsSpacePressed(false);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [cycleSizeMode, handleToggleFullscreen, isImmersive, onToggleImmersive]);

  // Global mousemove and mouseup listeners during panning
  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current) return;
      const dx = e.clientX - dragStartRef.current.startX;
      const dy = e.clientY - dragStartRef.current.startY;
      setPan({
        x: Math.round(dragStartRef.current.initialPanX + dx),
        y: Math.round(dragStartRef.current.initialPanY + dy),
      });
    };

    const onMouseUp = () => {
      if (isDraggingRef.current) {
        setIsDragging(false);
        isDraggingRef.current = false;
      }
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }, []);

  const handleMouseDown = (e: React.MouseEvent) => {
    const isHand = activeTool === 'hand' || isSpacePressed;
    const isMiddleClick = e.button === 1;

    if (isHand || isMiddleClick) {
      e.preventDefault();
      setIsDragging(true);
      isDraggingRef.current = true;
      dragStartRef.current = {
        startX: e.clientX,
        startY: e.clientY,
        initialPanX: pan.x,
        initialPanY: pan.y,
      };
    }
  };

  const getBgClass = () => {
    switch (bgMode) {
      case 'dark':
        return 'bg-[#18181b]';
      case 'light':
        return 'bg-[#f4f4f5]';
      case 'checker':
      default:
        return 'bg-[radial-gradient(#3e3e42_1px,transparent_1px)] [background-size:16px_16px] bg-[#1a1a1a]';
    }
  };

  const isPanActive = activeTool === 'hand' || isSpacePressed;
  const cursorClass = isDragging ? 'cursor-grabbing' : isPanActive ? 'cursor-grab' : 'cursor-default';
  const isResponsive = sizeMode === 'responsive';

  const cycleBgMode = () => {
    setBgMode((current) => {
      const index = BG_MODES.indexOf(current as BgMode);
      return BG_MODES[(index + 1) % BG_MODES.length]!;
    });
  };

  // The stage only needs to report a size when it is *not* showing the frame at
  // the size it was drawn at; otherwise the selection bar already said it.
  const showStageSize = effectiveWidth !== width || effectiveHeight !== height;

  return (
    <div ref={rootRef} className="flex flex-col h-full bg-[#1e1e1e] border-t border-[#3e3e42]">
      {/* Preview toolbar */}
      <div className="flex items-center justify-between px-2.5 py-1 bg-[#252526] border-b border-[#3e3e42] text-[11px] text-[#9e9e9e] shrink-0">
        <div className="flex items-center space-x-2">
          {/* Tool toggles: Select (V) / Hand (H) */}
          <div className="flex items-center space-x-0.5 mr-1 border-r border-[#3e3e42] pr-2">
            <button
              onClick={() => setActiveTool('select')}
              title="Move / Select (V)"
              className={`p-1 rounded transition ${activeTool === 'select' ? 'bg-[#3e3e42] text-white' : 'hover:bg-[#333333]'}`}
            >
              <MousePointer size={12} />
            </button>
            <button
              onClick={() => setActiveTool('hand')}
              title="Hand Tool (H or hold Space)"
              className={`p-1 rounded transition ${activeTool === 'hand' ? 'bg-[#3e3e42] text-white' : 'hover:bg-[#333333]'}`}
            >
              <Hand size={12} />
            </button>
          </div>

          {/* Sizing mode — press Z to cycle */}
          <button
            onClick={cycleSizeMode}
            title={`${SIZE_MODE_HINTS[sizeMode]}\nPress Z to cycle through the sizing modes`}
            className="px-1.5 py-0.5 rounded border border-[#3e3e42] bg-[#2a2a2d] hover:bg-[#333333] hover:border-[#4e4e52] transition text-[10px] text-white font-medium"
          >
            {SIZE_MODE_LABELS[sizeMode]}
          </button>

          <span className="font-mono text-white text-[11px] tabular-nums">
            {Math.round(scale * 100)}%
          </span>
          {/* Only when the stage is not showing the frame at its own size —
              the selection bar already carries the design's dimensions. */}
          {showStageSize && (
            <span className={`font-mono text-[10px] ${isResponsive ? 'text-blue-400/80' : 'text-[#6e6e6e]'}`}>
              {effectiveWidth}×{effectiveHeight}
            </span>
          )}
        </div>

        <div className="flex items-center space-x-1">
          {/* One button that cycles the stage background, instead of three */}
          <button
            onClick={cycleBgMode}
            title={`Stage background: ${BG_MODE_LABELS[bgMode]} (click to cycle)`}
            className="p-1 rounded hover:bg-[#333333] text-[#9e9e9e] hover:text-white transition"
          >
            {bgMode === 'checker' ? <Grid size={12} /> : bgMode === 'dark' ? <Moon size={12} /> : <Sun size={12} />}
          </button>

          <div className="w-[1px] h-3 bg-[#3e3e42] mx-1" />

          {/* Fit to view */}
          <button
            onClick={handleFit}
            title={`Fit to view (${SIZE_MODE_LABELS[sizeMode]})`}
            className="p-1 rounded hover:bg-[#333333] text-blue-400 hover:text-blue-300 transition"
          >
            <Maximize2 size={12} />
          </button>

          {/* 100% Reset */}
          <button
            onClick={handleResetZoom}
            title="100% Size"
            className="p-1 rounded hover:bg-[#333333] transition"
          >
            <RotateCcw size={12} />
          </button>

          {/* Zoom controls */}
          <button
            onClick={handleZoomOut}
            title="Zoom Out"
            className="p-1 rounded hover:bg-[#333333] transition"
          >
            <ZoomOut size={12} />
          </button>
          <button
            onClick={handleZoomIn}
            title="Zoom In"
            className="p-1 rounded hover:bg-[#333333] transition"
          >
            <ZoomIn size={12} />
          </button>

          <div className="w-[1px] h-3 bg-[#3e3e42] mx-1" />

          {/* Fullscreen — F toggles it */}
          <button
            onClick={() => void handleToggleFullscreen()}
            title={`${isFullscreen ? 'Exit fullscreen' : 'Fullscreen'} (F)`}
            aria-pressed={isFullscreen}
            className={`p-1 rounded transition ${
              isFullscreen ? 'bg-[#3e3e42] text-white' : 'hover:bg-[#333333]'
            }`}
          >
            {isFullscreen ? <Minimize size={12} /> : <Maximize size={12} />}
          </button>
        </div>
      </div>

      {/* Responsive viewport width — only meaningful in responsive mode */}
      {isResponsive && (
        <div className="flex items-center space-x-2 flex-wrap px-2.5 py-1 bg-[#232324] border-b border-[#3e3e42] text-[10px] text-[#9e9e9e] shrink-0">
          <span className="text-blue-400 font-medium">Viewport</span>
          <input
            type="range"
            min={MIN_VIEWPORT_WIDTH}
            max={MAX_VIEWPORT_WIDTH}
            step={1}
            value={effectiveWidth}
            onChange={(e) => setResponsiveWidth(Number(e.target.value))}
            title="Drag to sweep the viewport width"
            className="w-40 accent-blue-500 cursor-pointer"
          />
          <span className="font-mono text-white text-[11px] w-12 tabular-nums">{effectiveWidth}px</span>

          <div className="flex items-center space-x-0.5">
            {WIDTH_PRESETS.map((preset) => (
              <button
                key={preset}
                onClick={() => setResponsiveWidth(preset)}
                className={`px-1.5 py-0.5 rounded transition ${
                  effectiveWidth === preset
                    ? 'bg-blue-600 text-white'
                    : 'bg-[#2a2a2d] text-[#b0b0b0] hover:text-white hover:bg-[#38383c]'
                }`}
              >
                {preset}
              </button>
            ))}
          </div>

          {responsiveWidth !== null && (
            <button
              onClick={() => setResponsiveWidth(null)}
              title="Follow the panel width again"
              className="px-1.5 py-0.5 rounded text-blue-400 hover:text-blue-300 hover:bg-[#333333] transition"
            >
              Follow panel
            </button>
          )}
        </div>
      )}

      {/* Sandboxed iframe canvas with Figma-like pan & zoom */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        className={`flex-1 overflow-hidden relative select-none flex items-start justify-center ${cursorClass} ${getBgClass()}`}
      >
        <div
          style={{
            width: `${effectiveWidth}px`,
            height: `${effectiveHeight}px`,
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${scale})`,
            transformOrigin: 'top center',
            transition: isDragging ? 'none' : 'transform 0.12s ease-out',
            marginTop: '20px',
            marginBottom: '40px',
          }}
          className="shrink-0 relative"
        >
          <iframe
            srcDoc={injectedHtmlContent}
            title="Figma HTML Preview"
            sandbox="allow-scripts allow-same-origin"
            style={{
              width: `${effectiveWidth}px`,
              height: `${effectiveHeight}px`,
              border: 'none',
              display: 'block',
              backgroundColor: PREVIEW_STAGE_BG,
              pointerEvents: isPanActive || isDragging ? 'none' : 'auto',
            }}
          />
          {/* Overlay to ensure seamless dragging without iframe event capture */}
          {(isPanActive || isDragging) && (
            <div
              className={`absolute inset-0 z-30 ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
              onMouseDown={handleMouseDown}
            />
          )}
        </div>
      </div>
    </div>
  );
};
