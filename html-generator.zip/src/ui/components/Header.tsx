import React from 'react';
import { Settings, RefreshCw, Sparkles, Type, FolderDown } from 'lucide-react';

interface HeaderProps {
  onRefresh: () => void;
  onOpenSettings: () => void;
  onOpenFontManager: () => void;
  /** Converts every page of the file, not just the selection. */
  onExportDocument: () => void;
  /** Reopens the export log after it has been closed mid-run. */
  onOpenExportLog: () => void;
  isConverting: boolean;
  isExportingDocument?: boolean;
  /** Frames converted so far, for the whole-file progress readout. */
  exportProgress?: { done: number; total: number } | null;
  fontCount?: number;
  hasCustomFonts?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onRefresh,
  onOpenSettings,
  onOpenFontManager,
  onExportDocument,
  onOpenExportLog,
  isConverting,
  isExportingDocument = false,
  exportProgress,
  fontCount = 0,
  hasCustomFonts = false,
}) => {
  const progressLabel =
    isExportingDocument && exportProgress && exportProgress.total > 0
      ? `${exportProgress.done}/${exportProgress.total}`
      : null;

  return (
    <header className="flex items-center justify-between px-3 py-2 bg-[#252526] border-b border-[#3e3e42] shrink-0">
      <div className="flex items-center space-x-2">
        <div className="w-6 h-6 rounded bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-sm">
          <Sparkles size={14} />
        </div>
        <div>
          <h1 className="font-semibold text-xs tracking-tight text-white flex items-center gap-1.5">
            Pixel-Perfect
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 font-medium border border-blue-500/30">
              HTML & CSS
            </span>
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-0.5">
        <button
          onClick={isExportingDocument ? onOpenExportLog : onExportDocument}
          title={
            isExportingDocument
              ? 'Show the export log — running now'
              : 'Export the whole file — every page, every frame, one shared stylesheet'
          }
          className={`flex items-center gap-1 px-1.5 py-1 rounded transition ${
            isExportingDocument
              ? 'text-blue-400 bg-blue-500/10 hover:bg-blue-500/20'
              : 'text-[#9e9e9e] hover:text-white hover:bg-[#333333]'
          }`}
        >
          {isExportingDocument ? (
            <RefreshCw size={14} className="animate-spin" />
          ) : (
            <FolderDown size={14} />
          )}
          {progressLabel && (
            <span className="text-[10px] font-medium tabular-nums">{progressLabel}</span>
          )}
        </button>
        <button
          onClick={onOpenFontManager}
          title="Font Assets Manager"
          className="relative p-1.5 rounded hover:bg-[#333333] text-[#9e9e9e] hover:text-white transition"
        >
          <Type size={14} />
          {hasCustomFonts && (
            <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-green-400" />
          )}
          {!hasCustomFonts && fontCount > 0 && (
            <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-indigo-400" />
          )}
        </button>
        <button
          onClick={onRefresh}
          disabled={isConverting}
          title="Re-convert selected node"
          className="p-1.5 rounded hover:bg-[#333333] text-[#9e9e9e] hover:text-white transition disabled:opacity-40"
        >
          <RefreshCw size={14} className={isConverting ? 'animate-spin' : ''} />
        </button>
        <button
          onClick={onOpenSettings}
          title="Exporter Settings"
          className="p-1.5 rounded hover:bg-[#333333] text-[#9e9e9e] hover:text-white transition"
        >
          <Settings size={14} />
        </button>
      </div>
    </header>
  );
};
