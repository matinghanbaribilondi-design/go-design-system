import React, { useState } from 'react';
import { Copy, Check, Code2, FileCode2, Palette, Wind, Layers, Variable } from 'lucide-react';
import { ConversionResult } from '../../plugin/types/ir';
import { useClipboard } from '../hooks/useClipboard';

interface CodeViewerProps {
  result: ConversionResult;
  onNotify: (msg: string) => void;
}

type TabType = 'combined' | 'html' | 'css' | 'tailwind' | 'tokens' | 'debug';

const TABS: Array<{ id: TabType; label: string; icon: React.ReactNode }> = [
  { id: 'combined', label: 'Combined HTML', icon: <FileCode2 size={13} className="text-emerald-400" /> },
  { id: 'html', label: 'HTML', icon: <Code2 size={13} className="text-amber-400" /> },
  { id: 'css', label: 'Pure CSS', icon: <Palette size={13} className="text-blue-400" /> },
  { id: 'tailwind', label: 'Tailwind', icon: <Wind size={13} className="text-cyan-400" /> },
  { id: 'tokens', label: 'Tokens (CSS Vars)', icon: <Variable size={13} className="text-pink-400" /> },
  { id: 'debug', label: 'Tree', icon: <Layers size={13} className="text-purple-400" /> },
];

function TabButton({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center space-x-1.5 px-3 py-2 text-xs font-medium border-b-2 transition ${
        active
          ? 'border-blue-500 text-white bg-[#1e1e1e]'
          : 'border-transparent text-[#9e9e9e] hover:text-white hover:bg-[#2d2d2d]'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

type TokenFormat = 'css' | 'tailwind' | 'json' | 'js' | 'csv';

export const CodeViewer: React.FC<CodeViewerProps> = ({ result, onNotify }) => {
  const [activeTab, setActiveTab] = useState<TabType>('combined');
  const [tokenFormat, setTokenFormat] = useState<TokenFormat>('css');
  const { copied, copy } = useClipboard();

  const getActiveCode = (): string => {
    switch (activeTab) {
      case 'combined':
        return result.combinedHtml;
      case 'html':
        return result.html;
      case 'css':
        return result.css;
      case 'tailwind':
        return result.tailwindHtml;
      case 'tokens':
        switch (tokenFormat) {
          case 'css':
            return result.tokensCSS || result.variablesBlock || '/* No CSS variables detected */';
          case 'tailwind':
            return result.tokensTailwind || '/* No Tailwind theme tokens detected */';
          case 'json':
            return result.tokensJSON || '/* No JSON tokens detected */';
          case 'js':
            return result.tokensJS || '/* No JS tokens detected */';
          case 'csv':
            return result.tokensCSV || '/* No CSV tokens detected */';
        }
      case 'debug':
        return JSON.stringify(result.debugTree, null, 2);
    }
  };

  const handleCopy = async () => {
    const code = getActiveCode();
    const ok = await copy(code);
    onNotify(ok ? 'Copied code to clipboard!' : 'Copy failed — select the code manually.');
  };

  const code = getActiveCode();
  const lineCount = code.split('\n').length;

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e] border-t border-[#3e3e42]">
      {/* Tab Navigation */}
      <div className="flex items-center justify-between px-3 bg-[#252526] border-b border-[#3e3e42]">
        <div className="flex items-center space-x-1 overflow-x-auto">
          {TABS.map((t) => (
            <TabButton
              key={t.id}
              active={activeTab === t.id}
              onClick={() => setActiveTab(t.id)}
              icon={t.icon}
              label={t.label}
            />
          ))}
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-[10px] text-[#6e6e6e]">{lineCount} lines</span>
          <button
            onClick={handleCopy}
            className={`flex items-center space-x-1 px-2.5 py-1 rounded text-xs transition ${
              copied
                ? 'bg-emerald-600 text-white'
                : 'bg-blue-600 hover:bg-blue-500 text-white shadow-sm'
            }`}
          >
            {copied ? <Check size={12} /> : <Copy size={12} />}
            <span>{copied ? 'Copied!' : 'Copy'}</span>
          </button>
        </div>
      </div>

      {/* VarVar Token Format Selector */}
      {activeTab === 'tokens' && (
        <div className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#1b1b1c] border-b border-[#2d2d30] text-[11px]">
          <span className="text-[#8e8e8e] mr-1">VarVar Export:</span>
          {(['css', 'tailwind', 'json', 'js', 'csv'] as TokenFormat[]).map((fmt) => (
            <button
              key={fmt}
              onClick={() => setTokenFormat(fmt)}
              className={`px-2 py-0.5 rounded text-[10px] font-medium transition ${
                tokenFormat === fmt
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#2a2a2d] text-[#b0b0b0] hover:text-white hover:bg-[#38383c]'
              }`}
            >
              {fmt === 'css' && 'CSS (:root)'}
              {fmt === 'tailwind' && 'Tailwind (@theme)'}
              {fmt === 'json' && 'DTCG JSON'}
              {fmt === 'js' && 'JavaScript'}
              {fmt === 'csv' && 'CSV'}
            </button>
          ))}
        </div>
      )}

      {/* Code Display Area */}
      <div className="flex-1 overflow-auto bg-[#1e1e1e] p-3 font-mono text-[11px] leading-relaxed select-text">
        <pre className="text-[#d4d4d4] m-0 whitespace-pre">
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
};
