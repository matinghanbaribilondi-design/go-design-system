import React, { useState } from 'react';
import { Download, Archive, Copy, Check, Loader2, Wind } from 'lucide-react';
import JSZip from 'jszip';
import { ConversionOptions, ConversionResult } from '../../plugin/types/ir';
import { useClipboard } from '../hooks/useClipboard';
import { toFileSlug } from '../../shared/style-utils';
import { buildTailwindProjectFiles, buildTailwindPreviewHtml } from '../../generator/tailwind-project';
import { buildSelectionArchiveFiles, selectedFrames } from '../lib/selection-archive';

/** Lightweight RTL sniff for the ZIP export (avoids bundling the full generator). */
function looksRtl(s: string): boolean {
  return /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(s);
}

/** Writes the archive's file list into the ZIP. */
function addHtmlCssFiles(zip: JSZip, result: ConversionResult): void {
  for (const file of buildSelectionArchiveFiles(result)) {
    zip.file(file.path, file.content, file.base64 ? { base64: true } : undefined);
  }
}

/**
 * Writes a complete Tailwind project instead of HTML + CSS: the markup uses
 * utility classes only, and the archive carries the `@theme` tokens, the build
 * scripts and a zero-install preview page per frame.
 */
function addTailwindProjectFiles(zip: JSZip, result: ConversionResult, options: ConversionOptions): void {
  const frames = selectedFrames(result);
  const isRtl =
    frames.length > 0
      ? frames.some((frame) => frame.isRtl)
      : looksRtl(result.html) || looksRtl(result.combinedHtml);
  for (const file of buildTailwindProjectFiles(result, options, isRtl)) {
    zip.file(file.path, file.content, file.base64 ? { base64: true } : undefined);
  }
}

interface ActionToolbarProps {
  /** The full selection: a multi-frame result carries every frame. */
  result: ConversionResult | null;
  /** The frame the preview and the single-file actions currently show. */
  activeFrame: ConversionResult | null;
  options: ConversionOptions;
  /** When true the ZIP contains a Tailwind project instead of HTML + CSS. */
  tailwindZip: boolean;
  onNotify: (msg: string) => void;
}

export const ActionToolbar: React.FC<ActionToolbarProps> = ({
  result,
  activeFrame,
  options,
  tailwindZip,
  onNotify,
}) => {
  const [isExportingZip, setIsExportingZip] = useState(false);
  const { copied: isCopied, copy } = useClipboard();

  if (!result || !activeFrame) return null;

  const frames = selectedFrames(result);
  const multi = frames.length > 0;
  const fileSlug = toFileSlug(activeFrame.nodeName);
  // The ZIP holds every frame, so its name describes the selection rather than
  // whichever frame happened to be open.
  const archiveSlug = multi ? `selected-${frames.length}-frames` : fileSlug;

  // 1. Download standalone HTML — mirrors the selected ZIP format so the two
  //    buttons never disagree about which flavour you are working with. With
  //    several frames selected this saves the one currently in the preview.
  const handleDownloadHtml = () => {
    const isRtl = looksRtl(activeFrame.html) || looksRtl(activeFrame.combinedHtml);
    const content = tailwindZip
      ? buildTailwindPreviewHtml(activeFrame, options, isRtl)
      : activeFrame.combinedHtml;
    const blob = new Blob([content], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileSlug}${tailwindZip ? '-tailwind' : ''}.html`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify(
      multi
        ? `Downloaded ${fileSlug}.html — the frame in the preview. The ZIP contains every selected frame.`
        : tailwindZip
          ? 'Downloaded self-contained Tailwind preview HTML!'
          : 'Downloaded standalone HTML file!'
    );
  };

  // 2. Download ZIP package — one HTML file per selected frame, sharing the
  //    stylesheet, tokens, assets and fonts; a Tailwind project when enabled.
  const handleDownloadZip = async () => {
    try {
      setIsExportingZip(true);
      const zip = new JSZip();

      if (tailwindZip) {
        addTailwindProjectFiles(zip, result, options);
      } else {
        addHtmlCssFiles(zip, result);
      }

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${archiveSlug}${tailwindZip ? '-tailwind' : ''}.zip`;
      a.click();
      URL.revokeObjectURL(url);
      onNotify(
        multi
          ? tailwindZip
            ? `Exported ${frames.length} frames as a Tailwind project — one HTML file per frame. Run npm install && npm run build.`
            : `Exported ${frames.length} frames as separate HTML files, sharing one stylesheet.`
          : tailwindZip
            ? 'Exported complete Tailwind project! Run npm install && npm run build.'
            : 'Exported ZIP project package!'
      );
    } catch (err: unknown) {
      console.error(err);
      onNotify('Failed to create ZIP package.');
    } finally {
      setIsExportingZip(false);
    }
  };

  // 3. Quick Copy Combined HTML — the active frame, not a merged document.
  const handleQuickCopy = async () => {
    const ok = await copy(activeFrame.combinedHtml);
    onNotify(
      ok
        ? multi
          ? `Copied ${activeFrame.nodeName} as a full HTML document!`
          : 'Copied full HTML document to clipboard!'
        : 'Copy failed — select the code manually.'
    );
  };

  return (
    <div className="flex items-center justify-between gap-2 px-2.5 py-2 bg-[#252526] border-t border-[#3e3e42] shrink-0">
      {/* Quiet actions on the left: they are used far less than the download. */}
      <div className="flex items-center gap-1">
        <button
          onClick={handleQuickCopy}
          title={multi ? `Copy ${activeFrame.nodeName} as a full HTML document` : 'Copy the whole HTML document'}
          className={`p-1.5 rounded transition ${
            isCopied
              ? 'bg-emerald-600/20 text-emerald-400'
              : 'text-[#9e9e9e] hover:text-white hover:bg-[#333333]'
          }`}
        >
          {isCopied ? <Check size={13} /> : <Copy size={13} />}
        </button>
        <button
          onClick={handleDownloadHtml}
          title={
            multi
              ? `Save the previewed frame (${activeFrame.nodeName}) as a single .html file`
              : 'Save a single self-contained .html file'
          }
          className="flex items-center gap-1.5 px-2 py-1.5 rounded text-[#c8c8c8] hover:text-white hover:bg-[#333333] text-[11px] font-medium transition"
        >
          <Download size={12} />
          <span>.html</span>
        </button>
      </div>

      {/* One primary action, sized like one. */}
      <button
        onClick={handleDownloadZip}
        disabled={isExportingZip}
        title={
          tailwindZip
            ? multi
              ? `Exports ${frames.length} frames as one Tailwind project — a separate HTML file per frame`
              : 'Exports a complete Tailwind project (markup + @theme tokens + build setup)'
            : multi
              ? `Exports ${frames.length} separate HTML files sharing style.css, variables.css, assets and fonts`
              : 'Exports separated HTML, CSS, assets and fonts'
        }
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-white text-[11px] font-semibold shadow-sm transition disabled:opacity-50 ${
          tailwindZip ? 'bg-cyan-600 hover:bg-cyan-500' : 'bg-blue-600 hover:bg-blue-500'
        }`}
      >
        {isExportingZip ? (
          <Loader2 size={12} className="animate-spin" />
        ) : tailwindZip ? (
          <Wind size={12} />
        ) : (
          <Archive size={12} />
        )}
        <span>
          {tailwindZip
            ? multi
              ? `Tailwind ZIP (${frames.length})`
              : 'Download Tailwind ZIP'
            : multi
              ? `ZIP (${frames.length} HTML)`
              : 'Download ZIP'}
        </span>
      </button>
    </div>
  );
};
