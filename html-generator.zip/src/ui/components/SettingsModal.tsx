import React from 'react';
import { X, Check } from 'lucide-react';
import { ConversionOptions } from '../../plugin/types/ir';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  options: ConversionOptions;
  onOptionsChange: (newOptions: ConversionOptions) => void;
  /** When true the downloaded ZIP contains a Tailwind project instead of HTML + CSS. */
  tailwindZip: boolean;
  onTailwindZipChange: (enabled: boolean) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  options,
  onOptionsChange,
  tailwindZip,
  onTailwindZipChange,
}) => {
  if (!isOpen) return null;

  // One switch governs every adaptive behaviour in the output; the preview's
  // own sizing mode is separate and keeps working either way.
  //
  // `=== true`, not `?? true`: the pipeline's gate is strict, so an option
  // object that predates the flag produces a fixed export — and the panel has
  // to show that, not the opposite of it.
  const isResponsive = options.responsive === true;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-[#252526] border border-[#3e3e42] rounded-lg shadow-2xl w-full max-w-sm overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#3e3e42] bg-[#2d2d2d]">
          <h2 className="text-xs font-semibold text-white">Exporter Settings</h2>
          <button
            onClick={onClose}
            className="p-1 rounded text-[#9e9e9e] hover:text-white hover:bg-[#3e3e42] transition"
          >
            <X size={14} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 text-xs">
          {/* ZIP package format */}
          <div className="space-y-1.5">
            <label className="text-[#e0e0e0] font-medium block">ZIP Package Format</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onTailwindZipChange(false)}
                className={`py-1.5 px-3 rounded text-center border transition ${
                  !tailwindZip
                    ? 'bg-blue-600/20 border-blue-500 text-white font-medium'
                    : 'bg-[#333333] border-[#444444] text-[#9e9e9e] hover:text-white'
                }`}
              >
                HTML + CSS
              </button>
              <button
                type="button"
                onClick={() => onTailwindZipChange(true)}
                className={`py-1.5 px-3 rounded text-center border transition ${
                  tailwindZip
                    ? 'bg-cyan-600/20 border-cyan-500 text-white font-medium'
                    : 'bg-[#333333] border-[#444444] text-[#9e9e9e] hover:text-white'
                }`}
              >
                Tailwind
              </button>
            </div>
            <p className="text-[10px] text-[#8e8e8e] leading-relaxed">
              {tailwindZip
                ? 'The ZIP becomes a complete Tailwind v4 project: utility-class markup, @theme tokens, build scripts, and a zero-install preview.html.'
                : 'The ZIP contains separated index.html, style.css, variables.css, plus assets and fonts.'}
            </p>
          </div>

          <div className="border-t border-[#3e3e42]/60" />

          {/* Unit selection */}
          <div className="space-y-1.5">
            <label className="text-[#e0e0e0] font-medium block">CSS Units</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onOptionsChange({ ...options, useRem: false })}
                className={`py-1.5 px-3 rounded text-center border transition ${
                  !options.useRem
                    ? 'bg-blue-600/20 border-blue-500 text-white font-medium'
                    : 'bg-[#333333] border-[#444444] text-[#9e9e9e] hover:text-white'
                }`}
              >
                Pixels (px)
              </button>
              <button
                type="button"
                onClick={() => onOptionsChange({ ...options, useRem: true })}
                className={`py-1.5 px-3 rounded text-center border transition ${
                  options.useRem
                    ? 'bg-blue-600/20 border-blue-500 text-white font-medium'
                    : 'bg-[#333333] border-[#444444] text-[#9e9e9e] hover:text-white'
                }`}
              >
                Rem (rem)
              </button>
            </div>
          </div>

          {/* Base font size if Rem is selected */}
          {options.useRem && (
            <div className="space-y-1.5">
              <label className="text-[#e0e0e0] font-medium block">Base Font Size (px)</label>
              <input
                type="number"
                value={options.baseFontSize}
                onChange={(e) =>
                  onOptionsChange({ ...options, baseFontSize: Number(e.target.value) || 16 })
                }
                className="w-full bg-[#1e1e1e] border border-[#3e3e42] rounded px-3 py-1.5 text-white focus:outline-none focus:border-blue-500 text-xs"
              />
            </div>
          )}

          {/* CSS Reset Toggle */}
          <div className="flex items-center justify-between pt-1">
            <div>
              <div className="text-[#e0e0e0] font-medium">Include CSS Reset</div>
              <div className="text-[10px] text-[#8e8e8e]">Adds box-sizing & zero-margin reset</div>
            </div>
            <input
              type="checkbox"
              checked={options.includeReset}
              onChange={(e) => onOptionsChange({ ...options, includeReset: e.target.checked })}
              className="accent-blue-500 w-4 h-4 cursor-pointer"
            />
          </div>

          {/* Semantic HTML Tags */}
          <div className="flex items-center justify-between pt-1">
            <div>
              <div className="text-[#e0e0e0] font-medium">Semantic Tag Heuristics</div>
              <div className="text-[10px] text-[#8e8e8e]">Detects button, header, nav, h1-h4</div>
            </div>
            <input
              type="checkbox"
              checked={options.semanticTags}
              onChange={(e) => onOptionsChange({ ...options, semanticTags: e.target.checked })}
              className="accent-blue-500 w-4 h-4 cursor-pointer"
            />
          </div>

          {/* Responsive output — one switch for the whole pipeline */}
          <div className="pt-2 border-t border-[#3e3e42]/60">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-[#e0e0e0] font-medium">Responsive Output</div>
                <div className="text-[10px] text-[#8e8e8e]">
                  {isResponsive
                    ? 'Fluid values, intrinsic reflow and smart stacking — all derived from the design'
                    : 'Fixed-size export at the frame’s own dimensions — the default'}
                </div>
              </div>
              <input
                type="checkbox"
                checked={isResponsive}
                onChange={(e) => onOptionsChange({ ...options, responsive: e.target.checked })}
                className="accent-blue-500 w-4 h-4 cursor-pointer mt-0.5"
              />
            </div>

            {isResponsive ? (
              <div className="mt-2.5 ml-1 pl-3 border-l-2 border-[#3e3e42] flex items-start justify-between">
                <div>
                  <div className="text-[#d8d8d8] font-medium">Intrinsic Reflow</div>
                  <div className="text-[10px] text-[#8e8e8e]">
                    Let multi-column rows wrap on their own — no breakpoints
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={options.intrinsicReflow ?? true}
                  onChange={(e) => onOptionsChange({ ...options, intrinsicReflow: e.target.checked })}
                  className="accent-blue-500 w-4 h-4 cursor-pointer mt-0.5"
                />
              </div>
            ) : (
              <div className="mt-2.5 ml-1 pl-3 border-l-2 border-[#3e3e42] text-[10px] leading-relaxed text-[#7f7f7f]">
                Nothing adaptive is emitted: no <span className="font-mono">clamp()</span>, no{' '}
                <span className="font-mono">flex-wrap</span>, no <span className="font-mono">@container</span>. Every
                length is the frame’s own.
              </div>
            )}
          </div>

          {/* Component reuse — applies to the whole-file export */}
          <div className="pt-2 border-t border-[#3e3e42]/60">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-[#e0e0e0] font-medium">Reuse Components</div>
                <div className="text-[10px] text-[#8e8e8e]">
                  {(options.componentDedup ?? true)
                    ? 'A component is coded once; each instance adds only its own overrides'
                    : 'Every instance is coded again from scratch'}
                </div>
              </div>
              <input
                type="checkbox"
                checked={options.componentDedup ?? true}
                onChange={(e) => onOptionsChange({ ...options, componentDedup: e.target.checked })}
                className="accent-blue-500 w-4 h-4 cursor-pointer mt-0.5"
              />
            </div>
            <div className="mt-2 text-[10px] leading-relaxed text-[#7f7f7f]">
              Whole-file export only. Instances that differ structurally are always kept as their own copy, so this
              switch cannot change what a frame looks like.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#3e3e42] bg-[#2d2d2d] flex justify-end">
          <button
            onClick={onClose}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium transition shadow-sm"
          >
            <Check size={13} />
            <span>Apply & Close</span>
          </button>
        </div>
      </div>
    </div>
  );
};
