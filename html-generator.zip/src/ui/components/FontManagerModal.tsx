import React, { useState, useRef } from 'react';
import { X, UploadCloud, Trash2, CheckCircle2, AlertCircle, Type, Globe, HardDrive } from 'lucide-react';
import { UsedFont, CustomFontData, ConversionOptions } from '../../plugin/types/ir';
import { createCustomFont, isSupportedFontFile, withCustomFont } from '../../shared/font-assets';

interface FontManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  usedFonts?: UsedFont[];
  customFonts: CustomFontData[];
  onCustomFontsChange: (fonts: CustomFontData[]) => void;
  options: ConversionOptions;
  onOptionsChange: (newOptions: ConversionOptions) => void;
  onNotify: (msg: string) => void;
}

export const FontManagerModal: React.FC<FontManagerModalProps> = ({
  isOpen,
  onClose,
  usedFonts = [],
  customFonts,
  onCustomFontsChange,
  options,
  onOptionsChange,
  onNotify,
}) => {
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const targetFamilyRef = useRef<string | null>(null);

  if (!isOpen) return null;

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) {
      targetFamilyRef.current = null;
      return;
    }

    const explicitFamily = targetFamilyRef.current;
    targetFamilyRef.current = null;

    Array.from(files).forEach((file) => {
      if (!isSupportedFontFile(file.name)) {
        const ext = file.name.split('.').pop()?.toLowerCase();
        onNotify(`Format .${ext} is not supported. Please use .woff2, .woff, .ttf, or .otf`);
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const font = createCustomFont(file.name, reader.result as string, { usedFonts, explicitFamily });
        if (!font) return;
        onCustomFontsChange(withCustomFont(customFonts, font));
        onNotify(`Font "${font.family}" (${font.style}) added successfully!`);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleAttachToFamily = (family: string) => {
    targetFamilyRef.current = family;
    fileInputRef.current?.click();
  };

  const handleUpdateFamily = (id: string, newFamily: string) => {
    const updated = customFonts.map((f) => (f.id === id ? { ...f, family: newFamily } : f));
    onCustomFontsChange(updated);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleRemoveFont = (id: string) => {
    const updated = customFonts.filter((f) => f.id !== id);
    onCustomFontsChange(updated);
    onNotify('Font removed.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-[#252526] border border-[#3e3e42] rounded-lg shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#3e3e42] bg-[#2d2d2d]">
          <div className="flex items-center space-x-2">
            <div className="w-5 h-5 rounded bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <Type size={13} />
            </div>
            <h2 className="text-xs font-semibold text-white">Font Assets Manager</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-[#9e9e9e] hover:text-white hover:bg-[#3e3e42] transition"
          >
            <X size={14} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 overflow-y-auto text-xs flex-1">
          {/* Section 1: Detected Fonts in Selection */}
          <div className="space-y-2">
            <label className="text-[#e0e0e0] font-medium block flex items-center justify-between">
              <span>Detected Fonts in Selection</span>
              <span className="text-[10px] text-[#8e8e8e]">{usedFonts.length} families</span>
            </label>

            {usedFonts.length === 0 ? (
              <div className="p-3 rounded bg-[#1e1e1e] border border-[#333333] text-[#8e8e8e] text-center text-[11px]">
                No text layers in current selection.
              </div>
            ) : (
              <div className="space-y-1.5">
                {usedFonts.map((uf) => {
                  const normUf = uf.family.toLowerCase().replace(/[^a-z0-9]/g, '');
                  const baseNormUf = normUf.replace(/vf|variable/g, '');

                  const matchingCustoms = customFonts.filter((cf) => {
                    const normCf = cf.family.toLowerCase().replace(/[^a-z0-9]/g, '');
                    const baseNormCf = normCf.replace(/vf|variable/g, '');
                    return (
                      normCf === normUf ||
                      (baseNormUf.length > 3 &&
                        baseNormCf.length > 3 &&
                        (baseNormUf.includes(baseNormCf) || baseNormCf.includes(baseNormUf)))
                    );
                  });
                  const isGoogleOrWeb =
                    uf.family.toLowerCase().includes('vazir') ||
                    uf.family.toLowerCase().includes('inter') ||
                    uf.family.toLowerCase().includes('roboto');
                  const hasCustom = matchingCustoms.length > 0;

                  return (
                    <div
                      key={uf.family}
                      className="p-2.5 rounded bg-[#1e1e1e] border border-[#333333] flex items-center justify-between"
                    >
                      <div className="flex-1 min-w-0 pr-2">
                        <div className="font-semibold text-white flex items-center gap-1.5 flex-wrap">
                          <span>{uf.family}</span>
                          {hasCustom ? (
                            <span className="px-1.5 py-0.5 rounded text-[9px] bg-green-500/20 text-green-400 border border-green-500/30 flex items-center gap-1">
                              <CheckCircle2 size={10} /> {matchingCustoms[0]?.family} Attached
                            </span>
                          ) : isGoogleOrWeb ? (
                            <span className="px-1.5 py-0.5 rounded text-[9px] bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center gap-1">
                              <Globe size={10} /> Google Web Font
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.5 rounded text-[9px] bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                              <AlertCircle size={10} /> Vazirmatn Fallback
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-[#8e8e8e] mt-0.5">
                          Weights: {uf.styles.join(', ') || 'Regular'}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleAttachToFamily(uf.family)}
                        className={`px-2 py-1 rounded text-[10px] font-medium transition whitespace-nowrap ${
                          hasCustom
                            ? 'bg-[#2d2d2d] hover:bg-[#383838] text-[#cccccc] border border-[#444444]'
                            : 'bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 border border-indigo-500/40'
                        }`}
                        title={`Attach a font file for ${uf.family}`}
                      >
                        {hasCustom ? 'Replace File' : '+ Attach File'}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Section 2: Upload Zone */}
          <div className="space-y-2">
            <label className="text-[#e0e0e0] font-medium block">
              Upload Web Fonts (.woff2, .woff, .ttf)
            </label>
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition ${
                dragActive
                  ? 'border-indigo-500 bg-indigo-500/10'
                  : 'border-[#3e3e42] hover:border-[#555555] bg-[#1e1e1e]'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept=".woff2,.woff,.ttf,.otf"
                onChange={(e) => handleFiles(e.target.files)}
                className="hidden"
              />
              <UploadCloud size={24} className="mx-auto text-indigo-400 mb-1.5" />
              <div className="text-white font-medium text-[11px]">
                Drop font files here or <span className="text-indigo-400">browse</span>
              </div>
              <div className="text-[10px] text-[#8e8e8e] mt-1">
                Supports IRANYekanX, Dana, Shabnam or any custom typography
              </div>
            </div>
          </div>

          {/* Section 3: Attached Custom Fonts List */}
          {customFonts.length > 0 && (
            <div className="space-y-2">
              <label className="text-[#e0e0e0] font-medium block flex items-center justify-between">
                <span>Attached Project Fonts</span>
                <span className="text-[10px] text-[#8e8e8e]">{customFonts.length} files</span>
              </label>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {customFonts.map((font) => (
                  <div
                    key={font.id}
                    className="p-2.5 rounded bg-[#1e1e1e] border border-[#333333] flex items-center justify-between text-[11px] gap-2"
                  >
                    <div className="flex items-center space-x-2.5 flex-1 min-w-0">
                      <HardDrive size={14} className="text-indigo-400 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            value={font.family}
                            onChange={(e) => handleUpdateFamily(font.id, e.target.value)}
                            className="bg-[#141414] border border-[#3e3e42] hover:border-[#555] focus:border-indigo-500 rounded px-1.5 py-0.5 text-white font-medium text-xs w-36 outline-none"
                            placeholder="Font Family"
                            title="Edit font-family name to match Figma layers"
                          />
                          {font.isVariable && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] bg-purple-500/20 text-purple-300 border border-purple-500/30">
                              VF (Variable)
                            </span>
                          )}
                        </div>
                        <div className="text-[9px] text-[#8e8e8e] mt-1 flex items-center gap-1.5 truncate">
                          <span>
                            {font.style} ({String(font.weight)})
                          </span>
                          <span>•</span>
                          <span className="truncate max-w-[140px]" title={font.filename}>
                            {font.filename}
                          </span>
                          <span>•</span>
                          <span>{font.format}</span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleRemoveFont(font.id)}
                      title="Remove font"
                      className="p-1 rounded text-[#8e8e8e] hover:text-red-400 hover:bg-red-500/10 transition shrink-0"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section 4: Export Preferences */}
          <div className="pt-2 border-t border-[#333333] space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[#e0e0e0] font-medium text-[11px]">
                  Embed Fonts as Base64 in HTML
                </div>
                <div className="text-[10px] text-[#8e8e8e]">
                  Creates a 100% self-contained standalone HTML file
                </div>
              </div>
              <input
                type="checkbox"
                checked={options.embedFontsBase64 !== false}
                onChange={(e) =>
                  onOptionsChange({ ...options, embedFontsBase64: e.target.checked })
                }
                className="accent-indigo-500 w-4 h-4 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 bg-[#2d2d2d] border-t border-[#3e3e42] flex justify-end">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs transition shadow-sm"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
