import JSZip from 'jszip';
import { buildWholeFileExport, type WholeFileExportPayload } from '../../shared/whole-file-export';

/**
 * Whole-file archive.
 *
 * The file list itself comes from `buildWholeFileExport`, which is pure and
 * testable; this module only turns that list into bytes and hands them to the
 * browser. Keeping the two apart means the archive layout can be asserted in a
 * unit test without touching JSZip or the DOM.
 */
export async function buildWholeFileZip(payload: WholeFileExportPayload): Promise<Blob> {
  const zip = new JSZip();
  const files = buildWholeFileExport(payload);
  for (let i = 0; i < files.length; i += 1) {
    const file = files[i]!;
    zip.file(file.path, file.content, file.base64 ? { base64: true } : undefined);
    if (i % 50 === 0 && i > 0) {
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
  }
  // DEFLATE, not STORE. The archive is mostly HTML and CSS, which compress
  // roughly six to one; a 30 MB archive that arrives as 5 MB is worth the few
  // seconds of pure-JS compression, and those seconds are invisible next to
  // the export that produced it.
  return zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
}

/** Saves a blob under `filename` and releases the object URL. */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/** One line summarising what a whole-file export produced. */
export function summariseWholeFileExport(payload: WholeFileExportPayload): string {
  const plural = (n: number, word: string) => `${n} ${word}${n === 1 ? '' : 's'}`;
  const parts = [
    plural(payload.pages.length, 'page'),
    plural(payload.pages.reduce((sum, page) => sum + page.frames.length, 0), 'frame'),
    plural(payload.components.length, 'component'),
  ];
  if (payload.dedupe.merged > 0) {
    parts.push(`${plural(payload.dedupe.merged, 'instance')} reused`);
  }
  return parts.join(' · ');
}
