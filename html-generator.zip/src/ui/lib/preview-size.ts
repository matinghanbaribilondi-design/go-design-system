/**
 * Preview sizing modes — the pure half of the preview frame.
 *
 * These mirror Figma's presentation options and are kept free of React so the
 * cycling order and the zoom maths can be unit-tested directly.
 */

export type PreviewSizeMode = 'responsive' | 'full-width' | 'full-height' | 'full-both' | 'actual';

/** Cycle order used by the `Z` shortcut. */
export const SIZE_MODE_ORDER: PreviewSizeMode[] = [
  'responsive',
  'full-width',
  'full-height',
  'full-both',
  'actual',
];

export const SIZE_MODE_LABELS: Record<PreviewSizeMode, string> = {
  responsive: 'Responsive',
  'full-width': 'Full width',
  'full-height': 'Full height',
  'full-both': 'Full width & height',
  actual: 'Actual size',
};

export const SIZE_MODE_HINTS: Record<PreviewSizeMode, string> = {
  responsive: 'Viewport width is continuous — resize the panel or drag the right edge',
  'full-width': 'Zoomed so the frame fills the panel width',
  'full-height': 'Zoomed so the frame fills the panel height',
  'full-both': 'Zoomed so the whole frame fits',
  actual: '100% at the design size',
};

/** Padding (px) kept clear around the frame inside the stage. */
export const STAGE_PADDING = 48;
/** Bounds for the continuous responsive viewport width. */
export const MIN_VIEWPORT_WIDTH = 280;
export const MAX_VIEWPORT_WIDTH = 1920;
export const MIN_SCALE = 0.1;
export const MAX_SCALE = 5;

export const clamp = (value: number, min: number, max: number) => Math.min(Math.max(value, min), max);

/** The mode that follows `current` when `Z` is pressed. Wraps around. */
export function nextSizeMode(current: PreviewSizeMode): PreviewSizeMode {
  const index = SIZE_MODE_ORDER.indexOf(current);
  // An unknown mode falls back to the first one rather than stalling.
  if (index === -1) return SIZE_MODE_ORDER[0]!;
  return SIZE_MODE_ORDER[(index + 1) % SIZE_MODE_ORDER.length]!;
}

export interface StageMetrics {
  /** Width available for the frame, after the stage padding. */
  usableWidth: number;
  /** Height available for the frame, after the stage padding. */
  usableHeight: number;
  /** The frame's own size, which depends on the mode and device. */
  frameWidth: number;
  frameHeight: number;
}

/**
 * The zoom a mode asks for.
 *
 * `responsive` never magnifies past 100% so the preview stays pixel-accurate,
 * but it does shrink, so a viewport wider than the panel remains fully visible.
 * The other modes are pure fit calculations; `actual` is always 100%.
 *
 * Returns 1 when the stage has not been measured yet, so the first paint is
 * never scaled by a garbage ratio.
 */
export function computeTargetScale(mode: PreviewSizeMode, metrics: StageMetrics): number {
  const { usableWidth, usableHeight, frameWidth, frameHeight } = metrics;
  if (usableWidth <= 0 || usableHeight <= 0 || frameWidth <= 0 || frameHeight <= 0) return 1;

  switch (mode) {
    case 'responsive':
      return Math.min(1, usableWidth / frameWidth);
    case 'full-width':
      return usableWidth / frameWidth;
    case 'full-height':
      return usableHeight / frameHeight;
    case 'full-both':
      return Math.min(usableWidth / frameWidth, usableHeight / frameHeight);
    case 'actual':
    default:
      return 1;
  }
}

/**
 * The viewport width to render at.
 *
 * In responsive mode the width is continuous: an explicit dragged width wins,
 * otherwise the frame follows the panel. Every other mode renders at the
 * design width.
 */
export function computeFrameWidth(
  mode: PreviewSizeMode,
  designWidth: number,
  usableWidth: number,
  explicitWidth: number | null
): number {
  if (mode !== 'responsive') return designWidth;
  const following = Math.round(usableWidth || MIN_VIEWPORT_WIDTH);
  return clamp(explicitWidth ?? following, MIN_VIEWPORT_WIDTH, MAX_VIEWPORT_WIDTH);
}

export interface FrameSize {
  width: number;
  height: number;
}

/**
 * The viewport the design is rendered in.
 *
 * A preview reproduces the selected frame, so every mode except `responsive`
 * uses the design's own width and height. Only `responsive` sweeps the
 * viewport, and only horizontally — the height stays the design height.
 *
 * A device preset must never narrow this viewport: rendering a 390-wide design
 * in a 375-wide phone frame clips its edges and raises a scrollbar, which reads
 * as a broken preview rather than a different device.
 */
export function computeFrameSize(
  mode: PreviewSizeMode,
  designWidth: number,
  designHeight: number,
  usableWidth: number,
  explicitWidth: number | null
): FrameSize {
  return {
    width: computeFrameWidth(mode, designWidth, usableWidth, explicitWidth),
    height: designHeight,
  };
}
