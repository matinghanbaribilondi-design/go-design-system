import { describe, it, expect } from 'vitest';
import {
  MAX_VIEWPORT_WIDTH,
  MIN_VIEWPORT_WIDTH,
  SIZE_MODE_HINTS,
  SIZE_MODE_LABELS,
  SIZE_MODE_ORDER,
  clamp,
  computeFrameSize,
  computeFrameWidth,
  computeTargetScale,
  nextSizeMode,
} from './preview-size';
import type { PreviewSizeMode } from './preview-size';

describe('size mode cycle', () => {
  it('walks the documented order and wraps back to the start', () => {
    expect(SIZE_MODE_ORDER).toEqual(['responsive', 'full-width', 'full-height', 'full-both', 'actual']);

    let mode: PreviewSizeMode = 'responsive';
    const visited: PreviewSizeMode[] = [mode];
    for (let i = 0; i < SIZE_MODE_ORDER.length; i++) {
      mode = nextSizeMode(mode);
      visited.push(mode);
    }
    // One full lap returns to the starting mode.
    expect(visited).toEqual([...SIZE_MODE_ORDER, 'responsive']);
  });

  it('visits every mode exactly once per lap', () => {
    const seen = new Set<PreviewSizeMode>();
    let mode: PreviewSizeMode = SIZE_MODE_ORDER[0]!;
    for (let i = 0; i < SIZE_MODE_ORDER.length; i++) {
      seen.add(mode);
      mode = nextSizeMode(mode);
    }
    expect(seen.size).toBe(SIZE_MODE_ORDER.length);
  });

  it('falls back to the first mode when given something unknown', () => {
    expect(nextSizeMode('nonsense' as PreviewSizeMode)).toBe('responsive');
  });

  it('has a label and a hint for every mode', () => {
    for (const mode of SIZE_MODE_ORDER) {
      expect(SIZE_MODE_LABELS[mode]).toBeTruthy();
      expect(SIZE_MODE_HINTS[mode]).toBeTruthy();
    }
  });
});

describe('computeTargetScale', () => {
  const metrics = (usableWidth: number, usableHeight: number, frameWidth = 1000, frameHeight = 400) => ({
    usableWidth,
    usableHeight,
    frameWidth,
    frameHeight,
  });

  it('never magnifies in responsive mode, but does shrink a wide viewport', () => {
    // Room to spare: stays pixel-accurate at 100%.
    expect(computeTargetScale('responsive', metrics(1000, 800, 500, 400))).toBe(1);
    // Wider than the panel: shrinks so the whole viewport stays visible.
    expect(computeTargetScale('responsive', metrics(500, 800))).toBe(0.5);
  });

  it('fills the width and the height independently', () => {
    expect(computeTargetScale('full-width', metrics(500, 800))).toBe(0.5);
    expect(computeTargetScale('full-height', metrics(500, 800))).toBe(2);
  });

  it('fits both axes in full width & height mode', () => {
    expect(computeTargetScale('full-both', metrics(500, 800))).toBe(0.5);
    expect(computeTargetScale('full-both', metrics(2000, 100))).toBe(0.25);
  });

  it('is always 100% in actual size mode', () => {
    expect(computeTargetScale('actual', metrics(500, 800))).toBe(1);
    expect(computeTargetScale('actual', metrics(5000, 5000))).toBe(1);
  });

  it('returns 1 before the stage has been measured', () => {
    expect(computeTargetScale('full-both', metrics(0, 0))).toBe(1);
    expect(computeTargetScale('responsive', metrics(0, 0))).toBe(1);
  });
});

describe('computeFrameWidth', () => {
  it('renders at the design width outside responsive mode', () => {
    expect(computeFrameWidth('full-both', 1200, 472, null)).toBe(1200);
    expect(computeFrameWidth('actual', 1440, 472, 800)).toBe(1440);
  });

  it('follows the panel width in responsive mode', () => {
    expect(computeFrameWidth('responsive', 1200, 472, null)).toBe(472);
  });

  it('prefers an explicit dragged width in responsive mode', () => {
    expect(computeFrameWidth('responsive', 1200, 472, 1440)).toBe(1440);
  });

  it('keeps the responsive width inside its bounds', () => {
    expect(computeFrameWidth('responsive', 1200, 472, 99999)).toBe(MAX_VIEWPORT_WIDTH);
    expect(computeFrameWidth('responsive', 1200, 472, 10)).toBe(MIN_VIEWPORT_WIDTH);
  });

  it('falls back to the minimum when the stage is unmeasured', () => {
    expect(computeFrameWidth('responsive', 1200, 0, null)).toBe(MIN_VIEWPORT_WIDTH);
  });
});

describe('computeFrameSize', () => {
  it('renders a narrow design at its own size, not a device preset', () => {
    // A 390-wide modal is not a 375-wide phone: forcing the preset clips the
    // card and raises a horizontal scrollbar.
    expect(computeFrameSize('full-both', 390, 435, 420, null)).toEqual({ width: 390, height: 435 });
    expect(computeFrameSize('full-width', 390, 435, 420, null)).toEqual({ width: 390, height: 435 });
    expect(computeFrameSize('actual', 390, 435, 420, null)).toEqual({ width: 390, height: 435 });
  });

  it('keeps the design height when the frame is very short', () => {
    // A device minimum height would add empty space below the frame.
    expect(computeFrameSize('full-both', 390, 435, 420, null).height).toBe(435);
  });

  it('sweeps only the width in responsive mode', () => {
    expect(computeFrameSize('responsive', 390, 435, 472, null)).toEqual({ width: 472, height: 435 });
    expect(computeFrameSize('responsive', 390, 435, 472, 375)).toEqual({ width: 375, height: 435 });
  });
});

describe('clamp', () => {
  it('bounds a value between min and max', () => {
    expect(clamp(5, 0, 10)).toBe(5);
    expect(clamp(-5, 0, 10)).toBe(0);
    expect(clamp(50, 0, 10)).toBe(10);
  });
});
