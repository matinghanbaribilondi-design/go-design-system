import { describe, it, expect } from 'vitest';
import { buildSelectionArchiveFiles } from './selection-archive';
import type { ConversionResult, FrameResult } from '../../plugin/types/ir';

const PNG = 'data:image/png;base64,iVBORw0KGgo=';

function makeFrame(over: Partial<FrameResult> = {}): FrameResult {
  return {
    nodeName: 'Home',
    width: 1440,
    height: 900,
    isRtl: false,
    html: '<main class="home">Home</main>',
    combinedHtml: '<!DOCTYPE html><html><body><main class="home">Home</main></body></html>',
    tailwindHtml: '<main class="flex">Home</main>',
    ...over,
  };
}

function makeResult(over: Partial<ConversionResult> = {}): ConversionResult {
  return {
    nodeName: 'Home',
    width: 1440,
    height: 900,
    html: '<main class="home">Home</main>',
    css: '.home { color: red; }',
    combinedHtml: '<!DOCTYPE html><html><body><main class="home">Home</main></body></html>',
    tailwindHtml: '<main class="flex">Home</main>',
    assets: [],
    variablesBlock: ':root { --brand: #2563eb; }',
    ...over,
  };
}

const fileAt = (files: ReturnType<typeof buildSelectionArchiveFiles>, path: string) =>
  files.find((file) => file.path === path);

describe('buildSelectionArchiveFiles', () => {
  it('keeps the original single-frame layout', () => {
    const files = buildSelectionArchiveFiles(makeResult());
    const paths = files.map((file) => file.path).sort();

    expect(paths).toEqual([
      'fonts/README.txt',
      'index.html',
      'style.css',
      'variables.css',
    ]);
    const index = fileAt(files, 'index.html')!.content;
    expect(index).toContain('<main class="home">Home</main>');
    expect(index).toContain('<link rel="stylesheet" href="variables.css">');
    expect(index).toContain('<link rel="stylesheet" href="style.css">');
    expect(index).toContain('<title>Home</title>');
  });

  it('writes one HTML file per frame and no combined document', () => {
    const files = buildSelectionArchiveFiles(
      makeResult({
        nodeName: '2 frames',
        frames: [
          makeFrame(),
          makeFrame({
            nodeName: 'Pricing',
            html: '<main class="pricing">Pricing</main>',
            combinedHtml: '<!DOCTYPE html><html><body><main class="pricing">Pricing</main></body></html>',
          }),
        ],
      })
    );

    const paths = files.map((file) => file.path);
    expect(paths).toContain('home.html');
    expect(paths).toContain('pricing.html');
    expect(paths).not.toContain('index.html');

    const home = fileAt(files, 'home.html')!.content;
    const pricing = fileAt(files, 'pricing.html')!.content;
    expect(home).toContain('<main class="home">Home</main>');
    expect(home).not.toContain('Pricing</main>');
    expect(pricing).toContain('<main class="pricing">Pricing</main>');
    expect(pricing).not.toContain('Home</main>');

    // One stylesheet, linked by every frame.
    expect(files.filter((file) => file.path === 'style.css')).toHaveLength(1);
    expect(home).toContain('<link rel="stylesheet" href="style.css">');
    expect(pricing).toContain('<link rel="stylesheet" href="style.css">');
  });

  it('disambiguates two frames with the same name', () => {
    const files = buildSelectionArchiveFiles(
      makeResult({
        frames: [makeFrame(), makeFrame({ html: '<main class="second">Second</main>' })],
      })
    );

    expect(files.map((file) => file.path)).toContain('home.html');
    expect(files.map((file) => file.path)).toContain('home-2.html');
  });

  it('points every frame and the shared stylesheet at assets/ instead of inlining bytes', () => {
    const files = buildSelectionArchiveFiles(
      makeResult({
        css: `.home { background-image: url(${PNG}); }`,
        assets: [{ filename: 'logo.png', content: PNG, type: 'image' }],
        frames: [
          makeFrame({ html: `<main class="home"><img src="${PNG}"></main>` }),
          makeFrame({
            nodeName: 'Pricing',
            html: `<main class="pricing"><img src="${PNG}"></main>`,
          }),
        ],
      })
    );

    const home = fileAt(files, 'home.html')!.content;
    const pricing = fileAt(files, 'pricing.html')!.content;
    const css = fileAt(files, 'style.css')!.content;
    const asset = fileAt(files, 'assets/logo.png')!;

    expect(home).toContain('src="./assets/logo.png"');
    expect(pricing).toContain('src="./assets/logo.png"');
    expect(css).toContain('url(./assets/logo.png)');
    expect(home).not.toContain('base64,iVBORw0KGgo=');
    expect(asset).toMatchObject({ content: 'iVBORw0KGgo=', base64: true });
  });

  it('gives each frame its own direction', () => {
    const files = buildSelectionArchiveFiles(
      makeResult({
        frames: [
          makeFrame({ isRtl: true, nodeName: 'خانه', html: '<main>خانه</main>' }),
          makeFrame({ nodeName: 'Pricing' }),
        ],
      })
    );

    const rtl = fileAt(files, 'خانه.html')!.content;
    const ltr = fileAt(files, 'pricing.html')!.content;
    expect(rtl).toContain('lang="fa" dir="rtl"');
    expect(rtl).toContain('Vazirmatn');
    expect(ltr).toContain('lang="en"');
    expect(ltr).not.toContain('dir="rtl"');
  });
});
