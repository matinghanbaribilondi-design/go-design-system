import { describe, it, expect } from 'vitest';
import { canPresentFullscreen, fullscreenRoute } from './fullscreen';

/**
 * The preview's fullscreen button has two routes, and which one it takes is the
 * whole behaviour: the real Fullscreen API when the host allows it, and filling
 * the plugin panel when it does not.
 */
describe('canPresentFullscreen', () => {
  it('is true when the browser allows it and the element can ask', () => {
    expect(canPresentFullscreen(true, { requestFullscreen: () => Promise.resolve() })).toBe(true);
  });

  it('is false when the document has fullscreen disabled', () => {
    expect(canPresentFullscreen(false, { requestFullscreen: () => Promise.resolve() })).toBe(false);
  });

  it('is false when there is no element yet', () => {
    expect(canPresentFullscreen(true, null)).toBe(false);
    expect(canPresentFullscreen(true, undefined)).toBe(false);
  });

  it('is false when the element cannot ask — the host refused the iframe permission', () => {
    expect(canPresentFullscreen(true, {})).toBe(false);
    expect(canPresentFullscreen(true, { requestFullscreen: 'not a function' })).toBe(false);
  });
});

describe('fullscreenRoute', () => {
  it('leaves fullscreen first when the browser is already presenting the preview', () => {
    expect(fullscreenRoute({ isNativeFullscreen: true, canGoNative: true })).toBe('exit');
    // Even without the capability: something is presented, so undo it.
    expect(fullscreenRoute({ isNativeFullscreen: true, canGoNative: false })).toBe('exit');
  });

  it('asks the browser when it will allow it', () => {
    expect(fullscreenRoute({ isNativeFullscreen: false, canGoNative: true })).toBe('native');
  });

  it('fills the panel when the host will not grant real fullscreen', () => {
    expect(fullscreenRoute({ isNativeFullscreen: false, canGoNative: false })).toBe('immersive');
  });
});
