/**
 * Which route the preview's fullscreen button should take.
 *
 * The browser's Fullscreen API gives the whole screen, but it only works when
 * the host has granted the plugin iframe permission for it — which Figma does
 * not always do. The panel-filling presentation is the fallback, so the choice
 * has to be made from a capability check rather than assumed.
 *
 * Kept pure and separate from the component for the same reason `preview-size`
 * is: the decision is the part worth pinning down, and it can be exercised
 * without a DOM.
 */

export type FullscreenRoute =
  /** Leave the browser's fullscreen. */
  | 'exit'
  /** Ask the browser to present the preview fullscreen. */
  | 'native'
  /** Fill the panel instead, by hiding the rest of the plugin UI. */
  | 'immersive';

/** Whether the browser will let us present this element fullscreen at all. */
export function canPresentFullscreen(
  fullscreenEnabled: boolean,
  element: { requestFullscreen?: unknown } | null | undefined
): boolean {
  return fullscreenEnabled === true && typeof element?.requestFullscreen === 'function';
}

/**
 * The route to take. Leaving comes first: whatever is currently presented has
 * to be undone before anything else is asked for, or the button would appear to
 * do nothing while the browser was already fullscreen.
 */
export function fullscreenRoute(options: {
  /** The browser is presenting our preview fullscreen right now. */
  isNativeFullscreen: boolean;
  /** The browser will let us ask for it. */
  canGoNative: boolean;
}): FullscreenRoute {
  if (options.isNativeFullscreen) return 'exit';
  return options.canGoNative ? 'native' : 'immersive';
}
