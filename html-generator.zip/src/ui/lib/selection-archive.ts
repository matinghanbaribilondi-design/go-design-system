import type { ConversionResult, FrameResult } from '../../plugin/types/ir';
import { referenceAssets, uniqueAssets } from '../../shared/asset-references';
import { escapeHtml, toFileSlug } from '../../shared/style-utils';
import type { ExportFile } from '../../shared/whole-file-export';

/** One file to write into the selection archive. */
export type SelectionArchiveFile = ExportFile;

/** Lightweight RTL sniff for hand-built results that carry no `isRtl`. */
function looksRtl(s: string): boolean {
  return /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(s);
}

/**
 * The frames that get a document of their own.
 *
 * A one-frame result has no `frames` array; the top-level fields are its
 * document. Anything shorter than two is the same single frame.
 */
export function selectedFrames(result: ConversionResult): FrameResult[] {
  return result.frames && result.frames.length > 1 ? result.frames : [];
}

/** Hands out a unique slug: two frames may both be called "Home". */
function allocateSlug(base: string, taken: Set<string>): string {
  let slug = base;
  let n = 2;
  while (taken.has(slug)) {
    slug = `${base}-${n}`;
    n += 1;
  }
  taken.add(slug);
  return slug;
}

function stylesheetLinks(hasVariables: boolean): string {
  return hasVariables
    ? '  <link rel="stylesheet" href="variables.css">\n  <link rel="stylesheet" href="style.css">'
    : '  <link rel="stylesheet" href="style.css">';
}

function fontLinks(isRtl: boolean): string {
  return isRtl
    ? '  <link rel="preconnect" href="https://fonts.googleapis.com">\n' +
        '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n' +
        '  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100..900&display=swap" rel="stylesheet">\n'
    : '';
}

/**
 * One frame, alone, linking the shared stylesheet.
 *
 * The archive carries its images as files, so the body passed here has already
 * been rewritten to point at `./assets/`.
 */
function buildFrameDocument(
  frame: FrameResult,
  body: string,
  hasVariables: boolean
): string {
  const isRtl = frame.isRtl || looksRtl(frame.html) || looksRtl(frame.combinedHtml);
  const htmlAttrs = isRtl ? ' lang="fa" dir="rtl"' : ' lang="en"';

  return `<!DOCTYPE html>
<html${htmlAttrs}>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(frame.nodeName)}</title>
${fontLinks(isRtl)}${stylesheetLinks(hasVariables)}
</head>
<body>
${body}
</body>
</html>`;
}

/** The original single-frame document, unchanged. */
function buildSingleDocument(result: ConversionResult, body: string): string {
  const isRtl = looksRtl(result.html) || looksRtl(result.combinedHtml);
  const htmlAttrs = isRtl ? ' lang="fa" dir="rtl"' : ' lang="en"';

  return `<!DOCTYPE html>
<html${htmlAttrs}>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(result.nodeName)}</title>
${fontLinks(isRtl)}${stylesheetLinks(Boolean(result.variablesBlock))}
</head>
<body>
${body}
</body>
</html>`;
}

/**
 * The HTML + CSS archive layout.
 *
 * A single selection keeps the familiar `index.html` + `style.css` pair. A
 * multi-frame selection writes **one HTML file per frame**, named after the
 * frame, all linking the same `style.css`, `variables.css`, fonts and assets.
 * There is deliberately no combined document: the frames are separate pages,
 * not one canvas.
 */
export function buildSelectionArchiveFiles(result: ConversionResult): SelectionArchiveFile[] {
  const files: SelectionArchiveFile[] = [];
  const assets = uniqueAssets(result.assets ?? []);
  const customFonts = result.customFonts ?? [];

  if (result.variablesBlock) {
    files.push({ path: 'variables.css', content: result.variablesBlock });
  }

  let css = referenceAssets(result.css, assets);
  // In `style.css` the fonts are files in `fonts/`, not data URLs repeated in
  // the stylesheet.
  for (const font of customFonts) {
    const sample = font.base64.slice(0, 40).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const dataUrlRegex = new RegExp(`url\\(['"]?data:[^'"]*${sample}[^'"]*['"]?\\)`, 'g');
    css = css.replace(dataUrlRegex, `url('./fonts/${font.filename}')`);
  }
  files.push({ path: 'style.css', content: css });

  const frames = selectedFrames(result);
  if (frames.length > 0) {
    const taken = new Set<string>();
    for (const frame of frames) {
      const slug = allocateSlug(toFileSlug(frame.nodeName, 'frame'), taken);
      files.push({
        path: `${slug}.html`,
        content: buildFrameDocument(
          frame,
          referenceAssets(frame.html, assets),
          Boolean(result.variablesBlock)
        ),
      });
    }
  } else {
    files.push({
      path: 'index.html',
      content: buildSingleDocument(result, referenceAssets(result.html, assets)),
    });
  }

  for (const asset of assets) {
    if (asset.type === 'svg') {
      files.push({ path: `assets/${asset.filename}`, content: asset.content });
    } else if (asset.type === 'image' && asset.content.startsWith('data:image/')) {
      const base64 = asset.content.split(',')[1];
      if (base64) {
        files.push({ path: `assets/${asset.filename}`, content: base64, base64: true });
      }
    }
  }

  if (customFonts.length > 0) {
    for (const font of customFonts) {
      const base64 = font.base64.includes(',') ? font.base64.split(',')[1] : font.base64;
      if (base64) {
        files.push({ path: `fonts/${font.filename}`, content: base64, base64: true });
      }
    }
  } else {
    files.push({
      path: 'fonts/README.txt',
      content:
        'Place your custom web fonts (.woff2, .woff, .ttf) here.\n' +
        'By default, Persian text falls back to Vazirmatn via Google Fonts CDN.',
    });
  }

  return files;
}
