import { describe, it, expect, beforeAll } from 'vitest';
import { collectVariablesAndStyles } from './variable-collector';

/**
 * The collector and the exported CSS must agree on one contract: every
 * `var(--token)` the classes can reference must be defined in the variables
 * block. A `var()` with no definition is not an error at parse time — the
 * browser drops the declaration at computed-value time, so a design's entire
 * palette can disappear while the markup stays intact. When the VarVar block
 * fails to define a variable (collection unreachable, exporter failed), the
 * collector has to define it itself.
 */
describe('collectVariablesAndStyles — variables block covers every referenced token', () => {
  // 0.98, 0.62, 0.65 ≈ #fa9f5f9 — the pink of the design this fixes.
  const pink = { r: 0.98, g: 0.62, b: 0.65, a: 1 };

  beforeAll(() => {
    const variablesById = new Map<string, any>([['v1', {
      id: 'v1',
      name: 'Color/Brand/Pink',
      variableCollectionId: 'missing-collection',
      resolvedType: 'COLOR',
      valuesByMode: { m1: pink },
      scopes: [],
    }]]);
    (globalThis as any).figma = {
      variables: {
        getLocalVariablesAsync: async () => [variablesById.get('v1')],
        getLocalVariableCollectionsAsync: async () => [], // v1's collection is unreachable
        getVariableByIdAsync: async (id: string) => variablesById.get(id) ?? null,
      },
      getLocalPaintStylesAsync: async () => [],
      getLocalEffectStylesAsync: async () => [],
      getLocalTextStylesAsync: async () => [],
    };
  });

  it('defines a variable the VarVar block lost, so resolveColor never dangles', async () => {
    const result = await collectVariablesAndStyles({ useRem: false, baseFontSize: 16 } as any);

    const referenced = result.resolveColor(pink);
    expect(referenced).toBe('var(--color-brand-pink)');

    expect(result.cssVariablesBlock).toContain('--color-brand-pink:');
    expect(result.cssVariablesBlock).toMatch(/--color-brand-pink: *rgb\(250, 158, 166\)/);
  });

  it('does not duplicate names the VarVar block already defines', async () => {
    const result = await collectVariablesAndStyles({ useRem: false, baseFontSize: 16 } as any);
    const matches = result.cssVariablesBlock.match(/--color-brand-pink:/g) ?? [];
    expect(matches.length).toBe(1);
  });
});

describe('collectVariablesAndStyles — a style binding is a hint, not a colour', () => {
  const pink = { r: 0.98, g: 0.62, b: 0.65, a: 1 }; // rgb(250, 158, 166)
  const grey = { r: 242 / 255, g: 242 / 255, b: 242 / 255, a: 1 }; // #f2f2f2

  beforeAll(() => {
    (globalThis as any).figma = {
      variables: {
        getLocalVariablesAsync: async () => [],
        getLocalVariableCollectionsAsync: async () => [],
        getVariableByIdAsync: async () => null,
      },
      getLocalPaintStylesAsync: async () => [
        { id: 'S1', name: 'Background/N5', paints: [{ type: 'SOLID', visible: true, color: pink, opacity: 1 }] },
        { id: 'S2', name: 'Background N5', paints: [{ type: 'SOLID', visible: true, color: grey, opacity: 1 }] },
      ],
      getLocalEffectStylesAsync: async () => [],
      getLocalTextStylesAsync: async () => [],
    };
  });

  it('references the style only when the node paint is the style paint', async () => {
    const result = await collectVariablesAndStyles({ useRem: false, baseFontSize: 16 } as any);
    expect(result.resolveColor(pink, 1, null, 'S1')).toBe('var(--color-background-n5)');
    // The reported bug: the paint style S1 says rgb(250,158,166) but the node's
    // own fill was edited to #f2f2f2. S1's token is stale for this paint, so it
    // must not be used; the grey paint belongs to the (renamed) grey token.
    expect(result.resolveColor(grey, 1, null, 'S1')).toBe('var(--color-background-n5-2)');
  });

  it('keeps colliding names from sharing one definition', async () => {
    const result = await collectVariablesAndStyles({ useRem: false, baseFontSize: 16 } as any);
    // "Background/N5" and "Background N5" sanitize to the same property; the
    // second token must move aside instead of shadowing the first.
    expect(result.resolveColor(grey, 1, null, 'S2')).toBe('var(--color-background-n5-2)');

    const block = result.cssVariablesBlock;
    const first = block.indexOf('--color-background-n5:');
    const second = block.indexOf('--color-background-n5-2:');
    expect(first).toBeGreaterThan(-1);
    expect(second).toBeGreaterThan(-1);
    expect(block.slice(first, block.indexOf(';', first))).toMatch(/rgb\(250, 158, 166\)/);
    expect(block.slice(second, block.indexOf(';', second))).toMatch(/#f2f2f2|rgb\(242, 242, 242\)/);
  });
});
