import { describe, it, expect } from 'vitest';
import { toCssVar } from './varvar/stringTransformation';
import { formatNumericValue, toUnitOptions } from './varvar/units';
import { rgbToCssColor, cssColorToRgba } from './varvar/color';
import { variableNameToCssVar, normalizeColorKey } from './variable-collector';

describe('VarVar stringTransformation', () => {
  it('converts Figma variable groups to CSS custom properties', () => {
    expect(toCssVar('Color/Brand/Primary', true, '--')).toBe('--color--brand--primary');
    expect(toCssVar('Color/Brand/Primary', true, '-')).toBe('--color-brand-primary');
    expect(toCssVar('Space/2.5', true, '-')).toBe('--space-2_5');
  });
});

describe('VarVar units', () => {
  it('formats px, rem, and bare numbers', () => {
    const pxOpts = toUnitOptions('px', 16);
    expect(formatNumericValue(24, pxOpts)).toBe('24px');

    const remOpts = toUnitOptions('rem', 16);
    expect(formatNumericValue(32, remOpts)).toBe('2rem');

    const bareOpts = toUnitOptions('none', 16);
    expect(formatNumericValue(16, bareOpts)).toBe('16');
  });
});

describe('VarVar color conversions', () => {
  it('converts RGBA to hex and rgba css strings', () => {
    expect(rgbToCssColor({ r: 1, g: 0, b: 0, a: 1 })).toBe('#ff0000');
    expect(rgbToCssColor({ r: 0, g: 1, b: 0, a: 0.5 })).toBe('rgba(0, 255, 0, 0.50)');
  });

  it('round-trips CSS color strings back to RGBA', () => {
    const color = cssColorToRgba('#3b82f6');
    expect(color.r).toBeCloseTo(59 / 255);
    expect(color.g).toBeCloseTo(130 / 255);
    expect(color.b).toBeCloseTo(246 / 255);
    expect(color.a).toBe(1);
  });
});

describe('VariableCollector', () => {
  it('formats clean CSS var names', () => {
    expect(variableNameToCssVar('Typography/Heading 1')).toBe('--typography-heading-1');
  });

  it('normalizes color keys with opacity', () => {
    expect(normalizeColorKey({ r: 1, g: 0, b: 0 }, 1)).toBe('255,0,0,1');
    expect(normalizeColorKey({ r: 1, g: 0, b: 0 }, 0.5)).toBe('255,0,0,0.5');
  });
});
