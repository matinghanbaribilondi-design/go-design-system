import { describe, it, expect, beforeAll } from 'vitest';
import { exportToCSS } from './collectionToCSS';

/**
 * The :root block of an export must define the values nodes actually resolve
 * to — the collection's own default mode — no matter what that mode is called.
 * A collection whose modes are named "Light"/"Dark" used to leave :root empty
 * entirely, so every `var(--…)` in the exported CSS dangled and the browser
 * dropped the declaration: backgrounds, strokes and text colours vanished
 * while the structure survived.
 */
describe('exportToCSS — default mode selection', () => {
  const red = { r: 1, g: 0, b: 0, a: 1 };
  const blue = { r: 0, g: 0, b: 1, a: 1 };

  beforeAll(() => {
    const variablesById = new Map<string, any>([
      ['v1', { id: 'v1', name: 'Color/Brand/Red', resolvedType: 'COLOR', valuesByMode: { m1: red, m2: blue }, scopes: [] }],
      ['v2', { id: 'v2', name: 'Color/Brand/Blue', resolvedType: 'COLOR', valuesByMode: { m1: blue, m2: red }, scopes: [] }],
    ]);
    (globalThis as any).figma = {
      variables: {
        getLocalVariableCollectionsAsync: async () => [
          {
            id: 'c1',
            name: 'Color',
            modes: [
              { modeId: 'm2', name: 'Dark' },
              { modeId: 'm1', name: 'Light' },
            ],
            variableIds: ['v1', 'v2'],
            defaultModeId: 'm1',
          },
          {
            id: 'c2',
            name: 'Legacy',
            modes: [{ modeId: 'only', name: 'Mode 1' }],
            variableIds: ['v1'],
            defaultModeId: 'only',
          },
        ],
        getVariableByIdAsync: async (id: string) => variablesById.get(id) ?? null,
      },
    };
  });

  it('emits the collection default mode at :root even when it is not named Default/Mode 1', async () => {
    const css = await exportToCSS(true, false, 'px', 16);
    const root = css.slice(css.indexOf(':root {'), css.indexOf('}', css.indexOf(':root {')));
    expect(root).toContain('--color-brand-red: #ff0000');
    expect(root).toContain('--color-brand-blue: #0000ff');
  });

  it('keeps the non-default mode under its own class selector', async () => {
    const css = await exportToCSS(true, false, 'px', 16);
    expect(css).toContain('.color--dark');
    const darkBlock = css.slice(css.indexOf('.color--dark'), css.indexOf('}', css.indexOf('.color--dark')));
    // In the Dark mode the two variables swap values.
    expect(darkBlock).toContain('--color-brand-red: #0000ff');
    expect(darkBlock).toContain('--color-brand-blue: #ff0000');
    // …and the root value is not shadowed by the mode block.
    const root = css.slice(css.indexOf(':root {'), css.indexOf('}', css.indexOf(':root {')));
    expect(root).not.toContain('--color-brand-red: #0000ff');
  });

  it('still treats a single-mode collection as :root', async () => {
    const css = await exportToCSS(true, false, 'px', 16);
    const root = css.slice(css.indexOf(':root {'), css.indexOf('}', css.indexOf(':root {')));
    expect(root).toContain('--color-brand-red: #ff0000');
    expect(css).not.toContain('.legacy--');
  });

  it('falls back to the first mode when a collection declares no defaultModeId', async () => {
    const variablesById = new Map<string, any>([
      ['v9', { id: 'v9', name: 'Space/Gap', resolvedType: 'FLOAT', valuesByMode: { a: 8, b: 12 }, scopes: ['GAP'] }],
    ]);
    (globalThis as any).figma = {
      variables: {
        getLocalVariableCollectionsAsync: async () => [
          { id: 'c9', name: 'Space', modes: [ { modeId: 'a', name: 'Small' }, { modeId: 'b', name: 'Large' } ], variableIds: ['v9'] },
        ],
        getVariableByIdAsync: async (id: string) => variablesById.get(id) ?? null,
      },
    };
    const css = await exportToCSS(true, false, 'px', 16);
    const root = css.slice(css.indexOf(':root {'), css.indexOf('}', css.indexOf(':root {')));
    expect(root).toContain('--space-gap: 8px');
    expect(css).toContain('.space--large');
  });
});
