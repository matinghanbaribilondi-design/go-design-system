import { describe, it, expect } from 'vitest';
import { extractLayout } from './layout';
import type { ConversionOptions } from '../types/ir';

/**
 * Grid auto-layout.
 *
 * Figma's `layoutMode: 'GRID'` is a track model: columns and rows are declared
 * independently, a child occupies a cell (or a span of them), and each axis has
 * its own gap. Every branch in `extractLayout` used to treat "not NONE" as
 * "flex", so a grid frame arrived as `flex-direction: column` — the cards
 * stacked, the spans vanished, and nothing about the output said so.
 *
 * These tests pin the three things that have to survive: the track list, the
 * per-axis gaps, and the cell placement. They also pin the negative — a
 * horizontal or vertical frame must still be flex — because the grid branch sits
 * in the same `if` that every auto-layout frame goes through.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
  designWidth: 1200,
};

const fixedOptions: ConversionOptions = { ...options, responsive: false, intrinsicReflow: false };

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: (over.width as number) ?? 100,
    height: (over.height as number) ?? 100,
    x: 0,
    y: 0,
    layoutMode: 'NONE',
    children: [],
    ...over,
  };
}

const flex = (n: number) => Array.from({ length: n }, () => ({ type: 'FLEX', value: 1 }));

const grid = (over: Record<string, unknown> = {}) =>
  mk({
    id: 'grid',
    name: 'Cards',
    layoutMode: 'GRID',
    width: 1200,
    height: 400,
    gridColumnCount: 3,
    gridRowCount: 2,
    gridColumnSizes: flex(3),
    gridRowSizes: flex(2),
    gridColumnGap: 24,
    gridRowGap: 16,
    ...over,
  });

describe('grid auto-layout', () => {
  it('is emitted as a grid, never as a flex column', () => {
    const layout = extractLayout(grid(), null, fixedOptions);

    expect(layout.display).toBe('grid');
    expect(layout.flexDirection).toBeUndefined();
    expect(layout.flexWrap).toBeUndefined();
  });

  it('carries the track list through verbatim', () => {
    const layout = extractLayout(grid(), null, fixedOptions);

    expect(layout.gridTemplateColumns).toBe('minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr)');
    expect(layout.gridTemplateRows).toBe('minmax(0, 1fr) minmax(0, 1fr)');
  });

  it('keeps a fixed track as the pixel value it was drawn at', () => {
    const layout = extractLayout(
      grid({ gridColumnSizes: [{ type: 'FIXED', value: 240 }, { type: 'FLEX', value: 1 }], gridColumnCount: 2 }),
      null,
      options
    );

    expect(layout.gridTemplateColumns).toBe('240px minmax(0, 1fr)');
  });

  it('gives each axis its own gap', () => {
    const layout = extractLayout(grid(), null, fixedOptions);

    expect(layout.columnGap).toBe('24px');
    expect(layout.rowGap).toBe('16px');
    // A grid has no shorthand gap in the IR: the two axes are independent.
    expect(layout.gap).toBeUndefined();
  });

  it('lets equal flexible columns reflow with a floor equal to the drawn column', () => {
    // Inner width 1200, three columns, two gaps of 24 → each column is 384.
    const layout = extractLayout(grid(), null, options);

    expect(layout.gridTemplateColumns).toBe('repeat(auto-fit, minmax(min(384px, 100%), 1fr))');
  });

  it('keeps explicit tracks when the export is not responsive', () => {
    const layout = extractLayout(grid(), null, fixedOptions);

    expect(layout.gridTemplateColumns).not.toContain('auto-fit');
  });

  it('does not auto-fit a heterogeneous track list — there is no single floor', () => {
    const layout = extractLayout(
      grid({
        gridColumnSizes: [{ type: 'FIXED', value: 240 }, { type: 'FLEX', value: 1 }],
        gridColumnCount: 2,
      }),
      null,
      options
    );

    expect(layout.gridTemplateColumns).not.toContain('auto-fit');
  });

  it('places a child in the cell it was given, with its span', () => {
    const parent = grid({ gridItemsPositioning: 'MANUAL' });
    const child = mk({
      id: 'hero',
      name: 'Wide card',
      gridColumnAnchorIndex: 1,
      gridColumnSpan: 2,
      gridRowAnchorIndex: 0,
      gridRowSpan: 1,
    });

    const layout = extractLayout(child, parent, fixedOptions);

    expect(layout.gridColumn).toBe('2 / span 2');
    expect(layout.gridRow).toBe('1');
  });

  it('omits the span when the child occupies a single cell', () => {
    const parent = grid({ gridItemsPositioning: 'MANUAL' });
    const child = mk({ gridColumnAnchorIndex: 0, gridColumnSpan: 1, gridRowAnchorIndex: 1, gridRowSpan: 1 });

    const layout = extractLayout(child, parent, fixedOptions);

    expect(layout.gridColumn).toBe('1');
    expect(layout.gridRow).toBe('2');
  });

  it('does not pin a cell in a reflowing grid', () => {
    // The column count changes with the width, so a pinned `grid-column: 3`
    // would point past the last column and invent one. Auto-flow keeps the
    // reading order instead.
    const parent = grid();
    const child = mk({ gridColumnAnchorIndex: 2, gridColumnSpan: 1, gridRowAnchorIndex: 0, gridRowSpan: 1 });

    const layout = extractLayout(child, parent, options);

    expect(layout.gridColumn).toBeUndefined();
    expect(layout.gridRow).toBeUndefined();
  });

  it('keeps a grid with manual placement from reflowing at all', () => {
    const parent = grid({ gridItemsPositioning: 'MANUAL' });

    const layout = extractLayout(parent, null, options);

    expect(layout.gridTemplateColumns).not.toContain('auto-fit');
    expect(layout.gridTemplateColumns).toBe('minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr)');
  });

  it('drops the drawn row count when the columns reflow', () => {
    // At a narrower width the same cards occupy more rows than the design had;
    // declaring the drawn rows would leave the extra ones implicit and uneven.
    const layout = extractLayout(grid(), null, options);

    expect(layout.gridTemplateColumns).toContain('auto-fit');
    expect(layout.gridTemplateRows).toBeUndefined();
  });

  it('lets a FILL child take its cell instead of holding its drawn width', () => {
    const parent = grid();
    const child = mk({ width: 300, height: 120, layoutSizingHorizontal: 'FILL', layoutSizingVertical: 'FILL' });

    const layout = extractLayout(child, parent, options);

    expect(layout.width).toBe('100%');
    expect(layout.height).toBe('100%');
    expect(layout.flexBasis).toBeUndefined();
    expect(layout.flexGrow).toBeUndefined();
  });

  it('keeps a non-filling child at its drawn size', () => {
    const parent = grid();
    const child = mk({ width: 300, height: 120 });

    const layout = extractLayout(child, parent, options);

    expect(layout.width).toBe('300px');
    expect(layout.height).toBe('120px');
    // The track may be narrower than the content; the child must be allowed to
    // shrink with it rather than forcing the grid wider than the frame.
    expect(layout.minWidth).toBe('0');
  });

  it('leaves horizontal and vertical frames as flex', () => {
    const row = mk({ layoutMode: 'HORIZONTAL', width: 600, height: 80, itemSpacing: 16 });
    const column = mk({ layoutMode: 'VERTICAL', width: 600, height: 400, itemSpacing: 8 });

    const rowLayout = extractLayout(row, null, options);
    const columnLayout = extractLayout(column, null, options);

    expect(rowLayout.display).toBe('flex');
    expect(rowLayout.flexDirection).toBe('row');
    expect(rowLayout.gridTemplateColumns).toBeUndefined();

    expect(columnLayout.display).toBe('flex');
    expect(columnLayout.flexDirection).toBe('column');
    expect(columnLayout.gridTemplateColumns).toBeUndefined();
  });
});
