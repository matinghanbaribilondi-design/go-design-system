import { describe, it, expect } from 'vitest';
import { convertNodeToIR } from './index';
import { detectSemanticTag } from './utils';
import { generateHtml } from '../../generator/html-generator';
import { generateTailwindHtml } from '../../generator/tailwind-generator';
import { generateCss } from '../../generator/css-generator';
import type { ConversionOptions } from '../types/ir';

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: false,
  designWidth: 320,
};

function solid(r: number, g: number, b: number) {
  return { type: 'SOLID', visible: true, opacity: 1, color: { r, g, b } };
}

function node(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: 320,
    height: 48,
    x: 0,
    y: 0,
    rotation: 0,
    layoutMode: 'NONE',
    layoutSizingHorizontal: 'FIXED',
    layoutSizingVertical: 'FIXED',
    fills: [],
    strokes: [],
    effects: [],
    children: [],
    ...over,
  };
}

function text(content: string, over: Record<string, unknown> = {}): any {
  return node({
    type: 'TEXT',
    name: 'Placeholder',
    width: 200,
    height: 20,
    characters: content,
    fontSize: 14,
    fontName: { family: 'Inter', style: 'Regular' },
    textAutoResize: 'WIDTH_AND_HEIGHT',
    textAlignHorizontal: 'LEFT',
    lineHeight: { unit: 'PIXELS', value: 20 },
    letterSpacing: { unit: 'PIXELS', value: 0 },
    fills: [solid(0.42, 0.45, 0.5)],
    getStyledTextSegments: () => [],
    ...over,
  });
}

function field(children: any[], over: Record<string, unknown> = {}): any {
  return node({
    id: 'field',
    name: 'Email Input',
    width: 320,
    height: 48,
    layoutMode: 'HORIZONTAL',
    paddingLeft: 12,
    paddingRight: 12,
    paddingTop: 12,
    paddingBottom: 12,
    itemSpacing: 8,
    primaryAxisAlignItems: 'MIN',
    counterAxisAlignItems: 'CENTER',
    fills: [solid(1, 1, 1)],
    strokes: [solid(0.8, 0.82, 0.86)],
    strokeWeight: 1,
    strokeAlign: 'INSIDE',
    cornerRadius: 8,
    children,
    ...over,
  });
}

describe('component-driven form controls', () => {
  it('turns an Input component into a real input with its placeholder', async () => {
    const master = node({ id: 'master-input', name: 'Input', type: 'COMPONENT' });
    const instance = field([text('you@example.com')], {
      type: 'INSTANCE',
      name: 'Email Input',
      _resolvedMainComponent: master,
    });

    const ir = await convertNodeToIR(instance, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.tag).toBe('input');
    expect(ir.attrs).toEqual({
      type: 'email',
      placeholder: 'you@example.com',
      name: 'email-input',
    });
    expect(ir.children).toHaveLength(0);
    expect(ir.typography?.fontSize).toBe('14px');

    const html = generateHtml(ir, 0);
    expect(html).toContain('<input');
    expect(html).toContain('type="email"');
    expect(html).toContain('placeholder="you@example.com"');
    expect(html).not.toContain('<p');

    const css = generateCss(ir, options);
    expect(css).toContain('appearance: none;');
    expect(css).toContain('border: 1px solid');

    const tw = generateTailwindHtml(ir, 0);
    expect(tw).toContain('<input');
    expect(tw).toContain('appearance-none');
    expect(tw).toContain('type="email"');
  });

  it('keeps the wrapper when the field has an icon, and inputs in place of the text', async () => {
    const icon = node({ id: 'icon', name: 'Icon/Search', type: 'INSTANCE', width: 20, height: 20 });
    const master = node({ id: 'master-input', name: 'Input', type: 'COMPONENT' });
    const instance = field([icon, text('Search…', { name: 'Placeholder' })], {
      type: 'INSTANCE',
      name: 'Search Field',
      _resolvedMainComponent: master,
    });

    const ir = await convertNodeToIR(instance, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.tag).toBe('div');
    const control = ir.children.find((child) => child.tag === 'input');
    expect(control).toBeDefined();
    expect(control?.attrs?.type).toBe('search');
    expect(control?.attrs?.placeholder).toBe('Search…');
    expect(ir.children.some((child) => child.type === 'TEXT')).toBe(false);
    expect(ir.children).toHaveLength(2);

    const html = generateHtml(ir, 0);
    expect(html).toContain('<input');
    expect(html).toContain('type="search"');
    expect(html).not.toContain('Search…</p>');

    const tw = generateTailwindHtml(ir, 0);
    expect(tw).toContain('<input');
    expect(tw).toContain('bg-transparent');
    expect(tw).toContain('border-0');
  });

  it('infers textarea and does not add a type attribute', async () => {
    const message = field([text('Write a message…')], {
      id: 'message',
      name: 'Message Textarea',
      height: 120,
    });

    const ir = await convertNodeToIR(message, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.tag).toBe('textarea');
    expect(ir.attrs?.type).toBeUndefined();
    expect(ir.attrs?.placeholder).toBe('Write a message…');

    const html = generateHtml(ir, 0);
    expect(html).toContain('<textarea');
    expect(html).toContain('placeholder="Write a message…"');
    expect(html).toContain('</textarea>');
  });

  it('recognises a component-named button even when it has a background and an icon', async () => {
    const master = node({ id: 'master-button', name: 'Button', type: 'COMPONENT' });
    const background = node({
      id: 'bg',
      name: 'Background',
      type: 'RECTANGLE',
      width: 120,
      height: 40,
      fills: [solid(0.1, 0.4, 0.9)],
      cornerRadius: 8,
    });
    const icon = node({ id: 'icon', name: 'Icon/Arrow', type: 'INSTANCE', width: 16, height: 16 });
    const instance = node({
      id: 'button',
      name: 'Button/Primary',
      type: 'INSTANCE',
      width: 120,
      height: 40,
      layoutMode: 'HORIZONTAL',
      primaryAxisAlignItems: 'CENTER',
      counterAxisAlignItems: 'CENTER',
      itemSpacing: 8,
      fills: [solid(0.1, 0.4, 0.9)],
      cornerRadius: 8,
      children: [background, icon, text('Save', { name: 'Button Label' })],
      _resolvedMainComponent: master,
    });

    expect(detectSemanticTag(instance)).toBe('button');

    const ir = await convertNodeToIR(instance, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.tag).toBe('button');
    expect(ir.attrs?.type).toBe('button');

    const html = generateHtml(ir, 0);
    expect(html).toContain('<button');
    expect(html).toContain('type="button"');
    expect(html).toContain('Save');
    expect(html).not.toContain('<p');
    expect(html).not.toContain('<div');

    const tw = generateTailwindHtml(ir, 0);
    expect(tw).toContain('<button');
    expect(tw).toContain('type="button"');
    expect(tw).not.toContain('<p');
  });

  it('leaves the same layers as boxes when semantic tags are off', async () => {
    const instance = field([text('you@example.com')], { name: 'Email Input' });

    const ir = await convertNodeToIR(instance, null, { ...options, semanticTags: false });
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.tag).toBe('div');
    expect(ir.attrs).toBeUndefined();
    expect(generateHtml(ir, 0)).not.toContain('<input');
  });

  it('turns a Select component into a real select with its visible value as an option', async () => {
    const master = node({ id: 'master-select', name: 'Select', type: 'COMPONENT' });
    const instance = field([text('United States')], {
      id: 'country-select',
      name: 'Country Select',
      type: 'INSTANCE',
      _resolvedMainComponent: master,
    });

    const ir = await convertNodeToIR(instance, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.tag).toBe('select');
    expect(ir.attrs).toEqual({ name: 'country-select' });
    expect(ir.children).toHaveLength(1);
    expect(ir.children[0]?.tag).toBe('option');
    expect(ir.children[0]?.attrs).toEqual({ value: 'united-states', selected: 'selected' });
    expect(ir.children[0]?.text).toBe('United States');

    const html = generateHtml(ir, 0);
    expect(html).toContain('<select');
    expect(html).toContain('<option value="united-states" selected="selected">United States</option>');
    expect(html).not.toContain('<p');

    const tw = generateTailwindHtml(ir, 0);
    expect(tw).toContain('<select');
    expect(tw).toContain('<option value="united-states" selected="selected">United States</option>');
  });

  it('keeps a select wrapper when the component carries a chevron', async () => {
    const chevron = node({ id: 'chevron', name: 'Icon/Chevron', type: 'INSTANCE', width: 16, height: 16 });
    const master = node({ id: 'master-select', name: 'Dropdown', type: 'COMPONENT' });
    const instance = field([text('Choose a country', { name: 'Value' }), chevron], {
      id: 'country-dropdown',
      name: 'Country Dropdown',
      type: 'INSTANCE',
      _resolvedMainComponent: master,
    });

    const ir = await convertNodeToIR(instance, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.tag).toBe('div');
    const select = ir.children.find((child) => child.tag === 'select');
    expect(select?.attrs?.name).toBe('country-dropdown');
    expect(select?.children[0]?.tag).toBe('option');
    expect(ir.children.some((child) => child.type === 'TEXT')).toBe(false);
    expect(generateHtml(ir, 0)).toContain('<select');
  });

  it('wraps a Checkbox component in a label with a real checkbox input', async () => {
    const box = node({
      id: 'box',
      name: 'Box',
      type: 'RECTANGLE',
      width: 20,
      height: 20,
      fills: [solid(1, 1, 1)],
      strokes: [solid(0.8, 0.82, 0.86)],
      strokeWeight: 1,
      cornerRadius: 4,
    });
    const master = node({ id: 'master-checkbox', name: 'Checkbox', type: 'COMPONENT' });
    const instance = node({
      id: 'subscribe',
      name: 'Subscribe Checkbox',
      type: 'INSTANCE',
      width: 220,
      height: 24,
      layoutMode: 'HORIZONTAL',
      itemSpacing: 8,
      children: [box, text('Subscribe to updates', { name: 'Label', width: 180 })],
      _resolvedMainComponent: master,
    });

    expect(detectSemanticTag(instance)).toBe('input');

    const ir = await convertNodeToIR(instance, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.tag).toBe('label');
    expect(ir.layout.position).toBe('relative');

    const control = ir.children.find((child) => child.tag === 'input');
    expect(control).toBeDefined();
    expect(control?.attrs).toEqual({
      type: 'checkbox',
      name: 'subscribe-checkbox',
      value: 'subscribe-to-updates',
    });
    expect(control?.layout.position).toBe('absolute');
    expect(control?.visual.opacity).toBe(0);

    const html = generateHtml(ir, 0);
    expect(html).toContain('<label');
    expect(html).toContain('type="checkbox"');
    expect(html).toContain('Subscribe to updates');
    expect(html).not.toContain('<div');
    expect(html).not.toContain('<p');

    const css = generateCss(ir, options);
    expect(css).toContain('opacity: 0;');
    expect(css).toContain('clip-path: inset(50%);');

    const tw = generateTailwindHtml(ir, 0);
    expect(tw).toContain('<label');
    expect(tw).toContain('type="checkbox"');
    expect(tw).toContain('opacity-[0]');
    expect(tw).not.toContain('<div');
  });

  it("does not mistake a checkbox's own inner frame for a nested control", async () => {
    const inner = node({
      id: 'inner',
      name: 'Checkbox',
      type: 'FRAME',
      width: 20,
      height: 20,
      children: [
        node({
          id: 'inner-box',
          name: 'Box',
          type: 'RECTANGLE',
          width: 20,
          height: 20,
          fills: [solid(1, 1, 1)],
        }),
      ],
    });
    const master = node({ id: 'master-checkbox', name: 'Checkbox', type: 'COMPONENT' });
    const instance = node({
      id: 'terms',
      name: 'Terms Checkbox',
      type: 'INSTANCE',
      layoutMode: 'HORIZONTAL',
      itemSpacing: 8,
      children: [inner, text('I agree', { name: 'Label' })],
      _resolvedMainComponent: master,
    });

    expect(detectSemanticTag(instance)).toBe('input');

    const ir = await convertNodeToIR(instance, null, options);
    expect(ir?.tag).toBe('label');
    expect(ir?.children.find((child) => child.tag === 'input')?.attrs?.type).toBe('checkbox');
  });

  it('groups radio instances under the frame that holds them', async () => {
    const master = node({ id: 'master-radio', name: 'Radio', type: 'COMPONENT' });

    function radioOption(id: string, label: string): any {
      return node({
        id,
        name: label,
        type: 'INSTANCE',
        children: [
          node({ id: `${id}-dot`, name: 'Radio', type: 'ELLIPSE', width: 16, height: 16 }),
          text(label),
        ],
        _resolvedMainComponent: master,
      });
    }

    const standard = radioOption('standard', 'Standard');
    const express = radioOption('express', 'Express');
    const group = node({
      id: 'group',
      name: 'Shipping Radio Group',
      type: 'FRAME',
      layoutMode: 'VERTICAL',
      width: 320,
      height: 80,
      children: [standard, express],
    });
    standard.parent = group;
    express.parent = group;

    const ir = await convertNodeToIR(group, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.tag).not.toBe('label');
    expect(ir.children).toHaveLength(2);

    const names = ir.children.map(
      (child) => child.children.find((grandchild) => grandchild.tag === 'input')?.attrs
    );
    expect(names).toEqual([
      { type: 'radio', name: 'shipping-radio-group', value: 'standard' },
      { type: 'radio', name: 'shipping-radio-group', value: 'express' },
    ]);
    expect(ir.children.every((child) => child.tag === 'label')).toBe(true);
    expect(generateHtml(ir, 0)).not.toContain('<p');
  });

  it('emits a Switch as a checkbox with role="switch" and its checked state', async () => {
    const master = node({ id: 'master-switch', name: 'Switch', type: 'COMPONENT' });
    const instance = node({
      id: 'dark-mode',
      name: 'Dark Mode Switch',
      type: 'INSTANCE',
      variantProperties: { State: 'On' },
      children: [text('Dark mode', { name: 'Label' })],
      _resolvedMainComponent: master,
    });

    const ir = await convertNodeToIR(instance, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.tag).toBe('label');
    const control = ir.children.find((child) => child.tag === 'input');
    expect(control?.attrs).toEqual({
      type: 'checkbox',
      name: 'dark-mode-switch',
      value: 'dark-mode',
      role: 'switch',
      checked: 'checked',
    });
    expect(generateHtml(ir, 0)).toContain('role="switch"');
  });
});
