import { describe, it, expect } from 'vitest';
import { hyperlinkUrl } from './links';
import { extractTypography } from './typography';
import { generateHtml } from '../../generator/html-generator';
import { generateTailwindHtml } from '../../generator/tailwind-generator';
import { generateCss } from '../../generator/css-generator';
import type { ConversionOptions, IRNode } from '../types/ir';

/**
 * Hyperlinks.
 *
 * `hyperlink` was not read anywhere: neither the layer's own link nor a link on
 * a character range. Every link a designer set arrived as plain text — the word
 * was there, the destination was not.
 *
 * A Figma link comes in two kinds. `URL` is an address and becomes an `href`.
 * `NODE` is a link to another layer in the same file, which is a prototype
 * interaction with no HTML equivalent: a `#` that looks like a link would be
 * worse than the plain text it replaced.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: false,
  designWidth: 400,
};

const irNode = (over: Partial<IRNode> = {}): IRNode => ({
  id: 't',
  name: 'Link',
  className: 'link',
  tag: 'p',
  type: 'TEXT',
  layout: {},
  visual: {},
  typography: { fontSize: '14px', color: '#111111' },
  text: 'Read more',
  children: [],
  ...over,
});

describe('which links become addresses', () => {
  it('keeps an https address', () => {
    expect(hyperlinkUrl({ type: 'URL', value: 'https://example.com/a?b=1' })).toBe(
      'https://example.com/a?b=1'
    );
  });

  it('keeps mailto and tel', () => {
    expect(hyperlinkUrl({ type: 'URL', value: 'mailto:hi@example.com' })).toBe('mailto:hi@example.com');
    expect(hyperlinkUrl({ type: 'URL', value: 'tel:+15550100' })).toBe('tel:+15550100');
  });

  it('keeps a relative address, which has no scheme at all', () => {
    expect(hyperlinkUrl({ type: 'URL', value: '/pricing' })).toBe('/pricing');
    expect(hyperlinkUrl({ type: 'URL', value: '#top' })).toBe('#top');
    expect(hyperlinkUrl({ type: 'URL', value: 'docs/intro.html' })).toBe('docs/intro.html');
  });

  it('drops a script or data URL instead of carrying it into a page', () => {
    expect(hyperlinkUrl({ type: 'URL', value: 'javascript:alert(1)' })).toBeNull();
    expect(hyperlinkUrl({ type: 'URL', value: 'data:text/html,<script>' })).toBeNull();
    expect(hyperlinkUrl({ type: 'URL', value: 'vbscript:msgbox' })).toBeNull();
  });

  it('drops a NODE link, which is a prototype interaction and not an address', () => {
    expect(hyperlinkUrl({ type: 'NODE', value: '1:23' })).toBeNull();
  });

  it('has nothing to say about a missing or empty link', () => {
    expect(hyperlinkUrl(null)).toBeNull();
    expect(hyperlinkUrl(undefined)).toBeNull();
    expect(hyperlinkUrl({ type: 'URL', value: '   ' })).toBeNull();
  });
});

describe('a link reaches the markup', () => {
  it('wraps the text and keeps the element it sits in', () => {
    const html = generateHtml(irNode({ href: 'https://example.com' }));

    expect(html).toContain('<a href="https://example.com">Read more</a>');
    expect(html).toContain('<p class="link">');
  });

  it('escapes the address it was given', () => {
    const html = generateHtml(irNode({ href: 'https://example.com/?q=a&b="c"' }));

    expect(html).toContain('href="https://example.com/?q=a&amp;b=&quot;c&quot;"');
  });

  it('wraps only the run that carries the link', () => {
    const html = generateHtml(
      irNode({
        text: 'See the docs now',
        typography: {
          fontSize: '14px',
          segments: [
            { text: 'See the ', fontSize: '14px', fontWeight: 400, fontFamily: 'Inter', lineHeight: '1.4', letterSpacing: 'normal', color: '#111111' },
            { text: 'docs', fontSize: '14px', fontWeight: 400, fontFamily: 'Inter', lineHeight: '1.4', letterSpacing: 'normal', color: '#111111', href: 'https://example.com/docs' },
            { text: ' now', fontSize: '14px', fontWeight: 400, fontFamily: 'Inter', lineHeight: '1.4', letterSpacing: 'normal', color: '#111111' },
          ],
        },
      })
    );

    expect(html).toContain('<a href="https://example.com/docs"><span');
    expect(html).toContain('>See the </span>');
    expect(html).toContain('</a><span');
  });

  it('does not nest an anchor inside a whole-layer link', () => {
    const html = generateHtml(
      irNode({
        href: 'https://example.com',
        text: 'All of this',
        typography: {
          fontSize: '14px',
          segments: [
            { text: 'All ', fontSize: '14px', fontWeight: 400, fontFamily: 'Inter', lineHeight: '1.4', letterSpacing: 'normal', color: '#111111', href: 'https://inner.example' },
            { text: 'of this', fontSize: '14px', fontWeight: 700, fontFamily: 'Inter', lineHeight: '1.4', letterSpacing: 'normal', color: '#111111' },
          ],
        },
      })
    );

    expect(html.match(/<a /g)).toHaveLength(1);
    expect(html).not.toContain('https://inner.example');
  });

  it('says the same thing in the Tailwind markup', () => {
    const html = generateTailwindHtml(irNode({ href: 'https://example.com' }));

    expect(html).toContain('<a href="https://example.com">Read more</a>');
  });

  it('wraps each paragraph of a linked multi-paragraph layer once', () => {
    const html = generateHtml(
      irNode({
        href: 'https://example.com',
        text: 'One\nTwo',
        typography: { fontSize: '14px', paragraphSpacing: '8px' },
      })
    );

    expect(html.match(/<a href="https:\/\/example.com">/g)).toHaveLength(1);
    expect(html).toContain('One');
    expect(html).toContain('Two');
  });
});

describe('links keep the design’s look', () => {
  it('emits the anchor rule when the page has a link', () => {
    const css = generateCss(irNode({ href: 'https://example.com' }), options);

    expect(css).toContain('a {\n  color: inherit;\n  text-decoration: inherit;\n}');
  });

  it('emits nothing when it has none', () => {
    const css = generateCss(irNode({}), options);

    expect(css).not.toContain('text-decoration: inherit');
  });
});

describe('the range API is asked for links', () => {
  it('keeps a per-range destination on its segment', () => {
    const node: any = {
      id: 't',
      name: 'Body',
      type: 'TEXT',
      visible: true,
      width: 300,
      height: 40,
      characters: 'Read the docs',
      fontSize: 14,
      fontName: { family: 'Inter', style: 'Regular' },
      lineHeight: { unit: 'PERCENT', value: 150 },
      letterSpacing: { unit: 'PERCENT', value: 0 },
      textAlignHorizontal: 'LEFT',
      textAutoResize: 'HEIGHT',
      fills: [{ type: 'SOLID', visible: true, opacity: 1, color: { r: 0, g: 0, b: 0, a: 1 } }],
      getStyledTextSegments: (fields: string[]) => {
        expect(fields).toContain('hyperlink');
        return [
          {
            characters: 'Read the ',
            fontSize: 14,
            fontName: { family: 'Inter', style: 'Regular' },
            fontWeight: 400,
            fills: [{ type: 'SOLID', visible: true, color: { r: 0, g: 0, b: 0, a: 1 } }],
            lineHeight: { unit: 'PERCENT', value: 150 },
            letterSpacing: { unit: 'PERCENT', value: 0 },
            textDecoration: 'NONE',
            textCase: 'ORIGINAL',
            hyperlink: null,
          },
          {
            characters: 'docs',
            fontSize: 14,
            fontName: { family: 'Inter', style: 'Regular' },
            fontWeight: 400,
            fills: [{ type: 'SOLID', visible: true, color: { r: 0, g: 0, b: 0, a: 1 } }],
            lineHeight: { unit: 'PERCENT', value: 150 },
            letterSpacing: { unit: 'PERCENT', value: 0 },
            textDecoration: 'NONE',
            textCase: 'ORIGINAL',
            hyperlink: { type: 'URL', value: 'https://example.com/docs' },
          },
        ];
      },
    };

    const typography = extractTypography(node, options);

    expect(typography.segments?.[0]?.href).toBeUndefined();
    expect(typography.segments?.[1]?.href).toBe('https://example.com/docs');
  });
});
