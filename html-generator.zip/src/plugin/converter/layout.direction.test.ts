import { describe, it, expect } from 'vitest';
import { extractLayout } from './layout';
import { convertNodeToIR } from './index';
import type { ConversionOptions } from '../types/ir';

/**
 * Writing direction of auto-layout containers.
 *
 * Figma's auto-layout is a left-to-right coordinate model even for RTL designs:
 * counter-axis MIN/MAX in a column means physically left/right. CSS resolves
 * `flex-start` / `flex-end` against the container's `direction`, so a column
 * that inherits `rtl` from the page mirrors its alignment — a right-aligned
 * hint under an input silently moves to the left edge. Containers therefore
 * carry `direction: ltr`; the writing direction belongs to the text layer,
 * which emits its own `direction` from typography.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: true,
  designWidth: 390,
};

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: (over.width as number) ?? 350,
    height: (over.height as number) ?? 49,
    x: 0,
    y: 0,
    layoutMode: (over.layoutMode as string) ?? 'NONE',
    children: (over.children as any[]) ?? [],
    ...over,
  };
}

function rtlHint(over: Record<string, unknown> = {}): any {
  return mk({
    id: 'hint',
    name: 'Hint',
    type: 'TEXT',
    width: 187,
    height: 24,
    characters: 'حداقل ۸ کاراکتر، ترکیبی از حروف و عدد',
    textAutoResize: 'WIDTH_AND_HEIGHT',
    textAlignHorizontal: 'RIGHT',
    fontName: { family: 'IRANYekanXVF', style: 'Medium' },
    fontSize: 12,
    lineHeight: { unit: 'PIXELS', value: 24 },
    fills: [{ type: 'SOLID', visible: true, opacity: 1, color: { r: 0.53, g: 0.58, b: 0.63, a: 1 } }],
    ...over,
  });
}

describe('auto-layout writing direction', () => {
  it('keeps a column LTR so flex-end means the physical right edge', () => {
    const layout = extractLayout(
      mk({ layoutMode: 'VERTICAL', counterAxisAlignItems: 'MAX' }),
      null,
      options
    );

    expect(layout.direction).toBe('ltr');
    expect(layout.alignItems).toBe('flex-end');
  });

  it('keeps a column LTR so flex-start means the physical left edge', () => {
    const layout = extractLayout(
      mk({ layoutMode: 'VERTICAL', counterAxisAlignItems: 'MIN' }),
      null,
      options
    );

    expect(layout.direction).toBe('ltr');
    expect(layout.alignItems).toBe('flex-start');
  });

  it('keeps a horizontal row LTR as well', () => {
    const layout = extractLayout(
      mk({ layoutMode: 'HORIZONTAL', counterAxisAlignItems: 'MAX' }),
      null,
      options
    );

    expect(layout.direction).toBe('ltr');
  });

  it('does not touch the direction of a freeform frame', () => {
    const layout = extractLayout(mk({ layoutMode: 'NONE' }), null, options);

    expect(layout.direction).toBeUndefined();
  });

  it('lets RTL copy stay RTL inside the LTR frame', async () => {
    const root = mk({
      id: 'indicator',
      name: 'Indicator',
      width: 350,
      height: 49,
      layoutMode: 'VERTICAL',
      counterAxisAlignItems: 'MAX',
      children: [rtlHint()],
    });

    const ir = await convertNodeToIR(root, null, options);

    expect(ir?.layout.direction).toBe('ltr');
    expect(ir?.children[0]?.typography?.direction).toBe('rtl');
  });
});
