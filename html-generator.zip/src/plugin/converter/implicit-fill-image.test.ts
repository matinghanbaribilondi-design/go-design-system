import { describe, it, expect } from 'vitest';
import { convertNodeToIR } from './index';
import type { ConversionOptions } from '../types/ir';

/**
 * The image path runs through `convertNodeToIR`, not `extractLayout`, because
 * the sizing of an `<img>` is decided while the asset is exported. These tests
 * drive the real converter with a stubbed `exportAsync` so the implicit-fill
 * reading is covered end to end.
 */
const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
  designWidth: 360,
};

/** Minimal SceneNode stand-in — only the fields the converter reads. */
function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: (over.width as number) ?? 100,
    height: (over.height as number) ?? 100,
    x: 0,
    y: 0,
    layoutMode: (over.layoutMode as string) ?? 'NONE',
    children: (over.children as any[]) ?? [],
    exportAsync: () => Promise.resolve(new Uint8Array([137, 80, 78, 71])),
    ...over,
  };
}

/** A 360px card with 16px side padding: 328px of inner width. */
function card(imageOverrides: Record<string, unknown> = {}): any {
  const image = mk({
    id: 'banner',
    name: 'Banner',
    type: 'RECTANGLE',
    width: 328,
    height: 180,
    fills: [{ type: 'IMAGE', visible: true }],
    ...imageOverrides,
  });
  return mk({
    id: 'card',
    name: 'Card',
    layoutMode: 'VERTICAL',
    width: 360,
    height: 400,
    paddingLeft: 16,
    paddingRight: 16,
    children: [image],
  });
}

describe('implicit fill — images', () => {
  it('lets a banner drawn to its card’s inner width keep filling it', async () => {
    const parent = card();
    const ir = await convertNodeToIR(parent.children[0], parent, options);

    expect(ir).not.toBeNull();
    expect(ir!.tag).toBe('img');
    expect(ir!.layout.width).toBe('100%');
    // Capping at the drawn 328px would leave a stripe of the card's background
    // down the side the moment the card is wider than it was drawn.
    expect(ir!.layout.maxWidth).toBe('100%');
    expect(ir!.layout.alignSelf).toBe('stretch');
  });

  it('still caps an image that was drawn smaller than its card', async () => {
    const parent = card({ width: 200, height: 120 });
    const ir = await convertNodeToIR(parent.children[0], parent, options);

    expect(ir!.layout.width).toBe('200px');
    expect(ir!.layout.maxWidth).toBe('200px');
  });

  it('keeps the drawn cap when responsiveness is off', async () => {
    const parent = card();
    const ir = await convertNodeToIR(parent.children[0], parent, { ...options, responsive: false });

    expect(ir!.layout.width).toBe('100%');
    expect(ir!.layout.maxWidth).toBe('328px');
  });
});
