import { describe, it, expect } from 'vitest';
import { extractVisualStyles } from './styles';
import type { ConversionOptions } from '../types/ir';

/**
 * Paint fidelity: gradients and shadows.
 *
 * Two things were being thrown away on the way to CSS, and both are silent:
 *
 * 1. A gradient's `gradientTransform` carries where it starts and how far it
 *    reaches. Only the linear case read it. A radial fill was emitted as a bare
 *    `circle` — a corner glow became a disc in the middle of the node — and an
 *    angular fill was not emitted at all, because the branch did not exist.
 *
 * 2. A drop shadow on a text layer is cast by the glyphs. It was emitted as
 *    `box-shadow`, which draws a rectangle around the text block: the same
 *    shadow, attached to the wrong shape.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: false,
  designWidth: 1200,
};

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: 200,
    height: 100,
    x: 0,
    y: 0,
    ...over,
  };
}

const stops = [
  { position: 0, color: { r: 1, g: 0, b: 0, a: 1 } },
  { position: 1, color: { r: 0, g: 0, b: 1, a: 1 } },
];

const gradient = (type: string, transform: number[][]) =>
  mk({
    fills: [
      {
        type,
        visible: true,
        opacity: 1,
        gradientTransform: transform,
        gradientStops: stops,
      },
    ],
  });

describe('gradient geometry', () => {
  it('gives a radial gradient the centre and the ellipse it was drawn with', () => {
    const visual = extractVisualStyles(gradient('GRADIENT_RADIAL', [[1, 0, 0], [0, 1, 0]]), options);

    expect(visual.background).toBe(
      'radial-gradient(ellipse 50% 50% at 50% 50%, #ff0000 0%, #0000ff 100%)'
    );
  });

  it('moves the centre when the transform moves it', () => {
    const visual = extractVisualStyles(gradient('GRADIENT_RADIAL', [[1, 0, 0.25], [0, 1, 0.25]]), options);

    expect(visual.background).toContain('at 75% 75%');
  });

  it('scales the ellipse with the transform instead of assuming the whole box', () => {
    // Half the linear scale → a glow that covers a quarter of the node.
    const visual = extractVisualStyles(gradient('GRADIENT_RADIAL', [[0.5, 0, 0.25], [0, 0.5, 0.25]]), options);

    expect(visual.background).toContain('ellipse 25% 25%');
  });

  it('emits an angular gradient as a conic gradient starting at its own angle', () => {
    const visual = extractVisualStyles(gradient('GRADIENT_ANGULAR', [[1, 0, 0], [0, 1, 0]]), options);

    // Identity: the gradient's +x axis points right, which is 90° from
    // twelve o'clock in CSS.
    expect(visual.background).toBe('conic-gradient(from 90deg at 50% 50%, #ff0000 0%, #0000ff 100%)');
  });

  it('rotates the conic start with the transform', () => {
    // +90° rotation: the +x axis now points down, which is 180° in CSS.
    const visual = extractVisualStyles(gradient('GRADIENT_ANGULAR', [[0, -1, 1], [1, 0, 0]]), options);

    expect(visual.background).toContain('from 180deg');
  });

  it('still emits a linear gradient at its angle', () => {
    const visual = extractVisualStyles(gradient('GRADIENT_LINEAR', [[1, 0, 0], [0, 1, 0]]), options);

    expect(visual.background).toContain('linear-gradient(');
    expect(visual.background).toContain('#ff0000 0%');
  });
});

describe('text shadows', () => {
  const shadow = {
    type: 'DROP_SHADOW',
    visible: true,
    offset: { x: 0, y: 1 },
    radius: 2,
    spread: 0,
    color: { r: 0, g: 0, b: 0, a: 1 },
  };

  it('attaches a text shadow to the glyphs, not to the text box', () => {
    const visual = extractVisualStyles(mk({ type: 'TEXT', effects: [shadow] }), options);

    expect(visual.textShadow).toBe('0px 1px 2px #000000');
    expect(visual.boxShadow).toBeUndefined();
  });

  it('keeps a box shadow on a box', () => {
    const visual = extractVisualStyles(mk({ type: 'FRAME', effects: [shadow] }), options);

    expect(visual.boxShadow).toBe('0px 1px 2px 0px #000000');
    expect(visual.textShadow).toBeUndefined();
  });

  it('drops an inner shadow on text rather than drawing it around the block', () => {
    const visual = extractVisualStyles(
      mk({ type: 'TEXT', effects: [{ ...shadow, type: 'INNER_SHADOW' }] }),
      options
    );

    expect(visual.textShadow).toBeUndefined();
    expect(visual.boxShadow).toBeUndefined();
  });
});
