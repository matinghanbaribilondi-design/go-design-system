import { describe, it, expect } from 'vitest';
import { cssBlendMode, needsIsolation } from './blend';
import { extractVisualStyles } from './styles';
import { convertNodeToIR } from './index';
import type { ConversionOptions, IRNode } from '../types/ir';

/**
 * Blend modes.
 *
 * The mode itself always mapped 1:1. What was missing is the *group*: Figma
 * blends a layer against the group it sits in, CSS blends it against
 * everything painted below it in the nearest stacking context. Without
 * `isolation: isolate` on the group, a card's overlay multiplies the page
 * behind the card as well.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: false,
  designWidth: 400,
};

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: 'node',
    name: 'Card',
    type: 'FRAME',
    visible: true,
    width: 200,
    height: 200,
    x: 0,
    y: 0,
    layoutMode: 'NONE',
    children: [],
    fills: [],
    strokes: [],
    effects: [],
    ...over,
  };
}

const ir = (visual: Partial<IRNode['visual']>): IRNode => ({
  id: 'n',
  name: 'n',
  className: 'n',
  tag: 'div',
  type: 'FRAME',
  layout: {},
  visual,
  children: [],
});

describe('blend modes map to CSS', () => {
  it('maps every mode Figma and CSS agree on', () => {
    expect(cssBlendMode('MULTIPLY')).toBe('multiply');
    expect(cssBlendMode('COLOR_DODGE')).toBe('color-dodge');
    expect(cssBlendMode('LUMINOSITY')).toBe('luminosity');
  });

  it('treats NORMAL and PASS_THROUGH as "no blending"', () => {
    expect(cssBlendMode('NORMAL')).toBeNull();
    expect(cssBlendMode('PASS_THROUGH')).toBeNull();
    expect(cssBlendMode(undefined)).toBeNull();
  });

  it('leaves an unknown mode out instead of inventing a keyword', () => {
    expect(cssBlendMode('SOMETHING_NEW')).toBeNull();
  });

  it('reaches the IR', () => {
    const visual = extractVisualStyles(mk({ blendMode: 'SCREEN' }), options);
    expect(visual.mixBlendMode).toBe('screen');
  });
});

describe('the group becomes the backdrop', () => {
  it('isolates a group whose child blends', () => {
    expect(needsIsolation([ir({}), ir({ mixBlendMode: 'multiply' })])).toBe(true);
  });

  it('leaves a group with nothing to blend alone', () => {
    expect(needsIsolation([ir({}), ir({})])).toBe(false);
    expect(needsIsolation([])).toBe(false);
  });

  it('does not look deeper than its own children', () => {
    // A grandchild is the child's group's business: that group isolates itself
    // when it is converted, and this one stays out of it.
    const grandchild = ir({ mixBlendMode: 'multiply' });
    const child: IRNode = { ...ir({}), children: [grandchild] };
    expect(needsIsolation([child])).toBe(false);
  });

  it('sets isolation on the converted parent, not on the blending child', async () => {
    const card = mk({
      id: 'card',
      name: 'Card',
      children: [
        mk({
          id: 'photo',
          name: 'Photo',
          type: 'RECTANGLE',
          width: 200,
          height: 200,
          fills: [{ type: 'SOLID', visible: true, opacity: 1, color: { r: 0, g: 0, b: 1, a: 1 } }],
        }),
        mk({
          id: 'tint',
          name: 'Tint',
          type: 'RECTANGLE',
          width: 200,
          height: 200,
          blendMode: 'MULTIPLY',
          fills: [{ type: 'SOLID', visible: true, opacity: 1, color: { r: 1, g: 0, b: 0, a: 1 } }],
        }),
      ],
    });

    const tree = await convertNodeToIR(card, null, options);
    expect(tree?.visual.isolation).toBe('isolate');
    // The photo is promoted into the card's own background, so the tint is the
    // one child left — found by id rather than by position.
    const tint = tree?.children.find((child) => child.id === 'tint');
    expect(tint?.visual.mixBlendMode).toBe('multiply');
    expect(tint?.visual.isolation).toBeUndefined();
  });

  it('leaves a parent alone when its only child is NORMAL', async () => {
    const card = mk({
      id: 'card',
      children: [mk({ id: 'a', type: 'RECTANGLE', width: 200, height: 200, blendMode: 'NORMAL' })],
    });

    const tree = await convertNodeToIR(card, null, options);
    expect(tree?.visual.isolation).toBeUndefined();
  });
});
