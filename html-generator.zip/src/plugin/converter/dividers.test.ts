import { describe, it, expect } from 'vitest';
import { isInLayoutFlow, orthogonalQuarterTurn, readDividerGeometry } from './dividers';
import { extractLayout } from './layout';
import { extractVisualStyles } from './styles';
import { generateFullHtmlDocument } from '../../generator/html-generator';
import type { ConversionOptions, IRNode } from '../types/ir';

/**
 * Rotated dividers.
 *
 * The regression this guards: a 423px horizontal line rotated 90° is a 423px
 * tall vertical rule in Figma, and its auto-layout footprint is one pixel
 * wide. Reading its unrotated width made the exporter claim 423px of a 900px
 * row, which pushed the whole left column out of the frame.
 */

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: 'node',
    name: 'Line',
    type: 'LINE',
    visible: true,
    width: 423,
    height: 0,
    x: 0,
    y: 0,
    rotation: 0,
    ...over,
  };
}

function row(over: Record<string, unknown> = {}): any {
  return {
    id: 'row',
    name: 'Row',
    type: 'FRAME',
    visible: true,
    layoutMode: 'HORIZONTAL',
    width: 900,
    height: 455,
    x: 0,
    y: 0,
    rotation: 0,
    children: [],
    ...over,
  };
}

describe('readDividerGeometry', () => {
  it('keeps an unrotated horizontal line horizontal', () => {
    const geometry = readDividerGeometry(mk());

    expect(geometry).toMatchObject({
      axis: 'horizontal',
      quarterTurn: 0,
      width: 423,
      height: 0,
      lengthPx: 423,
      thicknessPx: 0,
    });
  });

  it('keeps an unrotated vertical line vertical', () => {
    const geometry = readDividerGeometry(mk({ width: 0, height: 423 }));

    expect(geometry).toMatchObject({
      axis: 'vertical',
      quarterTurn: 0,
      width: 0,
      height: 423,
      lengthPx: 423,
    });
  });

  it('reads a horizontal line rotated a quarter turn as a vertical rule', () => {
    const geometry = readDividerGeometry(mk({ rotation: 90 }));

    expect(geometry).toMatchObject({
      axis: 'vertical',
      quarterTurn: 1,
      width: 0,
      height: 423,
      lengthPx: 423,
    });
  });

  it.each([270, -90, 450])('treats %s° as the same quarter turn', (rotation) => {
    const geometry = readDividerGeometry(mk({ rotation }));

    expect(geometry?.axis).toBe('vertical');
    expect(geometry?.width).toBe(0);
    expect(geometry?.height).toBe(423);
  });

  it('does not change the axis on a half turn', () => {
    const geometry = readDividerGeometry(mk({ rotation: 180 }));

    expect(geometry).toMatchObject({
      axis: 'horizontal',
      quarterTurn: 2,
      width: 423,
      height: 0,
    });
  });

  it('tolerates Figma float noise around an orthogonal angle', () => {
    expect(orthogonalQuarterTurn(mk({ rotation: 90.008 }))).toBe(1);
    expect(orthogonalQuarterTurn(mk({ rotation: -89.999 }))).toBe(3);
  });

  it('leaves a diagonal line as a rotated graphic', () => {
    expect(orthogonalQuarterTurn(mk({ rotation: 45 }))).toBeNull();
    expect(readDividerGeometry(mk({ rotation: 45 }))).toBeNull();
    expect(readDividerGeometry(mk({ rotation: 89.5 }))).toBeNull();
  });

  it('reads a rotated 1-D vector divider', () => {
    const geometry = readDividerGeometry(
      mk({ type: 'VECTOR', width: 423, height: 1, rotation: 90 })
    );

    expect(geometry).toMatchObject({
      axis: 'vertical',
      width: 1,
      height: 423,
    });
  });

  it('reads named 1-D rectangles but not ordinary rectangles', () => {
    expect(
      readDividerGeometry(mk({ type: 'RECTANGLE', name: 'Separator', width: 330, height: 1 }))
    ).toMatchObject({ axis: 'horizontal', width: 330, height: 1 });

    expect(
      readDividerGeometry(mk({ type: 'RECTANGLE', name: 'Card', width: 200, height: 100 }))
    ).toBeNull();
  });
});

describe('isInLayoutFlow', () => {
  it('is true for a child of an auto-layout row', () => {
    expect(isInLayoutFlow(mk({ rotation: 90 }), row())).toBe(true);
  });

  it('is false for an explicitly absolute child of an auto-layout row', () => {
    expect(
      isInLayoutFlow(mk({ rotation: 90, layoutPositioning: 'ABSOLUTE' }), row())
    ).toBe(false);
  });

  it('is false inside a freeform frame, where rotation and position are already correct', () => {
    expect(isInLayoutFlow(mk({ rotation: 90 }), row({ layoutMode: 'NONE' }))).toBe(false);
  });

  it('is true for the root node', () => {
    expect(isInLayoutFlow(mk({ rotation: 90 }), null)).toBe(true);
  });
});

/* ------------------------------------------------------------------ *
 * Converter integration
 *
 * The geometry above only helps if `extractLayout` sizes the divider by the
 * box Figma lays out and `extractVisualStyles` draws the border on the axis
 * it appears on. These tests drive both against the frame that exposed the
 * bug: a 900px row whose 0.3px rule was drawn as a 423px line and rotated 90°.
 * ------------------------------------------------------------------ */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
  designWidth: 900,
};

const ink = { type: 'SOLID', visible: true, opacity: 1, color: { r: 0, g: 0, b: 0, a: 1 } };

/** A vertical AutoLayout column: the sidebar and the form either side of the rule. */
function column(over: Record<string, unknown> = {}): any {
  return {
    id: 'column',
    name: 'Column',
    type: 'FRAME',
    visible: true,
    width: 330,
    height: 423,
    x: 0,
    y: 0,
    rotation: 0,
    layoutMode: 'VERTICAL',
    children: [],
    ...over,
  };
}

/** The vertical rule as Figma stores it: a wide horizontal line, turned 90°. */
function rule(over: Record<string, unknown> = {}): any {
  return mk({ id: 'rule', name: 'Line', strokes: [ink], strokeWeight: 0.3, rotation: 90, ...over });
}

function mainRow(children: any[], over: Record<string, unknown> = {}): any {
  return row({
    id: 'main',
    name: 'Main',
    width: 900,
    height: 455,
    itemSpacing: 20,
    paddingTop: 16,
    paddingBottom: 16,
    paddingLeft: 20,
    paddingRight: 20,
    children,
    ...over,
  });
}

describe('extractVisualStyles — the rotated rule', () => {
  it('paints the border on the axis it appears on and drops the CSS rotation', () => {
    const visual = extractVisualStyles(rule(), options, undefined, mainRow([]));

    expect(visual.borderRight).toBe('0.3px solid #000000');
    expect(visual.borderTop).toBeUndefined();
    expect(visual.transform).toBeUndefined();
    expect(visual.boxSizing).toBe('border-box');
  });

  it('does not rotate a half-turned rule either', () => {
    const visual = extractVisualStyles(rule({ rotation: 180 }), options, undefined, mainRow([]));

    expect(visual.borderTop).toBe('0.3px solid #000000');
    expect(visual.transform).toBeUndefined();
  });

  it('keeps the rotation when the rule is positioned by hand', () => {
    const visual = extractVisualStyles(
      rule({ layoutPositioning: 'ABSOLUTE' }),
      options,
      undefined,
      mainRow([])
    );

    expect(visual.transform).toBe('rotate(-90deg)');
    expect(visual.borderTop).toBe('0.3px solid #000000');
    expect(visual.borderRight).toBeUndefined();
  });

  it('keeps the rotation inside a freeform frame', () => {
    const visual = extractVisualStyles(rule(), options, undefined, row({ layoutMode: 'NONE' }));

    expect(visual.transform).toBe('rotate(-90deg)');
  });

  it('leaves a diagonal line to its rotation', () => {
    const visual = extractVisualStyles(rule({ rotation: 45 }), options, undefined, mainRow([]));

    expect(visual.transform).toBe('rotate(-45deg)');
    expect(visual.borderTop).toBe('0.3px solid #000000');
  });
});

describe('extractLayout — the rule’s footprint in its row', () => {
  it('sizes the rotated rule by its visual box, not by the length it was drawn at', () => {
    const layout = extractLayout(rule(), mainRow([]), options);

    // A share-sized flex item states its width through the basis, and its cap
    // is the drawn box: zero wide is exactly the footprint Figma lays out.
    expect(layout.flexBasis).toBe('0px');
    expect(layout.maxWidth).toBe('0px');
    expect(layout.width).toBeUndefined();
    expect(layout.height).toBe('423px');
  });

  it('keeps the drawn box for a rule placed by hand', () => {
    const layout = extractLayout(
      rule({ layoutPositioning: 'ABSOLUTE' }),
      mainRow([]),
      options
    );

    expect(layout.width).toBe('423px');
    expect(layout.height).toBe('0px');
  });

  it('keeps the drawn box inside a freeform frame', () => {
    const layout = extractLayout(rule(), row({ layoutMode: 'NONE' }), options);

    expect(layout.width).toBe('423px');
    expect(layout.height).toBe('0px');
  });
});

describe('the reported 900px row', () => {
  const sidebar = () => column({ id: 'sidebar', name: 'Stats', width: 490, height: 287 });
  const form = () => column({ id: 'form', name: 'Form', width: 330, height: 423 });
  const main = () => mainRow([sidebar(), rule(), form()]);

  it('keeps the row’s real padding when the rule no longer overflows it', () => {
    const layout = extractLayout(main(), null, options);

    expect(layout.padding).toMatchObject({
      top: '16px',
      right: '20px',
      bottom: '16px',
      left: '20px',
    });
  });

  it('does not let the rule inflate the width at which the regions stack', () => {
    const parent = main();
    const stack = extractLayout(parent.children[2], parent, options).stackFill;

    expect(stack).toBeDefined();
    // The rule's visual width is zero, so the regions fit side by side at the
    // design width: the query must not fire until the row is narrower than 900.
    expect(parseFloat(stack!.maxInlineSize!)).toBeLessThanOrEqual(900);
  });

  it('still treats the row as a stacking container', () => {
    expect(extractLayout(main(), null, options).containerType).toBe('inline-size');
  });

  it('emits the whole row as CSS the browser can lay out side by side', () => {
    const parent = main();
    const irNode = (child: any): IRNode => ({
      id: child.id,
      name: child.name,
      className: child.id,
      tag: 'div',
      type: child.type,
      layout: extractLayout(child, parent, options),
      visual: extractVisualStyles(child, options, undefined, parent),
      children: [],
    });
    const root: IRNode = {
      id: parent.id,
      name: parent.name,
      className: 'main',
      tag: 'div',
      type: 'FRAME',
      layout: extractLayout(parent, null, options),
      visual: {},
      children: (parent.children as any[]).map(irNode),
    };

    const html = generateFullHtmlDocument(root, options);

    expect(html).toContain('border-right: 0.3px solid #000000');
    expect(html).not.toContain('rotate(-90deg)');
    const stackQuery = html.match(/@container \(width < ([\d.]+)px\)/);
    expect(stackQuery).not.toBeNull();
    expect(parseFloat(stackQuery![1]!)).toBeLessThanOrEqual(900);
  });
});
