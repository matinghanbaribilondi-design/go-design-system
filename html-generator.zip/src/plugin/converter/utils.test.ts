import { describe, it, expect } from 'vitest';
import {
  sanitizeClassName,
  shortHash,
  formatUnit,
  figmaColorToRgba,
  gradientTransformToAngle,
  getNodeBoxDimensions,
  getChildrenMaxOutsideStroke,
} from './utils';
import { extractLayout } from './layout';
import { extractTypography, getFontWeightNumber } from './typography';
import { extractVisualStyles } from './styles';
import { shouldExportAsSingleVector, getSmartImageExportScale, exportNodeAsImage, hasBlurEffect } from './assets';
import { variableNameToCssVar, normalizeColorKey } from '../variables/variable-collector';
import { segmentToInlineStyle, escapeHtml, toFileSlug } from '../../shared/style-utils';
import { generateCss } from '../../generator/css-generator';
import { generateHtml, wrapBidiNumbers } from '../../generator/html-generator';
import { generateTailwindHtml, nodeToTailwindClasses } from '../../generator/tailwind-generator';
import { TokenResolver } from '../../shared/token-resolver';
import type { IRNode } from '../types/ir';
import { convertNodeToIR } from './index';

const baseOptions = {
  outputMode: 'pure-css' as const,
  useRem: false,
  baseFontSize: 16,
  includeReset: false,
  inlineAssets: true,
  semanticTags: true,
};

function node(overrides: Partial<IRNode> = {}): IRNode {
  return {
    id: '1:1',
    name: 'Frame',
    className: 'frame-abc123',
    tag: 'div',
    type: 'FRAME',
    layout: {},
    visual: {},
    children: [],
    ...overrides,
  };
}

describe('sanitizeClassName', () => {
  it('produces a short stable suffix instead of the raw node id', () => {
    const a = sanitizeClassName('Hero Section', '1:2345');
    const b = sanitizeClassName('Hero Section', '1:2345');
    expect(a).toBe(b);
    expect(a).toMatch(/^hero-section-[a-z0-9]{6}$/);
    expect(a.length).toBeLessThanOrEqual('hero-section_1_2345'.length);
  });

  it('translates Persian UI terms and falls back to layer- for pure numbers', () => {
    expect(sanitizeClassName('بنر اصلی', '2:1')).toMatch(/^banner-primary-[a-z0-9]{6}$/);
    expect(sanitizeClassName('کارت ملی', '2:2')).toMatch(/^national-card-[a-z0-9]{6}$/);
    expect(sanitizeClassName('123', '3:1')).toMatch(/^layer-123-[a-z0-9]{6}$/);
  });

  it('supports BEM naming without random hashes when existingNamesSet is provided', () => {
    const set = new Set<string>();
    expect(sanitizeClassName('عنوان', '4:1', 'card', set)).toBe('card__title');
    expect(sanitizeClassName('فعال', '4:2', 'btn', set)).toBe('btn--active');
    // Collision handling
    expect(sanitizeClassName('عنوان', '4:3', 'card', set)).toMatch(/^card__title-[a-z0-9]{4}$/);
  });

  it('shortHash is deterministic', () => {
    expect(shortHash('1:2')).toBe(shortHash('1:2'));
    expect(shortHash('1:2')).not.toBe(shortHash('1:3'));
  });
});

describe('formatUnit', () => {
  it('formats px and rem', () => {
    expect(formatUnit(0)).toBe('0px');
    expect(formatUnit(16)).toBe('16px');
    expect(formatUnit(16, true, 16)).toBe('1rem');
    expect(formatUnit(24, true, 16)).toBe('1.5rem');
  });
});

describe('figmaColorToRgba', () => {
  it('returns rgb for opaque and rgba otherwise', () => {
    expect(figmaColorToRgba({ r: 1, g: 0, b: 0 })).toBe('rgb(255, 0, 0)');
    expect(figmaColorToRgba({ r: 0, g: 0, b: 0 }, 0.5)).toBe('rgba(0, 0, 0, 0.5)');
  });
});

describe('variableNameToCssVar', () => {
  it('converts Figma paths to css vars', () => {
    expect(variableNameToCssVar('Color/Brand/Primary 500')).toBe('--color-brand-primary-500');
  });
});

describe('TokenResolver zero-hex guarantee', () => {
  it('strictly returns pure var(--token) without fallback hex/rgb', () => {
    const resolver = new TokenResolver(new Map([
      ['var_1', { id: 'var_1', name: 'Primary', cssVarName: '--color-primary', type: 'color', value: '#3b82f6' }]
    ]));
    expect(resolver.resolveColor({ r: 0.23, g: 0.51, b: 0.96 }, 1, 'var_1')).toBe('var(--color-primary)');
    expect(resolver.varFor('var_1')).toBe('var(--color-primary)');
  });
});

describe('normalizeColorKey', () => {
  it('distinguishes opacity', () => {
    const a = normalizeColorKey({ r: 1, g: 1, b: 1 }, 1);
    const b = normalizeColorKey({ r: 1, g: 1, b: 1 }, 0.5);
    expect(a).not.toBe(b);
  });
});

describe('segmentToInlineStyle', () => {
  it('skips defaults', () => {
    expect(
      segmentToInlineStyle({
        text: 'hi',
        fontSize: '16px',
        fontWeight: 400,
        fontFamily: 'inherit',
        lineHeight: 'normal',
        letterSpacing: 'normal',
        color: 'rgb(0, 0, 0)',
      })
    ).toBe('font-size: 16px; color: rgb(0, 0, 0)');
  });
});

describe('escapeHtml / toFileSlug', () => {
  it('escapes and slugs', () => {
    expect(escapeHtml('<b>"x"&')).toBe('&lt;b&gt;&quot;x&quot;&amp;');
    expect(toFileSlug('My Frame 2!')).toBe('my-frame-2');
    expect(toFileSlug('!!!')).toBe('export');
  });
});

describe('fidelity: css-generator', () => {
  it('merges layout centering transform with visual rotation', () => {
    const css = generateCss(
      node({ layout: { transform: 'translate(-50%, -50%)' }, visual: { transform: 'rotate(12deg)' } }),
      baseOptions
    );
    expect(css).toContain('transform: translate(-50%, -50%) rotate(12deg);');
  });

  it('emits blend, box-sizing, outline, background layers', () => {
    const css = generateCss(
      node({
        visual: {
          background: 'rgb(255, 0, 0)',
          backgroundSize: 'cover',
          boxSizing: 'border-box',
          outline: '2px solid rgb(0, 0, 0)',
          mixBlendMode: 'multiply',
        },
      }),
      baseOptions
    );
    expect(css).toContain('mix-blend-mode: multiply;');
    expect(css).toContain('box-sizing: border-box;');
    expect(css).toContain('background-size: cover;');
  });

  it('emits italic + ellipsis truncation', () => {
    const css = generateCss(
      node({
        type: 'TEXT',
        tag: 'p',
        typography: { fontStyle: 'italic', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' },
      }),
      baseOptions
    );
    expect(css).toContain('font-style: italic;');
    expect(css).toContain('text-overflow: ellipsis;');
  });
});

describe('fidelity: tailwind-generator', () => {
  it('escapes text content', () => {
    const html = generateTailwindHtml(
      node({ type: 'TEXT', tag: 'p', text: '<b>&"' }),
    );
    expect(html).toContain('&lt;b&gt;&amp;&quot;');
  });
});

describe('typography: font-face generator', () => {
  it('generates base64 @font-face rules for standalone HTML', () => {
    const options = {
      ...baseOptions,
      customFonts: [
        {
          id: 'iranyekanx-bold',
          family: 'IRANYekanX',
          style: 'Bold',
          weight: 700,
          format: 'woff2' as const,
          base64: 'dGVzdGZvbnQ=',
          filename: 'IRANYekanX-Bold.woff2',
        },
      ],
      embedFontsBase64: true,
    };
    const css = generateCss(node(), options);
    expect(css).toContain("@font-face");
    expect(css).toContain("font-family: 'IRANYekanX';");
    expect(css).toContain("font-weight: 700;");
    expect(css).toContain("data:font/woff2;base64,dGVzdGZvbnQ=");
  });

  it('generates relative url @font-face rules for zip package', () => {
    const options = {
      ...baseOptions,
      customFonts: [
        {
          id: 'iranyekanx-regular',
          family: 'IRANYekanX',
          style: 'Regular',
          weight: 400,
          format: 'woff2' as const,
          base64: 'dGVzdGZvbnQ=',
          filename: 'IRANYekanX-Regular.woff2',
        },
      ],
    };
    const css = generateCss(node(), options, false, undefined, true);
    expect(css).toContain("@font-face");
    expect(css).toContain("url('./fonts/IRANYekanX-Regular.woff2')");
  });
});

describe('Circle and Ellipse handling', () => {
  it('generates rounded-full for visual.borderRadius 50% in Tailwind generator', () => {
    const circleNode = node({
      name: 'Color Indicator',
      tag: 'div',
      type: 'ELLIPSE',
      layout: { width: '10px', height: '10px' },
      visual: { borderRadius: '50%', background: '#4d81e7' },
    });
    const html = generateTailwindHtml(circleNode);
    expect(html).toContain('rounded-full');
    expect(html).toContain('w-[10px]');
    expect(html).toContain('h-[10px]');
    expect(html).toContain('bg-[#4d81e7]');
  });

  it('generates border-radius: 50% in CSS generator', () => {
    const circleNode = node({
      name: 'Color Indicator',
      tag: 'div',
      type: 'ELLIPSE',
      layout: { width: '10px', height: '10px' },
      visual: { borderRadius: '50%', background: '#4d81e7' },
    });
    const css = generateCss(circleNode, baseOptions);
    expect(css).toContain('border-radius: 50%;');
  });

  it('identifies partial arcs and donut ellipses as single vector export', () => {
    const fullCircle = {
      type: 'ELLIPSE',
      name: 'Full Circle',
      arcData: { startingAngle: 0, endingAngle: Math.PI * 2, innerRadius: 0 },
    } as unknown as SceneNode;
    expect(shouldExportAsSingleVector(fullCircle)).toBe(false);

    const donutArc = {
      type: 'ELLIPSE',
      name: 'Donut Arc',
      arcData: { startingAngle: 0, endingAngle: Math.PI, innerRadius: 0.5 },
    } as unknown as SceneNode;
    expect(shouldExportAsSingleVector(donutArc)).toBe(true);

    const pieSlice = {
      type: 'ELLIPSE',
      name: 'Pie Slice',
      arcData: { startingAngle: 0, endingAngle: Math.PI / 2, innerRadius: 0 },
    } as unknown as SceneNode;
    expect(shouldExportAsSingleVector(pieSlice)).toBe(true);
  });

  it('ensures vector asset wrappers do not emit duplicate borders or backgrounds', () => {
    const arcAssetNode = node({
      name: 'Value Arc',
      tag: 'div',
      type: 'ELLIPSE',
      layout: { width: '90px', height: '90px', position: 'absolute', left: '0px', top: '0px' },
      visual: {}, // clean visual styles as intended for SVG wrappers
      asset: {
        type: 'svg',
        content: '<svg viewBox="0 0 90 90"><path d="M45 5 A40 40 0 0 1 85 45" stroke="#189731" stroke-width="10"/></svg>',
      },
    });

    const css = generateCss(arcAssetNode, baseOptions);
    expect(css).not.toContain('border:');
    expect(css).not.toContain('border-radius:');
    expect(css).not.toContain('background:');
    const tw = generateTailwindHtml(arcAssetNode);
    expect(tw).not.toContain('border-');
    expect(tw).not.toContain('rounded-');
    expect(tw).not.toContain('bg-');
    expect(tw).toContain('w-[90px]');
    expect(tw).toContain('h-[90px]');
  });

  it('correctly calculates linear gradient angles using affine transform', () => {
    // Horizontal (to right)
    expect(gradientTransformToAngle([[1, 0, 0], [0, 1, 0]])).toBe(90);
    // Vertical (to bottom)
    expect(gradientTransformToAngle([[0, 1, 0], [-1, 0, 1]])).toBe(180);
  });

  it('multiplies fill.opacity with gradient stop alphas to prevent opaque white overlay', () => {
    const mockNode = {
      type: 'FRAME',
      width: 68,
      height: 24,
      fills: [
        {
          type: 'SOLID',
          visible: true,
          color: { r: 0.388, g: 0.482, b: 0.914 }, // Primary Blue
          opacity: 1,
        },
        {
          type: 'GRADIENT_LINEAR',
          visible: true,
          opacity: 0.12, // 12% opacity from Figma slider!
          gradientTransform: [[0, 1, 0], [-1, 0, 1]],
          gradientStops: [
            { position: 0, color: { r: 1, g: 1, b: 1, a: 1 } },
            { position: 1, color: { r: 1, g: 1, b: 1, a: 0 } },
          ],
        },
      ],
      effects: [
        {
          type: 'INNER_SHADOW',
          visible: true,
          color: { r: 1, g: 1, b: 1, a: 0.3 },
          offset: { x: 0, y: 1 },
          radius: 1,
          spread: 0,
        },
      ],
    } as unknown as SceneNode;

    const styles = extractVisualStyles(mockNode, {
      outputMode: 'pure-css',
      useRem: false,
      baseFontSize: 16,
      includeReset: false,
      inlineAssets: true,
      semanticTags: true,
    });

    // Background must have gradient first with 12% opacity (0.12), followed by solid primary blue
    expect(styles.background).toContain('linear-gradient(180deg');
    expect(styles.background).toContain('0.12');
    expect(styles.background).not.toContain('var(--color-white) 0%'); // MUST NOT be 100% opaque white!

    // Inner shadow must be present with inset
    expect(styles.boxShadow).toContain('inset 0px 1px 1px 0px');
  });

  it('maps strokeAlign OUTSIDE to standard CSS border and box-sizing: border-box', () => {
    const nodeWithOutsideStroke = {
      type: 'FRAME',
      name: 'Avatar',
      strokes: [
        {
          type: 'SOLID',
          visible: true,
          color: { r: 1, g: 1, b: 1 },
          opacity: 1,
        },
      ],
      strokeWeight: 3,
      strokeAlign: 'OUTSIDE',
      fills: [],
    } as unknown as SceneNode;

    const styles = extractVisualStyles(nodeWithOutsideStroke, baseOptions);
    expect(styles.border).toBe('3px solid #ffffff');
    expect(styles.boxSizing).toBe('border-box');
    expect(styles.outline).toBeUndefined();
    expect(styles.boxShadow).toBeUndefined();
  });

  it('inherits strokeAlign OUTSIDE from mainComponent on instance nodes and outputs border', () => {
    const mockMainComp = {
      type: 'COMPONENT',
      name: 'Avatar Component',
      strokes: [
        {
          type: 'SOLID',
          visible: true,
          color: { r: 1, g: 1, b: 1 },
          opacity: 1,
        },
      ],
      strokeWeight: 3,
      strokeAlign: 'OUTSIDE',
      fills: [],
    };

    const mockInstance = {
      type: 'INSTANCE',
      name: 'Avatar Instance',
      strokes: [
        {
          type: 'SOLID',
          visible: true,
          color: { r: 1, g: 1, b: 1 },
          opacity: 1,
        },
      ],
      mainComponent: mockMainComp,
      fills: [],
    } as unknown as SceneNode;

    const styles = extractVisualStyles(mockInstance, baseOptions);
    expect(styles.border).toBe('3px solid #ffffff');
    expect(styles.boxSizing).toBe('border-box');
    expect(styles.outline).toBeUndefined();
    expect(styles.boxShadow).toBeUndefined();
  });

  it('calculates outer box dimensions for strokeAlign OUTSIDE in layout and helper', () => {
    const nodeWithOutsideStroke = {
      type: 'FRAME',
      name: 'Avatar',
      width: 26,
      height: 26,
      strokes: [
        {
          type: 'SOLID',
          visible: true,
          color: { r: 1, g: 1, b: 1 },
          opacity: 1,
        },
      ],
      strokeWeight: 3,
      strokeAlign: 'OUTSIDE',
      fills: [],
    } as unknown as SceneNode;

    const boxDims = getNodeBoxDimensions(nodeWithOutsideStroke);
    expect(boxDims.width).toBe(32);
    expect(boxDims.height).toBe(32);
    expect(boxDims.outsideStrokeWeight).toBe(3);

    const layout = extractLayout(nodeWithOutsideStroke, null, baseOptions);
    expect(layout.width).toBe('32px');
    expect(layout.height).toBe('32px');
    expect(layout.boxSizing).toBe('border-box');
  });

  it('adjusts itemSpacing and dimensions of AutoLayout parent when children have outside stroke', () => {
    const child1 = {
      type: 'INSTANCE',
      name: 'Avatar 1',
      width: 26,
      height: 26,
      strokes: [
        {
          type: 'SOLID',
          visible: true,
          color: { r: 1, g: 1, b: 1 },
          opacity: 1,
        },
      ],
      strokeWeight: 3,
      strokeAlign: 'OUTSIDE',
      fills: [],
    } as unknown as SceneNode;

    const child2 = {
      type: 'INSTANCE',
      name: 'Avatar 2',
      width: 26,
      height: 26,
      strokes: [
        {
          type: 'SOLID',
          visible: true,
          color: { r: 1, g: 1, b: 1 },
          opacity: 1,
        },
      ],
      strokeWeight: 3,
      strokeAlign: 'OUTSIDE',
      fills: [],
    } as unknown as SceneNode;

    const parentList = {
      type: 'FRAME',
      name: 'List people',
      layoutMode: 'HORIZONTAL',
      width: 92,
      height: 26,
      itemSpacing: -4,
      strokesIncludedInLayout: false,
      children: [child1, child2],
      strokes: [],
      fills: [],
    } as unknown as SceneNode;

    const maxSw = getChildrenMaxOutsideStroke(parentList);
    expect(maxSw).toBe(3);

    const layout = extractLayout(parentList, null, baseOptions);
    expect(layout.width).toBe('98px'); // 92 + 2 * 3
    expect(layout.height).toBe('32px'); // 26 + 2 * 3
    expect(layout.itemSpacing).toBe(-10); // -4 - 2 * 3
  });

  it('handles strokes in AutoLayout by using CSS border and box-sizing: border-box', () => {
    const autoLayoutIncluded = {
      type: 'FRAME',
      name: 'Stroke Frame',
      layoutMode: 'HORIZONTAL',
      strokes: [
        {
          type: 'SOLID',
          visible: true,
          color: { r: 1, g: 1, b: 1 },
          opacity: 1,
        },
      ],
      strokeWeight: 2,
      strokeAlign: 'INSIDE',
      fills: [],
    } as unknown as SceneNode;

    const styles = extractVisualStyles(autoLayoutIncluded, baseOptions);
    expect(styles.border).toBe('2px solid #ffffff');
    expect(styles.boxSizing).toBe('border-box');
    expect(styles.outline).toBeUndefined();
  });
});

describe('Smart Image Export Scaling', () => {
  it('selects 3x scale for small elements (avatars, icons, thumbnails <= 160px)', () => {
    const avatarNode = { width: 26, height: 26, type: 'ELLIPSE', name: 'Avatar' } as unknown as SceneNode;
    expect(getSmartImageExportScale(avatarNode)).toBe(3);

    const smallCard = { width: 120, height: 120, type: 'FRAME', name: 'Thumbnail' } as unknown as SceneNode;
    expect(getSmartImageExportScale(smallCard)).toBe(3);

    const edgeSmall = { width: 160, height: 160, type: 'FRAME', name: 'Badge' } as unknown as SceneNode;
    expect(getSmartImageExportScale(edgeSmall)).toBe(3);
  });

  it('selects 2x scale for medium elements (160px - 800px)', () => {
    const cardNode = { width: 300, height: 200, type: 'RECTANGLE', name: 'Card Photo' } as unknown as SceneNode;
    expect(getSmartImageExportScale(cardNode)).toBe(2);

    const postBanner = { width: 800, height: 400, type: 'FRAME', name: 'Post Banner' } as unknown as SceneNode;
    expect(getSmartImageExportScale(postBanner)).toBe(2);
  });

  it('selects 2x for large banners and caps very large elements (> 800px) sensibly', () => {
    const heroBanner = { width: 1200, height: 600, type: 'FRAME', name: 'Hero Banner' } as unknown as SceneNode;
    expect(getSmartImageExportScale(heroBanner)).toBe(2);

    const fullHd = { width: 1920, height: 1080, type: 'FRAME', name: 'Background' } as unknown as SceneNode;
    const scale = getSmartImageExportScale(fullHd);
    expect(scale).toBeGreaterThanOrEqual(1.3);
    expect(scale).toBeLessThanOrEqual(2);
    // 1920 * scale <= 2880 to prevent excessive memory/base64 footprint
    expect(1920 * scale).toBeLessThanOrEqual(3000);
  });

  it('honors explicit options.imageScale override when provided', () => {
    const avatarNode = { width: 26, height: 26, type: 'ELLIPSE', name: 'Avatar' } as unknown as SceneNode;
    expect(getSmartImageExportScale(avatarNode, { ...baseOptions, imageScale: 1 })).toBe(1);
    expect(getSmartImageExportScale(avatarNode, { ...baseOptions, imageScale: 4 })).toBe(4);
  });

  it('exports image node using 3x constraint for avatar and falls back if needed', async () => {
    let capturedConstraint: any = null;
    const mockImageNode = {
      name: 'Avatar/32px',
      width: 26,
      height: 26,
      exportAsync: async (settings: any) => {
        capturedConstraint = settings.constraint;
        return new Uint8Array([137, 80, 78, 71]); // PNG magic bytes
      },
    } as unknown as SceneNode;

    const asset = await exportNodeAsImage(mockImageNode);
    expect(asset).not.null;
    expect(asset?.type).toBe('image');
    expect(asset?.mimeType).toBe('image/png');
    expect(capturedConstraint).toEqual({ type: 'SCALE', value: 3 });
  });

  it('falls back to 2x or 1x gracefully if high-scale exportAsync throws', async () => {
    let callCount = 0;
    const mockImageNode = {
      name: 'Avatar/32px',
      width: 26,
      height: 26,
      exportAsync: async (settings: any) => {
        callCount++;
        if (settings.constraint.value === 3) {
          throw new Error('Out of memory at 3x');
        }
        return new Uint8Array([137, 80, 78, 71]);
      },
    } as unknown as SceneNode;

    const asset = await exportNodeAsImage(mockImageNode);
    expect(asset).not.null;
    expect(callCount).toBe(2); // Attempted 3x, failed, then succeeded at 2x
  });
});

describe('typography: getFontWeightNumber and extractTypography', () => {
  it('correctly parses font weight names with spaces, hyphens, and numeric strings', () => {
    expect(getFontWeightNumber('Thin')).toBe(100);
    expect(getFontWeightNumber('Extra Light')).toBe(200);
    expect(getFontWeightNumber('Extra-Light')).toBe(200);
    expect(getFontWeightNumber('Ultra Light')).toBe(200);
    expect(getFontWeightNumber('Light')).toBe(300);
    expect(getFontWeightNumber('Regular')).toBe(400);
    expect(getFontWeightNumber('Medium')).toBe(500);
    expect(getFontWeightNumber('Semi Bold')).toBe(600);
    expect(getFontWeightNumber('SemiBold')).toBe(600);
    expect(getFontWeightNumber('Semi-Bold')).toBe(600);
    expect(getFontWeightNumber('Demi Bold')).toBe(600);
    expect(getFontWeightNumber('Bold')).toBe(700);
    expect(getFontWeightNumber('Extra Bold')).toBe(800);
    expect(getFontWeightNumber('Extra-Bold')).toBe(800);
    expect(getFontWeightNumber('Ultra Bold')).toBe(800);
    expect(getFontWeightNumber('Black')).toBe(900);
    expect(getFontWeightNumber('Heavy')).toBe(900);
    expect(getFontWeightNumber('Extra Black')).toBe(950);
    expect(getFontWeightNumber('ExtraBlack')).toBe(950);
    expect(getFontWeightNumber('UltraBlack')).toBe(950);
    expect(getFontWeightNumber('600')).toBe(600);
    expect(getFontWeightNumber('700')).toBe(700);
  });

  it('prioritizes direct node.fontWeight over fontName.style in extractTypography', () => {
    const mockNode = {
      characters: 'تست متن',
      textAutoResize: 'NONE',
      textAlignHorizontal: 'RIGHT',
      fontName: { family: 'Yekan Bakh VF', style: 'Regular' },
      fontWeight: 600,
      fontSize: 14,
      getStyledTextSegments: () => [],
    } as unknown as TextNode;

    const typo = extractTypography(mockNode, baseOptions as any);
    expect(typo.fontWeight).toBe(600);
  });
});

describe('layout: centering constraints without duplicate transforms', () => {
  it('does not duplicate translateX when both optical centering and constraints CENTER match', () => {
    const parentNode = {
      id: 'parent',
      name: 'Chart',
      type: 'FRAME',
      width: 90,
      height: 90,
      layoutMode: 'NONE',
    } as unknown as FrameNode;

    const textNode = {
      id: 'child',
      name: 'Value',
      type: 'TEXT',
      x: 22,
      y: 29,
      width: 46,
      height: 32,
      textAutoResize: 'NONE',
      constraints: { horizontal: 'CENTER', vertical: 'CENTER' },
      parent: parentNode,
    } as unknown as TextNode;

    const layout = extractLayout(textNode, parentNode, baseOptions as any);
    expect(layout.left).toBe('50%');
    expect(layout.top).toBe('50%');
    expect(layout.transform).toBe('translate(-50%, -50%)');
  });

  it('generates proper Tailwind translation classes for centered elements', () => {
    const irNode: IRNode = {
      id: 'gauge-text',
      name: 'Value',
      type: 'TEXT',
      tag: 'p',
      className: 'gauge-text',
      children: [],
      layout: {
        position: 'absolute',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        width: '46px',
        height: '32px',
      },
      visual: {},
      typography: {
        fontFamily: 'Yekan Bakh VF',
        fontWeight: 600,
        fontSize: '24px',
        textAlign: 'center',
      },
      text: '٪۸۲',
    };

    const twHtml = generateTailwindHtml(irNode, baseOptions as any);
    expect(twHtml).toContain('-translate-x-1/2');
    expect(twHtml).toContain('-translate-y-1/2');
    expect(twHtml).toContain('font-semibold');
  });
});

describe('typography: text wrapping and multiline rendering', () => {
  it('converts literal newlines into <br /> tags in both Pure CSS and Tailwind HTML', () => {
    const irNode: IRNode = {
      id: 'tooltip-text',
      name: 'Tooltip Content',
      type: 'TEXT',
      tag: 'p',
      className: 'tooltip-p',
      layout: { width: '230px', maxWidth: '100%' },
      visual: {},
      typography: {
        fontFamily: 'Yekan Bakh VF',
        fontSize: '14px',
        whiteSpace: 'pre-line',
        direction: 'rtl',
      },
      text: 'متن راهنمای دلیل مورد نظر هنگام هاور شدن\nآیکون راهنما',
      children: [],
    };

    const html = generateHtml(irNode);
    expect(html).toContain('متن راهنمای دلیل مورد نظر هنگام هاور شدن<br />آیکون راهنما');

    const twHtml = generateTailwindHtml(irNode);
    expect(twHtml).toContain('متن راهنمای دلیل مورد نظر هنگام هاور شدن<br />آیکون راهنما');
    expect(twHtml).toContain('whitespace-pre-line');
  });

  it('does not force nowrap on multiline or long text even if textAutoResize is WIDTH_AND_HEIGHT', () => {
    const multilineNode = {
      type: 'TEXT',
      characters: 'متن راهنمای دلیل مورد نظر هنگام هاور شدن\nآیکون راهنما',
      textAutoResize: 'WIDTH_AND_HEIGHT',
      textAlignHorizontal: 'RIGHT',
      fontName: { family: 'Yekan Bakh VF', style: 'Regular' },
      fontSize: 14,
      width: 230,
      height: 40,
      getStyledTextSegments: () => [],
    } as unknown as TextNode;

    const typo = extractTypography(multilineNode, baseOptions as any);
    expect(typo.whiteSpace).not.toBe('nowrap');
    expect(typo.whiteSpace).toBe('pre-line');
    expect(typo.overflowWrap).toBe('break-word');

    const parent = { type: 'FRAME', width: 246, height: 56, layoutMode: 'NONE' } as any;
    const layout = extractLayout(multilineNode, parent, baseOptions as any);
    expect(layout.maxWidth).toBe('100%');
  });

  it('keeps nowrap for short single-line badges/buttons without newlines', () => {
    const badgeNode = {
      characters: '٪۸۲',
      textAutoResize: 'WIDTH_AND_HEIGHT',
      textAlignHorizontal: 'CENTER',
      fontName: { family: 'Yekan Bakh VF', style: 'Bold' },
      fontSize: 24,
      width: 46,
      height: 32,
      getStyledTextSegments: () => [],
    } as unknown as TextNode;

    const typo = extractTypography(badgeNode, baseOptions as any);
    expect(typo.whiteSpace).toBe('nowrap');
  });

  it('correctly wraps multiline text with textAutoResize HEIGHT (e.g. tooltip / multiline description)', () => {
    const tooltipTextNode = {
      type: 'TEXT',
      characters: 'متن راهنمای دلیل مورد نظر هنگام هاور شدن آیکون راهنما',
      textAutoResize: 'HEIGHT',
      textAlignHorizontal: 'RIGHT',
      fontName: { family: 'Yekan Bakh VF', style: 'Regular' },
      fontSize: 14,
      lineHeight: { unit: 'PIXELS', value: 20 },
      width: 230,
      height: 40,
      getStyledTextSegments: () => [],
    } as unknown as TextNode;

    const typo = extractTypography(tooltipTextNode, baseOptions as any);
    expect(typo.whiteSpace).toBe('normal');
    expect(typo.overflowWrap).toBe('break-word');
    expect(typo.wordBreak).toBe('break-word');

    // Horizontal auto-layout parent (e.g. tooltip frame)
    const parent = {
      type: 'FRAME',
      width: 246,
      height: 56,
      layoutMode: 'HORIZONTAL',
      paddingLeft: 8,
      paddingRight: 8,
      paddingTop: 8,
      paddingBottom: 8,
    } as any;

    const layout = extractLayout(tooltipTextNode, parent, baseOptions as any);
    expect(layout.width).toBe('230px');
    expect(layout.maxWidth).toBe('100%');
  });

  describe('wrapBidiNumbers - dates, times, and phone numbers', () => {
    it('does NOT wrap or split dates separated by slashes', () => {
      const date1 = '۱۴۰۰/۰۷/۳';
      expect(wrapBidiNumbers(date1)).toBe('۱۴۰۰/۰۷/۳');

      const date2 = '2023/11/05';
      expect(wrapBidiNumbers(date2)).toBe('2023/11/05');
    });

    it('does NOT wrap or split times with colons or single numbers', () => {
      expect(wrapBidiNumbers('۱۴:۳۶')).toBe('۱۴:۳۶');
      expect(wrapBidiNumbers('۱۴۰۰')).toBe('۱۴۰۰');
      expect(wrapBidiNumbers('۵۴۲۰۰')).toBe('۵۴۲۰۰');
    });

    it('wraps multi-part phone numbers separated by spaces or hyphens', () => {
      const phone1 = '۰۹۱۲ ۳۴۵ ۶۷۸۹';
      expect(wrapBidiNumbers(phone1)).toContain('dir="ltr"');
      expect(wrapBidiNumbers(phone1)).toContain('۰۹۱۲ ۳۴۵ ۶۷۸۹');

      const phone2 = '۰۹۱۲-۳۴۵-۶۷۸۹';
      expect(wrapBidiNumbers(phone2)).toContain('dir="ltr"');
      expect(wrapBidiNumbers(phone2)).toContain('۰۹۱۲-۳۴۵-۶۷۸۹');

      const phone3 = '+98 912 345 6789';
      expect(wrapBidiNumbers(phone3)).toContain('dir="ltr"');
      expect(wrapBidiNumbers(phone3)).toContain('+98 912 345 6789');
    });

    it('leaves two-chunk ranges in the paragraph direction, the way Figma draws them', () => {
      expect(wrapBidiNumbers('کاردوره ۲-۴')).toBe('کاردوره ۲-۴');
      expect(wrapBidiNumbers('۲-۴')).toBe('۲-۴');
      expect(wrapBidiNumbers('۱۲–۱۸')).toBe('۱۲–۱۸');
      expect(wrapBidiNumbers('۱۴۰۲-۱۴۰۳')).toBe('۱۴۰۲-۱۴۰۳');
    });

    it('does not isolate a range in the generated markup', () => {
      const html = generateHtml(
        node({ type: 'TEXT', tag: 'p', text: 'کاردوره ۲-۴', typography: { direction: 'rtl' } })
      );
      expect(html).toContain('کاردوره ۲-۴');
      expect(html).not.toContain('unicode-bidi');
    });
  });

  describe('shouldExportAsSingleVector for LINE nodes', () => {
    it('does not export orthogonal straight LINE nodes as SVG', () => {
      const hLine = {
        type: 'LINE',
        rotation: 0,
        width: 336,
        height: 0,
        name: 'Divider',
      } as unknown as SceneNode;
      expect(shouldExportAsSingleVector(hLine)).toBe(false);

      const vLine = {
        type: 'LINE',
        rotation: 90,
        width: 0,
        height: 100,
        name: 'V-Divider',
      } as unknown as SceneNode;
      expect(shouldExportAsSingleVector(vLine)).toBe(false);
    });

    it('exports diagonal LINE nodes as SVG', () => {
      const diagLine = {
        type: 'LINE',
        rotation: 45,
        width: 100,
        height: 100,
        name: 'Slash',
      } as unknown as SceneNode;
      expect(shouldExportAsSingleVector(diagLine)).toBe(true);
    });
  });

  describe('extractLayout - SPACE_BETWEEN gap exclusion', () => {
    it('does not emit gap when primaryAxisAlignItems is SPACE_BETWEEN', () => {
      const rowNode = {
        type: 'FRAME',
        layoutMode: 'HORIZONTAL',
        primaryAxisAlignItems: 'SPACE_BETWEEN',
        counterAxisAlignItems: 'CENTER',
        itemSpacing: 12,
        width: 336,
        height: 48,
        children: [],
      } as unknown as FrameNode;

      const layout = extractLayout(rowNode, null, baseOptions as any);
      expect(layout.justifyContent).toBe('space-between');
      expect(layout.gap).toBeUndefined();
    });
  });

  describe('extractLayout - AutoLayout Hug sizing and constraints', () => {
    it('detects Hug sizing via primaryAxisSizingMode / counterAxisSizingMode AUTO and avoids overflow hidden', () => {
      const parentNode = {
        type: 'FRAME',
        width: 384,
        height: 76,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      const titleFrame = {
        type: 'FRAME',
        layoutMode: 'HORIZONTAL',
        primaryAxisSizingMode: 'AUTO',
        counterAxisSizingMode: 'AUTO',
        primaryAxisAlignItems: 'MAX',
        counterAxisAlignItems: 'CENTER',
        clipsContent: true,
        x: 225,
        y: 24,
        width: 135,
        height: 28,
        parent: parentNode,
        children: [{}, {}],
      } as unknown as FrameNode;

      const layout = extractLayout(titleFrame, parentNode, baseOptions as any);
      expect(layout.width).toBe('fit-content');
      expect(layout.minWidth).toBe('135px');
      expect(layout.height).toBe('fit-content');
      expect(layout.minHeight).toBe('28px');
      expect(layout.overflow).toBeUndefined(); // Should NOT clip text in hug frames
    });

    it('positions MAX horizontal and vertical constraints with right and bottom offsets', () => {
      const parentNode = {
        type: 'FRAME',
        width: 384,
        height: 412,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      const childNode = {
        type: 'FRAME',
        x: 225,
        y: 24,
        width: 135,
        height: 28,
        constraints: { horizontal: 'MAX', vertical: 'MIN' },
        parent: parentNode,
        children: [],
      } as unknown as FrameNode;

      const layout = extractLayout(childNode, parentNode, baseOptions as any);
      expect(layout.right).toBe('24px');
      expect(layout.left).toBeUndefined();
      expect(layout.top).toBe('24px');
    });

    it('preserves exact pixel coordinates for centered containers without unwanted translateX', () => {
      const cardNode = {
        type: 'FRAME',
        width: 384,
        height: 412,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      const tableNode = {
        type: 'FRAME',
        x: 24,
        y: 100,
        width: 336,
        height: 200,
        layoutMode: 'VERTICAL',
        parent: cardNode,
        children: [],
      } as unknown as FrameNode;

      const layout = extractLayout(tableNode, cardNode, baseOptions as any);
      expect(layout.left).toBe('24px');
      expect(layout.top).toBe('100px');
      expect(layout.transform).toBeUndefined(); // Should not have translateX(-50%)
    });

    it('automatically stretches non-text child that spans parent counter axis inner width', () => {
      const parentFrame = {
        type: 'FRAME',
        width: 109,
        height: 145,
        paddingLeft: 0,
        paddingRight: 0,
        paddingTop: 0,
        paddingBottom: 0,
        layoutMode: 'VERTICAL',
      } as unknown as FrameNode;

      const childFrame = {
        type: 'FRAME',
        width: 109,
        height: 119,
        layoutAlign: 'INHERIT',
        layoutSizingHorizontal: 'FIXED',
        layoutSizingVertical: 'FIXED',
        parent: parentFrame,
        children: [],
      } as unknown as FrameNode;

      const layout = extractLayout(childFrame, parentFrame, baseOptions as any);
      expect(layout.alignSelf).toBe('stretch');
      expect(layout.width).toBe('100%');
    });

    it('detects QR / barcode image nodes and applies contain, square aspect ratio, and 100% width', async () => {
      const parentBarcode = {
        id: 'p-1',
        name: 'barcode',
        type: 'FRAME',
        visible: true,
        width: 109,
        height: 145,
        paddingLeft: 0,
        paddingRight: 0,
        paddingTop: 0,
        paddingBottom: 0,
        layoutMode: 'VERTICAL',
      } as unknown as FrameNode;

      const scanNode = {
        id: 'c-1',
        name: 'Scan',
        type: 'RECTANGLE',
        visible: true,
        width: 109,
        height: 119,
        fills: [{ type: 'IMAGE', visible: true, imageHash: 'abc123' }],
        parent: parentBarcode,
        exportAsync: async () => new Uint8Array([1, 2, 3]),
      } as unknown as RectangleNode;

      const ir = await convertNodeToIR(scanNode, parentBarcode, baseOptions as any);
      expect(ir).not.toBeNull();
      if (!ir) return;

      expect(ir.tag).toBe('img');
      expect(ir.layout.objectFit).toBe('contain');
      expect(ir.layout.aspectRatio).toBe('1 / 1');
      expect(ir.layout.width).toBe('100%');
      expect(ir.layout.height).toBe('auto');
      expect(ir.layout.maxWidth).toBe('109px');
      expect(ir.layout.alignSelf).toBe('stretch');

      // Test CSS output
      const css = generateCss(ir, baseOptions as any, false);
      expect(css).toContain('width: 100%;');
      expect(css).toContain('height: auto;');
      expect(css).toContain('aspect-ratio: 1 / 1;');
      expect(css).toContain('object-fit: contain;');
      expect(css).toContain('max-width: 109px;');

      // Test Tailwind output
      const tw = nodeToTailwindClasses(ir);
      expect(tw).toContain('w-full');
      expect(tw).toContain('h-auto');
      expect(tw).toContain('aspect-square');
      expect(tw).toContain('object-contain');
      expect(tw).toContain('max-w-[109px]');
      expect(tw).toContain('self-stretch');
    });
  });

  describe('extractLayout - freeform text optical centering and RTL positioning', () => {
    it('centers text in a 384x248 modal card when textAlignHorizontal is CENTER', () => {
      const modalParent = {
        type: 'FRAME',
        width: 384,
        height: 248,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      const titleNode = {
        type: 'TEXT',
        name: 'Title',
        characters: 'ثبت وضعیت پرونده',
        x: 126,
        y: 24,
        width: 132,
        height: 28,
        textAlignHorizontal: 'CENTER',
        textAutoResize: 'WIDTH_AND_HEIGHT',
        parent: modalParent,
      } as unknown as TextNode;

      const layout = extractLayout(titleNode, modalParent, baseOptions as any);
      expect(layout.left).toBe('50%');
      expect(layout.top).toBe('24px');
      expect(layout.transform).toBe('translateX(-50%)');
      expect(layout.width).toBe('fit-content');
    });

    it('does NOT center right-aligned text and anchors it via right to prevent overflow', () => {
      const modalParent = {
        type: 'FRAME',
        width: 384,
        height: 248,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      // Subtitle placed at x=135, width=217 (right margin = 384 - 352 = 32px)
      const subtitleNode = {
        type: 'TEXT',
        name: 'Subtitle',
        characters: 'وضعیت پرونده را انتخاب و سپس ثبت کنید.',
        x: 135,
        y: 60,
        width: 217,
        height: 20,
        textAlignHorizontal: 'RIGHT',
        textAutoResize: 'WIDTH_AND_HEIGHT',
        parent: modalParent,
      } as unknown as TextNode;

      const layout = extractLayout(subtitleNode, modalParent, baseOptions as any);
      // Stays exactly on the right side without jumping to center!
      expect(layout.right).toBe('32px');
      expect(layout.left).toBeUndefined();
      expect(layout.transform).toBeUndefined();
      expect(layout.top).toBe('60px');
    });

    it('resolves stale node.x in instance overrides using absoluteBoundingBox', () => {
      const modalParent = {
        type: 'INSTANCE',
        width: 384,
        height: 248,
        layoutMode: 'NONE',
        absoluteBoundingBox: { x: 1000, y: 500, width: 384, height: 248 },
      } as unknown as InstanceNode;

      // In Figma instances, node.x might be stale at 150 from the master component
      // but absoluteBoundingBox on canvas is at 1000 + 135 = 1135
      const instanceTextNode = {
        type: 'TEXT',
        name: 'Subtitle Overridden',
        characters: 'وضعیت پرونده را انتخاب و سپس ثبت کنید.',
        x: 150, // Stale!
        y: 60,
        width: 217,
        height: 20,
        textAlignHorizontal: 'RIGHT',
        textAutoResize: 'WIDTH_AND_HEIGHT',
        absoluteBoundingBox: { x: 1135, y: 560, width: 217, height: 20 },
        parent: modalParent,
      } as unknown as TextNode;

      const layout = extractLayout(instanceTextNode, modalParent, baseOptions as any);
      // Uses canvas relative bounding box offset (135), so right is 384 - 135 - 217 = 32px
      expect(layout.right).toBe('32px');
      expect(layout.left).toBeUndefined();
      expect(layout.transform).toBeUndefined();
    });

    it('anchors right-aligned RTL text on the right side using right instead of left', () => {
      const cardParent = {
        type: 'FRAME',
        width: 384,
        height: 248,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      // Text placed on the right side: x=240, width=120 (right margin = 384 - 360 = 24px)
      const rightTextNode = {
        type: 'TEXT',
        name: 'Right Label',
        characters: 'اطلاعات پرونده',
        x: 240,
        y: 40,
        width: 120,
        height: 20,
        textAlignHorizontal: 'RIGHT',
        textAutoResize: 'WIDTH_AND_HEIGHT',
        parent: cardParent,
      } as unknown as TextNode;

      const layout = extractLayout(rightTextNode, cardParent, baseOptions as any);
      expect(layout.right).toBe('24px');
      expect(layout.left).toBeUndefined();
      expect(layout.top).toBe('40px');
      expect(layout.transform).toBeUndefined();
    });

    it('preserves exact left position for non-centered LTR / off-center text in wide containers', () => {
      const wideFrame = {
        type: 'FRAME',
        width: 1000,
        height: 600,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      const colText = {
        type: 'TEXT',
        name: 'Column Text',
        characters: 'Customer Name',
        x: 320,
        y: 50,
        width: 120,
        height: 20,
        textAlignHorizontal: 'LEFT',
        textAutoResize: 'WIDTH_AND_HEIGHT',
        parent: wideFrame,
      } as unknown as TextNode;

      const layout = extractLayout(colText, wideFrame, baseOptions as any);
      expect(layout.left).toBe('320px');
      expect(layout.top).toBe('50px');
      expect(layout.transform).toBeUndefined();
    });

    it('does NOT center off-center text even if constraint is CENTER in Figma', () => {
      const modalParent = {
        type: 'FRAME',
        width: 384,
        height: 248,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      // Off-center subtitle: x=135, width=217 (center = 243.5, parent center = 192, diff = 51.5px)
      // Even if Figma has constraints: { horizontal: 'CENTER' }
      const offCenterSubtitle = {
        type: 'TEXT',
        name: 'Subtitle',
        characters: 'وضعیت پرونده را انتخاب و سپس ثبت کنید.',
        x: 135,
        y: 60,
        width: 217,
        height: 20,
        textAlignHorizontal: 'RIGHT',
        textAutoResize: 'WIDTH_AND_HEIGHT',
        constraints: { horizontal: 'CENTER', vertical: 'MIN' },
        parent: modalParent,
      } as unknown as TextNode;

      const layout = extractLayout(offCenterSubtitle, modalParent, baseOptions as any);
      expect(layout.left).toBeUndefined();
      expect(layout.transform).toBeUndefined();
      expect(layout.right).toBe('32px');
      expect(layout.top).toBe('60px');
    });

    it('keeps an off-centre frame at its offset from the centre axis when constrained to CENTER', () => {
      const modalParent = {
        type: 'FRAME',
        width: 384,
        height: 76,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      // Title frame placed on right side: x=196, width=164 (center = 278, parent center = 192)
      const titleFrame = {
        type: 'FRAME',
        name: 'Card Title',
        x: 196,
        y: 24,
        width: 164,
        height: 28,
        layoutMode: 'HORIZONTAL',
        constraints: { horizontal: 'CENTER', vertical: 'MIN' },
        parent: modalParent,
      } as unknown as FrameNode;

      const layout = extractLayout(titleFrame, modalParent, baseOptions as any);
      // Figma's CENTER pins the frame *relative to the centre axis*: the 86px
      // between the frame's centre and the frame's centre is what has to
      // survive a resize. `calc(50% + 86px)` with the frame's own centre pulled
      // back by half its width renders at exactly x=196 here — but, unlike a
      // frozen `left: 196px`, it stays 86px right of the centre when the modal
      // grows. The frame is NOT snapped to the middle.
      expect(layout.left).toBe('calc(50% + 86px)');
      expect(layout.transform).toBe('translateX(-50%)');
      expect(layout.top).toBe('24px');
    });

    it('emits the same centre-relative offset for a wider parent, so the constraint survives a resize', () => {
      const wideParent = {
        type: 'FRAME',
        width: 640,
        height: 76,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      // Same frame, same 86px to the right of the centre — but the parent is
      // now 256px wider, so a frozen `left` would have had to change to 324px.
      const titleFrame = {
        type: 'FRAME',
        name: 'Card Title',
        x: 324,
        y: 24,
        width: 164,
        height: 28,
        layoutMode: 'HORIZONTAL',
        constraints: { horizontal: 'CENTER', vertical: 'MIN' },
        parent: wideParent,
      } as unknown as FrameNode;

      const layout = extractLayout(titleFrame, wideParent, baseOptions as any);
      expect(layout.left).toBe('calc(50% + 86px)');
      expect(layout.transform).toBe('translateX(-50%)');
    });

    it('collapses to a plain 50% when a CENTER-constrained frame really is on the centre line', () => {
      const modalParent = {
        type: 'FRAME',
        width: 384,
        height: 76,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      const titleFrame = {
        type: 'FRAME',
        name: 'Card Title',
        x: 110,
        y: 24,
        width: 164,
        height: 28,
        layoutMode: 'HORIZONTAL',
        constraints: { horizontal: 'CENTER', vertical: 'MIN' },
        parent: modalParent,
      } as unknown as FrameNode;

      const layout = extractLayout(titleFrame, modalParent, baseOptions as any);
      expect(layout.left).toBe('50%');
      expect(layout.transform).toBe('translateX(-50%)');
    });

    it('centers headline in a 1440px desktop hero frame without any hardcoded width limit', () => {
      const desktopHero = {
        type: 'FRAME',
        width: 1440,
        height: 600,
        layoutMode: 'NONE',
        children: [],
      } as unknown as FrameNode;

      const headlineText = {
        type: 'TEXT',
        name: 'Hero Title',
        characters: 'The Next Generation Design Tool',
        x: 420,
        y: 120,
        width: 600,
        height: 64,
        textAlignHorizontal: 'CENTER',
        textAutoResize: 'WIDTH_AND_HEIGHT',
        parent: desktopHero,
      } as unknown as TextNode;

      (desktopHero as any).children = [headlineText];

      const layout = extractLayout(headlineText, desktopHero, baseOptions as any);
      expect(layout.left).toBe('50%');
      expect(layout.top).toBe('120px');
      expect(layout.transform).toBe('translateX(-50%)');
    });

    it('does NOT center a table cell in the middle of a row when it has horizontal column siblings', () => {
      const tableRow = {
        type: 'FRAME',
        width: 1200,
        height: 48,
        layoutMode: 'NONE',
        children: [],
      } as unknown as FrameNode;

      const col1 = {
        type: 'TEXT',
        name: 'Col1',
        characters: '#1001',
        x: 24,
        y: 14,
        width: 80,
        height: 20,
        visible: true,
        parent: tableRow,
      } as unknown as TextNode;

      // Col2 happens to be centered at x=550 (width=100 -> center is 600, which matches row center 1200/2=600!)
      const col2 = {
        type: 'TEXT',
        name: 'Col2 (Status)',
        characters: 'Processing',
        x: 550,
        y: 14,
        width: 100,
        height: 20,
        visible: true,
        parent: tableRow,
      } as unknown as TextNode;

      const col3 = {
        type: 'TEXT',
        name: 'Col3',
        characters: '2026/10/12',
        x: 900,
        y: 14,
        width: 120,
        height: 20,
        visible: true,
        parent: tableRow,
      } as unknown as TextNode;

      (tableRow as any).children = [col1, col2, col3];

      const layout = extractLayout(col2, tableRow, baseOptions as any);
      // Because col2 has horizontal column siblings (col1, col3) in the same row band,
      // it should NOT be centered across the entire 1200px table!
      expect(layout.left).toBe('550px');
      expect(layout.transform).toBeUndefined();
    });
  });

  describe('FILL flex child sizing and left alignment fidelity', () => {
    it('sets minWidth: 0, flexGrow: 1, flexShrink: 1 for horizontal FILL child to allow proper expansion without container blowout', () => {
      const parentRow = {
        type: 'FRAME',
        layoutMode: 'HORIZONTAL',
        width: 472,
        height: 32,
      } as unknown as FrameNode;

      const fillChild = {
        type: 'FRAME',
        name: 'Value Container',
        width: 402,
        height: 32,
        layoutSizingHorizontal: 'FILL',
        layoutSizingVertical: 'FIXED',
        layoutGrow: 1,
        visible: true,
      } as unknown as FrameNode;

      const layout = extractLayout(fillChild, parentRow, baseOptions as any);
      expect(layout.flexGrow).toBe(1);
      expect(layout.flexShrink).toBe(1);
      expect(layout.flexBasis).toBe('0%');
      expect(layout.minWidth).toBe('0');
      // Must NOT assign artificial minWidth of 402px which would lock the flex child and cause misaligned left edges
      expect(layout.minWidth).not.toBe('402px');
    });

    it('sets direction: ltr and textAlign: left when textAlignHorizontal is explicitly LEFT on Persian text (e.g. dates/timestamps)', () => {
      const textNode = {
        type: 'TEXT',
        characters: '۱۴۰۰/۰۷/۳    ،    ۱۰:۱۵',
        textAlignHorizontal: 'LEFT',
        width: 389,
        height: 32,
        fontSize: 16,
        visible: true,
      } as unknown as TextNode;

      const typo = extractTypography(textNode, baseOptions as any);
      expect(typo.textAlign).toBe('left');
      expect(typo.direction).toBe('ltr');
    });

    it('generates dir="ltr" in HTML for text with direction: ltr', () => {
      const irText: IRNode = {
        id: '1:1',
        name: 'Date Value',
        className: 'date-val',
        tag: 'p',
        type: 'TEXT',
        text: '۱۴۰۰/۰۷/۳    ،    ۱۰:۱۵',
        typography: {
          direction: 'ltr',
          textAlign: 'left',
        },
        layout: {},
        visual: {},
        children: [],
      };

      const html = generateHtml(irText);
      expect(html).toContain('dir="ltr"');
      expect(html).not.toContain('dir="rtl"');
    });
  });

  describe('negative constraint offsets and text truncation fidelity', () => {
    it('preserves negative right offset when element extends past parent right edge (e.g. priority pill on card border)', () => {
      const parentFrame = {
        id: 'top-frame',
        type: 'FRAME',
        width: 221,
        height: 20,
        layoutMode: 'HORIZONTAL',
      } as unknown as FrameNode;

      // Pill positioned at x=225 with width=8 in a 221px frame (distance to right edge = 221 - 225 - 8 = -12px)
      const pillNode = {
        id: 'priority-pill',
        type: 'INSTANCE',
        name: 'Priority',
        x: 225,
        y: -3,
        width: 8,
        height: 26,
        layoutPositioning: 'ABSOLUTE',
        constraints: { horizontal: 'MAX', vertical: 'CENTER' },
        parent: parentFrame,
      } as unknown as InstanceNode;

      const layout = extractLayout(pillNode, parentFrame, baseOptions as any);
      expect(layout.position).toBe('absolute');
      expect(layout.right).toBe('-12px');
      expect(layout.left).toBeUndefined();
    });

    it('preserves negative bottom offset when element extends past parent bottom edge', () => {
      const parentFrame = {
        id: 'card',
        type: 'FRAME',
        width: 200,
        height: 100,
        layoutMode: 'NONE',
      } as unknown as FrameNode;

      // Badge positioned at y=95 with height=20 (bottom offset = 100 - 95 - 20 = -15px)
      const badgeNode = {
        id: 'badge',
        type: 'FRAME',
        name: 'Badge',
        x: 10,
        y: 95,
        width: 50,
        height: 20,
        constraints: { horizontal: 'MIN', vertical: 'MAX' },
        parent: parentFrame,
      } as unknown as FrameNode;

      const layout = extractLayout(badgeNode, parentFrame, baseOptions as any);
      expect(layout.bottom).toBe('-15px');
      expect(layout.top).toBeUndefined();
    });

    it('enables nowrap and text-overflow: ellipsis on single-line fixed text with textAutoResize: NONE', () => {
      const textNode = {
        id: 'title',
        type: 'TEXT',
        name: 'Title',
        characters: 'داشبورد مدیریت پروژه‌های خلاق',
        width: 177,
        height: 20,
        fontSize: 14,
        lineHeight: { unit: 'PIXELS', value: 20 },
        textAlignHorizontal: 'RIGHT',
        textAutoResize: 'NONE',
      } as unknown as TextNode;

      const typo = extractTypography(textNode, baseOptions as any);
      expect(typo.whiteSpace).toBe('nowrap');
      expect(typo.textOverflow).toBe('ellipsis');
      expect(typo.overflow).toBe('hidden');
    });

    it('keeps whiteSpace: normal for multi-line text to allow natural wrapping', () => {
      const multiLineNode = {
        id: 'desc',
        type: 'TEXT',
        name: 'Description',
        characters: 'این یک متن طولانی چند خطی است که باید به راحتی به خط بعدی برود و بریده نشود.',
        width: 200,
        height: 60, // Multi-line (lineHeight ~20, height=60 -> 3 lines)
        fontSize: 14,
        lineHeight: { unit: 'PIXELS', value: 20 },
        textAlignHorizontal: 'RIGHT',
        textAutoResize: 'NONE',
      } as unknown as TextNode;

      const typo = extractTypography(multiLineNode, baseOptions as any);
      expect(typo.whiteSpace).toBe('normal');
      expect(typo.textOverflow).toBeUndefined();
    });

    it('does NOT force top: 50% or translateY(-50%) on overhanging elements even if vertical constraint is CENTER', () => {
      const parentRow = {
        id: 'top-row',
        type: 'FRAME',
        layoutMode: 'HORIZONTAL',
        width: 221,
        height: 20,
      } as unknown as FrameNode;

      // Overhanging badge extending 3px above parent (y = -3, height = 26)
      const pill = {
        id: 'pill',
        type: 'INSTANCE',
        name: 'Priority',
        x: 225,
        y: -3,
        width: 8,
        height: 26,
        layoutPositioning: 'ABSOLUTE',
        constraints: { horizontal: 'MAX', vertical: 'CENTER' },
        parent: parentRow,
      } as unknown as InstanceNode;

      const layout = extractLayout(pill, parentRow, baseOptions as any);
      expect(layout.position).toBe('absolute');
      expect(layout.top).toBe('-3px');
      expect(layout.top).not.toBe('50%');
      expect(layout.transform).toBeUndefined();
      expect(layout.right).toBe('-12px');
    });

    it('sets overflow: hidden on root instance card with clipsContent', () => {
      const rootCard = {
        id: 'tasks-card',
        type: 'INSTANCE',
        name: 'Tasks Card',
        width: 245,
        height: 174,
        clipsContent: true,
        cornerRadius: 10,
        layoutMode: 'VERTICAL',
        parent: null,
      } as unknown as InstanceNode;

      const layout = extractLayout(rootCard, null, baseOptions as any);
      expect(layout.overflow).toBe('hidden');
      expect(layout.position).toBe('relative');
      expect(layout.width).toBe('245px');
      expect(layout.height).toBe('174px');
    });

    it('suppresses impossible padding on fixed-size AutoLayout frames to prevent container blowout', () => {
      const childIcon = {
        id: 'folder-icon',
        type: 'INSTANCE',
        name: 'folder-2',
        width: 12,
        height: 12,
        visible: true,
      } as unknown as SceneNode;

      const fixedBtn = {
        id: 'btn-sayject',
        type: 'FRAME',
        name: 'btn',
        width: 20,
        height: 20,
        layoutMode: 'HORIZONTAL',
        layoutSizingHorizontal: 'FIXED',
        layoutSizingVertical: 'FIXED',
        primaryAxisAlignItems: 'CENTER',
        counterAxisAlignItems: 'CENTER',
        paddingTop: 12,
        paddingRight: 14,
        paddingBottom: 12,
        paddingLeft: 14,
        children: [childIcon],
      } as unknown as FrameNode;

      const parentRow = {
        id: 'row',
        type: 'FRAME',
        layoutMode: 'HORIZONTAL',
        width: 100,
        height: 30,
      } as unknown as FrameNode;

      const layout = extractLayout(fixedBtn, parentRow, baseOptions as any);
      expect(layout.width).toBe('20px');
      expect(layout.height).toBe('20px');
      expect(layout.justifyContent).toBe('center');
      expect(layout.alignItems).toBe('center');
      // Padding must be suppressed so CSS box-sizing: border-box does not inflate 20x20 to 40x36
      expect(layout.padding).toBeUndefined();
    });

    it('detects blur effects and prevents collapsing containers with LAYER_BLUR into noisy SVG assets', () => {
      const activeCircle = {
        id: 'active-circle',
        type: 'RECTANGLE',
        name: 'Active Circle',
        width: 30,
        height: 30,
        x: 10,
        y: 1,
        layoutPositioning: 'ABSOLUTE',
        visible: true,
        effects: [
          {
            type: 'LAYER_BLUR',
            radius: 12,
            visible: true,
          },
        ],
      } as unknown as RectangleNode;

      expect(hasBlurEffect(activeCircle)).toBe(true);

      const folderIcon = {
        id: 'folder-2',
        type: 'INSTANCE',
        name: 'folder-2',
        width: 16,
        height: 16,
        visible: true,
        children: [
          {
            id: 'vec-body',
            type: 'VECTOR',
            name: 'Vector',
            visible: true,
          },
        ],
      } as unknown as InstanceNode;

      expect(hasBlurEffect(folderIcon)).toBe(false);
      expect(shouldExportAsSingleVector(folderIcon)).toBe(true);

      const iconFrame = {
        id: 'icon-container',
        type: 'FRAME',
        name: 'Icon',
        width: 50,
        height: 32,
        visible: true,
        layoutMode: 'HORIZONTAL',
        children: [activeCircle, folderIcon],
      } as unknown as FrameNode;

      expect(hasBlurEffect(iconFrame)).toBe(true);
      // Container MUST NOT be exported as a single SVG
      expect(shouldExportAsSingleVector(iconFrame)).toBe(false);

      // Verify visual styles of Active Circle render blur via CSS filter
      const styles = extractVisualStyles(activeCircle, baseOptions as any);
      expect(styles.filter).toBe('blur(12px)');

      // Verify layout & stacking: active circle is background (zIndex 0), folder icon is on top (zIndex 1)
      const circleLayout = extractLayout(
        { ...activeCircle, layoutPositioning: 'ABSOLUTE', x: 10, y: 1 } as any,
        iconFrame,
        baseOptions as any
      );
      expect(circleLayout.position).toBe('absolute');
      expect(circleLayout.left).toBe('10px');
      expect(circleLayout.top).toBe('1px');
      expect(circleLayout.zIndex).toBe(0);

      const folderLayout = extractLayout(folderIcon, iconFrame, baseOptions as any);
      expect(folderLayout.position).toBe('relative');
      expect(folderLayout.zIndex).toBe(1);

      // Figma clips a blurred child the same as a sharp one: the clip belongs
      // to the frame, so `clipsContent: true` has to reach the CSS.
      const frameLayout = extractLayout(
        { ...iconFrame, clipsContent: true } as any,
        null,
        baseOptions as any
      );
      expect(frameLayout.overflow).toBe('hidden');

      const openFrameLayout = extractLayout(
        { ...iconFrame, clipsContent: false } as any,
        null,
        baseOptions as any
      );
      expect(openFrameLayout.overflow).toBeUndefined();
    });

    it('handles TEXTURE effect and combines compound TEXTURE and LAYER_BLUR effects', () => {
      const activeCircleWithTexture = {
        id: 'active-circle-texture',
        type: 'RECTANGLE',
        name: 'Active Circle',
        width: 30,
        height: 30,
        x: 10,
        y: 1,
        layoutPositioning: 'ABSOLUTE',
        visible: true,
        effects: [
          {
            type: 'TEXTURE',
            noiseSize: 0.1,
            noiseSizeVector: { x: 0.1, y: 0.1 },
            radius: 3,
            clipToShape: false,
            visible: true,
          },
          {
            type: 'LAYER_BLUR',
            radius: 5,
            visible: true,
          },
        ],
      } as unknown as RectangleNode;

      // 1. hasBlurEffect detects TEXTURE
      expect(hasBlurEffect(activeCircleWithTexture)).toBe(true);

      // 2. extractVisualStyles combines both blur and SVG noise filter
      const styles = extractVisualStyles(activeCircleWithTexture, baseOptions as any);
      expect(styles.filter).toBeDefined();
      expect(styles.filter).toContain('blur(5px)');
      expect(styles.filter).toContain("url('data:image/svg+xml,");
      expect(styles.filter).toContain('feTurbulence');
      expect(styles.filter).toContain('feDisplacementMap');
      expect(styles.filter).toContain('scale%3D%273%27');
      // `clipToShape: false` — the texture is allowed to tear the outline.
      expect(decodeURIComponent(styles.filter!)).not.toContain('feComposite');
      // The filter region has to out-reach the blur (3x5px) plus the texture's
      // own 3px of displacement — 18px, 60% of this 30px box — or it squares
      // off the glow it was given.
      expect(decodeURIComponent(styles.filter!)).toContain("x='-60%' y='-60%' width='220%' height='220%'");

      // 3. A texture inside a clipping frame is still clipped by that frame
      const parentFrame = {
        id: 'parent-frame',
        type: 'FRAME',
        name: 'Icon',
        width: 50,
        height: 32,
        visible: true,
        clipsContent: true,
        layoutMode: 'HORIZONTAL',
        children: [activeCircleWithTexture],
      } as unknown as FrameNode;

      const parentLayout = extractLayout(parentFrame, { id: 'root', type: 'FRAME' } as any, baseOptions as any);
      expect(parentLayout.overflow).toBe('hidden');
    });

    it('keeps a texture inside a blurred shape when Figma clips it to the shape', () => {
      const circle = {
        id: 'active-circle-clipped',
        type: 'RECTANGLE',
        name: 'Active Circle',
        width: 30,
        height: 30,
        cornerRadius: 100,
        visible: true,
        effects: [
          { type: 'LAYER_BLUR', radius: 12, visible: true },
          { type: 'TEXTURE', noiseSize: 0.1, noiseSizeVector: { x: 0.1, y: 0.1 }, radius: 3, clipToShape: true, visible: true },
        ],
      } as unknown as RectangleNode;

      const styles = extractVisualStyles(circle, baseOptions as any);
      const svg = decodeURIComponent(styles.filter!);

      // Blur first, texture second: the order the effects are listed in.
      expect(styles.filter!.indexOf('blur(')).toBeLessThan(styles.filter!.indexOf('url('));
      // The displaced result is composited back into the shape's own alpha.
      expect(svg).toContain("<feComposite in='d' in2='SourceGraphic' operator='in'/>");
      // 12px of blur reaches ~36px out, plus 3px of displacement, on a 30px box.
      expect(svg).toContain("x='-130%' y='-130%' width='360%' height='360%'");
    });

    it('sizes the texture region by the shadow it has to leave room for', () => {
      // A drop shadow is painted into the same filter chain as the texture, and
      // it is off-centre: 10px down. Padding the region by a single symmetric
      // number would either crop the shadow or waste paint above the layer.
      const card = {
        id: 'textured-card',
        type: 'RECTANGLE',
        name: 'Textured Card',
        width: 40,
        height: 20,
        cornerRadius: 6,
        visible: true,
        effects: [
          {
            type: 'DROP_SHADOW',
            color: { r: 0, g: 0, b: 0, a: 0.25 },
            offset: { x: 0, y: 10 },
            radius: 4,
            spread: 2,
            visible: true,
          },
          { type: 'TEXTURE', noiseSize: 0.1, noiseSizeVector: { x: 0.1, y: 0.1 }, radius: 3, clipToShape: true, visible: true },
        ],
      } as unknown as RectangleNode;

      const styles = extractVisualStyles(card, baseOptions as any);
      const svg = decodeURIComponent(styles.filter!);

      // Horizontal: 4px of shadow blur reaches ~12px, +2 spread, +3 texture = 17px
      // of a 40px box. Vertical: the same 14px plus the 10px offset = 24, +3 = 27px
      // of a 20px box.
      expect(svg).toContain("x='-42.5%' y='-135%' width='185%' height='370%'");
      // The shadow itself still leaves as a shadow.
      expect(styles.boxShadow).toBe('0px 10px 4px 2px rgba(0, 0, 0, 0.25)');
    });

    it('clips a glass logo to its own rounded square although its decorations blur', () => {
      // The widget bar's logo: a 28x28 rounded square whose glass is built from
      // layers that are deliberately bigger than it — a 32x33 group holding a
      // blurred purple ellipse and a 32x29 wash, plus a 52x29 grain field.
      // Figma paints all of that inside the square; the preview was spilling a
      // purple smear across the page because a blur anywhere switched the clip
      // off.
      const mainComponent = {
        id: '27023:107433',
        type: 'COMPONENT',
        name: 'Logo',
        width: 28,
        height: 28,
        clipsContent: true,
        cornerRadius: 7.29,
        children: [],
      } as unknown as ComponentNode;

      const blurredGlow = {
        id: '27023:107435',
        type: 'ELLIPSE',
        name: 'Ellipse 165',
        width: 30,
        height: 7,
        x: -1,
        y: 26,
        visible: true,
        layoutPositioning: 'ABSOLUTE',
        effects: [{ type: 'LAYER_BLUR', radius: 12, visible: true }],
      } as unknown as EllipseNode;

      const wash = {
        id: '27023:107438',
        type: 'VECTOR',
        name: 'Rectangle 28',
        width: 32,
        height: 29,
        x: 0,
        y: 4,
        visible: true,
        layoutPositioning: 'ABSOLUTE',
      } as unknown as VectorNode;

      const decorations = {
        id: '27023:107434',
        type: 'GROUP',
        name: 'Group 1',
        width: 32,
        height: 33,
        x: -2,
        y: -3,
        visible: true,
        layoutPositioning: 'ABSOLUTE',
        children: [blurredGlow, wash],
      } as unknown as GroupNode;

      const grain = {
        id: '27023:107439',
        type: 'GROUP',
        name: 'bg',
        width: 52,
        height: 29,
        x: -12,
        y: 0,
        visible: true,
        layoutPositioning: 'ABSOLUTE',
        children: [],
      } as unknown as GroupNode;

      const logo = {
        id: '27025:112413',
        type: 'INSTANCE',
        name: 'Logo',
        width: 28,
        height: 28,
        x: 11,
        y: 0,
        visible: true,
        mainComponent,
        children: [decorations, grain],
      } as unknown as InstanceNode;
      const rail = { id: 'logo-frame', type: 'FRAME', name: 'logo', width: 28, height: 28 } as unknown as FrameNode;

      expect(extractLayout(logo, rail, baseOptions as any).overflow).toBe('hidden');
      // The same instance selected as the root has to clip too.
      expect(extractLayout(logo, null, baseOptions as any).overflow).toBe('hidden');
      // Nothing inside the logo invents a clip of its own.
      expect(extractLayout(decorations, logo, baseOptions as any).overflow).toBeUndefined();
    });
  });
});





