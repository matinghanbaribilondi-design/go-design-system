import { describe, it, expect } from 'vitest';
import { extractLayout, isPackedRow } from './layout';
import type { ConversionOptions } from '../types/ir';

/**
 * Guards the numbers quoted in `demo/smart-stacking-demo.html`: the demo claims
 * a 1100px frame with a 320px rail, a FILL body and a 24px gap produces
 * `gap: clamp(16px, 2.18%, 24px)` and an `@container (max-width: 616px)`.
 * If the policy changes, this fails and the demo has to be updated with it.
 */
const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
  designWidth: 1100,
};

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: (over.width as number) ?? 100,
    height: (over.height as number) ?? 100,
    x: 0,
    y: 0,
    layoutMode: (over.layoutMode as string) ?? 'NONE',
    children: (over.children as any[]) ?? [],
    ...over,
  };
}

describe('demo/smart-stacking-demo.html figures', () => {
  const rail = mk({
    id: 'rail',
    name: 'Sidebar',
    width: 320,
    height: 400,
    layoutMode: 'VERTICAL',
    layoutSizingHorizontal: 'FIXED',
  });
  const body = mk({
    id: 'body',
    name: 'Content',
    width: 756,
    height: 400,
    layoutMode: 'VERTICAL',
    layoutSizingHorizontal: 'FILL',
  });
  const shell = mk({
    id: 'shell',
    name: 'App Shell',
    layoutMode: 'HORIZONTAL',
    width: 1100,
    height: 400,
    itemSpacing: 24,
    children: [rail, body],
  });

  it('emits the documented gap', () => {
    // A percentage of the row's own content box, not of the window: the gap has
    // to track the frame the design was drawn in.
    expect(extractLayout(shell, null, options).gap).toBe('clamp(16px, 2.18%, 24px)');
  });

  it('emits the documented container type', () => {
    expect(extractLayout(shell, null, options).containerType).toBe('inline-size');
  });

  it('emits the documented 616px stacking threshold', () => {
    expect(extractLayout(rail, shell, options).stackFill).toEqual({ maxInlineSize: '616px' });
    expect(extractLayout(body, shell, options).stackFill).toEqual({ maxInlineSize: '616px' });
  });

  it('emits the documented region sizing', () => {
    const railLayout = extractLayout(rail, shell, options);
    expect(railLayout.flexBasis).toBe('320px');
    expect(railLayout.maxWidth).toBe('320px');
    // The rail is pinned at 320px by its basis and cap; the floor under it is
    // 65% of that, so the stacking query and the emitted `min-width` agree.
    expect(railLayout.minWidth).toBe('min(208px, 100%)');

    const bodyLayout = extractLayout(body, shell, options);
    expect(bodyLayout.flexBasis).toBe('0%');
    expect(bodyLayout.minWidth).toBe('min(280px, 100%)');
  });

  it('emits the documented packed-grid sizing', () => {
    // The demo's grid: three 328px cards with 24px gaps in a 1064px row. The
    // demo claims there is no designed cap, so a card that lands on a line of
    // its own fills that line.
    const cards = [0, 1, 2].map((i) =>
      mk({ id: `card${i}`, name: `Card ${i}`, layoutMode: 'VERTICAL', width: 328, height: 72 })
    );
    const grid = mk({
      id: 'grid',
      name: 'Cards',
      layoutMode: 'HORIZONTAL',
      width: 1064,
      height: 72,
      itemSpacing: 24,
      children: cards,
    });

    expect(isPackedRow(grid)).toBe(true);
    const cardLayout = extractLayout(cards[0], grid, options);
    expect(cardLayout.flexBasis).toBe('328px');
    expect(cardLayout.maxWidth).toBe('100%');
    // 65% of 328: a floor at the drawn width would make the card rigid and the
    // row would break into stretched cards plus one orphan.
    expect(cardLayout.minWidth).toBe('min(213px, 100%)');
  });

  it('emits the documented implicit-fill toolbar sizing', () => {
    // The demo's toolbar: 660px wide with 10px side padding, a 36px icon and a
    // 592px input drawn to fill the rest. The input was left `Fixed` in Figma.
    const icon = mk({ id: 'icon', name: 'Icon', width: 36, height: 36 });
    const input = mk({ id: 'input', name: 'Search Input', layoutMode: 'HORIZONTAL', width: 592, height: 36 });
    const toolbar = mk({
      id: 'toolbar',
      name: 'Toolbar',
      layoutMode: 'HORIZONTAL',
      width: 660,
      height: 56,
      itemSpacing: 12,
      paddingLeft: 10,
      paddingRight: 10,
      children: [icon, input],
    });

    const iconLayout = extractLayout(icon, toolbar, options);
    expect(iconLayout.width).toBe('36px');
    expect(iconLayout.flexShrink).toBe(0);

    const inputLayout = extractLayout(input, toolbar, options);
    expect(inputLayout.flexGrow).toBe(1);
    expect(inputLayout.flexBasis).toBe('0%');
    expect(inputLayout.maxWidth).toBe('100%');
    expect(inputLayout.width).toBeUndefined();
  });
});
