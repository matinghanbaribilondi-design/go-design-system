import { describe, it, expect } from 'vitest';
import { extractLayout } from './layout';
import { columnFloorPx } from '../../shared/fluid';
import { FLUID_MIN_RATIO, MIN_COLUMN_WIDTH_PX } from '../../shared/constants';
import type { ConversionOptions } from '../types/ir';

/**
 * The wrap floor of a column.
 *
 * A wrapping row reflows because each column carries a `min-width` floor: the
 * browser keeps as many columns on a line as fit, and pushes the rest down. The
 * floor therefore decides *when* the row breaks.
 *
 * The bug this file exists for: the floor was `min(drawnWidth, 280)`. For any
 * column drawn narrower than 280px that evaluates to the drawn width itself, so
 * `flex-basis: 0%` + `min-width: 261px` is a column that cannot shrink at all.
 * Four such columns are rigid, so the row breaks the moment the container is a
 * single pixel narrower than the drawn row — and it breaks into three stretched
 * columns and one orphan, which is not a reflow, it is a broken row.
 *
 * The floor has to sit *below* the drawn width, by the same fraction the rest of
 * the exporter uses for "how far a design value may shrink".
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
  designWidth: 1116,
};

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: (over.width as number) ?? 100,
    height: (over.height as number) ?? 100,
    x: 0,
    y: 0,
    layoutMode: (over.layoutMode as string) ?? 'NONE',
    children: (over.children as any[]) ?? [],
    ...over,
  };
}

/** A board: `count` equal FILL columns of `columnWidth`, `gap` apart. */
function board(columnWidth: number, count = 4, gap = 24): any {
  const columns = Array.from({ length: count }, (_, i) =>
    mk({
      id: `col-${i}`,
      name: i === 2 ? 'Projects/In progress' : `Column ${i}`,
      width: columnWidth,
      height: 420,
      layoutMode: 'VERTICAL',
      layoutSizingHorizontal: 'FILL',
      children: [mk({ id: `col-${i}-card`, name: 'Card', width: columnWidth, height: 120 })],
    })
  );
  return mk({
    id: 'board',
    name: 'Projects',
    layoutMode: 'HORIZONTAL',
    width: columnWidth * count + gap * (count - 1),
    height: 420,
    itemSpacing: gap,
    children: columns,
  });
}

/** Parses the px out of a `min(261px, 100%)` floor. */
function floorPx(value: string | undefined): number | null {
  const match = value?.match(/^min\((\d+(?:\.\d+)?)px, 100%\)$/);
  return match?.[1] ? Number(match[1]) : null;
}

describe('column wrap floor', () => {
  it('lets a column narrower than the absolute minimum actually shrink', () => {
    // The reported case: a 261px column, i.e. below MIN_COLUMN_WIDTH_PX.
    const row = board(261);
    const columns = row.children.map((child: any) => extractLayout(child, row, options));

    for (const layout of columns) {
      const floor = floorPx(layout.minWidth);
      expect(floor).not.toBeNull();
      expect(floor!).toBeLessThan(261);
    }
  });

  it('keeps the floor proportional to the drawn width, not equal to it', () => {
    const row = board(261);
    const column = extractLayout(row.children[0], row, options);
    expect(floorPx(column.minWidth)).toBe(columnFloorPx(261));
    // 65% of 261, rounded — the same ratio every other fluid value uses.
    expect(columnFloorPx(261)).toBe(Math.round(261 * FLUID_MIN_RATIO));
  });

  it('never lets the floor exceed the absolute minimum comfortable column', () => {
    // A wide column still bottoms out at MIN_COLUMN_WIDTH_PX: 65% of 1200 is
    // 780, which is not a "minimum", it is just a smaller column.
    expect(columnFloorPx(1200)).toBe(MIN_COLUMN_WIDTH_PX);
    expect(columnFloorPx(600)).toBe(MIN_COLUMN_WIDTH_PX);
    expect(columnFloorPx(400)).toBe(Math.round(400 * FLUID_MIN_RATIO));
  });

  it('is monotonic, so a wider column never gets a smaller floor', () => {
    let previous = 0;
    for (let width = 60; width <= 900; width += 20) {
      const floor = columnFloorPx(width);
      expect(floor).toBeGreaterThanOrEqual(previous);
      expect(floor).toBeLessThanOrEqual(width);
      previous = floor;
    }
  });

  it('leaves a row of four 261px columns room to compress before it breaks', () => {
    const row = board(261);
    const floors = row.children.map(
      (child: any) => floorPx(extractLayout(child, row, options).minWidth) ?? 0
    );
    const gap = 24;
    const minimumRowWidth = floors.reduce((sum: number, f: number) => sum + f, 0) + gap * (floors.length - 1);

    // The row as drawn is 4 × 261 + 3 × 24 = 1116. It must be able to absorb a
    // meaningful amount of narrowing before it is forced to wrap.
    expect(minimumRowWidth).toBeLessThan(1116);
    expect(minimumRowWidth).toBeLessThanOrEqual(Math.round(1116 * FLUID_MIN_RATIO) + 3 * gap);
  });

  it('does not touch a wide body, so region rows keep their threshold', () => {
    // A body of 700px was already floored at 280; 65% of 700 is 455, which is
    // above the cap, so the cap still wins and the old numbers stand.
    expect(columnFloorPx(700)).toBe(MIN_COLUMN_WIDTH_PX);
    expect(columnFloorPx(500)).toBe(MIN_COLUMN_WIDTH_PX);
  });
});
