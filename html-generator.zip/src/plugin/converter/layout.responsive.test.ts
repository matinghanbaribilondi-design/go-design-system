import { describe, it, expect } from 'vitest';
import {
  absoluteInlineCap,
  extractLayout,
  inferFreeformFlow,
  isMultiColumnRow,
  isPackedRow,
  isRegionsRow,
  isStackingRegionRow,
  isToolbarRow,
} from './layout';
import { extractTypography } from './typography';
import type { ConversionOptions } from '../types/ir';

/**
 * These tests drive `extractLayout` directly with mock SceneNodes so the
 * intrinsic-reflow decisions (does this row wrap? does this child size
 * proportionally? does this control stay put?) are covered at the source,
 * not only through the generated CSS.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
  designWidth: 1200,
};

/** Minimal SceneNode stand-in — only the fields the layout extractor reads. */
function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: (over.width as number) ?? 100,
    height: (over.height as number) ?? 100,
    x: 0,
    y: 0,
    layoutMode: (over.layoutMode as string) ?? 'NONE',
    children: (over.children as any[]) ?? [],
    ...over,
  };
}

/** A 1200px-wide row of three 360px cards — the canonical multi-column row. */
function threeColumnRow(): any {
  const children = [0, 1, 2].map((i) =>
    mk({ id: `c${i}`, name: `Card ${i}`, width: 360, height: 240, layoutMode: 'VERTICAL' })
  );
  return mk({
    id: 'row',
    name: 'Cards Row',
    layoutMode: 'HORIZONTAL',
    width: 1200,
    height: 240,
    itemSpacing: 32,
    children,
  });
}

/**
 * A 1200px-wide dashboard shell: a 320px rail beside an 848px body. The two
 * siblings are doing different jobs, which is what makes the row read as
 * *regions* rather than as a grid of interchangeable cards.
 */
function railAndBodyRow(bodyOverrides: Record<string, unknown> = {}): any {
  const rail = mk({ id: 'rail', name: 'Sidebar', width: 320, height: 600, layoutMode: 'VERTICAL' });
  const body = mk({
    id: 'body',
    name: 'Content',
    width: 848,
    height: 600,
    layoutMode: 'VERTICAL',
    ...bodyOverrides,
  });
  return mk({
    id: 'shell',
    name: 'App Shell',
    layoutMode: 'HORIZONTAL',
    width: 1200,
    height: 600,
    itemSpacing: 32,
    children: [rail, body],
  });
}

/** A page that holds `row`, so the row is not mistaken for the export root. */
function pageAround(row: any): any {
  return mk({ id: 'page', name: 'Page', layoutMode: 'VERTICAL', width: 1200, height: 900, children: [row] });
}

describe('isMultiColumnRow', () => {
  it('detects a wide row of substantial columns', () => {
    expect(isMultiColumnRow(threeColumnRow())).toBe(true);
  });

  it('does not treat a row that already fits a phone as multi-column', () => {
    const chips = mk({
      id: 'chips',
      name: 'Chips',
      layoutMode: 'HORIZONTAL',
      width: 300,
      height: 40,
      itemSpacing: 8,
      children: [
        mk({ id: 'a', width: 60, height: 24 }),
        mk({ id: 'b', width: 60, height: 24 }),
      ],
    });
    expect(isMultiColumnRow(chips)).toBe(false);
  });

  it('never reflows a header / toolbar row', () => {
    const header = mk({
      id: 'header',
      name: 'Header',
      layoutMode: 'HORIZONTAL',
      width: 1200,
      height: 72,
      itemSpacing: 16,
      primaryAxisAlignItems: 'SPACE_BETWEEN',
      children: [
        mk({ id: 'logo', name: 'Logo', width: 120, height: 40 }),
        mk({ id: 'menu', name: 'Menu', width: 260, height: 40 }),
      ],
    });
    expect(isMultiColumnRow(header)).toBe(false);
  });
});

describe('extractLayout — intrinsic row reflow', () => {
  it('lets a multi-column row wrap and makes its gap fluid', () => {
    const layout = extractLayout(threeColumnRow(), null, options);
    expect(layout.display).toBe('flex');
    expect(layout.flexDirection).toBe('row');
    expect(layout.flexWrap).toBe('wrap');
    // 32px inside a 1200px row → clamp(21px, 2.67%, 32px). A percentage, not a
    // viewport unit: the gap tracks the row it sits in, at any container width.
    expect(layout.gap).toBe('clamp(21px, 2.67%, 32px)');
  });

  it('sizes a column proportionally with a min-width floor so it can wrap', () => {
    const row = threeColumnRow();
    const layout = extractLayout(row.children[0], row, options);
    expect(layout.flexGrow).toBe(1);
    expect(layout.flexShrink).toBe(1);
    expect(layout.flexBasis).toBe('360px');
    // These three cards were drawn to fill their row, so they are a *packed
    // grid*: no designed cap, which is what lets a card that wraps onto a line
    // of its own fill that line instead of stranding itself at 360px.
    expect(layout.maxWidth).toBe('100%');
    // 65% of the 360px it was drawn at: the floor is what lets the row compress
    // before it breaks. A floor equal to the drawn width would make the column
    // rigid, and the row would break as soon as it was a pixel narrower.
    expect(layout.minWidth).toBe('min(234px, 100%)');
  });

  it('keeps the designed cap when the row was not drawn packed', () => {
    // Three 200px cards in a 1200px row: the designer left the row mostly
    // empty on purpose, so the cards must not be stretched to fill it.
    const children = [0, 1, 2].map((i) =>
      mk({ id: `s${i}`, name: `Small ${i}`, width: 200, height: 160, layoutMode: 'VERTICAL' })
    );
    const row = mk({
      id: 'sparse',
      name: 'Sparse Row',
      layoutMode: 'HORIZONTAL',
      width: 1200,
      height: 160,
      itemSpacing: 32,
      children,
    });
    expect(isMultiColumnRow(row)).toBe(true);
    expect(isPackedRow(row)).toBe(false);
    expect(extractLayout(children[0], row, options).maxWidth).toBe('200px');
  });

  it('keeps an intrinsic control at its designed size instead of squeezing it', () => {
    const row = threeColumnRow();
    const icon = mk({ id: 'icon', name: 'Icon', width: 40, height: 24 });
    const layout = extractLayout(icon, row, options);
    expect(layout.width).toBe('40px');
    expect(layout.flexShrink).toBe(0);
    // A control is not a flexible column: no proportional basis is applied.
    expect(layout.flexBasis).toBeUndefined();
    expect(layout.minWidth).toBeUndefined();
  });

  it('makes large padding fluid and leaves small padding fixed', () => {
    const row = mk({
      id: 'section',
      name: 'Section',
      layoutMode: 'VERTICAL',
      width: 1200,
      height: 600,
      paddingTop: 80,
      paddingRight: 80,
      paddingBottom: 80,
      paddingLeft: 80,
      children: [mk({ id: 'only', width: 400, height: 100 })],
    });
    const layout = extractLayout(row, null, options);
    expect(layout.padding).toEqual({
      top: 'clamp(52px, 6.67%, 80px)',
      right: 'clamp(52px, 6.67%, 80px)',
      bottom: 'clamp(52px, 6.67%, 80px)',
      left: 'clamp(52px, 6.67%, 80px)',
    });

    const small = mk({
      id: 'card',
      name: 'Card',
      layoutMode: 'VERTICAL',
      width: 360,
      height: 240,
      paddingTop: 16,
      paddingRight: 16,
      paddingBottom: 16,
      paddingLeft: 16,
      children: [mk({ id: 'body', width: 300, height: 80 })],
    });
    const smallLayout = extractLayout(small, null, options);
    // Fixed values are normalised to a CSS length string so the generator only
    // ever has to handle one shape.
    expect(smallLayout.padding).toEqual({ top: '16px', right: '16px', bottom: '16px', left: '16px' });
  });

  it('emits fixed values when responsiveness is off', () => {
    const layout = extractLayout(threeColumnRow(), null, {
      ...options,
      responsive: false,
      intrinsicReflow: false,
    });
    expect(layout.flexWrap).toBeUndefined();
    expect(layout.gap).toBe('32px');
  });

  it('keeps the row unwrapped when intrinsic reflow is disabled', () => {
    const layout = extractLayout(threeColumnRow(), null, {
      ...options,
      intrinsicReflow: false,
    });
    expect(layout.flexWrap).toBeUndefined();
  });
});

describe('extractLayout — smart stacking of layout regions', () => {
  it('reads a rail beside a body as regions, and a row of equal cards as a grid', () => {
    expect(isRegionsRow(railAndBodyRow())).toBe(true);
    // Equal-width siblings are interchangeable items, not distinct regions.
    expect(isRegionsRow(threeColumnRow())).toBe(false);
  });

  it('turns a regions row into an inline-size query container', () => {
    expect(isStackingRegionRow(railAndBodyRow(), options)).toBe(true);
    expect(extractLayout(railAndBodyRow(), null, options).containerType).toBe('inline-size');
  });

  it('leaves a grid row alone — wrapping it two-up, one-up is already correct', () => {
    const row = threeColumnRow();
    expect(isStackingRegionRow(row, options)).toBe(false);
    // Measured inside a page: a *root* row is always a query container, because
    // the page itself is the box fluid type is resolved against.
    expect(extractLayout(row, pageAround(row), options).containerType).toBeUndefined();
  });

  it('never reflows, and so never stacks, when intrinsic reflow is off', () => {
    const off: ConversionOptions = { ...options, intrinsicReflow: false };
    const row = railAndBodyRow();
    expect(isStackingRegionRow(row, off)).toBe(false);
    expect(extractLayout(row, pageAround(row), off).containerType).toBeUndefined();
  });

  it('never reflows, and so never stacks, when responsiveness is off', () => {
    const off: ConversionOptions = { ...options, responsive: false };
    const row = railAndBodyRow();
    expect(isStackingRegionRow(row, off)).toBe(false);
    expect(extractLayout(row, pageAround(row), off).containerType).toBeUndefined();
  });

  it('gives a regions row’s body the row’s space even though Figma left it Fixed', () => {
    const row = railAndBodyRow();
    const body = extractLayout(row.children[1], row, options);
    // The body was drawn into exactly the space the rail left over. Pinning it
    // at that drawn width would make the row's wrap point its own drawn width —
    // a `max-width` query at that number matches immediately, so the regions
    // would stack at the very size they were designed at. It flexes instead.
    expect(body.flexGrow).toBe(1);
    expect(body.flexBasis).toBe('0%');
    expect(body.minWidth).toBe('min(280px, 100%)');
    // 320 (rail) + 280 (the body's floor) + a 21px gap floor = 621px, well
    // below the 1200px the row was drawn at.
    expect(body.stackFill).toEqual({ maxInlineSize: '621px' });
    // The rail is a rail: it keeps its drawn width and its cap.
    const rail = extractLayout(row.children[0], row, options);
    expect(rail.flexBasis).toBe('320px');
    expect(rail.maxWidth).toBe('320px');
    expect(rail.stackFill).toEqual({ maxInlineSize: '621px' });
  });

  it('measures the wrap point against the emitted columns, not the drawn ones', () => {
    // A filling body is emitted as `flex-basis: 0` with a 280px floor, so it
    // weighs 280 — not its drawn 848px — when the browser decides to wrap.
    // Solving `320 + 280 + gap(W) = W` with gap clamped at its 21px floor gives
    // 621px, which is where the row really breaks.
    const row = railAndBodyRow({ layoutSizingHorizontal: 'FILL' });
    const body = extractLayout(row.children[1], row, options);
    expect(body.flexBasis).toBe('0%');
    expect(body.minWidth).toBe('min(280px, 100%)');
    // Identical to the `Fixed` body above: whether Figma's flag was set or the
    // geometry was read instead, the emitted column is the same and so is the
    // width at which it wraps.
    expect(body.stackFill).toEqual({ maxInlineSize: '621px' });
  });

  it('does not stack a detail-sized child of a regions row', () => {
    const row = railAndBodyRow();
    const icon = mk({ id: 'icon', name: 'Icon', width: 40, height: 40 });
    const layout = extractLayout(icon, row, options);
    // A 40px icon is not a region: it keeps its intrinsic size on the stack.
    expect(layout.stackFill).toBeUndefined();
    expect(layout.flexShrink).toBe(0);
  });

  it('gives a filling column a floor so a reflowing row wraps instead of collapsing it', () => {
    const row = railAndBodyRow({ layoutSizingHorizontal: 'FILL' });
    const body = extractLayout(row.children[1], row, options);
    expect(body.flexGrow).toBe(1);
    expect(body.minWidth).toBe('min(280px, 100%)');
  });

  it('leaves a filling column free to collapse when the row cannot wrap', () => {
    const row = threeColumnRow();
    const filler = mk({ id: 'filler', width: 360, height: 240, layoutSizingHorizontal: 'FILL' });
    const layout = extractLayout(filler, row, { ...options, intrinsicReflow: false });
    expect(layout.minWidth).toBe('0');
  });

  it('emits the threshold in rem when rem output is on', () => {
    const rem: ConversionOptions = { ...options, useRem: true };
    const row = railAndBodyRow();
    const rail = extractLayout(row.children[0], row, rem);
    // 621px / 16 = 38.8125rem
    expect(rail.stackFill).toEqual({ maxInlineSize: '38.813rem' });
  });
});

/**
 * A three-pane app shell — sidebar, main, widget bar — is the case that broke:
 * all three were drawn on `Fixed`, so the row's columns added up to exactly its
 * own width. With the middle column pinned at its drawn width the wrap point
 * came out as the row's own width, and a `max-width` query at that number
 * matches immediately — so the three panes stacked at the very size they were
 * designed at, and never sat side by side at all.
 */
describe('extractLayout — a three-pane shell stays three-up', () => {
  function threePaneShell(): any {
    const panes = [
      mk({ id: 'sidebar', name: 'Sidebar', width: 280, height: 900, layoutMode: 'VERTICAL' }),
      mk({ id: 'main', name: 'Main', width: 848, height: 900, layoutMode: 'VERTICAL' }),
      mk({ id: 'widget', name: 'Widget Bar', width: 280, height: 900, layoutMode: 'VERTICAL' }),
    ];
    return mk({
      id: 'shell',
      name: 'App Shell',
      layoutMode: 'HORIZONTAL',
      width: 1440,
      height: 900,
      itemSpacing: 16,
      children: panes,
    });
  }

  it('reads the three panes as a regions row', () => {
    expect(isRegionsRow(threePaneShell())).toBe(true);
    expect(isStackingRegionRow(threePaneShell(), options)).toBe(true);
  });

  it('gives the middle column the row’s space and leaves both rails at their drawn width', () => {
    const shell = threePaneShell();
    const [sidebar, main, widget] = shell.children;

    const middle = extractLayout(main, shell, options);
    expect(middle.flexBasis).toBe('0%');
    expect(middle.flexGrow).toBe(1);
    expect(middle.minWidth).toBe('min(280px, 100%)');

    // A rail is a rail: neither side pane grows or shrinks past its design.
    for (const rail of [sidebar, widget]) {
      const layout = extractLayout(rail, shell, options);
      expect(layout.flexBasis).toBe('280px');
      expect(layout.maxWidth).toBe('280px');
    }
  });

  it('puts the wrap point below the width the row was drawn at', () => {
    const shell = threePaneShell();
    const middle = extractLayout(shell.children[1], shell, options);
    // 280 + 280 + 280 (the middle column's floor) + 2 x 16 = 872.
    expect(middle.stackFill).toEqual({ maxInlineSize: '872px' });
    // The row is 1440 wide. A threshold at or above that would make the
    // `@container` query match at the size the design was drawn at — the bug.
    expect(Number.parseInt(middle.stackFill!.maxInlineSize, 10)).toBeLessThan(shell.width);
  });

  it('gives the widest pane the row’s space when no pane holds half of it', () => {
    // 280 / 500 / 280: the middle pane holds 45.8% of the row, so the toolbar
    // rule — "the filling element must hold half the row" — rejects all three.
    // That is what used to leave every pane pinned to its drawn width: the
    // columns then added up to the row's own width, the wrap point came out at
    // 1092, and the panes stacked at every size below the design.
    const panes = [
      mk({ id: 'a', name: 'Rail A', width: 280, height: 600, layoutMode: 'VERTICAL' }),
      mk({ id: 'b', name: 'Body', width: 500, height: 600, layoutMode: 'VERTICAL' }),
      mk({ id: 'c', name: 'Rail B', width: 280, height: 600, layoutMode: 'VERTICAL' }),
    ];
    const row = mk({
      id: 'row',
      name: 'Row',
      layoutMode: 'HORIZONTAL',
      width: 1092,
      height: 600,
      itemSpacing: 16,
      children: panes,
    });

    expect(isRegionsRow(row)).toBe(true);

    // The widest region is the body, and it is the only one that flexes.
    const body = extractLayout(panes[1], row, options);
    expect(body.flexBasis).toBe('0%');
    expect(body.flexGrow).toBe(1);
    expect(body.minWidth).toBe('min(280px, 100%)');

    // The rails keep the width they were drawn at.
    for (const rail of [panes[0], panes[2]]) {
      expect(extractLayout(rail, row, options).flexBasis).toBe('280px');
    }

    // 280 + 280 + 280 (the body's floor) + 2 x 16 = 872 — below the row's own
    // width, so the query cannot match at the size the design was drawn at.
    expect(body.stackFill).toEqual({ maxInlineSize: '872px' });
  });

  it('keeps a three-pane shell three-up when its widest pane is under half', () => {
    // The reported bug, at the size it was reported: 700 / 500 / 240 in a 1440
    // frame. The widest pane is 48.6% of the row, so nothing flexed, the wrap
    // point came out at 1440 — the row's own width — and the `@container`
    // query matched at every width the preview could ever be, stacking the
    // three panes immediately and at every size.
    const panes = [
      mk({ id: 'main', name: 'Main', width: 700, height: 900, layoutMode: 'VERTICAL' }),
      mk({ id: 'panel', name: 'Workspace Panel', width: 500, height: 900, layoutMode: 'VERTICAL' }),
      mk({ id: 'rail', name: 'Icon Rail', width: 240, height: 900, layoutMode: 'VERTICAL' }),
    ];
    const shell = mk({
      id: 'shell',
      name: 'App Shell',
      layoutMode: 'HORIZONTAL',
      width: 1440,
      height: 900,
      itemSpacing: 0,
      children: panes,
    });

    const main = extractLayout(panes[0], shell, options);
    expect(main.flexBasis).toBe('0%');
    // 280 (the main column's floor) + 500 + 240 = 1020, so the shell only
    // stacks once it genuinely cannot hold the three panes side by side.
    expect(main.stackFill).toEqual({ maxInlineSize: '1020px' });
    expect(Number.parseInt(main.stackFill!.maxInlineSize, 10)).toBeLessThan(shell.width);
  });
});

/**
 * Implicit fill. Figma's sizing flag is a weaker signal than the drawing: an
 * input is dragged to the end of its toolbar and left on `Fixed`, a body is
 * drawn into exactly the space a rail left over. These tests pin the reading of
 * that geometry.
 */
describe('extractLayout — primary-axis implicit fill', () => {
  /** A toolbar: a 40px icon beside a 600px input drawn to fill it. */
  function searchBar(width = 660): any {
    const icon = mk({ id: 'icon', name: 'Icon', width: 40, height: 40 });
    const input = mk({ id: 'input', name: 'Search Input', width: 600, height: 48, layoutMode: 'HORIZONTAL' });
    return mk({
      id: 'bar',
      name: 'Search Bar',
      layoutMode: 'HORIZONTAL',
      width,
      height: 48,
      itemSpacing: 20,
      children: [icon, input],
    });
  }

  it('lets the one filling child of a packed row absorb it, though drawn Fixed', () => {
    const row = searchBar();
    const input = extractLayout(row.children[1], row, options);
    expect(input.flexGrow).toBe(1);
    expect(input.flexShrink).toBe(1);
    expect(input.flexBasis).toBe('0%');
    expect(input.maxWidth).toBe('100%');
    // The drawn width is gone: leaving it in would pin the input to a stale
    // length the moment the toolbar is resized.
    expect(input.width).toBeUndefined();
  });

  it('leaves the row’s details at their intrinsic size', () => {
    const row = searchBar();
    const icon = extractLayout(row.children[0], row, options);
    expect(icon.width).toBe('40px');
    expect(icon.flexBasis).toBeUndefined();
    expect(icon.flexShrink).toBe(0);
  });

  it('stretches nothing when the row was not drawn packed', () => {
    const row = searchBar(900);
    const input = extractLayout(row.children[1], row, options);
    expect(input.flexBasis).toBe('600px');
    expect(input.maxWidth).toBe('600px');
  });

  it('does not promote a small control to the row’s filling element', () => {
    // Two 100px chips in a row they exactly fill. The row is packed, but
    // neither chip is its main content, so neither is stretched.
    const row = mk({
      id: 'chips',
      name: 'Chips',
      layoutMode: 'HORIZONTAL',
      width: 216,
      height: 32,
      itemSpacing: 16,
      children: [
        mk({ id: 'a', name: 'Chip A', width: 100, height: 32 }),
        mk({ id: 'b', name: 'Chip B', width: 100, height: 32 }),
      ],
    });
    expect(isPackedRow(row)).toBe(true);
    const chip = extractLayout(row.children[0], row, options);
    expect(chip.flexBasis).toBeUndefined();
    expect(chip.width).toBe('100px');
  });

  it('leaves a column row to reflow rather than filling one of its columns', () => {
    // A rail and a body are a multi-column row: the body already fills, and the
    // rail must not be turned into a filler.
    const row = railAndBodyRow();
    const rail = extractLayout(row.children[0], row, options);
    expect(rail.flexBasis).toBe('320px');
    expect(rail.maxWidth).toBe('320px');
  });

  it('is off entirely when responsiveness is off', () => {
    const off: ConversionOptions = { ...options, responsive: false };
    const row = searchBar();
    const input = extractLayout(row.children[1], row, off);
    expect(input.flexBasis).toBeUndefined();
    expect(input.width).toBe('600px');
  });
});

describe('extractLayout — counter-axis implicit fill', () => {
  /** A 360px card with 16px side padding, so 328px of inner width. */
  function card(children: any[] = []): any {
    return mk({
      id: 'card',
      name: 'Card',
      layoutMode: 'VERTICAL',
      width: 360,
      height: 240,
      paddingLeft: 16,
      paddingRight: 16,
      children,
    });
  }

  it('stretches a child drawn to the parent’s inner width', () => {
    const body = mk({ id: 'body', name: 'Body', width: 324, height: 80, layoutMode: 'VERTICAL' });
    const layout = extractLayout(body, card(), options);
    expect(layout.alignSelf).toBe('stretch');
    expect(layout.width).toBe('100%');
  });

  it('stretches a text box drawn to the parent’s inner width', () => {
    // Previously excluded: a fixed-width text box that matches its card had its
    // copy stop at a stale pixel width while the card grew past it.
    const copy = mk({ id: 'copy', name: 'Copy', type: 'TEXT', width: 320, height: 40 });
    const layout = extractLayout(copy, card(), options);
    expect(layout.alignSelf).toBe('stretch');
    expect(layout.width).toBe('100%');
  });

  it('leaves an inset child alone', () => {
    const inset = mk({ id: 'inset', name: 'Inset', width: 200, height: 80 });
    const layout = extractLayout(inset, card(), options);
    expect(layout.alignSelf).toBeUndefined();
    expect(layout.width).toBe('200px');
  });

  it('never stretches a circle, however close it comes to the width', () => {
    const avatar = mk({ id: 'avatar', name: 'Avatar', type: 'ELLIPSE', width: 320, height: 320 });
    const layout = extractLayout(avatar, card(), options);
    expect(layout.alignSelf).toBeUndefined();
    expect(layout.aspectRatio).toBe('1 / 1');
  });
});

describe('extractLayout — freeform full-width bands', () => {
  function page(): any {
    return mk({ id: 'page', name: 'Page', layoutMode: 'NONE', width: 1200, height: 800 });
  }

  it('pins a centred, near-full-width band to both edges', () => {
    const band = mk({
      id: 'band',
      name: 'Hero',
      type: 'FRAME',
      layoutMode: 'VERTICAL',
      width: 1168,
      height: 400,
      x: 16,
      y: 0,
    });
    const layout = extractLayout(band, page(), options);
    expect(layout.position).toBe('absolute');
    expect(layout.left).toBe('16px');
    expect(layout.right).toBe('16px');
    // A band pinned to both edges has no width of its own.
    expect(layout.width).toBeUndefined();
  });

  it('leaves a centred card at its drawn width', () => {
    const small = mk({ id: 'card2', name: 'Card', type: 'FRAME', width: 600, height: 300, x: 300, y: 100 });
    const layout = extractLayout(small, page(), options);
    expect(layout.width).toBe('600px');
    expect(layout.right).toBeUndefined();
  });

  it('leaves an off-centre strip alone', () => {
    const strip = mk({ id: 'strip', name: 'Strip', type: 'FRAME', width: 1000, height: 100, x: 0, y: 0 });
    const layout = extractLayout(strip, page(), options);
    expect(layout.width).toBe('1000px');
    expect(layout.right).toBeUndefined();
  });
});

/**
 * A layer that is out of flow was placed by hand, and Figma's constraint for it
 * is very often left at the default even when the drawing plainly says
 * otherwise. These tests pin the reading of the geometry: a flush edge, a
 * centre that lands on the parent's centre, or an explicit constraint.
 */
describe('extractLayout — absolute anchor inference', () => {
  function page(over: Record<string, unknown> = {}): any {
    return mk({ id: 'page', name: 'Page', layoutMode: 'NONE', width: 1200, height: 800, ...over });
  }

  it('reads a layer hugging the right edge as anchored to the right', () => {
    const badge = mk({ id: 'badge', name: 'Badge', width: 120, height: 32, x: 1064, y: 16 });
    const layout = extractLayout(badge, page(), options);

    expect(layout.position).toBe('absolute');
    expect(layout.right).toBe('16px');
    expect(layout.left).toBeUndefined();
    // A right-anchored layer keeps its own width.
    expect(layout.width).toBe('120px');
    expect(layout.top).toBe('16px');
  });

  it('reads a layer drawn in the middle as centred on both axes', () => {
    const dialog = mk({ id: 'dialog', name: 'Dialog', width: 480, height: 320, x: 360, y: 240 });
    const layout = extractLayout(dialog, page(), options);

    expect(layout.left).toBe('50%');
    expect(layout.top).toBe('50%');
    expect(layout.transform).toBe('translate(-50%, -50%)');
    expect(layout.width).toBe('480px');
    expect(layout.height).toBe('320px');
  });

  it('pins a vertical band to both horizontal edges, leaving it no height of its own', () => {
    const band = mk({ id: 'band', name: 'Band', width: 1168, height: 760, x: 16, y: 20 });
    const layout = extractLayout(band, page(), options);

    expect(layout.left).toBe('16px');
    expect(layout.right).toBe('16px');
    expect(layout.top).toBe('20px');
    expect(layout.bottom).toBe('20px');
    expect(layout.width).toBeUndefined();
    expect(layout.height).toBeUndefined();
  });

  it('honours an explicit STRETCH constraint even on a layer that is not drawn as a band', () => {
    const strip = mk({
      id: 'strip',
      name: 'Strip',
      width: 600,
      height: 100,
      x: 0,
      y: 0,
      constraints: { horizontal: 'STRETCH', vertical: 'MIN' },
    });
    const layout = extractLayout(strip, page(), options);

    expect(layout.left).toBe('0px');
    expect(layout.right).toBe('600px');
    expect(layout.width).toBeUndefined();
  });

  it('honours an explicit MAX constraint over the geometry', () => {
    const pin = mk({
      id: 'pin',
      name: 'Pin',
      width: 120,
      height: 32,
      x: 20,
      y: 16,
      constraints: { horizontal: 'MAX', vertical: 'MIN' },
    });
    const layout = extractLayout(pin, page(), options);

    expect(layout.right).toBe('1060px');
    expect(layout.left).toBeUndefined();
  });

  it('lets a centred hero stay centred underneath a full-width header band', () => {
    const header = mk({ id: 'header', name: 'Header', width: 1200, height: 72, x: 0, y: 0 });
    const hero = mk({ id: 'hero', name: 'Hero', width: 800, height: 400, x: 200, y: 200 });
    const layout = extractLayout(hero, page({ children: [header, hero] }), options);

    expect(layout.left).toBe('50%');
    expect(layout.top).toBe('50%');
    expect(layout.transform).toBe('translate(-50%, -50%)');
  });

  it('does NOT treat the middle card of a column as centred', () => {
    // Three full-width cards, evenly stacked: the middle one lands exactly on
    // the frame's centre by arithmetic alone. It is a stack, not a centred
    // layer, so it must keep the offset it was drawn at.
    const cards = [20, 320, 620].map((y, i) =>
      mk({ id: `card${i}`, name: `Card ${i}`, width: 1160, height: 260, x: 20, y })
    );
    const layout = extractLayout(cards[1], page({ height: 900, children: cards }), options);

    expect(layout.top).toBe('320px');
    expect(layout.transform).toBeUndefined();
    // It still reads as a band across the frame.
    expect(layout.left).toBe('20px');
    expect(layout.right).toBe('20px');
  });

  it('leaves text placement to the text path rather than the anchor reader', () => {
    const label = mk({
      id: 'label',
      name: 'Label',
      type: 'TEXT',
      width: 200,
      height: 24,
      x: 1000,
      y: 16,
      characters: 'Label',
      textAutoResize: 'WIDTH_AND_HEIGHT',
    });
    const layout = extractLayout(label, page(), options);

    // Not pinned to both edges by the anchor reader, and not centred either.
    expect(layout.right).toBeUndefined();
    expect(layout.left).toBe('1000px');
  });
});

describe('extractLayout — fake alignment padding normalization', () => {
  it('normalizes fake padding-left on a fixed box to flex-end alignment', () => {
    // A 144px wide vertical container with a 44px child and 100px padding-left (144 - 44 = 100)
    const titleContainer = mk({
      id: 'title-box',
      name: 'Assistant Title',
      layoutMode: 'VERTICAL',
      width: 144,
      height: 28,
      paddingLeft: 100,
      paddingRight: 0,
      paddingTop: 0,
      paddingBottom: 0,
      children: [
        mk({
          id: 'text-1',
          name: 'Vira',
          type: 'TEXT',
          width: 44,
          height: 28,
          characters: 'Vira',
        }),
      ],
    });

    const layout = extractLayout(titleContainer, null, options);
    expect(layout.alignItems).toBe('flex-end');
    // padding-left must be normalized to 0 so the box does not inflate
    expect(layout.padding?.left).toBeUndefined();
  });

  it('normalizes fake padding-left on a horizontal container to justifyContent: flex-end', () => {
    // 1080px hero container with 425px content and 655px left padding
    const hero = mk({
      id: 'hero',
      name: 'Hero Section',
      layoutMode: 'HORIZONTAL',
      width: 1080,
      height: 75,
      paddingLeft: 655,
      paddingRight: 0,
      children: [
        mk({
          id: 'title',
          name: 'Title',
          width: 425,
          height: 75,
        }),
      ],
    });

    const layout = extractLayout(hero, null, options);
    expect(layout.justifyContent).toBe('flex-end');
    expect(layout.padding?.left).toBeUndefined();
  });
});


/**
 * A bar — a header, a toolbar, a status line — is not a set of columns.
 *
 * The reported bug: a header with a logo, a search field and a pair of icon
 * buttons was read as a *regions* row (the widths differ by more than the
 * region ratio), so it became a query container and stacked its three parts
 * into three full-width rows as soon as the preview was narrower than 1063px.
 * The old guard only recognised a header whose every child was narrower than a
 * column, so a header with a real search field slipped through it.
 */
describe('extractLayout — bars keep one line', () => {
  function header(): any {
    const logo = mk({ id: 'logo', name: 'Logo', width: 120, height: 40 });
    const input = mk({ id: 'input', name: 'Input', width: 640, height: 36 });
    const search = mk({
      id: 'search',
      name: 'Search',
      width: 700,
      height: 40,
      layoutMode: 'HORIZONTAL',
      children: [input],
    });
    const actions = mk({
      id: 'actions',
      name: 'Actions',
      width: 200,
      height: 40,
      layoutMode: 'HORIZONTAL',
      itemSpacing: 8,
      children: [
        mk({ id: 'a1', name: 'Icon', width: 32, height: 32 }),
        mk({ id: 'a2', name: 'Icon', width: 32, height: 32 }),
      ],
    });
    return mk({
      id: 'header',
      name: 'Header',
      layoutMode: 'HORIZONTAL',
      width: 1200,
      height: 72,
      itemSpacing: 24,
      primaryAxisAlignItems: 'SPACE_BETWEEN',
      counterAxisAlignItems: 'CENTER',
      children: [logo, search, actions],
    });
  }

  it('reads a header as a bar, not as a row of columns', () => {
    expect(isToolbarRow(header())).toBe(true);
    expect(isMultiColumnRow(header())).toBe(false);
    expect(isRegionsRow(header())).toBe(true); // the widths do differ…
    expect(isStackingRegionRow(header(), options)).toBe(false); // …but it is a bar
  });

  it('may wrap its slot but never becomes a stacking container', () => {
    const h = header();
    const layout = extractLayout(h, pageAround(h), options);
    expect(layout.flexWrap).toBe('wrap');
    expect(layout.containerType).toBeUndefined();
  });

  it('makes the search field a slot that compresses instead of breaking the line', () => {
    const h = header();
    const search = extractLayout(h.children[1], h, options);

    // The field starts at nothing and grows into the row's slack. Its basis is
    // the thing a flex line breaks on, so starting at the drawn 700px would
    // break a 768px header into three lines before any shrinking was
    // considered. Starting at zero makes the floor the only reason to break.
    expect(search.flexBasis).toBe('0%');
    expect(search.flexGrow).toBe(1);

    // …and it stops at the width it was drawn at, which is what leaves the
    // slack for `space-between` to spend on the alignment. Growing past it
    // would push the trailing actions off the edge they were drawn on.
    expect(search.maxWidth).toBe('700px');

    // It may not be squeezed to something unusable before the bar breaks.
    expect(search.minWidth).toBe('min(180px, 100%)');
  });

  it('floors a cluster of icons at its own content, so icons cannot overlap', () => {
    const h = header();
    const actions = extractLayout(h.children[2], h, options);
    expect(actions.minWidth).toBe('min-content');
    expect(actions.flexShrink).toBe(1);
  });

  it('lets a packed bar’s field fill the row instead of holding its width', () => {
    const icon = mk({ id: 'icon', name: 'Icon', width: 40, height: 40 });
    const input = mk({ id: 'input', name: 'Search Input', width: 600, height: 48, layoutMode: 'HORIZONTAL' });
    const bar = mk({
      id: 'bar',
      name: 'Search Bar',
      layoutMode: 'HORIZONTAL',
      width: 660,
      height: 48,
      itemSpacing: 20,
      children: [icon, input],
    });

    expect(isToolbarRow(bar)).toBe(true);
    const layout = extractLayout(input, bar, options);
    expect(layout.flexGrow).toBe(1);
    expect(layout.flexBasis).toBe('0%');
    // Nothing to spend the slack on in a packed bar — no `space-between` — so
    // the slot drops its drawn cap and fills the line.
    expect(layout.maxWidth).toBe('100%');
    // Still a bar, so the field keeps a usable floor rather than collapsing.
    expect(layout.minWidth).toBe('min(180px, 100%)');
  });
});

describe('extractLayout — the wrap point includes the row’s padding', () => {
  it('measures the threshold on the border box the container query reports', () => {
    const row = railAndBodyRow();
    row.paddingLeft = 40;
    row.paddingRight = 40;

    const body = extractLayout(row.children[1], row, options);
    // 320 (rail) + 280 (the body's floor) + 21 (the gap at its floor) = 621 of
    // *inner* width, plus the 80px of padding the columns cannot use.
    expect(body.stackFill).toEqual({ maxInlineSize: '701px' });
  });

  it('derives the gap’s percentage from the row’s inner width, not the page', () => {
    const row = railAndBodyRow();
    row.paddingLeft = 40;
    row.paddingRight = 40;
    const layout = extractLayout(row, pageAround(row), options);
    // 32px of a 1120px inner width, not of the 1200px frame.
    expect(layout.gap).toBe('clamp(21px, 2.86%, 32px)');
  });
});

/**
 * An out-of-flow box is sized by `width` and placed by `left`. Capping it at
 * `100%` — which is what every other element gets — caps the width, not the
 * space the offset leaves, so `left: 100px; width: 600px` still reaches 700px
 * inside a 400px frame.
 */
describe('absoluteInlineCap', () => {
  it('is the frame minus a left offset', () => {
    expect(absoluteInlineCap({ width: '600px', left: '100px' })).toBe('calc(100% - 100px)');
  });

  it('is the frame minus a right offset', () => {
    expect(absoluteInlineCap({ width: '120px', right: '16px' })).toBe('calc(100% - 16px)');
  });

  it('is the frame minus both offsets when a box is inset on both sides', () => {
    expect(absoluteInlineCap({ width: '600px', left: '16px', right: '24px' })).toBe(
      'calc(100% - 16px - 24px)'
    );
  });

  it('is the whole frame for a centred box, whose centre is what is pinned', () => {
    expect(absoluteInlineCap({ width: '480px', left: '50%' })).toBe('100%');
    expect(absoluteInlineCap({ width: '164px', left: 'calc(50% + 86px)' })).toBe('100%');
  });

  it('is nothing for a box pinned to both edges: it has no width to cap', () => {
    expect(absoluteInlineCap({ left: '16px', right: '16px' })).toBeNull();
  });
});

describe('extractLayout — an out-of-flow box stays inside its frame', () => {
  function page(): any {
    return mk({ id: 'page', name: 'Page', layoutMode: 'NONE', width: 1200, height: 800 });
  }

  it('caps a left-anchored card by the space its offset leaves', () => {
    const card = mk({ id: 'card', name: 'Card', width: 600, height: 200, x: 100, y: 40 });
    const layout = extractLayout(card, page(), options);
    expect(layout.left).toBe('100px');
    expect(layout.maxWidth).toBe('calc(100% - 100px)');
  });

  it('caps a centred dialog at the frame width', () => {
    const dialog = mk({ id: 'dialog', name: 'Dialog', width: 480, height: 320, x: 360, y: 240 });
    expect(extractLayout(dialog, page(), options).maxWidth).toBe('100%');
  });

  it('leaves a band pinned to both edges alone', () => {
    const band = mk({ id: 'band', name: 'Hero', width: 1168, height: 400, x: 16, y: 0 });
    expect(extractLayout(band, page(), options).maxWidth).toBeUndefined();
  });

  it('anchors a quadrant-positioned floating action button to right and bottom', () => {
    const fab = mk({ id: 'fab', name: 'FAB', width: 56, height: 56, x: 1120, y: 720 });
    const layout = extractLayout(fab, page(), options);
    expect(layout.right).toBe('24px');
    expect(layout.bottom).toBe('24px');
    expect(layout.left).toBeUndefined();
    expect(layout.top).toBeUndefined();
    expect(layout.maxWidth).toBe('calc(100% - 24px)');
  });

  it('anchors an explicit-absolute child inside an AutoLayout frame when placed near the trailing edge', () => {
    const parent = mk({
      id: 'hero',
      name: 'Hero',
      layoutMode: 'VERTICAL',
      width: 1200,
      height: 500,
    });
    const closeBtn = mk({
      id: 'close',
      name: 'Close',
      width: 32,
      height: 32,
      x: 1144,
      y: 24,
      layoutPositioning: 'ABSOLUTE',
    });
    parent.children = [closeBtn];
    const layout = extractLayout(closeBtn, parent, options);
    expect(layout.position).toBe('absolute');
    expect(layout.right).toBe('24px');
    expect(layout.left).toBeUndefined();
    expect(layout.top).toBe('24px');
  });

  it('promotes a full-bleed explicit-absolute child inside an AutoLayout frame to 100% × 100%', () => {
    const parent = mk({
      id: 'card',
      name: 'Card',
      layoutMode: 'VERTICAL',
      width: 400,
      height: 300,
    });
    const overlay = mk({
      id: 'overlay',
      name: 'Overlay',
      width: 400,
      height: 300,
      x: 0,
      y: 0,
      layoutPositioning: 'ABSOLUTE',
    });
    parent.children = [overlay];
    const layout = extractLayout(overlay, parent, options);
    expect(layout.width).toBe('100%');
    expect(layout.height).toBe('100%');
    expect(layout.left).toBe('0px');
    expect(layout.top).toBe('0px');
  });
});

describe('inferFreeformFlow — promotes clean freeform rows to responsive flex flows', () => {
  function freeformThreeCardSection(): any {
    const c0 = mk({ id: 'c0', name: 'Card 0', width: 352, height: 240, x: 48, y: 40 });
    const c1 = mk({ id: 'c1', name: 'Card 1', width: 352, height: 240, x: 424, y: 40 });
    const c2 = mk({ id: 'c2', name: 'Card 2', width: 352, height: 240, x: 800, y: 40 });
    return mk({
      id: 'sec',
      name: 'Features Section',
      layoutMode: 'NONE',
      width: 1200,
      height: 320,
      children: [c0, c1, c2],
    });
  }

  it('infers a horizontal flow with exact padding and gap from non-overlapping side-by-side cards', () => {
    const sec = freeformThreeCardSection();
    const flow = inferFreeformFlow(sec, options);
    expect(flow).toEqual({
      direction: 'HORIZONTAL',
      paddingTop: 40,
      paddingRight: 48,
      paddingBottom: 40,
      paddingLeft: 48,
      itemSpacing: 24,
      counterAxisAlignItems: 'MIN',
    });
  });

  it('emits a responsive wrapping flex row for the promoted freeform section and proportional columns for its children', () => {
    const sec = freeformThreeCardSection();
    const secLayout = extractLayout(sec, pageAround(sec), options);
    expect(secLayout.display).toBe('flex');
    expect(secLayout.flexDirection).toBe('row');
    expect(secLayout.flexWrap).toBe('wrap');
    expect(secLayout.gap).toBe('clamp(16px, 2.17%, 24px)');

    const childLayout = extractLayout(sec.children[0], sec, options);
    expect(childLayout.position).not.toBe('absolute');
    expect(childLayout.flexBasis).toBe('352px');
    expect(childLayout.flexGrow).toBe(1);
    expect(childLayout.minWidth).toBe('min(229px, 100%)');
    expect(childLayout.maxWidth).toBe('100%');
  });

  it('never promotes a freeform frame whose children overlap (e.g. modal over scrim)', () => {
    const scrim = mk({ id: 'scrim', name: 'Scrim', width: 1200, height: 800, x: 0, y: 0 });
    const dialog = mk({ id: 'dlg', name: 'Dialog', width: 480, height: 320, x: 360, y: 240 });
    const modal = mk({ id: 'modal', name: 'Modal', layoutMode: 'NONE', width: 1200, height: 800, children: [scrim, dialog] });
    expect(inferFreeformFlow(modal, options)).toBeNull();
  });

  it('never promotes when responsiveness or intrinsic reflow is disabled', () => {
    const sec = freeformThreeCardSection();
    expect(inferFreeformFlow(sec, { ...options, responsive: false })).toBeNull();
    expect(inferFreeformFlow(sec, { ...options, intrinsicReflow: false })).toBeNull();
  });
});

describe('extractLayout — HUG and short-text elements never overflow narrow viewports', () => {
  it('allows a HUG container in a vertical parent to shrink on narrow viewports', () => {
    const parent = mk({ id: 'col', name: 'Column', layoutMode: 'VERTICAL', width: 600, height: 400 });
    const pill = mk({
      id: 'pill',
      name: 'Wide Pill',
      layoutMode: 'HORIZONTAL',
      layoutSizingHorizontal: 'HUG',
      width: 420,
      height: 44,
    });
    parent.children = [pill];
    const layout = extractLayout(pill, parent, options);
    expect(layout.width).toBe('420px');
    expect(layout.maxWidth).toBe('100%');
    expect(layout.minWidth).toBe('0');
  });

  it('allows a short text node in a horizontal row to shrink below its drawn width on narrow viewports', () => {
    const row = mk({ id: 'row', name: 'Row', layoutMode: 'HORIZONTAL', width: 400, height: 40 });
    const label = mk({
      id: 'lbl',
      name: 'Label',
      type: 'TEXT',
      characters: 'Short title here',
      textAutoResize: 'WIDTH_AND_HEIGHT',
      width: 180,
      height: 24,
    });
    row.children = [label];
    const layout = extractLayout(label, row, options);
    expect(layout.width).toBe('180px');
    expect(layout.maxWidth).toBe('100%');
    expect(layout.minWidth).toBe('0');
  });
});

describe('extractTypography — fluid styled text segments', () => {
  it('scales display-sized mixed text segments with fluid clamp() and unitless line-height', () => {
    const textNode: any = {
      id: 'hero-title',
      name: 'Hero Title',
      type: 'TEXT',
      width: 800,
      height: 60,
      characters: 'Build faster today',
      fontSize: 48,
      fontName: { family: 'Inter', style: 'Bold' },
      lineHeight: { unit: 'PIXELS', value: 56 },
      letterSpacing: { unit: 'PIXELS', value: -1.2 },
      textAlignHorizontal: 'LEFT',
      textAutoResize: 'HEIGHT',
      fills: [{ type: 'SOLID', visible: true, opacity: 1, color: { r: 0, g: 0, b: 0 } }],
      getStyledTextSegments: () => [
        {
          characters: 'Build ',
          start: 0,
          end: 6,
          fontSize: 48,
          fontName: { family: 'Inter', style: 'Bold' },
          fontWeight: 700,
          fills: [{ type: 'SOLID', visible: true, opacity: 1, color: { r: 0, g: 0, b: 0 } }],
          lineHeight: { unit: 'PIXELS', value: 56 },
          letterSpacing: { unit: 'PIXELS', value: -1.2 },
          textDecoration: 'NONE',
          textCase: 'ORIGINAL',
          hyperlink: null,
        },
        {
          characters: 'faster today',
          start: 6,
          end: 18,
          fontSize: 20,
          fontName: { family: 'Inter', style: 'Regular' },
          fontWeight: 400,
          fills: [{ type: 'SOLID', visible: true, opacity: 1, color: { r: 0.2, g: 0.4, b: 0.8 } }],
          lineHeight: { unit: 'PIXELS', value: 28 },
          letterSpacing: { unit: 'PIXELS', value: 0 },
          textDecoration: 'NONE',
          textCase: 'ORIGINAL',
          hyperlink: null,
        },
      ],
    };

    const typo = extractTypography(textNode, options, undefined, 1200);
    expect(typo.segments).toHaveLength(2);
    // 48px display segment scales fluidly with the 1200px container (48/1200 = 4cqi)
    expect(typo.segments![0]!.fontSize).toBe('clamp(31px, 4cqi, 48px)');
    expect(typo.segments![0]!.lineHeight).toBe('1.167');
    expect(typo.segments![0]!.letterSpacing).toBe('-0.025em');
    // 20px segment (< 28px threshold) stays fixed
    expect(typo.segments![1]!.fontSize).toBe('20px');
    expect(typo.segments![1]!.lineHeight).toBe('28px');
  });
});

