import { describe, it, expect } from 'vitest';
import { isMaskNode, maskClipsFor } from './masks';
import { convertNodeToIR } from './index';
import type { ConversionOptions } from '../types/ir';

/**
 * Masks.
 *
 * In Figma a layer marked "Use as mask" is not painted: its shape clips the
 * siblings drawn after it. The converter used to emit `clip-path: inset(0 round
 * 0px)` on the mask node — a clip on a box that already ends at its own bounds,
 * i.e. nothing — and then rendered the mask node like any other layer. A photo
 * under a rounded-rect mask therefore arrived as a solid rounded rectangle
 * sitting on top of the photo.
 *
 * These tests pin the three things that have to hold:
 *
 * 1. The mask node is gone from the output (it was never painted).
 * 2. The masked siblings carry the mask's shape, expressed in their own box.
 * 3. The mask only reaches the siblings drawn after it, and stops at the next
 *    mask.
 */

const format = (px: number) => `${px}px`;

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Layer',
    type: 'RECTANGLE',
    visible: true,
    width: 100,
    height: 100,
    x: 0,
    y: 0,
    ...over,
  };
}

const mask = (over: Record<string, unknown> = {}) => mk({ id: 'mask', isMask: true, ...over });

const solid = (alpha = 1, rgb = { r: 1, g: 1, b: 1 }) => ({
  type: 'SOLID',
  visible: true,
  opacity: 1,
  color: { ...rgb, a: alpha },
});

describe('mask geometry', () => {
  it('does not clip a sibling the mask already contains', () => {
    const clips = maskClipsFor([mask({ width: 100, height: 100 }), mk({ id: 'photo' })], format);
    expect(clips.size).toBe(0);
  });

  it('clips a sibling down to a smaller mask, per side', () => {
    const clips = maskClipsFor(
      [mask({ width: 100, height: 100, x: 10, y: 20 }), mk({ id: 'photo', width: 200, height: 300 })],
      format
    );
    expect(clips.get('photo')?.clipPath).toBe('inset(20px 90px 180px 10px)');
  });

  it('keeps the corner radius of a rounded rectangle mask', () => {
    const clips = maskClipsFor([mask({ cornerRadius: 12 }), mk({ id: 'photo' })], format);
    expect(clips.get('photo')?.clipPath).toBe('inset(0 0 0 0 round 12px)');
  });

  it('carries independent corner radii in top-left, top-right, bottom-right, bottom-left order', () => {
    const clips = maskClipsFor(
      [
        mask({
          cornerRadius: Symbol('figma.mixed'),
          topLeftRadius: 4,
          topRightRadius: 8,
          bottomRightRadius: 12,
          bottomLeftRadius: 16,
        }),
        mk({ id: 'photo' }),
      ],
      format
    );
    expect(clips.get('photo')?.clipPath).toBe('inset(0 0 0 0 round 4px 8px 12px 16px)');
  });

  it('drops the radii of the corners the mask pushed outside the sibling', () => {
    // The mask reaches 20px past the sibling's right edge, so its top-right and
    // bottom-right corners are not corners of the clip at all.
    const clips = maskClipsFor(
      [
        mask({ width: 120, height: 100, x: 0, y: 10, cornerRadius: 20 }),
        mk({ id: 'photo', width: 100, height: 200 }),
      ],
      format
    );
    expect(clips.get('photo')?.clipPath).toBe('inset(10px 0 90px 0 round 20px 0 0 20px)');
  });

  it('reproduces an ellipse mask with its radii and centre', () => {
    const clips = maskClipsFor(
      [
        mask({ type: 'ELLIPSE', width: 80, height: 40, x: 10, y: 20 }),
        mk({ id: 'photo', width: 200, height: 200 }),
      ],
      format
    );
    expect(clips.get('photo')?.clipPath).toBe('ellipse(40px 20px at 50px 40px)');
  });

  it('falls back to the bounding box for a shape it cannot express', () => {
    const clips = maskClipsFor(
      [mask({ type: 'VECTOR', width: 40, height: 40, x: 10, y: 10 }), mk({ id: 'photo' })],
      format
    );
    expect(clips.get('photo')?.clipPath).toBe('inset(10px 50px 50px 10px)');
  });

  it('ignores a degenerate mask', () => {
    const clips = maskClipsFor([mask({ width: 0 }), mk({ id: 'photo' })], format);
    expect(clips.size).toBe(0);
  });

  it('reads absolute coordinates when both nodes expose them', () => {
    const clips = maskClipsFor(
      [
        mask({
          // `x`/`y` are deliberately wrong: the absolute origin must win.
          x: 999,
          y: 999,
          absoluteTransform: [
            [1, 0, 50],
            [0, 1, 60],
          ],
        }),
        mk({
          id: 'photo',
          width: 200,
          height: 200,
          absoluteTransform: [
            [1, 0, 0],
            [0, 1, 0],
          ],
        }),
      ],
      format
    );
    expect(clips.get('photo')?.clipPath).toBe('inset(60px 50px 40px 50px)');
  });
});

describe('mask reach', () => {
  it('only reaches the siblings drawn after it', () => {
    const clips = maskClipsFor(
      [mk({ id: 'before' }), mask({ width: 50, height: 50 }), mk({ id: 'after' })],
      format
    );
    expect(clips.has('before')).toBe(false);
    expect(clips.get('after')?.clipPath).toBe('inset(0 50px 50px 0)');
    expect(clips.has('mask')).toBe(false);
  });

  it('stops at the next mask', () => {
    const clips = maskClipsFor(
      [
        mask({ id: 'mask-1', width: 50, height: 50 }),
        mk({ id: 'a' }),
        mask({ id: 'mask-2', width: 90, height: 90 }),
        mk({ id: 'b' }),
      ],
      format
    );
    expect(clips.get('a')?.clipPath).toBe('inset(0 50px 50px 0)');
    expect(clips.get('b')?.clipPath).toBe('inset(0 10px 10px 0)');
  });

  it('leaves everything alone when no layer is a mask', () => {
    const clips = maskClipsFor([mk({ id: 'a' }), mk({ id: 'b' })], format);
    expect(clips.size).toBe(0);
  });
});

describe('mask alpha', () => {
  it('carries a translucent fill as an opacity multiplier', () => {
    const clips = maskClipsFor([mask({ fills: [solid(0.5)] }), mk({ id: 'photo' })], format);
    // The shape covers the sibling, so only the alpha survives.
    expect(clips.get('photo')).toEqual({ alpha: 0.5 });
  });

  it('multiplies the mask node opacity into the fill alpha', () => {
    const clips = maskClipsFor(
      [mask({ opacity: 0.5, fills: [solid(0.5)] }), mk({ id: 'photo' })],
      format
    );
    expect(clips.get('photo')?.alpha).toBe(0.25);
  });

  it('ignores the paint for a vector mask', () => {
    const clips = maskClipsFor(
      [mask({ maskType: 'VECTOR', fills: [solid(0.5)] }), mk({ id: 'photo' })],
      format
    );
    expect(clips.size).toBe(0);
  });

  it('reads brightness for a luminance mask', () => {
    const white = maskClipsFor(
      [mask({ maskType: 'LUMINANCE', fills: [solid(1, { r: 1, g: 1, b: 1 })] }), mk({ id: 'photo' })],
      format
    );
    expect(white.size).toBe(0);

    const black = maskClipsFor(
      [mask({ maskType: 'LUMINANCE', fills: [solid(1, { r: 0, g: 0, b: 0 })] }), mk({ id: 'photo' })],
      format
    );
    expect(black.get('photo')?.alpha).toBe(0);
  });

  it('leaves a gradient-filled mask fully opaque', () => {
    // A gradient's alpha varies across the shape; one opacity cannot express
    // it, so the mask is kept opaque rather than guessed at.
    const clips = maskClipsFor(
      [
        mask({
          fills: [
            {
              type: 'GRADIENT_LINEAR',
              visible: true,
              opacity: 1,
              gradientTransform: [
                [1, 0, 0],
                [0, 1, 0],
              ],
              gradientStops: [],
            },
          ],
        }),
        mk({ id: 'photo' }),
      ],
      format
    );
    expect(clips.size).toBe(0);
  });
});

describe('isMaskNode', () => {
  it('reads the flag and nothing else', () => {
    expect(isMaskNode(mask() as any)).toBe(true);
    expect(isMaskNode(mk() as any)).toBe(false);
    expect(isMaskNode(mk({ isMask: false }) as any)).toBe(false);
  });
});

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: false,
  designWidth: 200,
};

const png = new Uint8Array([
  137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0, 0, 0,
  31, 21, 196, 137, 0, 0, 0, 11, 73, 68, 65, 84, 120, 156, 99, 96, 0, 0, 0, 2, 0, 1, 244, 113, 100,
  166, 0, 0, 0, 0, 73, 69, 78, 68, 174, 66, 96, 130,
]);

function scene(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: 200,
    height: 200,
    x: 0,
    y: 0,
    rotation: 0,
    layoutMode: 'NONE',
    children: [],
    fills: [],
    strokes: [],
    effects: [],
    exportAsync: () => Promise.resolve(png),
    ...over,
  };
}

describe('mask pass in the converter', () => {
  it('drops the mask node and clips the photo it shapes', async () => {
    const frame = scene({
      id: 'card',
      name: 'Card',
      children: [
        scene({
          id: 'mask',
          name: 'Mask',
          type: 'RECTANGLE',
          isMask: true,
          maskType: 'ALPHA',
          cornerRadius: 16,
          fills: [solid(1, { r: 0.1, g: 0.1, b: 0.1 })],
        }),
        scene({
          id: 'photo',
          name: 'Photo',
          type: 'RECTANGLE',
          fills: [{ type: 'IMAGE', visible: true, scaleMode: 'FILL', imageHash: 'abc' }],
        }),
      ],
    });

    const ir = await convertNodeToIR(frame, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.children.map((child) => child.name)).toEqual(['Photo']);
    const photo = ir.children[0];
    expect(photo).toBeDefined();
    if (!photo) return;
    expect(photo.visual.clipPath).toBe('inset(0 0 0 0 round 16px)');
    // The mask shape must not paint over the photo.
    expect(photo.visual.background ?? '').not.toContain('rgb(26, 26, 26)');
  });

  it('refuses to promote a masked photo into the card background', async () => {
    // The photo covers the frame and carries two fills, which is exactly the
    // shape of a "backdrop" child. Promoting it would strip the mask.
    const frame = scene({
      id: 'card',
      name: 'Card',
      children: [
        scene({
          id: 'mask',
          name: 'Mask',
          type: 'RECTANGLE',
          isMask: true,
          cornerRadius: 16,
          fills: [solid(1, { r: 0.1, g: 0.1, b: 0.1 })],
        }),
        scene({
          id: 'photo',
          name: 'Photo',
          type: 'RECTANGLE',
          fills: [
            { type: 'IMAGE', visible: true, scaleMode: 'FILL', imageHash: 'abc' },
            {
              type: 'GRADIENT_LINEAR',
              visible: true,
              opacity: 1,
              gradientTransform: [
                [1, 0, 0],
                [0, 1, 0],
              ],
              gradientStops: [
                { position: 0, color: { r: 0, g: 0, b: 0, a: 0 } },
                { position: 1, color: { r: 0, g: 0, b: 0, a: 1 } },
              ],
            },
          ],
        }),
      ],
    });

    const ir = await convertNodeToIR(frame, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    expect(ir.children.map((child) => child.name)).toEqual(['Photo']);
    const photo = ir.children[0];
    expect(photo).toBeDefined();
    if (!photo) return;
    expect(photo.visual.clipPath).toBe('inset(0 0 0 0 round 16px)');
    expect(ir.visual.background ?? '').not.toContain('__FIGMA_IMAGE_FILL__');
  });
});
