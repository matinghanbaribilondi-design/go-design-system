import { describe, it, expect } from 'vitest';
import { convertNodeToIR } from './index';
import { generateFullHtmlDocument } from '../../generator/html-generator';

const options: any = {
  outputMode: 'pure-css', useRem: false, baseFontSize: 16, includeReset: true,
  inlineAssets: true, semanticTags: true, responsive: false, intrinsicReflow: false,
  designWidth: 328,
};

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: (over.width as number) ?? 100,
    height: (over.height as number) ?? 100,
    x: 0, y: 0, rotation: 0,
    layoutMode: (over.layoutMode as string) ?? 'NONE',
    children: (over.children as any[]) ?? [],
    exportAsync: () => {
      try {
        const { readFileSync, existsSync } = require('fs');
        if (existsSync('/private/tmp/figma_canvas_image_21.png')) {
          return Promise.resolve(new Uint8Array(readFileSync('/private/tmp/figma_canvas_image_21.png')));
        }
      } catch {}
      return Promise.resolve(new Uint8Array([
        137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82,
        0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0, 0, 0, 31, 21, 196, 137,
        0, 0, 0, 11, 73, 68, 65, 84, 120, 156, 99, 96, 0, 0, 0, 2,
        0, 1, 244, 113, 100, 166, 0, 0, 0, 0, 73, 69, 78, 68, 174, 66, 96, 130
      ]));
    },
    fills: [], strokes: [], effects: [],
    ...over,
  };
}

function qeshmCardReal(): any {
  const image21 = mk({
    id: '217:1193', name: 'image 21', type: 'RECTANGLE',
    width: 331, height: 192, x: 0, y: 0,
    fills: [
      { type: 'IMAGE', visible: true, scaleMode: 'FILL', imageHash: 'abc' },
      {
        type: 'GRADIENT_LINEAR', visible: true, opacity: 1,
        gradientTransform: [[1, 0, 0], [0, 1, 0]],
        gradientStops: [
          { position: 0, color: { r: 0.1, g: 0.1, b: 0.1, a: 0 } },
          { position: 1, color: { r: 0.1, g: 0.1, b: 0.1, a: 1 } },
        ],
      },
    ],
  });
  const nav = mk({
    id: '217:1194', name: 'Navigation', type: 'FRAME',
    width: 52, height: 8, x: 264, y: 130,
    layoutMode: 'HORIZONTAL', itemSpacing: 6,
    children: [
      mk({ id: '217:1195', name: 'Rectangle 2', type: 'RECTANGLE', width: 8, height: 8, cornerRadius: 20, fills: [{ type: 'SOLID', visible: true, color: { r: 1, g: 1, b: 1, a: 0.8 }, opacity: 0.8 }] }),
      mk({ id: '217:1196', name: 'Rectangle 3', type: 'RECTANGLE', width: 8, height: 8, cornerRadius: 20, fills: [{ type: 'SOLID', visible: true, color: { r: 1, g: 1, b: 1, a: 0.8 }, opacity: 0.8 }] }),
      mk({ id: '217:1197', name: 'Rectangle 4', type: 'RECTANGLE', width: 24, height: 8, cornerRadius: 20, fills: [{ type: 'SOLID', visible: true, color: { r: 0.106, g: 0.655, b: 0.953, a: 1 }, opacity: 1 }] }),
    ],
  });
  const label = mk({
    id: '217:1198', name: 'Lable', type: 'TEXT',
    width: 103, height: 65, x: 210, y: 16,
    characters: 'قشم؛\r\nبازگشت آینده',
    textAlignHorizontal: 'RIGHT', textAlignVertical: 'TOP',
    fontName: { family: 'Yekan Bakh VF', style: 'Black' },
    fontSize: 18,
    fills: [{ type: "SOLID", visible: true, color: { r: 1, g: 1, b: 1, a: 1 }, opacity: 1 }],
    getStyledTextSegments: () => [
      {
        characters: "قشم؛",
        fontSize: 18,
        fontName: { family: "Yekan Bakh VF", style: "Black" },
        fontWeight: 900,
        fills: [{ type: "SOLID", visible: true, color: { r: 0.106, g: 0.655, b: 0.953, a: 1 }, opacity: 1 }]
      },
      {
        characters: "\r\nبازگشت آینده",
        fontSize: 18,
        fontName: { family: "Yekan Bakh VF", style: "Black" },
        fontWeight: 900,
        fills: [{ type: "SOLID", visible: true, color: { r: 1, g: 1, b: 1, a: 1 }, opacity: 1 }]
      }
    ],
  });
  return mk({
    id: '217:1192', name: 'Frame 6144', type: 'FRAME',
    width: 328, height: 150, x: 0, y: 0,
    cornerRadius: 16, clipsContent: true,
    layoutMode: 'NONE',
    fills: [],
    children: [image21, nav, label],
  });
}

describe('card backdrop promotion', () => {
  it('promotes covering background image + gradient to container CSS background and preserves children', async () => {
    const card = qeshmCardReal();
    const ir = await convertNodeToIR(card, null, options);
    expect(ir).not.toBeNull();
    if (!ir) return;

    // Container visual background must have the gradient overlay on top of the image
    expect(ir.visual.background).toBeDefined();
    expect(ir.visual.background).toContain('linear-gradient(');
    expect(ir.visual.background).toContain('url("data:image/png;base64,');

    // The covering child (image 21) must be promoted and excluded from DOM children
    expect(ir.children.map((c) => c.name)).toEqual(['Navigation', 'Lable']);

    // Frame tag must be div, not img
    expect(ir.tag).toBe('div');

    const doc = generateFullHtmlDocument(ir, options);
    expect(doc).toContain('<div class="frame-6144">');
    expect(doc).not.toContain('<img class="frame-6144"');
    expect(doc).toContain('<nav class="frame-6144__navigation">');
    expect(doc).toContain('<p class="frame-6144__lable"');
    expect(doc).toContain('قشم؛');
    expect(doc).toContain('بازگشت آینده');
  });
});
