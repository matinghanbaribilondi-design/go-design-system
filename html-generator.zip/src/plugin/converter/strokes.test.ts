import { describe, it, expect } from 'vitest';
import { activeStroke, isUniform, planStroke, readStrokeShape } from './strokes';
import { extractVisualStyles } from './styles';
import type { ConversionOptions } from '../types/ir';

/**
 * Stroke fidelity.
 *
 * A stroke list is a stack, and the converter read it bottom-up with
 * `find(s => s.type === 'SOLID')`. Two losses followed from that, both silent:
 * a gradient stroke matched nothing and produced no border at all, and a solid
 * stroke sitting under another one won even though it was not the one on top.
 *
 * The gradient case cannot become `border-image`: that property ignores
 * `border-radius`, so a rounded card would arrive with square corners. It
 * becomes a masked ring instead, which is why the plan distinguishes the two.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: false,
  designWidth: 1200,
};

const solid = (r: number, g: number, b: number, over: Record<string, unknown> = {}) => ({
  type: 'SOLID',
  visible: true,
  opacity: 1,
  color: { r, g, b, a: 1 },
  ...over,
});

const gradient = (over: Record<string, unknown> = {}) => ({
  type: 'GRADIENT_LINEAR',
  visible: true,
  opacity: 1,
  gradientTransform: [
    [1, 0, 0],
    [0, 1, 0],
  ],
  gradientStops: [
    { position: 0, color: { r: 1, g: 0, b: 0, a: 1 } },
    { position: 1, color: { r: 0, g: 0, b: 1, a: 1 } },
  ],
  ...over,
});

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: 'node',
    name: 'Card',
    type: 'FRAME',
    visible: true,
    width: 200,
    height: 100,
    x: 0,
    y: 0,
    ...over,
  };
}

describe('which stroke paints', () => {
  it('takes the top-most stroke, not the bottom-most solid', () => {
    const strokes = [solid(0, 1, 0), solid(1, 0, 0)];

    const paint = activeStroke(strokes as unknown as Paint[]);
    expect(paint).toMatchObject({ color: { r: 1, g: 0, b: 0 } });
  });

  it('skips a hidden stroke on top of a visible one', () => {
    const strokes = [solid(0, 1, 0), solid(1, 0, 0, { visible: false })];

    const paint = activeStroke(strokes as unknown as Paint[]);
    expect(paint).toMatchObject({ color: { r: 0, g: 1, b: 0 } });
  });

  it('finds a gradient where the old solid-only search found nothing', () => {
    const plan = planStroke([gradient()] as unknown as Paint[], {});

    expect(plan.kind).toBe('gradient');
  });

  it('has nothing to say about a node with no strokes', () => {
    expect(planStroke([], {}).kind).toBe('none');
    expect(planStroke(undefined, {}).kind).toBe('none');
  });
});

describe('stroke weights', () => {
  it('reads the four sides when the designer set them individually', () => {
    const { weights, perSide } = readStrokeShape({
      strokeTopWeight: 2,
      strokeRightWeight: 0,
      strokeBottomWeight: 1,
      strokeLeftWeight: 0,
    });

    expect(perSide).toBe(true);
    expect(weights).toEqual({ top: 2, right: 0, bottom: 1, left: 0 });
  });

  it('falls back to the uniform weight when no side is listed', () => {
    const { weights, perSide } = readStrokeShape({ strokeWeight: 3 });

    expect(perSide).toBe(false);
    expect(weights).toEqual({ top: 3, right: 3, bottom: 3, left: 3 });
  });

  it('inherits the weight from the component an instance was made from', () => {
    // The property is simply absent on an instance node: reading only the
    // instance would give every instance a 1px hairline.
    const { weights } = readStrokeShape({ mainComponent: { strokeWeight: 3 } });

    expect(weights).toEqual({ top: 3, right: 3, bottom: 3, left: 3 });
  });

  it('prefers the instance’s own weight over the component’s', () => {
    const { weights } = readStrokeShape({ strokeWeight: 2, mainComponent: { strokeWeight: 3 } });

    expect(weights.top).toBe(2);
  });

  it('treats an explicit zero weight as no stroke', () => {
    expect(planStroke([solid(0, 0, 0)] as unknown as Paint[], { strokeWeight: 0 }).kind).toBe('none');
  });

  it('calls equal sides uniform and unequal sides not', () => {
    expect(isUniform({ top: 2, right: 2, bottom: 2, left: 2 })).toBe(true);
    expect(isUniform({ top: 2, right: 2, bottom: 2, left: 0 })).toBe(false);
    // Zero is not a stroke, so it is not a uniform one either.
    expect(isUniform({ top: 0, right: 0, bottom: 0, left: 0 })).toBe(false);
  });
});

describe('a gradient stroke becomes a ring', () => {
  it('plans a ring for a uniform gradient stroke', () => {
    const plan = planStroke([gradient()] as unknown as Paint[], { strokeWeight: 2 });

    expect(plan).toMatchObject({ kind: 'gradient', ring: true });
  });

  it('does not ring a stroke that only exists on some sides', () => {
    const plan = planStroke([gradient()] as unknown as Paint[], {
      strokeTopWeight: 2,
      strokeRightWeight: 0,
      strokeBottomWeight: 0,
      strokeLeftWeight: 0,
    });

    expect(plan).toMatchObject({ kind: 'gradient', ring: false });
  });

  it('does not ring a divider: a ring around a 1px line is invisible', () => {
    const plan = planStroke([gradient()] as unknown as Paint[], { strokeWeight: 1 }, true);

    expect(plan).toMatchObject({ kind: 'gradient', ring: false });
  });

  it('carries the gradient itself, not just its colours', () => {
    const visual = extractVisualStyles(
      mk({ strokes: [gradient()], strokeWeight: 2, cornerRadius: 16 }),
      options
    );

    expect(visual.gradientBorder?.width).toBe('2px');
    expect(visual.gradientBorder?.image).toContain('linear-gradient(');
    expect(visual.gradientBorder?.image).toContain('#ff0000 0%');
    // A ring is not a border: no border colour is invented for it.
    expect(visual.border).toBeUndefined();
  });

  it('keeps the first stop as a per-side colour when a ring is impossible', () => {
    const visual = extractVisualStyles(
      mk({
        strokes: [gradient()],
        strokeTopWeight: 2,
        strokeRightWeight: 0,
        strokeBottomWeight: 0,
        strokeLeftWeight: 0,
      }),
      options
    );

    expect(visual.gradientBorder).toBeUndefined();
    expect(visual.borderTop).toBe('2px solid #ff0000');
    expect(visual.borderRight).toBeUndefined();
  });
});

describe('a solid stroke still becomes a border', () => {
  it('paints the top-most colour', () => {
    const visual = extractVisualStyles(
      mk({ strokes: [solid(0, 1, 0), solid(1, 0, 0)], strokeWeight: 1 }),
      options
    );

    expect(visual.border).toBe('1px solid #ff0000');
    expect(visual.gradientBorder).toBeUndefined();
  });

  it('keeps the per-side structure when the sides differ', () => {
    const visual = extractVisualStyles(
      mk({
        strokes: [solid(0, 0, 0)],
        strokeTopWeight: 2,
        strokeRightWeight: 1,
        strokeBottomWeight: 2,
        strokeLeftWeight: 1,
      }),
      options
    );

    expect(visual.borderTop).toBe('2px solid #000000');
    expect(visual.borderRight).toBe('1px solid #000000');
  });

  it('honours a dashed pattern', () => {
    const visual = extractVisualStyles(
      mk({ strokes: [solid(0, 0, 0)], strokeWeight: 1, dashPattern: [4, 4] }),
      options
    );

    expect(visual.border).toBe('1px dashed #000000');
  });
});
