import { describe, it, expect } from 'vitest';
import { extractLayout, isRegionsRow, isStackingRegionRow } from './layout';
import type { ConversionOptions } from '../types/ir';
import { MIN_COLUMN_WIDTH_PX, SUBSTANTIAL_CHILD_MIN_PX } from '../../shared/constants';
import { columnFloorPx } from '../../shared/fluid';

/**
 * A regions row — "a rail beside a body" — has to behave the same way whatever
 * its proportions are. These tests do not pin one drawing; they sweep a matrix
 * of shapes and assert the properties that make the row adaptive, so a future
 * change to the body rule has to keep all of them true.
 *
 * The properties:
 *
 * 1. exactly one region absorbs the row's space, and it is the widest one;
 * 2. every region the row can stack fills its line, and they agree on the
 *    threshold — one query, not one per region;
 * 3. the threshold sits at the row's minimum viable width: at or below the
 *    design width, and strictly below it whenever some region can still
 *    shrink. A threshold at the design width is the bug this file exists for:
 *    the query would then match at every size the preview could be.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
  designWidth: 1200,
};

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'node',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: (over.width as number) ?? 100,
    height: (over.height as number) ?? 100,
    x: 0,
    y: 0,
    layoutMode: (over.layoutMode as string) ?? 'NONE',
    children: (over.children as any[]) ?? [],
    ...over,
  };
}

type Shape = { name: string; panes: number[]; row: number; gap: number };

/** Shapes a real design produces: shells, rails, four-pane workspaces. */
const SHAPES: Shape[] = [
  { name: 'a dominant body with two equal rails', panes: [848, 280, 280], row: 1440, gap: 16 },
  { name: 'three panes where none holds half the row', panes: [700, 500, 240], row: 1440, gap: 0 },
  { name: 'the same with a gap', panes: [680, 500, 240], row: 1440, gap: 10 },
  { name: 'a rail beside a body', panes: [320, 1120], row: 1440, gap: 0 },
  { name: 'a body between two narrow rails', panes: [200, 1040, 200], row: 1440, gap: 0 },
  { name: 'four panes', panes: [300, 600, 300, 240], row: 1440, gap: 0 },
  { name: 'a wide body, a panel and a narrow icon rail', panes: [1153, 220, 67], row: 1440, gap: 0 },
  { name: 'a narrow row', panes: [420, 300, 200], row: 920, gap: 0 },
  { name: 'every pane under the column floor', panes: [240, 180, 120], row: 540, gap: 0 },
];

function rowOf(shape: Shape): any {
  return mk({
    id: 'row',
    name: shape.name,
    layoutMode: 'HORIZONTAL',
    width: shape.row,
    height: 600,
    itemSpacing: shape.gap,
    children: shape.panes.map((width, i) =>
      mk({ id: `pane-${i}`, name: `Pane ${i}`, width, height: 600, layoutMode: 'VERTICAL' })
    ),
  });
}

describe('a regions row keeps its properties at every proportion', () => {
  for (const shape of SHAPES) {
    it(shape.name, () => {
      const row = rowOf(shape);
      expect(isRegionsRow(row)).toBe(true);
      expect(isStackingRegionRow(row, options)).toBe(true);

      const layouts = row.children.map((pane: any) => extractLayout(pane, row, options));

      // 1. One body, and it is the widest pane.
      const bodies = layouts.filter((l: any) => l.flexBasis === '0%' && l.flexGrow === 1);
      expect(bodies).toHaveLength(1);
      const widest = Math.max(...shape.panes);
      expect(shape.panes[layouts.indexOf(bodies[0])]).toBe(widest);

      // 2. One threshold for the whole row, on every region that can stack.
      const thresholds = new Set(layouts.map((l: any) => l.stackFill?.maxInlineSize).filter(Boolean));
      expect(thresholds.size).toBe(1);
      const [threshold] = [...thresholds];
      const size = Number.parseInt(threshold as string, 10);

      const small = shape.panes
        .map((w, i) => ({ w, i }))
        .filter(({ w }) => w < SUBSTANTIAL_CHILD_MIN_PX);
      for (const { i } of small) {
        // A detail — an icon, a dot — is not a region and must not be told to
        // take the whole line when the row stacks.
        expect(layouts[i].stackFill).toBeUndefined();
      }

      // 3. The threshold is the row's minimum viable width: the body may shrink
      // to the column floor, a rail may not shrink at all.
      const bodyIndex = layouts.indexOf(bodies[0]);
      const floors = shape.panes.reduce(
        // The floor comes from the same function the converter emits with, so
        // the test cannot drift from the implementation it is checking.
        (sum, w, i) => sum + (i === bodyIndex ? columnFloorPx(w) : w),
        0
      );
      const gaps = shape.gap * (shape.panes.length - 1);
      expect(size).toBe(floors + gaps);
      expect(size).toBeLessThanOrEqual(shape.row);

      // A rail is a rail: every pane but the body keeps the width it was drawn
      // at, so the row can only give ground where the drawing allows it.
      shape.panes.forEach((w, i) => {
        if (i === bodyIndex) return;
        expect(layouts[i].flexBasis).toBe(`${w}px`);
        expect(layouts[i].maxWidth).toBe(`${w}px`);
      });

      // Strictly below the design width whenever a pane can still shrink —
      // otherwise the query matches at the size the design was drawn at.
      if (widest > MIN_COLUMN_WIDTH_PX) {
        expect(size).toBeLessThan(shape.row);
      }
    });
  }
});
