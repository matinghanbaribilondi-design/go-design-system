import { convertNodeToIR } from './converter';
import { resetImageExportCache } from './converter/assets';
import { generateCssForRoots } from '../generator/css-generator';
import { generateHtml, hasRtlInTree } from '../generator/html-generator';
import { dedupeComponents } from '../shared/component-registry';
import { collectVariablesAndStyles } from './variables/variable-collector';
import { guard, isTimedOut } from '../shared/async';
import {
  createExportLog,
  formatBytes,
  formatDuration,
  type ExportLogReporter,
} from '../shared/export-log';
import type { ConversionOptions, IRNode } from './types/ir';
import type {
  WholeFileAsset,
  WholeFileComponent,
  WholeFileExportPayload,
  WholeFileFrame,
  WholeFilePage,
  WholeFileSkipped,
} from '../shared/whole-file-export';

/**
 * Whole-file export, sandbox side.
 *
 * The export is a loop of *ordinary* conversions — one per top-level frame,
 * with `parent = null` — followed by two passes over the results. Nothing in
 * the converter is aware that a whole file is being exported, which is what
 * makes the output of this path identical to exporting each frame by hand:
 * same classes, same layout, same responsiveness.
 *
 * What the loop adds is a single class namespace and a single stylesheet. Those
 * two things are the reason this cannot be "just call the existing export N
 * times": two frames that both contain a layer called `header` would each get
 * `.header` and fight over it in a shared stylesheet.
 *
 * The other thing the loop adds is a voice. A file with 274 frames is a minute
 * of work, and the loop used to spend that minute silently: one counter moved
 * from 1 to 1 and stopped, and there was no way to tell a slow frame from a
 * dead export. Every step below now narrates itself through `createExportLog`,
 * and each frame is awaited through `guard`, so a frame that never returns
 * costs its timeout instead of the whole run.
 */

/**
 * Safety ceiling on the number of scene nodes a single frame may contain.
 *
 * This guards against corrupted or pathological infinite node hierarchies
 * while safely allowing large real-world frames (e.g. icon sets or dense boards).
 */
const MAX_FRAME_NODES = 100_000;

/**
 * A frame that takes longer than this is reported while it is still running.
 *
 * Four seconds is well past any healthy frame — a normal one is tens of
 * milliseconds — so crossing it means something in that subtree is unusual,
 * which is exactly what the user needs to be told before they decide to
 * restart.
 */
const FRAME_SLOW_MS = 4_000;

/**
 * A frame that takes longer than this is abandoned.
 *
 * Deliberately generous: a genuinely enormous frame can legitimately take a
 * while, and dropping real content is worse than waiting. The point is not to
 * be quick, it is to guarantee the loop always moves — no single layer can hold
 * the export forever.
 */
const FRAME_TIMEOUT_MS = 30_000;

/** How many of the slowest frames the closing summary names. */
const SLOWEST_REPORTED = 3;

/**
 * One frame, converted but not yet rendered.
 *
 * The root is kept rather than its markup because `dedupeComponents` runs
 * *after* the loop and rewrites classes in place; HTML generated before it
 * would name classes that no longer exist.
 */
interface PendingFrame {
  name: string;
  /** The Figma node id, so the archive can link back to this exact frame. */
  nodeId: string;
  /** Figma page coordinates — where the canvas has to put this frame. */
  x: number;
  y: number;
  width: number;
  height: number;
  root: IRNode;
}

/** One page's worth of converted output, collected while walking the document. */
interface PageBucket {
  page: PageNode;
  roots: IRNode[];
  frames: PendingFrame[];
  /** Visible top-level layers on the page, before conversion. */
  visible: number;
}

/**
 * Hands the event loop back for one tick.
 *
 * `await`ing a promise that is already settled only drains the microtask queue,
 * and Figma's message channel to the UI is not a microtask: a loop of
 * microtask-only awaits can run for a minute while the UI sees nothing. A
 * macrotask yield per frame is what makes the progress messages actually
 * arrive, and it is what lets the log show frames going by instead of one
 * frozen number.
 */
function yieldToEventLoop(): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, 0);
  });
}

/** Cheap structural size of a subtree; the budget's unit of work. */
function countSceneNodes(node: SceneNode): number {
  let total = 1;
  try {
    if ('children' in node && Array.isArray(node.children)) {
      for (const child of node.children) total += countSceneNodes(child);
    }
  } catch {
    // An unreadable subtree contributes nothing; conversion will report it.
  }
  return total;
}

/**
 * Every asset in the document, once.
 *
 * The same logo on forty cards is forty IR nodes with the same bytes. Keying on
 * the content keeps one file in `assets/` instead of forty.
 */
function collectDocumentAssets(roots: IRNode[]): WholeFileAsset[] {
  const byContent = new Map<string, WholeFileAsset>();
  const takenNames = new Set<string>();

  const visit = (node: IRNode): void => {
    const asset = node.asset;
    if (asset && !byContent.has(asset.content)) {
      const base =
        asset.filename || `${node.className}.${asset.type === 'svg' ? 'svg' : 'png'}`;
      let filename = base;
      let n = 2;
      while (takenNames.has(filename)) {
        const dot = base.lastIndexOf('.');
        filename = dot > 0 ? `${base.slice(0, dot)}-${n}${base.slice(dot)}` : `${base}-${n}`;
        n += 1;
      }
      takenNames.add(filename);
      byContent.set(asset.content, { filename, content: asset.content, type: asset.type });
    }
    for (const child of node.children) visit(child);
  };

  for (const root of roots) visit(root);
  return Array.from(byContent.values());
}

/** Approximate serialised size, without paying to `JSON.stringify` it twice. */
function payloadSize(payload: WholeFileExportPayload): number {
  let bytes = payload.css.length;
  for (const page of payload.pages) {
    bytes += page.name.length;
    for (const frame of page.frames) bytes += frame.html.length + frame.name.length;
  }
  for (const component of payload.components) bytes += component.html.length;
  for (const asset of payload.assets) bytes += asset.content.length;
  return bytes;
}

/**
 * Whole-file markup carries `data-component` / `data-component-id`.
 *
 * This is what makes `components/*.html` a real dependency instead of a folder
 * of look-alikes: a page states which component each subtree *is*, and the
 * manifest states which components each page uses. HTML has no include, so the
 * markup still has to be written out — but it is no longer anonymous.
 *
 * The single-frame export does not pass this, so its output is unchanged.
 */
const MARKED_HTML = { componentMarkers: true } as const;

/** Every component id that appears anywhere in these trees, in first-use order. */
function collectComponentIds(roots: IRNode[]): string[] {
  const seen = new Set<string>();
  const visit = (node: IRNode): void => {
    const id = node.componentRef?.id;
    if (id) seen.add(id);
    for (const child of node.children) visit(child);
  };
  for (const root of roots) visit(root);
  return Array.from(seen);
}

/**
 * Converts the whole document into one payload.
 *
 * Frames are converted in page order, so the output is stable across runs: the
 * first frame to use a component defines it, and `-2`/`-3` suffixes on
 * duplicate names are handed out in that same order.
 */
export async function exportDocument(
  options: ConversionOptions,
  log: ExportLogReporter = createExportLog(),
  shouldStop?: () => boolean
): Promise<WholeFileExportPayload> {
  const skipped: WholeFileSkipped[] = [];

  // One cache for the whole document: a component instance rendered on nine
  // pages exports its images once, not nine times.
  resetImageExportCache();

  // ── Stage 1: read the document ───────────────────────────────────────────
  // In dynamic-page mode a page's children are not readable until the page is
  // loaded. A page that refuses to load must not abort the export of the rest.
  log.report({
    stage: 'scan',
    level: 'info',
    message: 'Reading pages…',
    done: 0,
    total: 0,
  });

  const readable: PageNode[] = [];
  for (const page of figma.root.children) {
    try {
      if (typeof page.loadAsync === 'function') await page.loadAsync();
      void page.children.length;
      readable.push(page);
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'page could not be loaded';
      skipped.push({ name: page.name, reason });
      log.report({
        stage: 'scan',
        level: 'warn',
        message: `Page "${page.name}" could not be loaded: ${reason}`,
        done: 0,
        total: 0,
      });
    }
  }

  // Enumerate the work, so progress is a real fraction from the first tick.
  const jobs: { page: PageNode; node: SceneNode }[] = [];
  const pageRoots = new Map<string, PageBucket>();
  for (const page of readable) {
    const bucket: PageBucket = { page, roots: [], frames: [], visible: 0 };
    pageRoots.set(page.id, bucket);
    let children: readonly SceneNode[] = [];
    try {
      children = page.children;
    } catch {
      continue;
    }
    for (const node of children) {
      if (!node.visible) continue;
      bucket.visible += 1;
      jobs.push({ page, node });
    }
  }

  log.report({
    stage: 'scan',
    level: 'info',
    message: `Found ${jobs.length} frame${jobs.length === 1 ? '' : 's'} across ${
      readable.length
    } page${readable.length === 1 ? '' : 's'}`,
    done: 0,
    total: jobs.length,
  });

  if (jobs.length === 0) {
    log.report({
      stage: 'scan',
      level: 'warn',
      message: 'Nothing to export: no visible frames on any page.',
      done: 0,
      total: 0,
    });
    return {
      fileName: figma.root.name,
      fileKey: figma.fileKey,
      generatedAt: new Date().toISOString(),
      responsive: options.responsive === true,
      css: '',
      pages: [],
      components: [],
      assets: [],
      customFonts: options.customFonts,
      dedupe: { merged: 0, standalone: 0 },
      skipped,
    };
  }

  // ── Stage 2: variables and styles ────────────────────────────────────────
  // Not guarded: a timed-out variable collection would leave every colour in
  // the document unresolvable, which is worse than waiting. It is timed
  // instead, so if it is the thing that hangs the log says so by name.
  log.report({
    stage: 'variables',
    level: 'info',
    message: 'Reading variables and paint styles…',
    done: 0,
    total: jobs.length,
  });
  const variablesStartedAt = Date.now();
  const varResult = await collectVariablesAndStyles(options);
  log.report({
    stage: 'variables',
    level: 'info',
    message: `Read ${varResult.tokens.length} token${
      varResult.tokens.length === 1 ? '' : 's'
    }`,
    done: 0,
    total: jobs.length,
    frameMs: Date.now() - variablesStartedAt,
  });

  // ── Stage 3: convert each top-level frame exactly as if it were selected ──
  // One shared name set: classes must be unique across the whole document,
  // because all pages are served by one stylesheet.
  const classNames = new Set<string>();
  const roots: IRNode[] = [];
  const timings: { name: string; ms: number }[] = [];

  for (let i = 0; i < jobs.length; i += 1) {
    const job = jobs[i]!;
    const frameStartedAt = Date.now();
    const progress = { done: i, total: jobs.length };

    // Checked between frames, never inside one: the yield at the end of each
    // iteration is what lets the UI's cancel message be delivered at all, so
    // this is the earliest point at which "stop" can honestly be honoured.
    // Whatever was converted so far is still returned — a partial archive is
    // more useful than a discarded one.
    if (shouldStop?.()) {
      log.report({
        stage: 'convert',
        level: 'warn',
        message: `Stopped by the user after ${i} of ${jobs.length} frames`,
        ...progress,
      });
      break;
    }

    const cost = countSceneNodes(job.node);
    if (cost > MAX_FRAME_NODES) {
      skipped.push({
        name: job.node.name,
        reason: `over the ${MAX_FRAME_NODES}-node per-frame safety limit`,
      });
      log.report({
        stage: 'convert',
        level: 'warn',
        message: `Skipped "${job.node.name}": ${cost} nodes, exceeds ${MAX_FRAME_NODES}-node safety limit`,
        ...progress,
        nodeName: job.node.name,
      });
      await yieldToEventLoop();
      continue;
    }

    log.report({
      stage: 'convert',
      level: 'info',
      message: `Converting "${job.node.name}" (${cost} nodes)`,
      ...progress,
      nodeName: job.node.name,
    });

    // Adaptive deadline: small frames get the base timeout, while complex
    // frames scale linearly with node count (~35ms per node) so large
    // frames (e.g. icon sheets or dense dashboards) have enough time to finish.
    const frameTimeoutMs = Math.max(FRAME_TIMEOUT_MS, Math.round(cost * 35));

    // One bad layer must cost one frame, not the export. `guard` also fires
    // `onSlow` while the frame is *still running*, which is the only way the
    // log can distinguish a frame that is thinking from an export that is dead.
    const result = await guard(
      convertNodeToIR(
        job.node,
        null,
        // Each frame is its own design: a fluid length that is pixel-exact for
        // a 1440 shell must not be derived from a 360 card on another page.
        { ...options, designWidth: Math.max(1, Math.round(job.node.width)) },
        varResult,
        undefined,
        classNames
      ),
      {
        timeoutMs: frameTimeoutMs,
        slowAfterMs: FRAME_SLOW_MS,
        onSlow: (elapsedMs) =>
          log.report({
            stage: 'convert',
            level: 'warn',
            message: `Still converting "${job.node.name}" — ${formatDuration(elapsedMs)} so far`,
            ...progress,
            nodeName: job.node.name,
          }),
      }
    );

    const frameMs = Date.now() - frameStartedAt;
    timings.push({ name: job.node.name, ms: frameMs });

    if (isTimedOut(result)) {
      const reason = `conversion did not finish within ${formatDuration(frameTimeoutMs)}`;
      skipped.push({ name: job.node.name, reason });
      log.report({
        stage: 'convert',
        level: 'error',
        message: `Gave up on "${job.node.name}" after ${formatDuration(frameMs)} — ${reason}`,
        done: i + 1,
        total: jobs.length,
        frameMs,
        nodeName: job.node.name,
      });
      // The abandoned conversion keeps running in the background; it can only
      // add names to the shared set, which is harmless because nothing will
      // reference them. Moving on is the whole point of the timeout.
      await yieldToEventLoop();
      continue;
    }

    if (!result) {
      skipped.push({ name: job.node.name, reason: 'nothing visible to export' });
      log.report({
        stage: 'convert',
        level: 'warn',
        message: `Skipped "${job.node.name}": nothing visible to export`,
        done: i + 1,
        total: jobs.length,
        frameMs,
        nodeName: job.node.name,
      });
      await yieldToEventLoop();
      continue;
    }

    roots.push(result);
    const bucket = pageRoots.get(job.page.id);
    if (bucket) {
      bucket.roots.push(result);
      // The frame's page coordinates, not its position inside a parent: the
      // canvas lays frames out exactly where Figma drew them, which is the
      // whole reason a page file is not just a list of frames. `x`/`y` are
      // relative to the page for a top-level child, but `absoluteBoundingBox`
      // is the honest source and costs one property read.
      const box = job.node.absoluteBoundingBox;
      bucket.frames.push({
        name: job.node.name,
        nodeId: job.node.id,
        x: Math.round(box ? box.x : job.node.x),
        y: Math.round(box ? box.y : job.node.y),
        width: Math.round(job.node.width),
        height: Math.round(job.node.height),
        root: result,
      });
    }
    log.report({
      stage: 'convert',
      level: 'info',
      message: `Converted "${job.node.name}"`,
      done: i + 1,
      total: jobs.length,
      frameMs,
      nodeName: job.node.name,
    });

    await yieldToEventLoop();
  }

  // ── Stage 4: one dedupe pass over the whole document ─────────────────────
  // So a component used on page 1 and page 9 shares one definition and one set
  // of rules.
  log.report({
    stage: 'dedupe',
    level: 'info',
    message:
      options.componentDedup === false
        ? 'Component reuse is off — every instance stays its own copy'
        : 'Merging repeated components…',
    done: jobs.length,
    total: jobs.length,
  });
  const dedupeStartedAt = Date.now();
  const report = options.componentDedup === false ? null : dedupeComponents(roots);
  log.report({
    stage: 'dedupe',
    level: 'info',
    message: report
      ? `Reused ${report.merged} instance${report.merged === 1 ? '' : 's'}, kept ${
          report.standalone
        } standalone`
      : 'Skipped component merging',
    done: jobs.length,
    total: jobs.length,
    frameMs: Date.now() - dedupeStartedAt,
  });

  // ── Stage 5: one stylesheet, one HTML document per page ──────────────────
  log.report({
    stage: 'render',
    level: 'info',
    message: 'Writing page canvases…',
    done: jobs.length,
    total: jobs.length,
  });
  const renderStartedAt = Date.now();
  const pages: WholeFilePage[] = [];
  for (const bucket of pageRoots.values()) {
    if (bucket.roots.length === 0) {
      // An empty page, or a page divider, has nothing to export — that is not a
      // failure and listing it as skipped would only be noise. A page that *had*
      // visible layers and produced nothing is a real omission, so it is listed.
      if (bucket.visible > 0) {
        skipped.push({ name: bucket.page.name, reason: 'no visible frames' });
        log.report({
          stage: 'render',
          level: 'warn',
          message: `Page "${bucket.page.name}" had ${bucket.visible} visible layer(s) but produced nothing`,
          done: jobs.length,
          total: jobs.length,
        });
      }
      continue;
    }
    pages.push({
      name: bucket.page.name,
      nodeId: bucket.page.id,
      // One entry per frame, each carrying its own markup and its own place on
      // the page. The page document is composed from these by
      // `buildPageDocument`, so a frame's markup is serialised once and travels
      // across the plugin boundary once.
      frames: bucket.frames.map(
        (frame): WholeFileFrame => ({
          name: frame.name,
          nodeId: frame.nodeId,
          x: frame.x,
          y: frame.y,
          width: frame.width,
          height: frame.height,
          html: generateHtml(frame.root, 1, false, MARKED_HTML),
          // The frame's own fill, so the canvas can stand in for the content
          // while it is not mounted. A frame with no fill stays transparent —
          // the canvas shows through it, which is what Figma does.
          background: frame.root.visual?.background,
        })
      ),
      isRtl: bucket.roots.some(hasRtlInTree),
      components: collectComponentIds(bucket.roots),
    });
    await yieldToEventLoop();
  }

  const variablesBlock = varResult.getCssVariablesBlock
    ? varResult.getCssVariablesBlock()
    : varResult.cssVariablesBlock;
  const css = generateCssForRoots(
    roots,
    options,
    pages.some((page) => page.isRtl),
    variablesBlock,
    true
  );

  const components: WholeFileComponent[] = (report?.definitions ?? []).map((definition) => ({
    id: definition.id,
    name: definition.name,
    className: definition.className,
    uses: definition.uses,
    html: generateHtml(definition.tree, 1, false, MARKED_HTML),
  }));

  const payload: WholeFileExportPayload = {
    fileName: figma.root.name,
    // Optional in the API: a local or untitled file has no key, and a link
    // that lands nowhere is worse than no link at all.
    fileKey: figma.fileKey,
    generatedAt: new Date().toISOString(),
    responsive: options.responsive === true,
    css,
    pages,
    components,
    assets: collectDocumentAssets(roots),
    customFonts: options.customFonts,
    dedupe: { merged: report?.merged ?? 0, standalone: report?.standalone ?? 0 },
    skipped,
  };

  log.report({
    stage: 'render',
    level: 'info',
    message: `${pages.length} page${pages.length === 1 ? '' : 's'}, ${
      components.length
    } component${components.length === 1 ? '' : 's'}, ${formatBytes(payloadSize(payload))} payload`,
    done: jobs.length,
    total: jobs.length,
    frameMs: Date.now() - renderStartedAt,
  });

  // ── Stage 6: hand it over ────────────────────────────────────────────────
  // Reported *before* the message is posted, so if the payload is too big for
  // the plugin boundary the last line in the log is the handover rather than a
  // frame that looked finished — the log then points at the right suspect.
  const slowest = timings
    .slice()
    .sort((a, b) => b.ms - a.ms)
    .slice(0, SLOWEST_REPORTED)
    .filter((entry) => entry.ms >= FRAME_SLOW_MS / 2);

  log.report({
    stage: 'archive',
    level: 'info',
    message:
      slowest.length > 0
        ? `Handing ${formatBytes(payloadSize(payload))} to the UI. Slowest: ${slowest
            .map((entry) => `"${entry.name}" ${formatDuration(entry.ms)}`)
            .join(', ')}`
        : `Handing ${formatBytes(payloadSize(payload))} to the UI`,
    done: jobs.length,
    total: jobs.length,
  });

  // The closing "done" line belongs to the caller: it is only true once the
  // payload has actually crossed the plugin boundary.
  return payload;
}
