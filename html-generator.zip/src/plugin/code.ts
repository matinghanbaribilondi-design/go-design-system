import { convertNodeToIR } from './converter';
import { resetImageExportCache } from './converter/assets';
import { generateHtml, generateFullHtmlDocument, hasRtlInTree } from '../generator/html-generator';
import { generateCss, generateCssForRoots } from '../generator/css-generator';
import { generateTailwindHtml } from '../generator/tailwind-generator';
import { exportDocument } from './document-export';
import { createExportLog, formatDuration } from '../shared/export-log';
import { ConversionOptions, ConversionResult, FrameResult, IRNode, UsedFont } from './types/ir';
import { collectVariablesAndStyles } from './variables/variable-collector';
import { uniqueAssets } from '../shared/asset-references';

type CodeDebugSummary = import('./types/ir').DebugNodeSummary;

// Default options
let currentOptions: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: true,
};

// Show the plugin UI
figma.showUI(__html__, {
  width: 540,
  height: 680,
  title: 'Pixel-Perfect HTML/CSS Exporter',
  themeColors: true,
});

/**
 * Collect all exported assets (SVGs and Images) from IRNode tree.
 *
 * Identical payloads are collapsed: the same logo on forty cards is forty IR
 * nodes holding the same bytes, and the archive needs one file for them.
 */
function collectAssets(
  node: IRNode,
  assets: { filename: string; content: string; type: string }[] = []
) {
  if (node.asset) {
    assets.push({
      filename: node.asset.filename || `${node.className}.${node.asset.type === 'svg' ? 'svg' : 'png'}`,
      content: node.asset.content,
      type: node.asset.type,
    });
  }
  for (const child of node.children) {
    collectAssets(child, assets);
  }
  return assets;
}

/**
 * Recursively scans SceneNode tree and extracts all unique font families and styles used
 */
function collectUsedFonts(node: SceneNode, fontMap = new Map<string, Set<string>>()): UsedFont[] {
  if (node.type === 'TEXT') {
    const textNode = node as TextNode;
    try {
      if (typeof textNode.getStyledTextSegments === 'function') {
        const segments = textNode.getStyledTextSegments(['fontName']);
        for (const seg of segments) {
          if (seg.fontName && typeof seg.fontName === 'object' && 'family' in seg.fontName) {
            const fam = seg.fontName.family;
            const style = String(seg.fontName.style || 'Regular');
            if (!fontMap.has(fam)) fontMap.set(fam, new Set());
            fontMap.get(fam)!.add(style);
          }
        }
      } else if (textNode.fontName && typeof textNode.fontName === 'object' && 'family' in textNode.fontName) {
        const fam = textNode.fontName.family;
        const style = String(textNode.fontName.style || 'Regular');
        if (!fontMap.has(fam)) fontMap.set(fam, new Set());
        fontMap.get(fam)!.add(style);
      }
    } catch {
      if (textNode.fontName && typeof textNode.fontName === 'object' && 'family' in textNode.fontName) {
        const fam = textNode.fontName.family;
        const style = String(textNode.fontName.style || 'Regular');
        if (!fontMap.has(fam)) fontMap.set(fam, new Set());
        fontMap.get(fam)!.add(style);
      }
    }
  }

  if ('children' in node && Array.isArray(node.children)) {
    for (const child of node.children) {
      collectUsedFonts(child, fontMap);
    }
  }

  return Array.from(fontMap.entries()).map(([family, stylesSet]) => ({
    family,
    styles: Array.from(stylesSet),
  }));
}

interface Box {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface ConvertedSelection {
  node: SceneNode;
  root: IRNode;
  /** The options this frame was converted with, including its design width. */
  options: ConversionOptions;
}

/**
 * Page coordinates of a selected node.
 *
 * `absoluteBoundingBox` is the honest source for a top-level frame and also
 * works for a group of layers selected inside one. It is null only for a node
 * the API cannot measure, which is not a reason to drop the export.
 */
function absoluteBoxOf(node: SceneNode): Box {
  const box = node.absoluteBoundingBox;
  if (box) {
    return { x: box.x, y: box.y, width: box.width, height: box.height };
  }
  return { x: 0, y: 0, width: node.width, height: node.height };
}

/** Union of the selected boxes, used for the progress line's dimensions. */
function unionBox(nodes: readonly SceneNode[]): Box {
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const node of nodes) {
    const box = absoluteBoxOf(node);
    minX = Math.min(minX, box.x);
    minY = Math.min(minY, box.y);
    maxX = Math.max(maxX, box.x + box.width);
    maxY = Math.max(maxY, box.y + box.height);
  }
  return {
    x: minX,
    y: minY,
    width: Math.max(1, maxX - minX),
    height: Math.max(1, maxY - minY),
  };
}

/**
 * Which selection request is the current one.
 *
 * A conversion is slow — it collects every variable and style in the file
 * before it touches the node — so two selections in quick succession produce
 * two runs in flight at once. Without an order check the *slowest* run wins,
 * and the preview ends up showing a node the user has already moved on from.
 * That looks exactly like "it loaded the wrong thing".
 */
let selectionRequestId = 0;

/**
 * Converts the current selection and sends one result to the UI.
 *
 * A selection is an array, not a node. Figma lets a user select several frames
 * — the linked screens of one flow are the usual reason — and the export used
 * to read `selection[0]` and silently drop the rest. Every selected node is
 * converted now, with one shared class namespace, one stylesheet and one asset
 * set, but each frame remains a document of its own: the ZIP writes one HTML
 * file per frame. A one-node selection takes exactly the same path it always
 * did.
 */
async function processCurrentSelection(options: ConversionOptions = currentOptions) {
  const requestId = ++selectionRequestId;
  const selection = figma.currentPage.selection;

  if (selection.length === 0) {
    figma.ui.postMessage({
      type: 'SELECTION_EMPTY',
      message: 'Please select a frame or element in Figma to export.',
    });
    return;
  }

  const selectedNodes = Array.from(selection);
  const firstNode = selectedNodes[0];
  if (!firstNode) {
    return;
  }

  const multi = selectedNodes.length > 1;
  const startBox = multi ? unionBox(selectedNodes) : absoluteBoxOf(firstNode);

  figma.ui.postMessage({
    type: 'CONVERTING_START',
    nodeName: multi ? `${selectedNodes.length} frames` : firstNode.name,
    width: Math.round(startBox.width),
    height: Math.round(startBox.height),
  });

  // The frame's own width is the reference every fluid length is derived from:
  // a value rendered at this width is pixel-identical to the Figma design, and
  // scales from there. Deriving it here (rather than asking the user to set it)
  // keeps the output correct for any design they select.
  const effectiveOptions: ConversionOptions = {
    ...options,
    designWidth: options.designWidth ?? Math.round(firstNode.width),
  };

  try {
    // 1. Collect all Figma variables and styles (like VarVar)
    const varResult = await collectVariablesAndStyles(effectiveOptions);

    // 2. Convert node trees using bound variables and dynamic color registry.
    // The image export cache is per conversion: the same node converted again
    // at a different scale is a different picture, not a cache hit.
    resetImageExportCache();

    // One name set for the whole selection: two frames can both contain a layer
    // called "header", and they share one stylesheet, so they cannot both own
    // `.header`.
    const classNames = new Set<string>();
    const converted: ConvertedSelection[] = [];

    for (const node of selectedNodes) {
      // Every frame keeps its own design width: a fluid length that is exact
      // for a 1440 shell must not be derived from a 360 card selected next to
      // it. The single-node path keeps using `effectiveOptions` unchanged.
      const nodeOptions: ConversionOptions = multi
        ? { ...options, designWidth: options.designWidth ?? Math.max(1, Math.round(node.width)) }
        : effectiveOptions;

      const root = await convertNodeToIR(node, null, nodeOptions, varResult, undefined, classNames);

      // A newer selection started while this one was working; its result is the
      // one the user is waiting for, so this one is dropped rather than painted.
      if (requestId !== selectionRequestId) return;
      if (root) converted.push({ node, root, options: nodeOptions });
    }

    if (converted.length === 0) {
      figma.ui.postMessage({
        type: 'CONVERT_ERROR',
        error: multi
          ? 'None of the selected elements is visible or can be exported.'
          : 'The selected element is not visible or cannot be exported.',
      });
      return;
    }

    const finalVariablesBlock = varResult.getCssVariablesBlock
      ? varResult.getCssVariablesBlock()
      : varResult.cssVariablesBlock;

    const finalTailwindTheme = varResult.getTailwindThemeBlock
      ? varResult.getTailwindThemeBlock()
      : varResult.tailwindThemeBlock;

    // The debug attribute is opt-in: with it the markup names every layer's
    // Figma id, which is what lets a pixel diff point at a layer instead of
    // a percentage. Off by default, and off means the bytes do not change.
    const debugMarkup = { debugFigmaIds: effectiveOptions.debugFigmaIds };

    function dumpNodeSummary(node: SceneNode, depth = 0): CodeDebugSummary {
      const summary: CodeDebugSummary = {
        name: node.name,
        type: node.type,
        x: Math.round(node.x),
        y: Math.round(node.y),
        w: Math.round(node.width),
        h: Math.round(node.height),
        visible: node.visible,
      };
      if ('layoutMode' in node) summary.layoutMode = node.layoutMode;
      if ('layoutPositioning' in node)
        summary.layoutPositioning = String((node as { layoutPositioning?: unknown }).layoutPositioning ?? '');
      if ('primaryAxisAlignItems' in node) summary.primaryAlign = String(node.primaryAxisAlignItems);
      if ('counterAxisAlignItems' in node) summary.counterAlign = String(node.counterAxisAlignItems);
      if ('itemSpacing' in node) summary.itemSpacing = node.itemSpacing as number | string;
      if ('clipsContent' in node) summary.clipsContent = Boolean((node as { clipsContent?: unknown }).clipsContent);
      if ('constraints' in node) summary.constraints = (node as { constraints?: unknown }).constraints;
      if ('paddingLeft' in node) {
        const padded = node as {
          paddingTop?: unknown;
          paddingRight?: unknown;
          paddingBottom?: unknown;
          paddingLeft?: unknown;
        };
        summary.padding = {
          top: padded.paddingTop,
          right: padded.paddingRight,
          bottom: padded.paddingBottom,
          left: padded.paddingLeft,
        };
      }
      if ('children' in node && depth < 4) {
        summary.children = node.children.map((c) => dumpNodeSummary(c, depth + 1));
      }
      return summary;
    }

    // One font map for the whole selection, so the same family used on three
    // screens is listed once.
    const fontMap = new Map<string, Set<string>>();
    let usedFonts: UsedFont[] = [];
    for (const { node } of converted) {
      usedFonts = collectUsedFonts(node, fontMap);
    }

    let result: ConversionResult;

    if (converted.length === 1) {
      // The single-frame path is unchanged, byte for byte.
      const { node, root } = converted[0]!;
      const isRtl = hasRtlInTree(root);
      const assets = uniqueAssets(collectAssets(root));

      const html = generateHtml(root, 0, false, debugMarkup);
      const css = generateCss(root, effectiveOptions, isRtl, finalVariablesBlock);
      const combinedHtml = generateFullHtmlDocument(root, effectiveOptions, finalVariablesBlock);
      const tailwindHtml = generateTailwindHtml(root, 0, false, [], debugMarkup);

      result = {
        nodeName: node.name,
        width: Math.round(node.width),
        height: Math.round(node.height),
        html,
        css,
        combinedHtml,
        tailwindHtml,
        assets,
        debugTree: dumpNodeSummary(node),
        variablesBlock: finalVariablesBlock,
        tokensCSS: finalVariablesBlock,
        tokensTailwind: finalTailwindTheme,
        tokensJSON: varResult.jsonExport,
        tokensJS: varResult.jsExport,
        tokensCSV: varResult.csvExport,
        usedFonts,
        customFonts: options.customFonts,
      };
    } else {
      // Several frames mean several pages, not one canvas. Each gets its own
      // document; the stylesheet, tokens, fonts and assets are written once
      // and shared by all of them.
      const isRtl = converted.some(({ root }) => hasRtlInTree(root));
      const css = generateCssForRoots(
        converted.map(({ root }) => root),
        options,
        isRtl,
        finalVariablesBlock
      );

      const frames: FrameResult[] = converted.map(({ node, root, options: frameOptions }) => ({
        nodeId: node.id,
        nodeName: node.name,
        width: Math.round(node.width),
        height: Math.round(node.height),
        isRtl: hasRtlInTree(root),
        html: generateHtml(root, 0, false, debugMarkup),
        combinedHtml: generateFullHtmlDocument(root, frameOptions, finalVariablesBlock),
        tailwindHtml: generateTailwindHtml(root, 0, false, [], debugMarkup),
        debugTree: dumpNodeSummary(node),
      }));

      // Assets are deduped across the selection: the same logo on two screens
      // is one file, referenced by both pages.
      const collected: { filename: string; content: string; type: string }[] = [];
      for (const { root } of converted) collectAssets(root, collected);
      const assets = uniqueAssets(collected);

      const first = frames[0]!;
      result = {
        // The top level stays a valid single-frame document for consumers that
        // do not know about `frames`; the UI switches between them by index.
        nodeName: `${frames.length} frames`,
        width: first.width,
        height: first.height,
        html: first.html,
        css,
        combinedHtml: first.combinedHtml,
        tailwindHtml: first.tailwindHtml,
        assets,
        debugTree: first.debugTree,
        frames,
        variablesBlock: finalVariablesBlock,
        tokensCSS: finalVariablesBlock,
        tokensTailwind: finalTailwindTheme,
        tokensJSON: varResult.jsonExport,
        tokensJS: varResult.jsExport,
        tokensCSV: varResult.csvExport,
        usedFonts,
        customFonts: options.customFonts,
      };
    }

    figma.ui.postMessage({
      type: 'CONVERT_SUCCESS',
      payload: result,
    });
  } catch (error: unknown) {
    if (requestId !== selectionRequestId) return;
    console.error('Error during conversion:', error);
    figma.ui.postMessage({
      type: 'CONVERT_ERROR',
      error: error instanceof Error ? error.message : 'An unexpected error occurred during conversion.',
    });
  }
}

// Listen to selection changes in Figma
figma.on('selectionchange', () => {
  processCurrentSelection();
});

/**
 * Converts every page of the document and hands the UI one payload.
 *
 * Kept separate from `processCurrentSelection` on purpose: that path is driven
 * by Figma's selection events, so sharing it would make a whole-file export
 * restart every time the selection moved. Nothing here reads or writes the
 * selection, and nothing here changes what the single-frame path produces.
 *
 * Every event the export raises is forwarded to the UI as it happens. There is
 * no throttle: an event is tiny, and a document large enough for the message
 * count to matter would be one where the log is the only thing telling the user
 * what is going on.
 */
let documentExportRunning = false;
/**
 * Set by the UI's Stop button and read between frames by the export loop.
 *
 * It cannot interrupt a frame that is already inside `convertNodeToIR` — that
 * is synchronous work, or an await on Figma's own API, and neither can be
 * pre-empted. What it does guarantee is that stopping costs at most one frame,
 * which is the same guarantee the per-frame timeout gives.
 */
let documentExportCancelled = false;

async function processWholeDocument(options: ConversionOptions = currentOptions) {
  if (documentExportRunning) {
    return;
  }
  documentExportRunning = true;
  documentExportCancelled = false;

  const log = createExportLog((event) => {
    figma.ui.postMessage({ type: 'EXPORT_DOCUMENT_LOG', event });
  });

  try {
    const payload = await exportDocument(options, log, () => documentExportCancelled);

    if (payload.pages.length === 0) {
      log.report({
        stage: 'done',
        level: 'error',
        message: 'No visible frames were found on any page — nothing was written.',
        done: 0,
        total: 0,
      });
      figma.ui.postMessage({
        type: 'EXPORT_DOCUMENT_ERROR',
        error: 'There is nothing to export: no visible frames were found on any page.',
      });
      return;
    }

    figma.ui.postMessage({ type: 'EXPORT_DOCUMENT_SUCCESS', payload });

    // Reported after the post, so this line means the payload really is on the
    // other side. If it never appears, the handover is what failed.
    const last = log.events[log.events.length - 1];
    const skippedCount = payload.skipped.length;
    const stopped = documentExportCancelled;
    log.report({
      stage: 'done',
      level: stopped || skippedCount > 0 ? 'warn' : 'good',
      message: stopped
        ? `Stopped by the user — delivered a partial export of ${payload.pages.length} page(s)`
        : skippedCount > 0
          ? `Delivered to the UI in ${formatDuration(Date.now() - log.startedAt)} — ${skippedCount} item${
              skippedCount === 1 ? '' : 's'
            } skipped`
          : `Delivered to the UI in ${formatDuration(Date.now() - log.startedAt)}`,
      done: last?.total ?? 0,
      total: last?.total ?? 0,
    });
  } catch (error: unknown) {
    console.error('Error during whole-file export:', error);
    const message = error instanceof Error ? error.message : 'The whole-file export failed.';
    log.report({
      stage: 'done',
      level: 'error',
      message: `Failed: ${message}`,
      done: 0,
      total: 0,
    });
    figma.ui.postMessage({
      type: 'EXPORT_DOCUMENT_ERROR',
      error: message,
    });
  } finally {
    documentExportRunning = false;
  }
}

// Listen to messages from UI
figma.ui.onmessage = async (msg) => {
  switch (msg.type) {
    case 'INIT':
      try {
        const storedFonts = await figma.clientStorage.getAsync('custom_fonts');
        if (Array.isArray(storedFonts) && storedFonts.length > 0) {
          currentOptions.customFonts = storedFonts;
          figma.ui.postMessage({
            type: 'CUSTOM_FONTS_LOADED',
            fonts: storedFonts,
          });
        }
      } catch (err) {
        console.warn('Failed to load custom fonts from clientStorage:', err);
      }
      processCurrentSelection(currentOptions);
      break;

    case 'SAVE_CUSTOM_FONTS':
      try {
        if (Array.isArray(msg.fonts)) {
          await figma.clientStorage.setAsync('custom_fonts', msg.fonts);
          currentOptions.customFonts = msg.fonts;
          processCurrentSelection(currentOptions);
        }
      } catch (err) {
        console.warn('Failed to save custom fonts to clientStorage:', err);
      }
      break;

    case 'RECONVERT':
      if (msg.options) {
        currentOptions = { ...currentOptions, ...msg.options };
      }
      processCurrentSelection(currentOptions);
      break;

    // Whole file: every page, every top-level frame, one shared stylesheet.
    // Deliberately not awaited — a long export must not block the plugin from
    // answering a resize or a settings change while it runs.
    case 'EXPORT_DOCUMENT':
      if (msg.options) {
        currentOptions = { ...currentOptions, ...msg.options };
      }
      processWholeDocument(currentOptions);
      break;

    // Stop the run at the next frame boundary. Nothing is thrown: the frames
    // already converted are still packaged, so a stuck export can be rescued.
    case 'CANCEL_DOCUMENT_EXPORT':
      documentExportCancelled = true;
      break;

    case 'NOTIFY':
      if (msg.message) {
        figma.notify(msg.message, { timeout: msg.timeout || 2500 });
      }
      break;

    case 'RESIZE_UI':
      if (msg.width && msg.height) {
        figma.ui.resize(msg.width, msg.height);
      }
      break;
  }
};
