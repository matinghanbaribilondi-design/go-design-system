import { build } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

async function run() {
  const isWatch = process.argv.includes('--watch');
  const pkg = JSON.parse(fs.readFileSync(path.resolve(rootDir, 'package.json'), 'utf-8'));
  const version = pkg.version ?? '0.0.0';
  const banner = `/* Pixel-Perfect Exporter v${version} — built ${new Date().toISOString()} */\n`;

  console.log(`🚀 Building Plugin UI (v${version})...`);
  // 1. Build UI (HTML + CSS + React bundled into a single file)
  await build({
    root: path.resolve(rootDir, 'src/ui'),
    plugins: [react(), viteSingleFile()],
    base: './',
    define: { __PLUGIN_VERSION__: JSON.stringify(version) },
    build: {
      outDir: path.resolve(rootDir, 'dist'),
      emptyOutDir: false,
      sourcemap: false,
      watch: isWatch ? {} : null,
      rollupOptions: {
        input: path.resolve(rootDir, 'src/ui/index.html'),
      },
    },
  });

  // Ensure dist/ui.html exists (copy from index.html if needed)
  const indexHtml = path.resolve(rootDir, 'dist/index.html');
  const uiHtml = path.resolve(rootDir, 'dist/ui.html');
  if (fs.existsSync(indexHtml)) {
    fs.copyFileSync(indexHtml, uiHtml);
  }

  console.log('🚀 Building Plugin Sandbox (code.ts)...');
  // 2. Build Plugin Code (code.js)
  await build({
    configFile: false,
    build: {
      outDir: path.resolve(rootDir, 'dist'),
      emptyOutDir: false,
      target: 'es2020',
      minify: false,
      sourcemap: false,
      lib: {
        entry: path.resolve(rootDir, 'src/plugin/code.ts'),
        formats: ['iife'],
        name: 'code',
        fileName: () => 'code.js',
      },
      watch: isWatch ? {} : null,
    },
  });

  // Stamp version banner on code.js (cheap cache-buster / traceability)
  try {
    const codePath = path.resolve(rootDir, 'dist/code.js');
    if (fs.existsSync(codePath)) {
      const prev = fs.readFileSync(codePath, 'utf-8');
      if (!prev.startsWith('/* Pixel-Perfect Exporter')) {
        fs.writeFileSync(codePath, banner + prev);
      }
    }
  } catch (err) {
    console.warn('⚠️ Could not stamp version banner:', err);
  }

  console.log('✅ Build completed successfully!');
}

run().catch((err) => {
  console.error('❌ Build failed:', err);
  process.exit(1);
});
