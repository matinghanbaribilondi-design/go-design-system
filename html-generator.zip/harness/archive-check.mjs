// Screenshots the archive's index, a page canvas and one frame, built by
// harness/archive.test.ts.
//
//   npx vitest run harness/archive.test.ts && node harness/archive-check.mjs
//
// The question this answers is not "is the HTML valid" — the test does that.
// It is "does this look like what it claims to be": can someone opening the ZIP
// tell what is in it, does a page read as Figma's canvas (frames where Figma
// put them), and does a frame open on its own.
import { spawnSync } from 'child_process';
import { existsSync } from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, 'out', 'archive');

const shots = [
  { out: 'archive-index.png', file: 'index.html', size: '820,760' },
  { out: 'archive-canvas.png', file: 'pages/home.html', size: '1440,900' },
  // The board is the performance case: 24 frames. At this size the canvas is
  // zoomed in far enough to mount the frames that are on screen.
  { out: 'archive-board.png', file: 'pages/board.html', size: '1440,900' },
  // ...and at this size it is zoomed out past the point where content is
  // readable, so every frame is a block in its own colour instead.
  { out: 'archive-board-lod.png', file: 'pages/board.html', size: '560,420' },
  { out: 'archive-frame.png', file: 'frames/home-desktop.html', size: '1440,900' },
  // A deep link is the same canvas with one frame already centred: the
  // `#frame` half of "whatever you are looking at is a link you can send".
  { out: 'archive-deeplink.png', file: 'pages/home.html#home-mobile', size: '1200,820' },
];

for (const shot of shots) {
  const [rel, hash] = shot.file.split('#');
  const target = path.join(root, rel);
  if (!existsSync(target)) {
    console.error(`missing ${rel} — run: npx vitest run harness/archive.test.ts`);
    process.exit(1);
  }

  const out = path.join(__dirname, 'out', shot.out);
  const result = spawnSync(
    CHROME,
    [
      '--headless=new',
      '--no-sandbox',
      '--disable-gpu',
      '--hide-scrollbars',
      '--force-device-scale-factor=2',
      `--window-size=${shot.size}`,
      '--virtual-time-budget=2000',
      `--screenshot=${out}`,
      pathToFileURL(target).href + (hash ? `#${hash}` : ''),
    ],
    { encoding: 'utf8' }
  );

  if (result.status !== 0) {
    console.error(result.stderr);
    process.exit(1);
  }
  console.log(`${shot.file} -> ${out}`);
}
