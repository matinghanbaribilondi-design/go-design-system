// Reads the real rendering of `harness/out/22-mask.html` out of Chrome.
//
//   npx vitest run harness/mask.test.ts && node harness/mask-check.mjs
//
// The fixture is a 400×300 card whose photo is shaped by a 24px rounded-rect
// mask, with a blue badge shaped by a separate ellipse mask. Three claims, none
// of which a CSS-string assertion can settle:
//
//   1. The mask layers are not in the document. In Figma a mask is never
//      painted, so a `div` for it in the output is a layer that does not exist.
//   2. The photo is actually clipped to the rounded rectangle. Checked at the
//      top-left corner, where a 24px radius has to remove the photo entirely.
//   3. The ellipse mask reaches only the badge. Checked at a point inside the
//      badge's box but outside the ellipse: the photo has to show through.
//
// `elementFromPoint` is used as the pixel test: hit testing honours
// `clip-path`, so "which layer is on top here" answers "is this point inside
// the clip" without needing a screenshot decoder.
import { spawnSync } from 'child_process';
import { existsSync, writeFileSync } from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const source = path.join(__dirname, 'out', '22-mask.html');

if (!existsSync(source)) {
  console.error('missing 22-mask.html — run: npx vitest run harness/mask.test.ts');
  process.exit(1);
}

const wrapper = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
html,body{margin:0;padding:0;background:#fff}
iframe{border:0;display:block}
</style></head><body><script>
window.addEventListener('load', function () {
  var frame = document.createElement('iframe');
  frame.width = 900;
  frame.height = 700;
  frame.src = '22-mask.html';
  frame.onload = function () {
    var doc = frame.contentDocument;
    var win = doc.defaultView;
    function who(x, y) {
      var el = doc.elementFromPoint(x, y);
      if (!el) return 'none';
      var cls = typeof el.className === 'string' ? el.className : '';
      return cls || el.tagName.toLowerCase();
    }
    var clip = {};
    Array.prototype.forEach.call(doc.querySelectorAll('[class]'), function (el) {
      var name = typeof el.className === 'string' ? el.className : '';
      var value = win.getComputedStyle(el).clipPath;
      if (value && value !== 'none') clip[name] = value;
    });
    var masks = Array.prototype.filter.call(doc.querySelectorAll('[class]'), function (el) {
      return /mask/i.test(typeof el.className === 'string' ? el.className : '');
    }).map(function (el) { return el.className; });

    var card = doc.querySelector('article, section, div');
    var report = {
      // The card drew four layers and two of them were masks, so exactly two
      // elements should be left in it.
      childCount: card ? card.children.length : -1,
      // Corner of the card: the 24px radius must have removed the photo here.
      corner: who(3, 3),
      // Middle of the card, left of the ellipse.
      middle: who(200, 150),
      // Inside the badge's box but outside the ellipse: the photo shows through.
      outsideEllipse: who(170, 180),
      // Centre of the ellipse.
      ellipseCentre: who(280, 180),
      // Right of the ellipse, still inside the photo.
      rightOfEllipse: who(390, 180),
      clip: clip,
      masks: masks
    };
    document.body.insertAdjacentHTML('beforeend', '<pre id="mask-' + 'report">' + JSON.stringify(report) + '</pre>');
  };
  document.body.appendChild(frame);
});
</script></body></html>`;

const probe = path.join(__dirname, 'out', '22-mask-probe.html');
writeFileSync(probe, wrapper);

const result = spawnSync(
  CHROME,
  [
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--hide-scrollbars',
    '--allow-file-access-from-files',
    '--window-size=1400,1000',
    '--virtual-time-budget=3000',
    '--dump-dom',
    pathToFileURL(probe).href,
  ],
  { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 }
);

const match = result.stdout.match(/<pre id="mask-report">([^<]*)<\/pre>/);
if (!match) {
  console.error('could not read the report from Chrome');
  process.exit(1);
}

const report = JSON.parse(match[1].replace(/&quot;/g, '"'));

const checks = [
  ['the mask layers are gone', report.masks.length === 0, report.masks.join(', ') || 'none'],
  ['two layers left in the card', report.childCount === 2, String(report.childCount)],
  ['photo clipped at the rounded corner', !/photo/.test(report.corner), report.corner],
  ['photo visible inside the card', /photo/.test(report.middle), report.middle],
  ['ellipse does not reach the photo', /photo/.test(report.outsideEllipse), report.outsideEllipse],
  ['badge visible inside the ellipse', /badge/.test(report.ellipseCentre), report.ellipseCentre],
  ['photo visible right of the ellipse', /photo/.test(report.rightOfEllipse), report.rightOfEllipse],
];

let failures = 0;
for (const [label, ok, detail] of checks) {
  if (!ok) failures += 1;
  console.log(`${ok ? 'ok  ' : 'BAD '} ${label.padEnd(36)} ${detail}`);
}

console.log('\nclip-path in use:');
for (const [selector, value] of Object.entries(report.clip)) {
  console.log(`  ${selector.padEnd(24)} ${value}`);
}

if (failures > 0) {
  console.error(`\n${failures} check(s) failed.`);
  process.exit(1);
}
console.log('\nThe mask shapes the layers after it, and is never painted itself.');
