// Drives the canvas script in real Chrome and asserts what it did.
//
// There is no browser test runner in this project, and adding one for four
// behaviours would be out of proportion. This is the smallest honest thing:
// copy a page, append a probe script, run Chrome with --dump-dom, and read
// what the probe wrote. It is the same trick as archive-check.mjs, one step
// further — that one looks at pixels, this one presses keys.
//
//   npx vitest run harness/archive.test.ts && node harness/canvas-check.mjs
import { spawnSync } from 'child_process';
import { existsSync, readFileSync, unlinkSync, writeFileSync } from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, 'out', 'archive');
const page = path.join(root, 'pages', 'home.html');

if (!existsSync(page)) {
  console.error('missing pages/home.html — run: npx vitest run harness/archive.test.ts');
  process.exit(1);
}

// The probe runs after the canvas script has booted, so it sees the same DOM a
// reader would. Everything it learns is written into one <pre>, which
// --dump-dom then hands back as text.
const PROBE = `<script>
setTimeout(function () {
  var log = [];
  function say(key, value) { log.push(key + '=' + value); }

  var dlg = document.getElementById('__canvas-palette');
  var q = document.getElementById('__canvas-q');
  var results = document.getElementById('__canvas-results');
  var rows = document.querySelectorAll('.__canvas-list a[data-goto]');

  say('dialog', !!dlg);
  say('rows', rows.length);

  // The minimap starts hidden. At fit zoom the whole page is on screen, so a
  // scaled copy of it would only restate what the reader can already see.
  var mini = document.getElementById('__canvas-mini');
  var miniC = document.getElementById('__canvas-mini-c');
  var vp = document.getElementById('__canvas-vp');
  say('miniAtFit', !!(mini && mini.classList.contains('__canvas-mini-off')));

  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', metaKey: true, bubbles: true }));
  say('opened', dlg && dlg.open);
  say('results', results.querySelectorAll('li[data-i]').length);

  q.value = 'pricing';
  q.dispatchEvent(new Event('input', { bubbles: true }));
  say('filtered', results.querySelectorAll('li[data-i]').length);
  var first = results.querySelector('li[data-i] .__canvas-result-name');
  say('filteredName', first ? first.textContent : '');

  q.value = 'board';
  q.dispatchEvent(new Event('input', { bubbles: true }));
  say('crossPage', results.querySelectorAll('li[data-i]').length);

  if (dlg && dlg.open) dlg.close();

  // Clicking a row in the list should move the canvas, not the tab.
  var row = document.querySelector('.__canvas-list a[data-goto="home-mobile"]');
  if (row) row.click();
  say('hash', location.hash);
  var active = document.querySelector('.__canvas-item.__canvas-active');
  say('active', active ? active.getAttribute('data-slug') : '');
  var current = document.querySelector('.__canvas-list a[aria-current="true"]');
  say('current', current ? current.getAttribute('data-goto') : '');

  // 100% puts part of the page off screen, which is when the map earns its
  // corner. The handler reads "code", not "key": with Shift held the key is ")".
  document.dispatchEvent(
    new KeyboardEvent('keydown', { key: ')', code: 'Digit0', shiftKey: true, bubbles: true })
  );
  say('miniAt100', !!(mini && mini.classList.contains('__canvas-mini-off')));

  // The viewport rectangle is painted in Figma blue (#0d99ff). Reading the
  // pixels is the only way to know the map drew anything, not just unhid.
  var blue = 0;
  var px = miniC.getContext('2d').getImageData(0, 0, miniC.width, miniC.height).data;
  for (var i = 0; i < px.length; i += 4) {
    if (px[i] < 60 && px[i + 1] > 120 && px[i + 1] < 190 && px[i + 2] > 220) blue += 1;
  }
  say('miniBlue', blue > 0);

  // Clicking the map moves the canvas there. The far edge of the map is the
  // far edge of the page, so from scroll 0 the viewport can only go right.
  vp.scrollLeft = 0;
  var before = vp.scrollLeft;
  var box = miniC.getBoundingClientRect();
  miniC.dispatchEvent(
    new PointerEvent('pointerdown', {
      bubbles: true,
      cancelable: true,
      pointerId: 1,
      clientX: box.right - 1,
      clientY: box.top + box.height / 2,
    })
  );
  say('miniJumped', vp.scrollLeft > before);

  var pre = document.createElement('pre');
  pre.id = '__probe';
  pre.textContent = 'PROBE\\n' + log.join('\\n') + '\\nENDPROBE';
  document.body.appendChild(pre);
}, 150);
</script>`;

const probeFile = path.join(root, 'pages', '__probe.html');
writeFileSync(probeFile, readFileSync(page, 'utf8').replace('</body>', `${PROBE}\n</body>`));

const result = spawnSync(
  CHROME,
  [
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--window-size=1200,800',
    '--virtual-time-budget=2500',
    '--dump-dom',
    pathToFileURL(probeFile).href,
  ],
  { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 }
);
unlinkSync(probeFile);

if (result.status !== 0) {
  console.error(result.stderr);
  process.exit(1);
}

const match = result.stdout.match(/PROBE\n([\s\S]*?)\nENDPROBE/);
if (!match) {
  console.error('the probe did not run — the canvas script probably threw');
  process.exit(1);
}

const got = {};
for (const line of match[1].split('\n')) {
  const at = line.indexOf('=');
  if (at > 0) got[line.slice(0, at)] = line.slice(at + 1);
}

const expected = {
  // The palette is built from nav.js: 4 pages + 28 frames.
  dialog: 'true',
  rows: '3',
  opened: 'true',
  results: '32',
  filtered: '1',
  filteredName: 'Pricing',
  // "board" matches a page and its 24 frames, from another page.
  crossPage: '25',
  // The list navigates the canvas and the address bar follows.
  hash: '#home-mobile',
  active: 'home-mobile',
  current: 'home-mobile',
  // The minimap is hidden at fit, visible at 100%, and drawn — not just
  // unhidden — with the viewport in blue. Clicking its far edge scrolls.
  miniAtFit: 'true',
  miniAt100: 'false',
  miniBlue: 'true',
  miniJumped: 'true',
};

let failed = 0;
for (const [key, want] of Object.entries(expected)) {
  const ok = got[key] === want;
  if (!ok) failed += 1;
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${key}: ${got[key]}${ok ? '' : ` (want ${want})`}`);
}

if (failed > 0) process.exit(1);
console.log('canvas interactions: all good');
