import { describe, it, expect } from 'vitest';
import { mkdirSync, rmSync, writeFileSync } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { buildWholeFileExport, type WholeFileExportPayload } from '../src/shared/whole-file-export';

/**
 * Writes a real archive to `harness/out/archive/` so it can be opened and
 * looked at, not just asserted on.
 *
 * The assertions here are the ones a developer would make with their eyes:
 * the page places its frames where Figma did, a frame file is the frame on its
 * own, the component file is a fragment, and the index says which page uses
 * what. `harness/archive-check.mjs` then screenshots the canvas and the index,
 * which is the only way to see whether "looks like Figma's canvas" is true.
 */

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(__dirname, 'out', 'archive');

/**
 * A small but real stylesheet: the archive is judged on whether a frame looks
 * like a design sitting on a canvas, and an unstyled `<div>` cannot show that.
 */
const CSS = `* { box-sizing: border-box; }
body { margin: 0; }
.screen {
  width: 100%;
  height: 100%;
  background: #ffffff;
  padding: 56px;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  color: #1f2328;
}
.header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 56px; }
.logo { font-weight: 700; font-size: 20px; letter-spacing: -0.02em; }
.nav { display: flex; gap: 28px; color: #59636e; font-size: 14px; }
.title { font-size: 46px; font-weight: 700; margin: 0 0 16px; letter-spacing: -0.03em; }
.sub { color: #59636e; font-size: 17px; margin: 0 0 44px; max-width: 520px; }
.board { display: flex; gap: 24px; }
.card { flex: 1; background: #f6f7f9; border: 1px solid #e6e9ed; border-radius: 14px; padding: 18px; }
.card__media { height: 132px; background: #dfe3e8; border-radius: 9px; margin-bottom: 16px; }
.card__title { font-size: 16px; font-weight: 600; margin: 0 0 6px; }
.card__meta { font-size: 13px; color: #6e7781; }
.narrow { padding: 28px; }
.narrow .title { font-size: 28px; }
.narrow .board { flex-direction: column; }
.narrow .header { margin-bottom: 32px; }
.narrow .nav { display: none; }
.tile { padding: 26px; display: flex; flex-direction: column; gap: 10px; }
.tile--dark { background: #101114; color: #f5f5f5; }
.tile__n { font: 600 12px/1 ui-monospace, SFMono-Regular, monospace; color: #0d99ff; }
.tile__title { font-size: 22px; font-weight: 650; margin: 0; letter-spacing: -0.02em; }
.tile__bar { height: 8px; border-radius: 999px; background: #eceff3; overflow: hidden; }
.tile--dark .tile__bar { background: #24262c; }
.tile__fill { display: block; height: 100%; background: #0d99ff; }`;

function payload(): WholeFileExportPayload {
  const card = (title: string, meta: string) => `<div class="card" data-component="Card" data-component-id="2:9">
  <div class="card__media" data-component="Card" data-component-id="2:9"></div>
  <p class="card__title">${title}</p>
  <span class="card__meta">${meta}</span>
</div>`;

  const header = `<header class="header" data-component="Header" data-component-id="1:1">
  <span class="logo">Acme</span>
  <nav class="nav"><span>Product</span><span>Pricing</span><span>Docs</span></nav>
</header>`;

  const desktop = `  <div class="screen" data-component="Home" data-component-id="4:1">
${header}
    <h1 class="title">Design systems at scale</h1>
    <p class="sub">Every frame on this canvas sits exactly where Figma put it.</p>
    <div class="board">
      ${card('Shipping a plugin', '7 min read')}
      ${card('Type and rhythm', '4 min read')}
      ${card('Tokens that travel', '9 min read')}
    </div>
  </div>`;

  const mobile = `  <div class="screen narrow">
${header}
    <h1 class="title">Design systems</h1>
    <div class="board">
      ${card('Shipping a plugin', '7 min read')}
      ${card('Type and rhythm', '4 min read')}
    </div>
  </div>`;

  const settings = `  <div class="screen" data-component="Settings Panel" data-component-id="3:4">
    <h1 class="title">Account settings</h1>
    <p class="sub">Profile, billing and notifications.</p>
    <div class="board">
      ${card('Profile', 'Updated today')}
      ${card('Billing', 'Next invoice in 12 days')}
    </div>
  </div>`;

  const tile = (n: number, dark: boolean) => `  <div class="screen tile${dark ? ' tile--dark' : ''}" data-component="Tile" data-component-id="5:1">
    <span class="tile__n">${String(n).padStart(2, '0')}</span>
    <h1 class="tile__title">Tile ${n}</h1>
    <div class="tile__bar"><span class="tile__fill" style="width:${20 + n * 3}%"></span></div>
  </div>`;

  return {
    fileName: 'Acme Dashboard',
    fileKey: 'HARNESSKEY',
    generatedAt: '2026-10-17T10:00:00.000Z',
    responsive: false,
    css: CSS,
    pages: [
      {
        name: 'Home',
        nodeId: '0:1',
        frames: [
          {
            name: 'Home / Desktop',
            nodeId: '1:1',
            width: 1440,
            height: 900,
            x: 0,
            y: 0,
            html: desktop,
          },
          {
            name: 'Home / Mobile',
            nodeId: '1:2',
            width: 390,
            height: 844,
            x: 1560,
            y: 0,
            html: mobile,
          },
          { name: 'Pricing', nodeId: '1:3', width: 1440, height: 760, x: 0, y: 1000, html: desktop },
        ],
        isRtl: false,
        components: ['1:1', '2:9', '4:1'],
      },
      {
        name: 'Account Settings',
        nodeId: '0:2',
        frames: [
          { name: 'Settings', nodeId: '3:1', width: 1024, height: 800, x: 0, y: 0, html: settings },
        ],
        isRtl: false,
        components: ['2:9', '3:4'],
      },
      {
        // A board, not a page: 24 frames in a grid, which is the shape that
        // made the first canvas slow. It is here so the harness exercises the
        // two things that make it fast — mounting only what is on screen, and
        // dropping detail below the zoom where content is unreadable.
        name: 'Board',
        nodeId: '0:3',
        frames: Array.from({ length: 24 }, (_, i) => ({
          name: `Tile ${i + 1}`,
          nodeId: `5:${i + 1}`,
          width: 480,
          height: 320,
          x: (i % 6) * 520,
          y: Math.floor(i / 6) * 400,
          html: tile(i + 1, i % 3 === 0),
          background: i % 3 === 0 ? '#101114' : '#ffffff',
        })),
        isRtl: false,
        components: ['5:1'],
      },
      {
        name: 'Empty',
        nodeId: '0:4',
        frames: [],
        isRtl: false,
        components: [],
      },
    ],
    components: [
      {
        id: '1:1',
        name: 'Header',
        className: 'header',
        uses: 2,
        html: `  ${header}`,
      },
      {
        id: '2:9',
        name: 'Card',
        className: 'card',
        uses: 5,
        html: `  ${card('Shipping a plugin', '7 min read')}`,
      },
      {
        id: '3:4',
        name: 'Settings Panel',
        className: 'screen',
        uses: 1,
        html: settings,
      },
    ],
    assets: [],
    dedupe: { merged: 5, standalone: 0 },
    skipped: [{ name: 'Legacy', reason: 'page could not be loaded' }],
  };
}

describe('archive preview', () => {
  it('writes an openable archive whose pages place their frames like Figma', () => {
    rmSync(outDir, { recursive: true, force: true });
    mkdirSync(outDir, { recursive: true });

    const files = buildWholeFileExport(payload());
    for (const file of files) {
      const target = path.join(outDir, file.path);
      mkdirSync(path.dirname(target), { recursive: true });
      writeFileSync(target, file.base64 ? Buffer.from(file.content, 'base64') : file.content);
    }

    const page = files.find((f) => f.path === 'pages/home.html')!.content;

    // The canvas really is a coordinate system: the mobile frame is 1560px to
    // the right of the desktop one, and the second row starts at y = 1000.
    expect(page).toContain('data-w="2110"');
    expect(page).toContain('data-h="1920"');
    expect(page).toContain('left:80px;top:80px;width:1440px;height:900px');
    expect(page).toContain('left:1640px;top:80px;width:390px;height:844px');
    expect(page).toContain('left:80px;top:1080px;width:1440px;height:760px');

    // Every frame is a link to its own document, opening in a new tab.
    expect(page).toContain('href="../frames/home-desktop.html" target="_blank" rel="noopener"');
    expect(page).toContain('href="../frames/home-mobile.html" target="_blank" rel="noopener"');

    // What this proves is that the canvas passes the frame markup through
    // untouched — attributes and all — so the markers the generator emits
    // survive into the file. (That the generator emits them is pinned in
    // `src/shared/component-dedup.test.ts`.)
    expect(page).toContain('data-component-id="2:9"');
    expect(page).toContain('data-component="Header"');

    // A frame file is the frame, alone: same markup, its own document, no
    // canvas around it.
    const frame = files.find((f) => f.path === 'frames/home-desktop.html')!.content;
    expect(frame.startsWith('<!DOCTYPE html>')).toBe(true);
    expect(frame).toContain('<h1 class="title">Design systems at scale</h1>');
    expect(frame).not.toContain('__canvas');

    const component = files.find((f) => f.path === 'components/card.html')!.content;
    expect(component.startsWith('<!-- Card')).toBe(true);
    expect(component).not.toContain('<!DOCTYPE');

    // The chrome is shared, not inlined: one copy of each, at the root.
    for (const shared of ['canvas.css', 'canvas.js', 'nav.js', 'README.md']) {
      expect(files.map((f) => f.path)).toContain(shared);
    }
    expect(page).not.toContain('<style');

    // A page knows where it came from: one link back to Figma, on the page.
    expect(page).toContain('https://www.figma.com/design/HARNESSKEY?node-id=0-1');

    // The archive really is on disk for the screenshot step.
    expect(files.map((f) => f.path)).toContain('index.html');
  });
});
