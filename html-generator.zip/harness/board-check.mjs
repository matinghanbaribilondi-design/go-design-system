// Reads the real layout of `harness/out/board.html` out of Chrome.
//
//   npx vitest run harness/board.test.ts && node harness/board-check.mjs
//
// The board is four 261px columns with 24px gaps — a 1116px row. The question
// this answers is the one a CSS assertion cannot: how many columns actually
// share a line at each viewport width.
//
// The invariant is *not* "the row never splits 3 + 1". With one uniform floor
// per column that split is arithmetic: three columns always fit in a width that
// four do not, so a narrow band of widths has to produce it. What the fix
// guarantees is that the band sits at the row's minimum viable width — four
// floors plus three gaps — and not at the design width. That is the difference
// between "the row reflows when it runs out of room" and "the row breaks as soon
// as the preview is a pixel narrower than the frame".
import { spawnSync } from 'child_process';
import { existsSync, readFileSync } from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const file = path.join(__dirname, 'out', 'board.html');

if (!existsSync(file)) {
  console.error('missing board.html — run: npx vitest run harness/board.test.ts');
  process.exit(1);
}

const COLUMNS = 4;
const GAP = 24;

// The floor the exporter emitted, read back from the generated CSS so the check
// cannot disagree with the page it is measuring.
const css = readFileSync(file, 'utf8');
const floorMatch = css.match(/min-width: min\((\d+(?:\.\d+)?)px, 100%\)/);
if (!floorMatch) {
  console.error('no min-width floor found in board.html');
  process.exit(1);
}
const floor = Number(floorMatch[1]);
const minimumViable = COLUMNS * floor + (COLUMNS - 1) * GAP;

const WIDTHS = [1116, 1100, 1000, 900, 800, minimumViable, minimumViable - 4, 700, 480];
const url = pathToFileURL(file).href;

console.log(`floor ${floor}px  →  the row holds all four down to ${minimumViable}px\n`);

let failures = 0;
for (const width of WIDTHS) {
  const result = spawnSync(
    CHROME,
    [
      '--headless=new',
      '--no-sandbox',
      '--disable-gpu',
      '--hide-scrollbars',
      `--window-size=${width},600`,
      '--virtual-time-budget=2000',
      '--dump-dom',
      url,
    ],
    { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 }
  );

  const match = result.stdout.match(/<pre id="report">([^<]*)<\/pre>/);
  if (!match) {
    console.error(`  ${width}px  could not read the report`);
    failures += 1;
    continue;
  }

  const report = JSON.parse(match[1].replace(/&quot;/g, '"'));
  const perLine = report.perLine.join(' + ');
  const holdsAll = report.perLine.length === 1 && report.perLine[0] === COLUMNS;
  // Above the minimum viable width the row must not have split at all.
  const shouldHold = width >= minimumViable;
  const wrong = shouldHold && !holdsAll;
  if (wrong) failures += 1;

  console.log(
    `${wrong ? 'BAD ' : 'ok  '} ${String(width).padStart(4)}px  row ${report.rowWidth}px  ` +
      `${perLine}${shouldHold ? '   (must hold all four)' : ''}`
  );
}

if (failures > 0) {
  console.error(`\n${failures} width(s) broke the row above its minimum viable width.`);
  process.exit(1);
}
console.log('\nThe row holds all four columns down to its minimum viable width, and only below it.');
