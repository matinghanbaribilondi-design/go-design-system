import { describe, it } from 'vitest';
import { writeFileSync, mkdirSync } from 'fs';
import { generateCssForRoots } from '../src/generator/css-generator';
import { generateHtml } from '../src/generator/html-generator';
import { dedupeComponents } from '../src/shared/component-registry';
import type {
  ConversionOptions,
  IRNode,
  LayoutStyles,
  TypographyStyles,
  VisualStyles,
} from '../src/plugin/types/ir';

/**
 * Renders the same document twice — once with every instance coded from
 * scratch, once with instances reusing their component — and writes both to
 * `harness/out/` so `harness/dedupe-check.mjs` can screenshot them.
 *
 * The unit tests prove the *declarations* are equivalent. This proves the
 * *pixels* are: the browser is the only authority on cascade order, specificity
 * and the `@container` block that lands after every class rule.
 */

const OPT: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
  designWidth: 1280,
};

const text = (
  id: string,
  value: string,
  over: Partial<TypographyStyles> = {}
): IRNode => ({
  id,
  name: 'Text',
  className: id,
  tag: 'p',
  type: 'TEXT',
  layout: { display: 'block' },
  visual: {},
  typography: { fontSize: '14px', lineHeight: '1.5', color: '#0f172a', ...over },
  text: value,
  children: [],
});

/** A button: an instance of the same master every time it appears. */
function button(id: string, label: string, background = '#2563eb'): IRNode {
  const layout: LayoutStyles = {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: '8px',
    padding: { top: 12, right: 24, bottom: 12, left: 24 },
  };
  const visual: VisualStyles = { background, borderRadius: '8px' };
  const typography: TypographyStyles = {
    fontSize: '14px',
    fontWeight: 600,
    lineHeight: '1.4',
    color: '#ffffff',
  };

  return {
    id,
    name: 'Button',
    className: id,
    tag: 'button',
    type: 'INSTANCE',
    componentRef: { id: 'master-button', name: 'Button' },
    layout,
    visual,
    children: [
      {
        id: `${id}__label`,
        name: 'Label',
        className: `${id}__label`,
        tag: 'span',
        type: 'TEXT',
        layout: { display: 'block' },
        visual: {},
        typography,
        text: label,
        children: [],
      },
    ],
  };
}

/** A card: also an instance, and it contains a button instance of its own. */
function card(id: string, title: string, buttonBackground?: string): IRNode {
  return {
    id,
    name: 'Card',
    className: id,
    tag: 'div',
    type: 'INSTANCE',
    componentRef: { id: 'master-card', name: 'Card' },
    layout: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px',
      padding: { top: 20, right: 20, bottom: 20, left: 20 },
      width: '320px',
    },
    visual: { background: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0' },
    children: [text(`${id}__title`, title, { fontSize: '18px', fontWeight: 600 }), button(`${id}__cta`, 'Open', buttonBackground)],
  };
}

/**
 * A rail + body row — the shape that emits an `@container` query.
 *
 * This is the interaction most likely to break under reuse: the `@container`
 * block is emitted *after* every class rule, so an instance whose override
 * touches `flex-basis` or `max-width` has to lose to it in both documents, in
 * the same way, or the stacked layout would differ.
 */
function shell(id: string, railWidth: number): IRNode {
  const threshold = '1120px';
  return {
    id,
    name: 'Shell',
    className: id,
    tag: 'div',
    type: 'INSTANCE',
    componentRef: { id: 'master-shell', name: 'Shell' },
    layout: {
      display: 'flex',
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: '24px',
      width: '100%',
      maxWidth: '1280px',
      containerType: 'inline-size',
    },
    visual: { background: '#ffffff' },
    children: [
      {
        id: `${id}__rail`,
        name: 'Rail',
        className: `${id}__rail`,
        tag: 'aside',
        type: 'FRAME',
        layout: {
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          width: `${railWidth}px`,
          flexBasis: `${railWidth}px`,
          maxWidth: `${railWidth}px`,
          stackFill: { maxInlineSize: threshold },
        },
        visual: { background: '#e2e8f0' },
        children: [text(`${id}__rail-text`, 'Navigation', { fontSize: '13px' })],
      },
      {
        id: `${id}__body`,
        name: 'Body',
        className: `${id}__body`,
        tag: 'main',
        type: 'FRAME',
        layout: {
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          flexGrow: 1,
          minWidth: '280px',
          stackFill: { maxInlineSize: threshold },
        },
        visual: {},
        children: [text(`${id}__body-text`, 'Content', { fontSize: '13px' })],
      },
    ],
  };
}

/** The page: two card instances, one of them with a recoloured button. */
function buildPage(): IRNode[] {
  const root: IRNode = {
    id: 'page',
    name: 'Page',
    className: 'page',
    tag: 'div',
    type: 'FRAME',
    layout: {
      display: 'flex',
      flexDirection: 'column',
      gap: '24px',
      padding: { top: 40, right: 40, bottom: 40, left: 40 },
      width: '100%',
      maxWidth: '1280px',
    },
    visual: { background: '#f1f5f9' },
    children: [
      {
        id: 'header',
        name: 'Header',
        className: 'header',
        tag: 'header',
        type: 'FRAME',
        layout: {
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '16px',
        },
        visual: {},
        children: [
          text('header__title', 'Projects', { fontSize: '24px', fontWeight: 700 }),
          button('header__cta', 'New project'),
        ],
      },
      {
        id: 'grid',
        name: 'Grid',
        className: 'grid',
        tag: 'div',
        type: 'FRAME',
        layout: {
          display: 'flex',
          flexDirection: 'row',
          flexWrap: 'wrap',
          gap: '16px',
          alignItems: 'flex-start',
        },
        visual: {},
        children: [
          card('card-a', 'Alpha'),
          card('card-b', 'Beta'),
          card('card-c', 'Gamma', '#dc2626'),
          card('card-d', 'Delta'),
        ],
      },
      // Two shells of the same master; the second has a narrower rail, so it
      // reuses the shell and carries the difference as an override.
      shell('shell-a', 240),
      shell('shell-b', 200),
    ],
  };
  return [root];
}

function documentFor(roots: IRNode[], title: string): string {
  const css = generateCssForRoots(roots, OPT, false);
  const body = roots.map((root) => generateHtml(root, 1)).join('\n');
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>${title}</title>
<style>
${css}
</style>
</head>
<body>
${body}
</body>
</html>`;
}

describe('dedupe equivalence corpus', () => {
  it('emits the same document with and without component reuse', () => {
    const before = buildPage();
    const after = buildPage();

    const beforeHtml = documentFor(before, 'before dedupe');
    dedupeComponents(after);
    const afterHtml = documentFor(after, 'after dedupe');

    mkdirSync('harness/out', { recursive: true });
    writeFileSync('harness/out/dedupe-before.html', beforeHtml);
    writeFileSync('harness/out/dedupe-after.html', afterHtml);

    // The optimisation has to be visible in the output, or there is nothing to
    // compare: the after-document must carry modifier classes.
    if (!/class="[^"]+ [^"]+--v\d+_\d+"/.test(afterHtml)) {
      throw new Error('expected at least one instance to reuse a component with an override');
    }
  });
});
