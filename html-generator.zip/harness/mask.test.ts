import { describe, it } from 'vitest';
import { writeFileSync, mkdirSync } from 'fs';
import { convertNodeToIR } from '../src/plugin/converter/index';
import { generateFullHtmlDocument } from '../src/generator/html-generator';
import type { ConversionOptions } from '../src/plugin/types/ir';

/**
 * Mask fixture, measured in a real browser by `harness/mask-check.mjs`.
 *
 * Unlike the layout corpus this goes through the whole converter, because the
 * claim being tested is end-to-end: a layer marked "Use as mask" must vanish
 * from the output and the layers it shapes must arrive clipped to its outline.
 *
 * Solid fills on purpose — a colour tells the check which layer is on top at a
 * given point, and `elementFromPoint` honours `clip-path`, so the hit test is a
 * pixel test without a screenshot.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: false,
  designWidth: 400,
};

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'n',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: 100,
    height: 100,
    x: 0,
    y: 0,
    rotation: 0,
    layoutMode: 'NONE',
    children: [],
    fills: [],
    strokes: [],
    effects: [],
    ...over,
  };
}

const fill = (rgb: { r: number; g: number; b: number }) => [
  { type: 'SOLID', visible: true, opacity: 1, color: { ...rgb, a: 1 } },
];

describe('mask corpus', () => {
  it('22 mask: rounded-rect card photo + ellipse badge', async () => {
    const card = mk({
      id: 'card',
      name: 'Card',
      width: 400,
      height: 300,
      children: [
        // Shapes the photo. Never painted.
        mk({
          id: 'mask-rect',
          name: 'Mask',
          type: 'RECTANGLE',
          isMask: true,
          maskType: 'ALPHA',
          cornerRadius: 24,
          width: 400,
          height: 300,
          fills: fill({ r: 0, g: 0, b: 0 }),
        }),
        mk({
          id: 'photo',
          name: 'Photo',
          type: 'RECTANGLE',
          width: 400,
          height: 300,
          fills: fill({ r: 1, g: 0, b: 0 }),
        }),
        // A second mask: it must not reach back to the photo.
        mk({
          id: 'mask-ellipse',
          name: 'Ellipse Mask',
          type: 'ELLIPSE',
          isMask: true,
          maskType: 'ALPHA',
          width: 160,
          height: 160,
          x: 200,
          y: 100,
          fills: fill({ r: 0, g: 0, b: 0 }),
        }),
        mk({
          id: 'badge',
          name: 'Badge',
          type: 'RECTANGLE',
          width: 240,
          height: 200,
          x: 160,
          y: 80,
          fills: fill({ r: 0, g: 0, b: 1 }),
        }),
      ],
    });

    const ir = await convertNodeToIR(card, null, options);
    if (!ir) throw new Error('conversion produced no IR');

    const html = generateFullHtmlDocument(ir, options);
    mkdirSync('harness/out', { recursive: true });
    writeFileSync('harness/out/22-mask.html', html);
  });
});
