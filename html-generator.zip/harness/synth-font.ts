/**
 * A font *specimen*, so the harness can measure font metrics.
 *
 * The font-metrics pass reads `head`, `hhea` and `OS/2` out of the file the
 * plugin embeds, and the claim under test is that the fallback the plugin
 * registers from those numbers reproduces the line box the file describes. A
 * measurement needs a file whose numbers are known, so this writes one.
 *
 * A machine-installed font cannot do that job: its metrics come with the OS
 * patch level, so the expected line box would have to be read back out of the
 * same file the browser is reading, which makes the comparison circular.
 *
 * Only the three tables that carry metrics are written. That is deliberate.
 * The font is never *rendered* — the check measures the fallback it
 * registers, not the glyphs it draws — and a hand-written `glyf`/`loca` pair is
 * a far harder thing to get through FreeType than the three metric tables are
 * to get through the plugin's own reader: an sfnt with no outline tables at all
 * parses as a metrics specimen, while a sfnt with a malformed outline is
 * rejected by the renderer and the check would silently compare two fallback
 * fonts instead of a font and its fallback. (Chrome also refuses a format-4
 * `cmap` whose last segment is not the 0xFFFF sentinel, and a font with no
 * `name` table — both of which are load-bearing for anyone who does take this
 * further.)
 */

export interface SynthFontMetrics {
  unitsPerEm: number;
  /** `hhea.ascender`, in font units. */
  ascender: number;
  /** `hhea.descender`, negative, as the convention has it. */
  descender: number;
  lineGap: number;
  /** `OS/2.xAvgCharWidth` — the width signal `size-adjust` is computed from. */
  avgCharWidth: number;
}

/**
 * Deliberately nothing like the reference the overrides are calibrated against
 * (Arial: 2048 / 1854 / -434 / 67 / 904). If they were the same, a wrong
 * override would be cancelled out by a wrong reference and the check would
 * pass for the wrong reason.
 */
export const SYNTH_METRICS: SynthFontMetrics = {
  unitsPerEm: 1000,
  ascender: 900,
  descender: -300,
  lineGap: 0,
  avgCharWidth: 500,
};

function u16(value: number): number[] {
  return [(value >> 8) & 0xff, value & 0xff];
}

function i16(value: number): number[] {
  return u16(value & 0xffff);
}

function ascii(text: string): number[] {
  return [...text].map((char) => char.charCodeAt(0));
}

/** `head` — 54 bytes. Only `unitsPerEm` (offset 18) is read back by the plugin. */
function headTable(metrics: SynthFontMetrics): number[] {
  const bytes = new Array<number>(54).fill(0);
  const put = (offset: number, values: number[]) => bytes.splice(offset, values.length, ...values);
  put(0, [0x00, 0x01, 0x00, 0x00]); // version 1.0
  put(12, [0x5f, 0x0f, 0x3c, 0xf5]); // magicNumber
  put(16, u16(0x0003)); // flags
  put(18, u16(metrics.unitsPerEm));
  put(42, i16(metrics.ascender)); // yMax
  return bytes;
}

/**
 * `hhea` — 36 bytes. ascender/descender/lineGap are offsets 4/6/8, which is the
 * only part of the table that decides a line box.
 */
function hheaTable(metrics: SynthFontMetrics): number[] {
  const bytes = new Array<number>(36).fill(0);
  const put = (offset: number, values: number[]) => bytes.splice(offset, values.length, ...values);
  put(0, [0x00, 0x01, 0x00, 0x00]);
  put(4, i16(metrics.ascender));
  put(6, i16(metrics.descender));
  put(8, i16(metrics.lineGap));
  return bytes;
}

/**
 * `OS/2` — 96 bytes, version 4. `xAvgCharWidth` is offset 2, and the typo
 * metrics are set to the same numbers as `hhea` so a renderer that prefers
 * either one measures the same font.
 */
function os2Table(metrics: SynthFontMetrics): number[] {
  const bytes = new Array<number>(96).fill(0);
  const put = (offset: number, values: number[]) => bytes.splice(offset, values.length, ...values);
  put(0, u16(4)); // version
  put(2, i16(metrics.avgCharWidth));
  put(60, u16(0x0040)); // fsSelection: USE_TYPO_METRICS off
  put(66, i16(metrics.ascender)); // sTypoAscender
  put(68, i16(metrics.descender)); // sTypoDescender
  put(70, i16(metrics.lineGap)); // sTypoLineGap
  put(72, u16(metrics.ascender)); // usWinAscent
  put(74, u16(Math.abs(metrics.descender))); // usWinDescent
  return bytes;
}

/** Assembles a table directory around the given tables, 4-byte aligned. */
function assemble(tables: Record<string, number[]>): Uint8Array {
  const entries = Object.entries(tables);
  const directory: number[] = [];
  let offset = 12 + entries.length * 16;
  const bodies: number[] = [];

  for (const [name, body] of entries) {
    directory.push(...ascii(name), ...u32(0), ...u32(offset), ...u32(body.length));
    const padded = [...body, ...new Array<number>((4 - (body.length % 4)) % 4).fill(0)];
    bodies.push(...padded);
    offset += padded.length;
  }

  return Uint8Array.from([
    0x00, 0x01, 0x00, 0x00, // sfntVersion: TrueType
    ...u16(entries.length),
    ...u16(8), // searchRange
    ...u16(3), // entrySelector
    ...u16(0), // rangeShift
    ...directory,
    ...bodies,
  ]);
}

function u32(value: number): number[] {
  return [(value >>> 24) & 0xff, (value >>> 16) & 0xff, (value >>> 8) & 0xff, value & 0xff];
}

/** An sfnt carrying exactly the vertical metrics given. */
export function synthFont(over: Partial<SynthFontMetrics> = {}): Uint8Array {
  const metrics = { ...SYNTH_METRICS, ...over };
  return assemble({
    'OS/2': os2Table(metrics),
    head: headTable(metrics),
    hhea: hheaTable(metrics),
  });
}

const BASE64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

/** The base64 payload a `@font-face` data URL is built from. */
export function toBase64(bytes: Uint8Array): string {
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const a = bytes[i]!;
    const b = bytes[i + 1];
    const c = bytes[i + 2];
    out += BASE64[a >> 2];
    out += BASE64[((a & 0x03) << 4) | ((b ?? 0) >> 4)];
    out += b === undefined ? '=' : BASE64[((b & 0x0f) << 2) | ((c ?? 0) >> 6)];
    out += c === undefined ? '=' : BASE64[c & 0x3f];
  }
  return out;
}
