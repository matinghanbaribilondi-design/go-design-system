window.__measure = function () {
  const vw = document.documentElement.clientWidth;
  const nodes = [];
  const root = document.body.firstElementChild;
  for (const el of document.querySelectorAll('*')) {
    if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') continue;
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    const parent = el.parentElement;
    const pr = parent && parent !== document.body ? parent.getBoundingClientRect() : null;
    // Content wider than the element's own content box (text or a wide child).
    const contentOverflow = el.scrollWidth - el.clientWidth;
    // Element's border box sticking out of its parent's border box on the right.
    const escapesParent = pr ? Math.round(r.right - pr.right) : 0;
    // Element taller than a clipped parent.
    const pcs = parent ? getComputedStyle(parent) : null;
    const clippedBy = pcs && pcs.overflow !== 'visible' ? parent.className : null;
    const escapesBottom = pr ? Math.round(r.bottom - pr.bottom) : 0;
    nodes.push({
      cls: (typeof el.className === 'string' ? el.className : el.tagName).slice(0, 30),
      tag: el.tagName,
      w: Math.round(r.width),
      h: Math.round(r.height),
      contentOverflow: Math.round(contentOverflow),
      escapesParent,
      escapesBottom: Math.max(0, escapesBottom),
      clippedBy,
      parentW: pr ? Math.round(pr.width) : null,
      text: (el.children.length === 0 ? (el.textContent || '').trim().slice(0, 26) : ''),
    });
  }
  return { vw, pageScrollW: document.documentElement.scrollWidth, nodes };
};
