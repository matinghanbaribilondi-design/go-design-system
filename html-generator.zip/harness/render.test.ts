import { describe, it } from 'vitest';
import { writeFileSync, mkdirSync } from 'fs';
import { generateCss } from '../src/generator/css-generator';
import { generateHtml, hasRtlInTree } from '../src/generator/html-generator';
import { mk, toIR, OPT } from './mock';

function emit(name: string, node: any, opts = OPT) {
  const ir = toIR(node, null, opts);
  const isRtl = hasRtlInTree(ir);
  const css = generateCss(ir, opts, isRtl);
  const body = generateHtml(ir, 1);
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
${css}
</style></head><body>${body}</body></html>`;
  mkdirSync('harness/out', { recursive: true });
  writeFileSync(`harness/out/${name}.html`, html);
}

const T = (o: Record<string, unknown> = {}) => mk({ type: 'TEXT', characters: 'Sample text', ...o });

/** A 1200-wide page wrapper. */
const page = (children: any[], o: Record<string, unknown> = {}) =>
  mk({ id: 'root', name: 'Page', layoutMode: 'VERTICAL', width: 1200, height: 900, children, ...o });

describe('corpus', () => {
  it('01 header-with-search', () => {
    const logo = mk({ id: 'logo', name: 'Logo', width: 120, height: 40 });
    const search = mk({ id: 's', name: 'Search', width: 700, height: 40, layoutMode: 'HORIZONTAL',
      children: [mk({ id: 'si', name: 'Input', width: 640, height: 36 })] });
    const actions = mk({ id: 'a', name: 'Actions', width: 200, height: 40, layoutMode: 'HORIZONTAL', itemSpacing: 8,
      children: [mk({ id: 'a1', name: 'Icon', width: 32, height: 32 }), mk({ id: 'a2', name: 'Icon', width: 32, height: 32 })] });
    emit('01-header', page([mk({ id: 'h', name: 'Header', layoutMode: 'HORIZONTAL', width: 1200, height: 72,
      itemSpacing: 24, primaryAxisAlignItems: 'SPACE_BETWEEN', counterAxisAlignItems: 'CENTER',
      children: [logo, search, actions] })]));
  });

  it('02 form: label + input rows', () => {
    const field = (id: string, label: string) => mk({ id, name: `Field ${id}`, layoutMode: 'VERTICAL', width: 520, height: 72, itemSpacing: 8,
      children: [T({ id: `${id}l`, name: 'Label', characters: label, width: 520, height: 20 }),
                 mk({ id: `${id}i`, name: 'Input', width: 520, height: 44 })] });
    emit('02-form', page([mk({ id: 'f', name: 'Form', layoutMode: 'VERTICAL', width: 1200, height: 400, itemSpacing: 24,
      paddingTop: 48, paddingRight: 48, paddingBottom: 48, paddingLeft: 48,
      children: [field('a', 'Full name'), field('b', 'Email address')] })]));
  });

  it('03 table: 5 columns of rows', () => {
    const cols = [240, 180, 160, 140, 120];
    const row = (ri: number) => mk({ id: `r${ri}`, name: `Row ${ri}`, layoutMode: 'HORIZONTAL', width: 900, height: 48, itemSpacing: 16,
      children: cols.map((w, i) => T({ id: `r${ri}c${i}`, name: `Cell ${i}`, characters: `Cell ${ri}-${i}`, width: w, height: 20 })) });
    emit('03-table', page([mk({ id: 't', name: 'Table', layoutMode: 'VERTICAL', width: 1200, height: 400, itemSpacing: 0,
      children: [0,1,2,3,4].map(row) })]));
  });

  it('04 footer: 4 link columns', () => {
    const col = (i: number) => mk({ id: `fc${i}`, name: `Column ${i}`, layoutMode: 'VERTICAL', width: 260, height: 200, itemSpacing: 12,
      children: [T({ id: `fch${i}`, name: 'Heading', characters: `Heading ${i}`, width: 260, height: 24 }),
                 T({ id: `fcl${i}`, name: 'Link', characters: 'A link here', width: 260, height: 20 })] });
    emit('04-footer', page([mk({ id: 'f', name: 'Footer Columns', layoutMode: 'HORIZONTAL', width: 1200, height: 280, itemSpacing: 32,
      paddingTop: 48, paddingRight: 48, paddingBottom: 48, paddingLeft: 48,
      children: [0,1,2,3].map(col) })]));
  });

  it('05 hero: text beside image', () => {
    const copy = mk({ id: 'copy', name: 'Copy', layoutMode: 'VERTICAL', width: 520, height: 360, itemSpacing: 24,
      children: [T({ id: 'h1', name: 'Title', characters: 'A headline that is reasonably long', width: 520, height: 120 }),
                 T({ id: 'p1', name: 'Body', characters: 'Body copy explaining the product in a couple of sentences.', width: 520, height: 80 }),
                 mk({ id: 'cta', name: 'Button', width: 160, height: 48 })] });
    const img = mk({ id: 'hero', name: 'Hero Image', width: 560, height: 400, fills: [{ type: 'IMAGE', imageHash: 'x', scaleMode: 'FILL', visible: true }] });
    emit('05-hero', page([mk({ id: 'h', name: 'Hero Row', layoutMode: 'HORIZONTAL', width: 1200, height: 480, itemSpacing: 48,
      paddingTop: 64, paddingRight: 64, paddingBottom: 64, paddingLeft: 64, counterAxisAlignItems: 'CENTER',
      children: [copy, img] })]));
  });

  it('06 stat cards row of 4', () => {
    const card = (i: number) => mk({ id: `s${i}`, name: `Stat ${i}`, layoutMode: 'VERTICAL', width: 258, height: 140, itemSpacing: 8,
      paddingTop: 20, paddingRight: 20, paddingBottom: 20, paddingLeft: 20,
      children: [T({ id: `sv${i}`, name: 'Value', characters: '12,480', width: 218, height: 40 }),
                 T({ id: `sl${i}`, name: 'Label', characters: 'Total revenue this month', width: 218, height: 20 })] });
    emit('06-stats', page([mk({ id: 'r', name: 'Stats Row', layoutMode: 'HORIZONTAL', width: 1200, height: 140, itemSpacing: 24,
      children: [0,1,2,3].map(card) })]));
  });

  it('07 modal: centered fixed-width dialog over scrim', () => {
    const frame = mk({ id: 'root', name: 'Modal Screen', width: 1200, height: 800, layoutMode: 'NONE', children: [] });
    const scrim = mk({ id: 'scrim', name: 'Scrim', width: 1200, height: 800, x: 0, y: 0 });
    const dlg = mk({ id: 'dlg', name: 'Dialog', width: 480, height: 280, x: 360, y: 260, layoutMode: 'VERTICAL', itemSpacing: 16,
      paddingTop: 24, paddingRight: 24, paddingBottom: 24, paddingLeft: 24,
      children: [T({ id: 'dt', name: 'Title', characters: 'Confirm this action', width: 432, height: 28 }),
                 T({ id: 'db', name: 'Body', characters: 'This cannot be undone.', width: 432, height: 44 })] });
    frame.children = [scrim, dlg];
    emit('07-modal', frame);
  });

  it('08 tabs row of 5 equal chips', () => {
    const tab = (i: number) => mk({ id: `t${i}`, name: `Tab ${i}`, width: 160, height: 40,
      children: [T({ id: `tl${i}`, name: 'Label', characters: `Tab ${i}`, width: 120, height: 20 })] });
    emit('08-tabs', page([mk({ id: 'tb', name: 'Tabs', layoutMode: 'HORIZONTAL', width: 1200, height: 40, itemSpacing: 8,
      children: [0,1,2,3,4].map(tab) })]));
  });

  it('09 user rows: avatar + name + badge', () => {
    const row = (i: number) => mk({ id: `u${i}`, name: `User ${i}`, layoutMode: 'HORIZONTAL', width: 560, height: 56, itemSpacing: 12, counterAxisAlignItems: 'CENTER',
      children: [mk({ id: `ua${i}`, name: 'Avatar', width: 40, height: 40 }),
                 T({ id: `un${i}`, name: 'Name', characters: 'A Person Name', width: 300, height: 20 }),
                 mk({ id: `ub${i}`, name: 'Badge', width: 60, height: 24 })] });
    emit('09-users', page([mk({ id: 'list', name: 'User List', layoutMode: 'VERTICAL', width: 560, height: 300, itemSpacing: 8,
      children: [0,1,2].map(row) })]));
  });

  it('10 pricing: 3 plan cards with CTA', () => {
    const plan = (i: number) => mk({ id: `p${i}`, name: `Plan ${i}`, layoutMode: 'VERTICAL', width: 373, height: 420, itemSpacing: 20,
      paddingTop: 32, paddingRight: 32, paddingBottom: 32, paddingLeft: 32, counterAxisAlignItems: 'CENTER',
      children: [T({ id: `pn${i}`, name: 'Name', characters: 'Professional', width: 309, height: 28 }),
                 T({ id: `pp${i}`, name: 'Price', characters: '$49', width: 309, height: 56 }),
                 T({ id: `pf${i}`, name: 'Features', characters: 'Everything in Starter, plus more seats.', width: 309, height: 80 }),
                 mk({ id: `pc${i}`, name: 'CTA Button', width: 309, height: 48 })] });
    emit('10-pricing', page([mk({ id: 'r', name: 'Plans', layoutMode: 'HORIZONTAL', width: 1200, height: 420, itemSpacing: 40,
      children: [0,1,2].map(plan) })]));
  });

  it('11 article: prose column with headings', () => {
    emit('11-article', page([mk({ id: 'a', name: 'Article', layoutMode: 'VERTICAL', width: 1200, height: 600, itemSpacing: 24,
      paddingTop: 64, paddingRight: 64, paddingBottom: 64, paddingLeft: 64,
      children: [
        T({ id: 'h', name: 'Heading', characters: 'Understanding layout constraint systems', width: 1072, height: 48 }),
        T({ id: 'p1', name: 'Para', characters: 'A paragraph of body copy that runs to a couple of lines in the column.', width: 1072, height: 72 }),
        T({ id: 'q', name: 'Quote', characters: 'A pull quote that stands apart from the body.', width: 1072, height: 48 }),
        T({ id: 'p2', name: 'Para', characters: 'Another paragraph of body copy following the quote.', width: 1072, height: 72 }),
      ] })]));
  });

  it('12 gallery: 2x3 image grid', () => {
    const tile = (i: number) => mk({ id: `g${i}`, name: `Tile ${i}`, width: 384, height: 260,
      fills: [{ type: 'IMAGE', imageHash: `h${i}`, scaleMode: 'FILL', visible: true }] });
    emit('12-gallery', page([mk({ id: 'r', name: 'Gallery', layoutMode: 'HORIZONTAL', width: 1200, height: 560, itemSpacing: 24,
      children: [0,1,2,3,4,5].map(tile) })]));
  });

  it('13 breadcrumbs row of small items', () => {
    const crumb = (i: number) => mk({ id: `c${i}`, name: `Crumb ${i}`, width: 96, height: 20,
      children: [T({ id: `ct${i}`, name: 'Label', characters: `Step ${i}`, width: 96, height: 20 })] });
    emit('13-breadcrumbs', page([mk({ id: 'b', name: 'Breadcrumbs', layoutMode: 'HORIZONTAL', width: 1200, height: 20, itemSpacing: 8,
      children: [0,1,2,3,4,5].map(crumb) })]));
  });

  it('14 sidebar nav: rail + content, rail has icons + labels', () => {
    const navItem = (i: number) => mk({ id: `ni${i}`, name: `Nav Item ${i}`, layoutMode: 'HORIZONTAL', width: 264, height: 44, itemSpacing: 12, counterAxisAlignItems: 'CENTER',
      children: [mk({ id: `nii${i}`, name: 'Icon', width: 20, height: 20 }),
                 T({ id: `nit${i}`, name: 'Label', characters: 'Dashboard', width: 180, height: 20 })] });
    const rail = mk({ id: 'rail', name: 'Sidebar', layoutMode: 'VERTICAL', width: 296, height: 640, itemSpacing: 4,
      paddingTop: 16, paddingRight: 16, paddingBottom: 16, paddingLeft: 16, children: [0,1,2,3,4].map(navItem) });
    const body = mk({ id: 'body', name: 'Main Content', layoutMode: 'VERTICAL', width: 856, height: 640, itemSpacing: 16, children: [] });
    emit('14-sidenav', page([mk({ id: 'shell', name: 'App Shell', layoutMode: 'HORIZONTAL', width: 1200, height: 640, itemSpacing: 24,
      children: [rail, body] })]));
  });

  it('15 fixed-size icon button with padding (padding blowout)', () => {
    emit('15-iconbtn', page([mk({ id: 'b', name: 'Icon Button', layoutMode: 'HORIZONTAL', width: 20, height: 20,
      paddingTop: 8, paddingRight: 8, paddingBottom: 8, paddingLeft: 8, counterAxisAlignItems: 'CENTER', primaryAxisAlignItems: 'CENTER',
      children: [mk({ id: 'i', name: 'Icon', width: 20, height: 20 })] })]));
  });

  it('16 long unbroken string in narrow column', () => {
    emit('16-longword', page([mk({ id: 'c', name: 'Card', layoutMode: 'VERTICAL', width: 360, height: 200,
      paddingTop: 16, paddingRight: 16, paddingBottom: 16, paddingLeft: 16,
      children: [T({ id: 't', name: 'Body', characters: 'Supercalifragilisticexpialidociousness_and_more', width: 328, height: 24 })] })]));
  });

  it('17 nested rows: row in row in row', () => {
    const inner = mk({ id: 'i', name: 'Inner Row', layoutMode: 'HORIZONTAL', width: 300, height: 80, itemSpacing: 12,
      children: [mk({ id: 'ia', name: 'A', width: 140, height: 80 }), mk({ id: 'ib', name: 'B', width: 140, height: 80 })] });
    const mid = mk({ id: 'm', name: 'Middle Row', layoutMode: 'HORIZONTAL', width: 640, height: 120, itemSpacing: 20,
      children: [mk({ id: 'ma', name: 'A', width: 300, height: 120 }), inner] });
    emit('17-nested', page([mk({ id: 'o', name: 'Outer Row', layoutMode: 'HORIZONTAL', width: 1200, height: 200, itemSpacing: 40,
      children: [mid, mk({ id: 'ob', name: 'B', width: 520, height: 200 })] })]));
  });

  it('18 rtl dashboard', () => {
    const rail = mk({ id: 'rail', name: 'نوار کناری', layoutMode: 'VERTICAL', width: 300, height: 600, itemSpacing: 12, children: [
      T({ id: 'r1', name: 'آیتم', characters: 'داشبورد اصلی', width: 260, height: 24 }),
      T({ id: 'r2', name: 'آیتم', characters: 'گزارش‌های مالی', width: 260, height: 24 }),
    ] });
    const body = mk({ id: 'body', name: 'محتوا', layoutMode: 'VERTICAL', width: 860, height: 600, itemSpacing: 24, children: [
      T({ id: 'b1', name: 'عنوان', characters: 'خلاصه عملکرد این ماه', width: 800, height: 36 }),
      mk({ id: 'cards', name: 'کارت‌ها', layoutMode: 'HORIZONTAL', width: 860, height: 160, itemSpacing: 20, children: [
        mk({ id: 'k1', name: 'کارت', width: 420, height: 160 }), mk({ id: 'k2', name: 'کارت', width: 420, height: 160 })] }),
    ] });
    emit('18-rtl-dash', page([mk({ id: 's', name: 'پوسته', layoutMode: 'HORIZONTAL', width: 1200, height: 600, itemSpacing: 40,
      children: [rail, body] })]));
  });

  it('19 overlapping absolute layers', () => {
    const frame = mk({ id: 'root', name: 'Card Canvas', width: 400, height: 300, layoutMode: 'NONE', children: [] });
    frame.children = [
      mk({ id: 'bg', name: 'Background', width: 400, height: 300, x: 0, y: 0 }),
      mk({ id: 'tb', name: 'Tag Badge', width: 80, height: 28, x: 12, y: 12 }),
      mk({ id: 'cta', name: 'CTA', width: 120, height: 44, x: 264, y: 240 }),
    ];
    emit('19-absolute', frame);
  });

  it('20 status bar: icon + text + trailing action', () => {
    emit('20-statusbar', page([mk({ id: 'sb', name: 'Status Bar', layoutMode: 'HORIZONTAL', width: 1200, height: 56, itemSpacing: 12,
      paddingTop: 12, paddingRight: 16, paddingBottom: 12, paddingLeft: 16, counterAxisAlignItems: 'CENTER',
      children: [mk({ id: 'si', name: 'Icon', width: 20, height: 20 }),
                 T({ id: 'st', name: 'Message', characters: 'Your export completed successfully.', width: 900, height: 20 }),
                 mk({ id: 'sa', name: 'Action Button', width: 120, height: 32 })] })])
  );
});

  it('21 grid: a 3x2 card grid that reflows to 2 and then 1', () => {
    const card = (i: number) => mk({ id: `gc${i}`, name: `Card ${i}`, layoutMode: 'VERTICAL', width: 384, height: 192, itemSpacing: 8,
      layoutSizingHorizontal: 'FILL', layoutSizingVertical: 'FILL',
      paddingTop: 16, paddingRight: 16, paddingBottom: 16, paddingLeft: 16,
      children: [T({ id: `gct${i}`, name: 'Title', characters: `Card number ${i}`, width: 352, height: 24 }),
                 T({ id: `gcb${i}`, name: 'Body', characters: 'Supporting copy for this card.', width: 352, height: 20 })] });
    emit('21-grid', page([mk({ id: 'grid', name: 'Card Grid', layoutMode: 'GRID', width: 1200, height: 400,
      gridColumnCount: 3, gridRowCount: 2, gridColumnGap: 24, gridRowGap: 16,
      gridColumnSizes: [0, 1, 2].map(() => ({ type: 'FLEX', value: 1 })),
      gridRowSizes: [0, 1].map(() => ({ type: 'FLEX', value: 1 })),
      gridItemsPositioning: 'ROW_AUTO_FLOW',
      children: [0, 1, 2, 3, 4, 5].map(card) })]));
  });
});
