// Chrome, driven from the command line, for the measurements a CSS string
// cannot make.
//
// Two shapes are enough for every check in this folder:
//
//   probe()      load a page, let its script write a JSON report into the DOM,
//                and read that report back out of `--dump-dom`. Good for
//                geometry, computed styles and hit tests.
//   screenshot() load a page and hand back its pixels. Good for colour — a
//                gradient, a blend mode, a whole page compared to a reference.
import { spawnSync } from 'child_process';
import { existsSync, readFileSync, writeFileSync } from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { decodePng } from './png.mjs';

export const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
export const OUT = path.join(path.dirname(fileURLToPath(import.meta.url)), 'out');

function run(args) {
  const result = spawnSync(CHROME, args, { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  if (result.error) throw result.error;
  return result;
}

/**
 * Runs a page and returns whatever it wrote into `<pre id="report">`.
 *
 * The page's script has to have finished before the DOM is dumped, so
 * `--virtual-time-budget` is what turns "probably loaded" into "settled".
 */
export function probe(html, { width = 1400, height = 1000, budget = 3000 } = {}) {
  const file = path.join(OUT, `_probe-${Math.random().toString(36).slice(2)}.html`);
  writeFileSync(file, html);

  const result = run([
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--hide-scrollbars',
    '--allow-file-access-from-files',
    `--window-size=${width},${height}`,
    `--virtual-time-budget=${budget}`,
    '--dump-dom',
    pathToFileURL(file).href,
  ]);

  const match = result.stdout.match(/<pre id="report">([\s\S]*?)<\/pre>/);
  if (!match) throw new Error('the page did not write a report');
  const json = match[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
  return JSON.parse(json);
}

/**
 * Renders a page at exactly `width`×`height` and returns its pixels.
 *
 * The default background is set to opaque white because a transparent
 * screenshot reports `rgba(0,0,0,0)` for empty areas, which is not a colour
 * anything can be compared against.
 */
export function screenshot(source, { width, height, budget = 1500 } = {}) {
  const target = path.join(OUT, `_shot-${Math.random().toString(36).slice(2)}.png`);
  const sourceUrl = source.startsWith('http') ? source : pathToFileURL(path.resolve(source)).href;

  run([
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--hide-scrollbars',
    '--allow-file-access-from-files',
    '--force-device-scale-factor=1',
    '--default-background-color=ffffffff',
    `--window-size=${width},${height}`,
    `--virtual-time-budget=${budget}`,
    `--screenshot=${target}`,
    sourceUrl,
  ]);

  if (!existsSync(target)) throw new Error(`Chrome wrote no screenshot for ${source}`);
  return decodePng(readFileSync(target));
}

/** Loads a fixture in an iframe of a known size and runs `body` inside it. */
export function inFrame(fixture, { width, height, body, budget = 3000 }) {
  const src = path.basename(fixture);
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
html,body{margin:0;padding:0;background:#fff}
iframe{border:0;display:block}
</style></head><body><script>
window.addEventListener('load', function () {
  var frame = document.createElement('iframe');
  frame.width = ${width};
  frame.height = ${height};
  frame.src = '${src}';
  frame.onload = function () {
    var doc = frame.contentDocument;
    var win = doc.defaultView;
    function write(value) {
      document.body.insertAdjacentHTML('beforeend',
        '<pre id="rep' + 'ort">' + JSON.stringify(value) + '</pre>');
    }
    var result = (function (doc, win) {
      ${body}
    })(doc, win);
    // A body that has to wait for something — a font to load, a layout to
    // settle — can return a promise instead of a value, and the report is
    // written when it comes back.
    if (result && typeof result.then === 'function') result.then(write);
    else write(result);
  };
  document.body.appendChild(frame);
});
</script></body></html>`;
  return probe(html, { width: width + 40, height: height + 40, budget });
}

/** Prints a check table and exits non-zero when anything failed. */
export function report(title, checks) {
  let failures = 0;
  for (const [label, ok, detail] of checks) {
    if (!ok) failures += 1;
    console.log(`${ok ? 'ok  ' : 'BAD '} ${label.padEnd(52)} ${detail ?? ''}`);
  }
  if (failures > 0) {
    console.error(`\n${title}: ${failures} check(s) failed.`);
    process.exit(1);
  }
  console.log(`\n${title}: all ${checks.length} checks passed.`);
}
