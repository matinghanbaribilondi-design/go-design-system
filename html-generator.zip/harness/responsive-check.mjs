// Reads the real layout of the responsive corpus out of Chrome.
//
//   npx vitest run harness/responsive.test.ts && node harness/responsive-check.mjs
//
// Three things have to be true at every width, and none of them can be proved
// by asserting on the generated CSS:
//
//   1. Nothing scrolls sideways and nothing reaches outside the frame. A
//      `min-width` that survived from the drawing shows up here first.
//   2. The frame is exactly `min(viewport, designWidth)` wide, so the export is
//      capped at its design width and fills anything narrower.
//   3. Fluid values track *the frame*, not the window. The page is measured
//      inside an iframe that is narrower than the browser window, so a `vw`
//      value would keep its design size while a container-relative one shrinks.
//      That difference is the whole point of the check: `maxPad` has to equal
//      `clamp(floor, design × frame / designWidth, design)`.
//
// The measurements happen in an iframe rather than by resizing the window:
// Chrome on macOS refuses to go below ~500px, which silently turns a phone
// width into a second measurement of a tablet.
import { spawnSync } from 'child_process';
import { existsSync, writeFileSync } from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.join(__dirname, 'out');

const DESIGN_WIDTH = 1200;
const WIDTHS = [1200, 1024, 768, 600, 480, 390, 320];

/**
 * What each fixture is expected to do. `pad` and `fs` are the design values of
 * the largest padding and font size on the page; the check derives the expected
 * value at each width from them.
 *
 * `oneLineAtOrAbove` is not a breakpoint — it is the arithmetic of the bar
 * itself. The header's parts cannot occupy less than logo 120 + slot floor 180
 * + actions 200 + two gaps 32 = 532px, so below 532 the bar is *entitled* to
 * break, and at or above it a break would mean the slot had failed to
 * compress. That is the distinction the check is drawing: the bar breaks
 * because it must, not because a basis was left at its drawn size.
 */
const FIXTURES = [
  { file: 'rp-header', oneLineAtOrAbove: 532 },
  { file: 'rp-stats' },
  { file: 'rp-form', pad: 64 },
  { file: 'rp-article', pad: 80, fs: 48 },
  { file: 'rp-shell', railAtDesign: 296 },
  { file: 'rp-gallery' },
  { file: 'rp-modal' },
];

/** The value a container-relative clamp must produce at `width`. */
function expectedFluid(design, width) {
  const floor = Math.round(design * 0.65);
  return Math.min(Math.max((design * Math.min(width, DESIGN_WIDTH)) / DESIGN_WIDTH, floor), design);
}

// The report is copied into a fresh element rather than written as an HTML
// string: the wrapper's own source is echoed back by `--dump-dom`, and a
// literal `<pre id="report">` inside this script would be found by the
// extraction regex before the real report is.
const wrapper = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
html,body{margin:0;padding:0;background:#fff}
iframe{border:0;display:block}
</style></head><body><script>
window.addEventListener('load', function () {
  var q = location.hash.slice(1).split('|');
  var width = Number(q[0]) || 1200;
  var src = q[1];
  var frame = document.createElement('iframe');
  frame.width = width;
  frame.height = 1400;
  frame.src = src;
  frame.onload = function () {
    var inner = frame.contentDocument.getElementById('report');
    var out = document.createElement('pre');
    out.id = 'report';
    out.textContent = inner ? inner.textContent : '';
    document.body.appendChild(out);
  };
  document.body.appendChild(frame);
});
</script></body></html>`;

const probeFile = path.join(OUT, '_responsive-probe.html');
writeFileSync(probeFile, wrapper);
const base = pathToFileURL(probeFile).href;

function measure(file, width) {
  const result = spawnSync(
    CHROME,
    [
      '--headless=new',
      '--no-sandbox',
      '--disable-gpu',
      '--hide-scrollbars',
      '--allow-file-access-from-files',
      '--window-size=1500,1500',
      '--virtual-time-budget=3000',
      '--dump-dom',
      `${base}#${width}|${file}.html`,
    ],
    { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 }
  );

  // The last match wins, and only a JSON payload counts: `--dump-dom` echoes
  // this file's own script back, so an earlier match can be source text.
  const all = [...result.stdout.matchAll(/<pre id="report">([\s\S]*?)<\/pre>/g)];
  const match = all.filter((m) => m[1].trim().startsWith('{')).pop();
  if (!match) return null;
  return JSON.parse(
    match[1]
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
  );
}

const near = (a, b) => Math.abs(a - b) <= 1.5;

let failures = 0;
const rows = [];

for (const fixture of FIXTURES) {
  const file = path.join(OUT, `${fixture.file}.html`);
  if (!existsSync(file)) {
    console.error(`missing ${fixture.file}.html — run: npx vitest run harness/responsive.test.ts`);
    process.exit(1);
  }

  for (const width of WIDTHS) {
    const report = measure(fixture.file, width);
    if (!report) {
      rows.push([false, fixture.file, width, 'could not read the report']);
      failures += 1;
      continue;
    }

    const problems = [];

    // 1. Nothing outside the frame.
    if (report.scrollW > report.clientW + 1) {
      problems.push(`H-SCROLL ${report.scrollW} > ${report.clientW}`);
    }
    if (report.overflowCount > 0) {
      const first = report.overflow[0];
      problems.push(`OUT ${report.overflowCount} (${first.cls} ${first.left}..${first.right})`);
    }

    // 2. The frame is capped at the design width and fills anything narrower.
    const expectedRoot = Math.min(width, DESIGN_WIDTH);
    if (!near(report.rootW, expectedRoot)) {
      problems.push(`root ${report.rootW} (want ${expectedRoot})`);
    }

    // 3. Fluid values follow the frame.
    if (fixture.pad !== undefined) {
      const want = expectedFluid(fixture.pad, width);
      if (!near(report.maxPad, want)) {
        problems.push(`padding ${report.maxPad} (want ${want.toFixed(1)})`);
      }
    }
    if (fixture.fs !== undefined) {
      const want = expectedFluid(fixture.fs, width);
      if (!near(report.maxFs, want)) {
        problems.push(`font-size ${report.maxFs} (want ${want.toFixed(1)})`);
      }
    }

    // 4. A bar keeps one line until its parts genuinely do not fit.
    if (fixture.oneLineAtOrAbove && width >= fixture.oneLineAtOrAbove && report.lines.length !== 1) {
      problems.push(`bar split into ${report.lines.map((l) => l.count).join('+')}`);
    }

    // 5. A rail keeps its width at the design width and fills the line once
    //    the shell has stacked.
    if (fixture.railAtDesign !== undefined) {
      if (width === DESIGN_WIDTH && !near(report.firstW, fixture.railAtDesign)) {
        problems.push(`rail ${report.firstW} (want ${fixture.railAtDesign})`);
      }
      if (width <= 480 && !near(report.firstW, report.rootW)) {
        problems.push(`stacked rail ${report.firstW} (want ${report.rootW})`);
      }
    }

    failures += problems.length > 0 ? 1 : 0;
    rows.push([
      problems.length === 0,
      fixture.file,
      width,
      problems.length ? problems.join(', ') : `pad ${report.maxPad}  fs ${report.maxFs}  lines ${report.lines.map((l) => l.count).join('+') || '—'}`,
    ]);
  }
}

for (const [ok, file, width, detail] of rows) {
  console.log(`${ok ? 'ok  ' : 'BAD '} ${String(file).padEnd(12)} ${String(width).padStart(4)}px  ${detail}`);
}

if (failures > 0) {
  console.error(`\n${failures} measurement(s) failed.`);
  process.exit(1);
}
console.log('\nNo sideways scroll, no element outside the frame, fluid values tracking the frame, bars intact.');
