// A minimal PNG reader, so the harness can look at actual pixels.
//
// Every check in this repo so far answered questions a CSS string or a hit test
// could answer. A gradient ring, a blend mode and a screenshot comparison
// cannot be settled that way — they are colour, and colour needs pixels.
//
// Scope on purpose: the format Chrome writes from `--screenshot`. 8 bits per
// channel, non-interlaced, greyscale / RGB / RGBA. That is a decoder of about
// sixty lines instead of a dependency, and every unsupported file is rejected
// loudly rather than decoded into noise.
import { inflateSync } from 'zlib';

const SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

const CHANNELS = { 0: 1, 2: 3, 4: 2, 6: 4 };

/**
 * @param {Buffer} buffer
 * @returns {{width: number, height: number, data: Uint8Array}} RGBA, 4 bytes per pixel
 */
export function decodePng(buffer) {
  if (!buffer.subarray(0, 8).equals(SIGNATURE)) throw new Error('not a PNG');

  let pos = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  let interlace = 0;
  const chunks = [];

  while (pos + 8 <= buffer.length) {
    const length = buffer.readUInt32BE(pos);
    const type = buffer.toString('ascii', pos + 4, pos + 8);
    const data = buffer.subarray(pos + 8, pos + 8 + length);
    if (type === 'IHDR') {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
      interlace = data[12];
    } else if (type === 'IDAT') {
      chunks.push(data);
    } else if (type === 'IEND') {
      break;
    }
    pos += 12 + length;
  }

  if (bitDepth !== 8) throw new Error(`unsupported bit depth ${bitDepth}`);
  if (interlace !== 0) throw new Error('interlaced PNG is not supported');
  const channels = CHANNELS[colorType];
  if (!channels) throw new Error(`unsupported colour type ${colorType}`);

  const raw = inflateSync(Buffer.concat(chunks));
  const stride = width * channels;
  const pixels = Buffer.alloc(height * stride);

  // Undo the per-scanline filters (PNG spec §9.2). Each line is prefixed by its
  // filter type; `a` and `b` are the bytes to the left and above, `c` the one
  // diagonally above-left.
  for (let y = 0; y < height; y += 1) {
    const filter = raw[y * (stride + 1)];
    const line = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1));
    const out = pixels.subarray(y * stride, (y + 1) * stride);
    const up = y > 0 ? pixels.subarray((y - 1) * stride, y * stride) : null;

    for (let x = 0; x < stride; x += 1) {
      const a = x >= channels ? out[x - channels] : 0;
      const b = up ? up[x] : 0;
      const c = up && x >= channels ? up[x - channels] : 0;
      let value = line[x];
      switch (filter) {
        case 0:
          break;
        case 1:
          value += a;
          break;
        case 2:
          value += b;
          break;
        case 3:
          value += (a + b) >> 1;
          break;
        case 4: {
          const p = a + b - c;
          const pa = Math.abs(p - a);
          const pb = Math.abs(p - b);
          const pc = Math.abs(p - c);
          value += pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
          break;
        }
        default:
          throw new Error(`unknown filter ${filter} on row ${y}`);
      }
      out[x] = value & 0xff;
    }
  }

  // Normalise to RGBA so every caller works in one pixel format.
  const data = new Uint8Array(width * height * 4);
  for (let i = 0; i < width * height; i += 1) {
    const s = i * channels;
    const d = i * 4;
    if (channels === 1) {
      data[d] = data[d + 1] = data[d + 2] = pixels[s];
      data[d + 3] = 255;
    } else if (channels === 2) {
      data[d] = data[d + 1] = data[d + 2] = pixels[s];
      data[d + 3] = pixels[s + 1];
    } else {
      data[d] = pixels[s];
      data[d + 1] = pixels[s + 1];
      data[d + 2] = pixels[s + 2];
      data[d + 3] = channels === 4 ? pixels[s + 3] : 255;
    }
  }

  return { width, height, data };
}

/** The colour at a point, as `[r, g, b, a]`. Out of bounds throws. */
export function pixelAt(image, x, y) {
  if (x < 0 || y < 0 || x >= image.width || y >= image.height) {
    throw new Error(`pixel ${x},${y} is outside ${image.width}×${image.height}`);
  }
  const i = (y * image.width + x) * 4;
  return [image.data[i], image.data[i + 1], image.data[i + 2], image.data[i + 3]];
}

/** Human-readable pixel, for a failure message that says what it actually saw. */
export function describePixel(pixel) {
  const [r, g, b, a] = pixel;
  const hex = `#${[r, g, b].map((c) => c.toString(16).padStart(2, '0')).join('')}`;
  return a === 255 ? hex : `${hex} @${Math.round((a / 255) * 100)}%`;
}

/** Per-channel distance, so "close enough" can be one number. */
export function distance(a, b) {
  return Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1]), Math.abs(a[2] - b[2]));
}

/**
 * How many pixels differ between two images, and where the differences start.
 *
 * A plain ratio would pass a layout that shifted one pixel everywhere, so the
 * first differing row and column are reported as well: they are what says
 * "everything moved down by 8px" instead of "12% of the page changed".
 */
export function compare(expected, actual, tolerance = 8) {
  if (expected.width !== actual.width || expected.height !== actual.height) {
    return {
      sizeMismatch: true,
      expectedSize: `${expected.width}×${expected.height}`,
      actualSize: `${actual.width}×${actual.height}`,
      differing: -1,
      ratio: 1,
      firstDifference: null,
    };
  }

  let differing = 0;
  let firstDifference = null;
  const rowHits = new Map();
  const colHits = new Map();

  for (let y = 0; y < expected.height; y += 1) {
    for (let x = 0; x < expected.width; x += 1) {
      const i = (y * expected.width + x) * 4;
      const d = Math.max(
        Math.abs(expected.data[i] - actual.data[i]),
        Math.abs(expected.data[i + 1] - actual.data[i + 1]),
        Math.abs(expected.data[i + 2] - actual.data[i + 2]),
        Math.abs(expected.data[i + 3] - actual.data[i + 3])
      );
      if (d > tolerance) {
        differing += 1;
        if (!firstDifference) firstDifference = { x, y };
        rowHits.set(y, (rowHits.get(y) ?? 0) + 1);
        colHits.set(x, (colHits.get(x) ?? 0) + 1);
      }
    }
  }

  const busiest = (hits) =>
    [...hits.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;

  return {
    sizeMismatch: false,
    differing,
    total: expected.width * expected.height,
    ratio: differing / (expected.width * expected.height),
    firstDifference,
    busiestRow: busiest(rowHits),
    busiestColumn: busiest(colHits),
  };
}
