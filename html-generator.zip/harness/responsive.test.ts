import { describe, it } from 'vitest';
import { writeFileSync, mkdirSync } from 'fs';
import { convertNodeToIR } from '../src/plugin/converter/index';
import { generateFullHtmlDocument } from '../src/generator/html-generator';
import type { ConversionOptions } from '../src/plugin/types/ir';

/**
 * Responsive corpus, measured in a real browser by
 * `harness/responsive-check.mjs`.
 *
 * Every claim this folder makes about "it reflows" is a claim about layout,
 * and a layout claim cannot be proved by asserting on a CSS string: the string
 * can be right and the page still overflow. These fixtures are converted
 * through the *real* pipeline — `convertNodeToIR`, so typography, padding and
 * gaps go through the same code the plugin ships — and then measured at seven
 * widths inside an iframe.
 *
 * The iframe matters. Chrome on macOS refuses windows below ~500px, and a
 * `vw`-based value would resolve against the 1400px window rather than the
 * 600px frame — which is exactly the bug this corpus is meant to catch, so the
 * measurement has to happen in a box that is genuinely narrower than the
 * window.
 *
 * Each fixture carries a probe that reports the largest padding and the largest
 * font size on the page, plus every element that reaches outside the frame.
 * The check script compares those numbers against what a container-relative
 * clamp must produce at that width.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: true,
  intrinsicReflow: true,
  designWidth: 1200,
};

function mk(over: Record<string, unknown> = {}): any {
  const node: any = {
    id: (over.id as string) ?? 'n',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: 100,
    height: 100,
    x: 0,
    y: 0,
    rotation: 0,
    layoutMode: 'NONE',
    children: [],
    fills: [],
    strokes: [],
    effects: [],
    ...over,
  };
  // A childless frame is exported as a vector, so the pipeline asks the node for
  // an SVG. Handing back one of exactly the node's own size keeps the box the
  // same as an empty div would be, and keeps the console quiet about it.
  node.exportAsync = async () =>
    new TextEncoder().encode(
      `<svg xmlns="http://www.w3.org/2000/svg" width="${node.width}" height="${node.height}"></svg>`
    );
  return node;
}

function text(over: Record<string, unknown> = {}): any {
  return mk({
    type: 'TEXT',
    textAutoResize: 'HEIGHT',
    fontSize: 16,
    fontName: { family: 'Inter', style: 'Regular' },
    lineHeight: { unit: 'PIXELS', value: 24 },
    letterSpacing: { unit: 'PIXELS', value: 0 },
    textAlignHorizontal: 'LEFT',
    characters: 'Sample text for the responsive corpus',
    ...over,
  });
}

/** A 1200×900 page wrapper. */
function page(children: any[], over: Record<string, unknown> = {}): any {
  return mk({ id: 'page', name: 'Page', layoutMode: 'VERTICAL', width: 1200, height: 900, children, ...over });
}

/** A header: logo, a wide search field, and a cluster of icon actions. */
function header(): any {
  const logo = mk({ id: 'logo', name: 'Logo', width: 120, height: 40 });
  const input = mk({ id: 'input', name: 'Input', width: 640, height: 36 });
  const search = mk({
    id: 'search',
    name: 'Search',
    width: 700,
    height: 40,
    layoutMode: 'HORIZONTAL',
    children: [input],
  });
  const actions = mk({
    id: 'actions',
    name: 'Actions',
    width: 200,
    height: 40,
    layoutMode: 'HORIZONTAL',
    itemSpacing: 8,
    children: [
      mk({ id: 'a1', name: 'Icon', width: 32, height: 32 }),
      mk({ id: 'a2', name: 'Icon', width: 32, height: 32 }),
    ],
  });
  return mk({
    id: 'header',
    name: 'Header',
    layoutMode: 'HORIZONTAL',
    width: 1200,
    height: 72,
    itemSpacing: 24,
    primaryAxisAlignItems: 'SPACE_BETWEEN',
    counterAxisAlignItems: 'CENTER',
    children: [logo, search, actions],
  });
}

/** Four stat cards in a row — a packed grid that has to go two-up, then one-up. */
function stats(): any {
  const card = (i: number) =>
    mk({
      id: `stat-${i}`,
      name: `Stat ${i}`,
      layoutMode: 'VERTICAL',
      width: 258,
      height: 140,
      itemSpacing: 8,
      paddingTop: 20,
      paddingRight: 20,
      paddingBottom: 20,
      paddingLeft: 20,
      children: [
        text({ id: `v${i}`, name: 'Value', characters: '12,480', width: 218, height: 40, fontSize: 32 }),
        text({ id: `l${i}`, name: 'Label', characters: 'Total revenue this month', width: 218, height: 20, fontSize: 13 }),
      ],
    });
  return mk({
    id: 'stats',
    name: 'Stats Row',
    layoutMode: 'HORIZONTAL',
    width: 1200,
    height: 140,
    itemSpacing: 24,
    children: [0, 1, 2, 3].map(card),
  });
}

/** A padded form section: the padding is the value that must track the frame. */
function form(): any {
  const field = (id: string, label: string) =>
    mk({
      id,
      name: `Field ${id}`,
      layoutMode: 'VERTICAL',
      width: 1072,
      height: 72,
      itemSpacing: 8,
      children: [
        text({ id: `${id}-label`, name: 'Label', characters: label, width: 1072, height: 20 }),
        mk({ id: `${id}-input`, name: 'Input', width: 1072, height: 44 }),
      ],
    });

  return mk({
    id: 'form-section',
    name: 'Form Section',
    layoutMode: 'VERTICAL',
    width: 1200,
    height: 600,
    itemSpacing: 24,
    paddingTop: 64,
    paddingRight: 64,
    paddingBottom: 64,
    paddingLeft: 64,
    children: [field('name', 'Full name'), field('email', 'Email address')],
  });
}

/** A prose column: display type that has to scale with the frame. */
function article(): any {
  return mk({
    id: 'article',
    name: 'Article',
    layoutMode: 'VERTICAL',
    width: 1200,
    height: 600,
    itemSpacing: 24,
    paddingTop: 80,
    paddingRight: 80,
    paddingBottom: 80,
    paddingLeft: 80,
    children: [
      text({
        id: 'heading',
        name: 'Heading',
        characters: 'Understanding layout constraint systems',
        width: 1040,
        height: 56,
        fontSize: 48,
        lineHeight: { unit: 'PIXELS', value: 56 },
        letterSpacing: { unit: 'PIXELS', value: 1.5 },
      }),
      text({
        id: 'para',
        name: 'Paragraph',
        characters: 'A paragraph of body copy that runs to a couple of lines in the column.',
        width: 1040,
        height: 72,
        fontSize: 16,
      }),
    ],
  });
}

/** A rail beside a body — the case where wrapping alone strands the rail. */
function shell(): any {
  const navItem = (i: number) =>
    mk({
      id: `nav-${i}`,
      name: `Nav Item ${i}`,
      layoutMode: 'HORIZONTAL',
      width: 264,
      height: 44,
      itemSpacing: 12,
      counterAxisAlignItems: 'CENTER',
      children: [
        mk({ id: `ni-${i}`, name: 'Icon', width: 20, height: 20 }),
        text({ id: `nt-${i}`, name: 'Label', characters: 'Dashboard', width: 180, height: 20 }),
      ],
    });
  const rail = mk({
    id: 'rail',
    name: 'Sidebar',
    layoutMode: 'VERTICAL',
    width: 296,
    height: 640,
    itemSpacing: 4,
    paddingTop: 16,
    paddingRight: 16,
    paddingBottom: 16,
    paddingLeft: 16,
    children: [0, 1, 2, 3, 4].map(navItem),
  });
  const body = mk({
    id: 'body',
    name: 'Main Content',
    layoutMode: 'VERTICAL',
    width: 856,
    height: 640,
    itemSpacing: 16,
    children: [text({ id: 'body-title', name: 'Title', characters: 'Overview', width: 856, height: 32, fontSize: 24 })],
  });
  return mk({
    id: 'shell',
    name: 'App Shell',
    layoutMode: 'HORIZONTAL',
    width: 1200,
    height: 640,
    itemSpacing: 24,
    children: [rail, body],
  });
}

/** Six tiles across — the case that must step down 6 → 3 → 2 → 1. */
function gallery(): any {
  const tile = (i: number) =>
    mk({ id: `tile-${i}`, name: `Tile ${i}`, width: 184, height: 260 });
  return mk({
    id: 'gallery',
    name: 'Gallery',
    layoutMode: 'HORIZONTAL',
    width: 1200,
    height: 260,
    itemSpacing: 16,
    children: [0, 1, 2, 3, 4, 5].map(tile),
  });
}

/** A freeform screen: a scrim and a centred dialog placed by hand. */
function modal(): any {
  const scrim = mk({ id: 'scrim', name: 'Scrim', width: 1200, height: 800, x: 0, y: 0 });
  const dialog = mk({
    id: 'dialog',
    name: 'Dialog',
    layoutMode: 'VERTICAL',
    width: 480,
    height: 280,
    x: 360,
    y: 260,
    itemSpacing: 16,
    paddingTop: 24,
    paddingRight: 24,
    paddingBottom: 24,
    paddingLeft: 24,
    children: [
      text({ id: 'dt', name: 'Title', characters: 'Confirm this action', width: 432, height: 28, fontSize: 20 }),
      text({ id: 'db', name: 'Body', characters: 'This cannot be undone.', width: 432, height: 44 }),
    ],
  });
  return mk({ id: 'screen', name: 'Modal Screen', width: 1200, height: 800, layoutMode: 'NONE', children: [scrim, dialog] });
}

/**
 * The probe every fixture carries. It reports what the check needs and nothing
 * else: the largest padding, the largest font size, the frame's own size, every
 * element that reaches outside it, and how the page's main row is broken into
 * lines.
 *
 * The line grouping is by *vertical overlap*, not by `offsetTop`. A row with
 * `align-items: center` gives its children different `offsetTop` values even
 * when they share a line, so comparing tops would report a one-line bar as
 * three. Two boxes are on the same line when they overlap by more than half of
 * the shorter one — true for start, center and end alignment alike.
 */
const PROBE = `
  <script>
    window.addEventListener('load', function () {
      var root = document.body.firstElementChild;
      var all = document.querySelectorAll('*');
      var maxPad = 0, maxFs = 0, overflow = [];
      for (var i = 0; i < all.length; i++) {
        var el = all[i];
        var cs = window.getComputedStyle(el);
        var r = el.getBoundingClientRect();
        maxPad = Math.max(maxPad, parseFloat(cs.paddingLeft) || 0);
        maxFs = Math.max(maxFs, parseFloat(cs.fontSize) || 0);
        if ((r.width || r.height) && (r.right > window.innerWidth + 1 || r.left < -1)) {
          overflow.push({
            cls: (el.className || el.tagName).toString().slice(0, 24),
            left: Math.round(r.left),
            right: Math.round(r.right),
            width: Math.round(r.width)
          });
        }
      }

      // In-flow element children of a flex container.
      function inFlow(el) {
        var out = [];
        for (var i = 0; i < el.children.length; i++) {
          var k = el.children[i];
          var p = window.getComputedStyle(k).position;
          if (p === 'absolute' || p === 'fixed') continue;
          var r = k.getBoundingClientRect();
          if (!r.width && !r.height) continue;
          out.push({ top: r.top, bottom: r.bottom, left: r.left, h: r.height, w: r.width });
        }
        return out;
      }

      // Group boxes into lines by vertical overlap.
      function groupLines(kids) {
        kids.sort(function (a, b) { return a.top - b.top; });
        var groups = [];
        for (var i = 0; i < kids.length; i++) {
          var cur = kids[i];
          var g = groups[groups.length - 1];
          var overlap = g ? Math.min(g.bottom, cur.bottom) - Math.max(g.top, cur.top) : -1;
          if (g && overlap > Math.min(g.h, cur.h) * 0.5) {
            g.count += 1;
            g.bottom = Math.max(g.bottom, cur.bottom);
            g.h = Math.max(g.h, cur.h);
          } else {
            groups.push({ top: cur.top, bottom: cur.bottom, h: cur.h, count: 1 });
          }
        }
        return groups.map(function (g) { return { count: g.count }; });
      }

      // The page's main row: the widest flex container that holds at least two
      // in-flow children and spans most of the frame. Everything narrower than
      // that is a nested cluster, and a bar is always the widest thing on its
      // own line.
      var rootW = root ? root.getBoundingClientRect().width : window.innerWidth;
      var primary = null, primaryW = 0;
      for (var j = 0; j < all.length; j++) {
        var box = all[j];
        if (window.getComputedStyle(box).display.indexOf('flex') !== 0) continue;
        var w = box.getBoundingClientRect().width;
        if (w < rootW * 0.55 || w <= primaryW) continue;
        if (inFlow(box).length < 2) continue;
        primary = box;
        primaryW = w;
      }

      var lines = [], firstW = 0;
      if (primary) {
        var kids = inFlow(primary);
        lines = groupLines(kids);
        // The leftmost child of the topmost line — the leading item, whatever
        // the cross-axis alignment did to the tops.
        var topEdge = Math.min.apply(null, kids.map(function (k) { return k.top; }));
        var lead = null;
        for (var m = 0; m < kids.length; m++) {
          var k = kids[m];
          if (k.top > topEdge + k.h * 0.5) continue;
          if (!lead || k.left < lead.left) lead = k;
        }
        firstW = Math.round(lead ? lead.w : 0);
      }

      var report = {
        viewport: window.innerWidth,
        rootW: root ? Math.round(root.getBoundingClientRect().width) : 0,
        rootH: root ? Math.round(root.getBoundingClientRect().height) : 0,
        scrollW: document.documentElement.scrollWidth,
        clientW: document.documentElement.clientWidth,
        maxPad: Math.round(maxPad * 100) / 100,
        maxFs: Math.round(maxFs * 100) / 100,
        lines: lines,
        firstW: firstW,
        overflowCount: overflow.length,
        overflow: overflow.slice(0, 5)
      };
      var pre = document.createElement('pre');
      pre.id = 'report';
      pre.textContent = JSON.stringify(report);
      document.body.appendChild(pre);
    });
  </script>`;

const FIXTURES: { name: string; root: () => any }[] = [
  { name: 'rp-header', root: () => page([header()]) },
  { name: 'rp-stats', root: () => page([stats()]) },
  { name: 'rp-form', root: () => page([form()]) },
  { name: 'rp-article', root: () => page([article()]) },
  { name: 'rp-shell', root: () => page([shell()]) },
  { name: 'rp-gallery', root: () => page([gallery()]) },
  { name: 'rp-modal', root: modal },
];

describe('responsive corpus', () => {
  for (const fixture of FIXTURES) {
    it(`emits ${fixture.name}`, async () => {
      const ir = await convertNodeToIR(fixture.root(), null, options);
      if (!ir) throw new Error(`${fixture.name}: conversion produced no IR`);

      const html = generateFullHtmlDocument(ir, options).replace('</body>', `${PROBE}\n</body>`);

      mkdirSync('harness/out', { recursive: true });
      writeFileSync(`harness/out/${fixture.name}.html`, html);
    });
  }
});
