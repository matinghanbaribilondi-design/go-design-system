// Renders the real export log viewer in Chrome and screenshots two states.
//
//   npm run build && node harness/export-log-check.mjs
//
// The point is not to test logic — `src/shared/export-log.test.ts` does that.
// The point is to see the thing: does the status pill change, does the silence
// banner appear, do 274 frames' worth of lines lay out without overflowing, and
// does the modal still read as a log rather than a wall of text.
//
// The plugin UI talks to its sandbox over `postMessage`, and when the page is
// opened directly `parent === window`, so a script inside the page can play the
// sandbox's part by posting to itself.
import { spawnSync } from 'child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dist = path.join(__dirname, '..', 'dist', 'index.html');
const outDir = path.join(__dirname, 'out');

if (!existsSync(dist)) {
  console.error('missing dist/index.html — run: npm run build');
  process.exit(1);
}
if (!existsSync(outDir)) mkdirSync(outDir, { recursive: true });

/** The run we are pretending to watch: 274 frames, frame two is the slow one. */
function events() {
  const list = [
    ['scan', 'info', 'Reading pages…', 0, 0, 0],
    ['scan', 'info', 'Found 274 frames across 6 pages', 0, 274, 210],
    ['variables', 'info', 'Reading variables and paint styles…', 0, 274, 240],
    ['variables', 'info', 'Read 143 tokens', 0, 274, 1_240, 1_000],
    ['convert', 'info', 'Converting "Home / Hero" (412 nodes)', 0, 274, 1_300],
    ['convert', 'info', 'Converted "Home / Hero"', 1, 274, 1_720, 420],
    ['convert', 'info', 'Converting "Home / Features" (1,180 nodes)', 1, 274, 1_760],
    ['convert', 'warn', 'Still converting "Home / Features" — 4.2s so far', 1, 274, 5_960],
  ];
  return list.map(([stage, level, message, done, total, at, frameMs], seq) => ({
    seq,
    stage,
    level,
    message,
    done,
    total,
    at,
    ...(frameMs === undefined ? {} : { frameMs }),
  }));
}

/**
 * Injects a driver that plays the sandbox.
 *
 * `Date.now` is shifted by hand rather than left to `--virtual-time-budget`:
 * the elapsed clock and the silence counter both read it, and a deterministic
 * jump is the only way to screenshot "12 seconds of nothing" on purpose.
 */
function driver(eventsJson, offsetMs) {
  return `
<script>
(function () {
  const send = (pluginMessage) => window.postMessage({ pluginMessage }, '*');
  const EVENTS = ${eventsJson};
  const realNow = Date.now.bind(Date);
  let offset = 0;
  Date.now = () => realNow() + offset;

  function start() {
    const button = Array.from(document.querySelectorAll('button')).find((b) =>
      (b.getAttribute('title') || '').startsWith('Export the whole file')
    );
    if (!button) { document.title = 'BUTTON NOT FOUND'; return; }
    button.click();
    EVENTS.forEach((event, i) => {
      setTimeout(() => send({ type: 'EXPORT_DOCUMENT_LOG', event }), 20 + i * 20);
    });
    // Let the last line paint, then jump the clock so the silence counter has
    // something real to report.
    setTimeout(() => { offset = ${offsetMs}; }, 20 + EVENTS.length * 20 + 120);
  }

  window.addEventListener('load', () => setTimeout(start, 200));
})();
</script>`;
}

function render(name, offsetMs, budget) {
  const html = readFileSync(dist, 'utf8');
  // The plugin's own generators emit the literal string `</body>` inside the
  // inlined bundle, so the driver has to go before the *last* one or it lands
  // in the middle of a JavaScript string and the page renders as source.
  const cut = html.lastIndexOf('</body>');
  if (cut < 0) {
    console.error('no </body> in dist/index.html');
    process.exit(1);
  }
  const withDriver = `${html.slice(0, cut)}${driver(JSON.stringify(events()), offsetMs)}${html.slice(cut)}`;
  const file = path.join(outDir, `${name}.html`);
  writeFileSync(file, withDriver);

  const shot = path.join(outDir, `${name}.png`);
  const result = spawnSync(
    CHROME,
    [
      '--headless=new',
      '--no-sandbox',
      '--disable-gpu',
      '--hide-scrollbars',
      '--force-device-scale-factor=2',
      '--window-size=980,700',
      `--virtual-time-budget=${budget}`,
      `--screenshot=${shot}`,
      pathToFileURL(file).href,
    ],
    { encoding: 'utf8' }
  );
  if (result.status !== 0) {
    console.error(result.stderr);
    process.exit(1);
  }
  console.log(`${name}: ${shot}`);
}

// A: the export is alive — the clock has moved ~1.5s past the last line.
render('export-log-live', 5_000, 2_500);
// B: the same run, another 16s of nothing — the case the user actually hit.
render('export-log-stalled', 21_000, 2_500);
