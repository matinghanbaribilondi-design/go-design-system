import { describe, it } from 'vitest';
import { writeFileSync, mkdirSync } from 'fs';
import { generateCssForRoots } from '../src/generator/css-generator';
import { generateHtml } from '../src/generator/html-generator';
import { toIR, mk, OPT } from './mock';

/**
 * The reported case, rendered: a board of four 261px columns with 24px gaps in
 * a 1116px row.
 *
 * The page carries a small measuring script that reports how many columns land
 * on each line, so `harness/board-check.mjs` can read the real layout out of
 * Chrome instead of trusting the CSS. Before the fix the floor equalled the
 * drawn width, so the columns were rigid and the row broke into 3 + 1 the
 * moment the container was narrower than 1116px.
 */

const COLUMN_WIDTH = 261;
const GAP = 24;
const COUNT = 4;
const ROW_WIDTH = COLUMN_WIDTH * COUNT + GAP * (COUNT - 1); // 1116

function board() {
  const columns = Array.from({ length: COUNT }, (_, i) =>
    mk({
      id: `col-${i}`,
      name: i === 2 ? 'Projects/In progress' : `Column ${i}`,
      width: COLUMN_WIDTH,
      height: 220,
      layoutMode: 'VERTICAL',
      layoutSizingHorizontal: 'FILL',
      children: [
        mk({ id: `col-${i}-card`, name: 'Card', width: COLUMN_WIDTH, height: 120, layoutMode: 'VERTICAL' }),
      ],
    })
  );

  return mk({
    id: 'board',
    name: 'Projects',
    layoutMode: 'HORIZONTAL',
    width: ROW_WIDTH,
    height: 220,
    itemSpacing: GAP,
    children: columns,
  });
}

describe('board corpus', () => {
  it('emits the four-column board with its measuring script', () => {
    const ir = toIR(board(), null, OPT);
    const css = generateCssForRoots([ir], OPT, false);
    const body = generateHtml(ir, 1);

    const script = `
  <script>
    // Reports how many columns share each line, plus the row's own width.
    function report() {
      var board = document.querySelector('.${ir.className}');
      if (!board) return;
      var tops = Array.prototype.map.call(board.children, function (el) {
        return Math.round(el.getBoundingClientRect().top);
      });
      var lines = {};
      tops.forEach(function (t) { lines[t] = (lines[t] || 0) + 1; });
      var out = {
        viewport: window.innerWidth,
        rowWidth: Math.round(board.getBoundingClientRect().width),
        perLine: Object.keys(lines).map(function (k) { return lines[k]; })
      };
      var el = document.createElement('pre');
      el.id = 'report';
      el.textContent = JSON.stringify(out);
      document.body.appendChild(el);
    }
    window.addEventListener('load', report);
  </script>`;

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>board</title>
<style>
${css}
</style>
</head>
<body>
${body}
${script}
</body>
</html>`;

    mkdirSync('harness/out', { recursive: true });
    writeFileSync('harness/out/board.html', html);

    // The floor has to sit below the drawn width, or the columns are rigid and
    // there is nothing for the browser to compress.
    if (html.includes('min-width: min(261px, 100%)')) {
      throw new Error('the wrap floor equals the drawn column width — the row cannot compress');
    }
  });
});
