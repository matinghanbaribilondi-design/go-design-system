// Proves that component reuse changes no pixels.
//
// `harness/dedupe.test.ts` writes the same document twice — every instance
// coded from scratch, then the same instances reusing their component — into
// `harness/out/`. This screenshots both in headless Chrome and compares the
// bytes. Identical bytes mean the browser resolved the exact same layout,
// colours and text in both, which is the only claim that matters.
//
//   node harness/dedupe-check.mjs
//
// Run it after `npx vitest run harness/dedupe.test.ts` has produced the pages.
import { spawnSync } from 'child_process';
import { existsSync, readFileSync } from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const WIDTHS = [1280, 1024, 768, 480];
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const out = path.join(__dirname, 'out');

for (const name of ['dedupe-before', 'dedupe-after']) {
  if (!existsSync(path.join(out, `${name}.html`))) {
    console.error(`missing ${name}.html — run: npx vitest run harness/dedupe.test.ts`);
    process.exit(1);
  }
}

function shoot(name, width) {
  const png = path.join(out, `${name}-${width}.png`);
  const result = spawnSync(
    CHROME,
    [
      '--headless=new',
      '--no-sandbox',
      '--disable-gpu',
      '--hide-scrollbars',
      '--force-device-scale-factor=1',
      `--window-size=${width},1400`,
      `--screenshot=${png}`,
      pathToFileURL(path.join(out, `${name}.html`)).href,
    ],
    { stdio: 'ignore' }
  );
  if (result.status !== 0 || !existsSync(png)) {
    throw new Error(`chrome failed to screenshot ${name} at ${width}px`);
  }
  return readFileSync(png);
}

let failures = 0;
for (const width of WIDTHS) {
  const before = shoot('dedupe-before', width);
  const after = shoot('dedupe-after', width);
  const same = before.equals(after);
  if (!same) failures += 1;
  console.log(
    `${same ? 'ok  ' : 'DIFF'} ${String(width).padStart(4)}px  ${before.length}B vs ${after.length}B`
  );
}

if (failures > 0) {
  console.error(`\n${failures} width(s) rendered differently — component reuse is not pixel-safe.`);
  process.exit(1);
}
console.log('\nComponent reuse is pixel-identical at every width.');
