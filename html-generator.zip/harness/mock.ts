import { extractLayout } from '../src/plugin/converter/layout';
import type { ConversionOptions, IRNode } from '../src/plugin/types/ir';

export const OPT: ConversionOptions = {
  outputMode: 'pure-css', useRem: false, baseFontSize: 16, includeReset: true,
  inlineAssets: true, semanticTags: true, responsive: true, intrinsicReflow: true, designWidth: 1200,
};

export function mk(o: Record<string, unknown> = {}): any {
  return {
    id: (o.id as string) ?? 'n', name: (o.name as string) ?? 'Frame',
    type: (o.type as string) ?? 'FRAME', visible: true,
    width: (o.width as number) ?? 100, height: (o.height as number) ?? 100,
    x: 0, y: 0, layoutMode: (o.layoutMode as string) ?? 'NONE', children: [], ...o,
  };
}

let counter = 0;
export function toIR(node: any, parent: any, options = OPT): IRNode {
  const cls = `n${counter++}`;
  const layout = extractLayout(node, parent, options);
  const ir: IRNode = {
    id: node.id ?? cls, name: node.name, className: cls,
    tag: 'div', type: node.type, layout, visual: {}, children: [],
  };
  const kids = (node.children ?? []).filter((c: any) => c.visible !== false);
  ir.children = kids.map((c: any) => toIR(c, node, options));
  if (kids.length === 0 && node.type === 'TEXT') {
    ir.type = 'TEXT'; ir.tag = 'p'; ir.text = node.characters ?? 'Sample text';
    ir.typography = { fontSize: '16px', color: '#111' };
  }
  return ir;
}
