// Reads the real layout of `harness/out/21-grid.html` out of Chrome.
//
//   npx vitest run harness/render.test.ts && node harness/grid-check.mjs
//
// The fixture is a 3×2 grid of 384px cards in a 1200px frame with 24px column
// gaps. Three things have to be true, and none of them can be proved by a CSS
// assertion:
//
//   1. At the design width the grid is exactly three columns of 384px — the
//      auto-fit floor is derived from the drawing, so the design width has to
//      reproduce the drawing rather than "about" it.
//   2. Below it the grid steps down to two columns and then one, at the exact
//      widths the arithmetic says, instead of squeezing three cards into a
//      phone.
//   3. Nothing ever scrolls sideways. A phantom column — the failure mode of a
//      pinned `grid-column` in a reflowing grid — shows up here first.
//
// The page is measured inside an iframe rather than by resizing the browser
// window: Chrome on macOS refuses to go below ~500px, which silently turned the
// phone widths into a second measurement of a tablet.
import { spawnSync } from 'child_process';
import { existsSync, writeFileSync } from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const source = path.join(__dirname, 'out', '21-grid.html');

if (!existsSync(source)) {
  console.error('missing 21-grid.html — run: npx vitest run harness/render.test.ts');
  process.exit(1);
}

// One wrapper, parameterised by the hash, so the fixture stays a plain document
// exactly as the exporter produced it.
const wrapper = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
html,body{margin:0;padding:0;background:#fff}
iframe{border:0;display:block}
</style></head><body><script>
window.addEventListener('load', function () {
  var width = Number(location.hash.slice(1)) || 1200;
  var frame = document.createElement('iframe');
  frame.width = width;
  frame.height = 900;
  frame.src = '21-grid.html';
  frame.onload = function () {
    var doc = frame.contentDocument;
    var grid = Array.prototype.find.call(doc.querySelectorAll('*'), function (el) {
      return doc.defaultView.getComputedStyle(el).display === 'grid';
    });
    var report;
    if (!grid) {
      report = { error: 'no grid' };
    } else {
      var kids = Array.prototype.slice.call(grid.children);
      var tops = [];
      kids.forEach(function (k) {
        var t = Math.round(k.getBoundingClientRect().top);
        if (tops.indexOf(t) === -1) tops.push(t);
      });
      tops.sort(function (a, b) { return a - b; });
      report = {
        perLine: tops.map(function (t) {
          return kids.filter(function (k) { return Math.round(k.getBoundingClientRect().top) === t; }).length;
        }),
        tracks: doc.defaultView.getComputedStyle(grid).gridTemplateColumns,
        cardWidth: Math.round(kids[0].getBoundingClientRect().width),
        gridWidth: Math.round(grid.getBoundingClientRect().width),
        // How far the rightmost card sticks out of the grid. Clipping by an
        // ancestor can hide this from scrollWidth, so it is measured directly.
        overflowRight: Math.max(0, Math.round(Math.max.apply(null, kids.map(function (k) {
          return k.getBoundingClientRect().right;
        })) - grid.getBoundingClientRect().right)),
        scrollW: doc.documentElement.scrollWidth,
        clientW: doc.documentElement.clientWidth
      };
    }
    document.body.insertAdjacentHTML('beforeend', '<pre id="grid-' + 'report">' + JSON.stringify(report) + '</pre>');
  };
  document.body.appendChild(frame);
});
</script></body></html>`;

const probe = path.join(__dirname, 'out', '21-grid-probe.html');
writeFileSync(probe, wrapper);
const base = pathToFileURL(probe).href;

// 1200 = 3×384 + 2×24, so it is the last width that holds three columns.
//  792 = 2×384 + 1×24, the last that holds two.
const CASES = [
  { width: 1200, columns: 3 },
  { width: 1000, columns: 2 },
  { width: 792, columns: 2 },
  { width: 760, columns: 1 },
  { width: 375, columns: 1 },
];

let failures = 0;

for (const { width, columns } of CASES) {
  const result = spawnSync(
    CHROME,
    [
      '--headless=new',
      '--no-sandbox',
      '--disable-gpu',
      '--hide-scrollbars',
      '--allow-file-access-from-files',
      '--window-size=1400,1000',
      '--virtual-time-budget=3000',
      '--dump-dom',
      `${base}#${width}`,
    ],
    { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 }
  );

  const match = result.stdout.match(/<pre id="grid-report">([^<]*)<\/pre>/);
  if (!match) {
    console.error(`  ${width}px  could not read the report`);
    failures += 1;
    continue;
  }

  const report = JSON.parse(match[1].replace(/&quot;/g, '"'));
  if (report.error) {
    console.error(`  ${width}px  ${report.error}`);
    failures += 1;
    continue;
  }

  const actual = report.perLine[0] ?? 0;
  const wrongColumns = actual !== columns;
  // Every line must be full except the last one.
  const ragged = report.perLine.slice(0, -1).some((n) => n !== columns);
  const hScroll = report.scrollW > report.clientW + 1;
  const spills = report.overflowRight > 1;

  if (wrongColumns || ragged || hScroll || spills) failures += 1;

  console.log(
    `${wrongColumns || ragged || hScroll || spills ? 'BAD ' : 'ok  '} ${String(width).padStart(4)}px  ` +
      `columns ${report.perLine.join('+')} (want ${columns})  ` +
      `card ${report.cardWidth}px  grid ${report.gridWidth}  tracks ${report.tracks}` +
      `${hScroll ? `  H-SCROLL ${report.scrollW} > ${report.clientW}` : ''}` +
      `${spills ? `  CARD SPILLS ${report.overflowRight}px` : ''}`
  );
}

if (failures > 0) {
  console.error(`\n${failures} width(s) did not match the design.`);
  process.exit(1);
}
console.log('\nThree columns at the design width, two below it, one on a phone — and never a sideways scroll.');
