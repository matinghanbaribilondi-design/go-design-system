// Measures each generated page in headless Chrome at several viewport widths.
// Reports elements that overflow their own box, or that escape their parent.
import { spawn } from 'child_process';
import { readdirSync, readFileSync } from 'fs';
import path from 'path';
import http from 'http';
import { fileURLToPath, pathToFileURL } from 'url';
import { WebSocket } from 'ws';

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WIDTHS = [1440, 1200, 1024, 900, 768, 600, 480, 414, 375, 320];
const PORT = 9333;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const getJSON = (p) => new Promise((resolve, reject) => {
  http.get({ host: '127.0.0.1', port: PORT, path: p }, res => {
    let d = ''; res.on('data', c => d += c);
    res.on('end', () => { try { resolve(JSON.parse(d)); } catch (e) { reject(e); } });
  }).on('error', reject);
});

const chrome = spawn(CHROME, [
  '--headless=new', `--remote-debugging-port=${PORT}`, '--no-first-run', '--no-default-browser-check',
  '--disable-gpu', '--hide-scrollbars', '--user-data-dir=/tmp/probe-chrome-profile' + process.pid, 'about:blank',
], { stdio: 'ignore' });

for (let i = 0; i < 80; i++) { try { await getJSON('/json/version'); break; } catch { await sleep(250); } }

const targets = await getJSON('/json/list');
const page = targets.find(t => t.type === 'page');
const ws = new WebSocket(page.webSocketDebuggerUrl, { maxPayload: 256 * 1024 * 1024 });
await new Promise(r => ws.on('open', r));

let id = 0;
const send = (method, params) => new Promise(resolve => {
  const myId = ++id;
  const onMsg = raw => { const m = JSON.parse(raw.toString()); if (m.id === myId) { ws.off('message', onMsg); resolve(m.result); } };
  ws.on('message', onMsg);
  ws.send(JSON.stringify({ id: myId, method, params }));
});

await send('Page.enable');
await send('Runtime.enable');

const MEASURE = readFileSync(path.join(__dirname, 'measure.js'), 'utf8');
await send('Page.addScriptToEvaluateOnNewDocument', { source: MEASURE });

const files = readdirSync(path.join(__dirname, 'out')).filter(f => f.endsWith('.html')).sort();
const results = {};

for (const file of files) {
  const name = file.replace('.html', '');
  results[name] = {};
  const url = pathToFileURL(path.join(__dirname, 'out', file)).href;
  await send('Page.navigate', { url });
  await sleep(220);

  for (const w of WIDTHS) {
    await send('Emulation.setDeviceMetricsOverride', { width: w, height: 900, deviceScaleFactor: 1, mobile: false });
    await sleep(90);
    const r = await send('Runtime.evaluate', { expression: 'JSON.stringify(window.__measure())', returnByValue: true });
    try { results[name][w] = JSON.parse(r.result.value); } catch { results[name][w] = { error: 'eval failed' }; }
  }
}

ws.close(); chrome.kill();

// --- Report ---
for (const [name, byWidth] of Object.entries(results)) {
  console.log(`\n${'='.repeat(78)}\n### ${name}\n${'='.repeat(78)}`);
  for (const [w, res] of Object.entries(byWidth)) {
    if (res.error) { console.log(`  ${w}px: ERROR ${res.error}`); continue; }
    const issues = [];
    if (res.pageScrollW > res.vw + 1) issues.push(`PAGE H-SCROLL (${res.pageScrollW} vs ${res.vw})`);
    for (const n of res.nodes) {
      if (n.contentOverflow > 1) issues.push(`  OVERFLOW [${n.tag}.${n.cls}] content ${n.contentOverflow}px > box ${n.w}px  "${n.text}"`);
      if (n.escapesParent > 1) issues.push(`  ESCAPES  [${n.tag}.${n.cls}] by ${n.escapesParent}px (w=${n.w} parentW=${n.parentW})  "${n.text}"`);
      if (n.escapesBottom > 1 && n.clippedBy) issues.push(`  V-CLIP   [${n.tag}.${n.cls}] overflows clipped parent by ${n.escapesBottom}px  "${n.text}"`);
    }
    console.log(`  ${String(w).padStart(4)}px  ${issues.length ? '' : 'ok'}`);
    for (const i of issues.slice(0, 14)) console.log(`         ${i}`);
    if (issues.length > 14) console.log(`         ... +${issues.length - 14} more`);
  }
}
