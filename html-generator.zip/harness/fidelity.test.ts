import { describe, it } from 'vitest';
import { writeFileSync, mkdirSync } from 'fs';
import { convertNodeToIR } from '../src/plugin/converter/index';
import { generateFullHtmlDocument } from '../src/generator/html-generator';
import type { ConversionOptions } from '../src/plugin/types/ir';
import { synthFont, toBase64 } from './synth-font';
import { base64ToBytes, metricOverrides, parseFontMetrics } from '../src/shared/font-metrics';

/**
 * Phase 2 fidelity corpus, measured in a real browser by
 * `harness/fidelity-check.mjs`.
 *
 * Phase 1 fixtures each proved one geometry claim with a hit test. These claims
 * are about *colour*, *text flow*, *font metrics* and *figures*, so the check
 * reads pixels (`png.mjs`), measured boxes, and computed styles instead:
 *
 *   23-stroke      a gradient stroke is a ring: it follows the corner radius,
 *                  it is exactly as thick as the stroke, and it is not a fill.
 *   24-blend       a blend mode is confined to its group instead of reaching
 *                  the page behind it.
 *   25-paragraphs  paragraph spacing exists between paragraphs, and nowhere
 *                  else.
 *   26-links       a Figma hyperlink arrives as a real <a href>, on the whole
 *                  layer or on the run that carries it.
 *   27-fonts       a fallback wearing the embedded font's own measurements
 *                  occupies the same line box as the font itself.
 *   28-tables      a column of digits is kept in step, and prose beside it is
 *                  left in proportional figures.
 *   30-divider     a horizontal LINE rotated 90° is a vertical rule that takes
 *                  its visual width in the row, not the length it was drawn at.
 *   31-direction   a column's MIN/MAX alignment stays physical in an RTL page:
 *                  a right-aligned hint is still on the right.
 *   32-glass-clip  a component whose master clips holds its blurred glass
 *                  decorations inside its own rounded square.
 *   33-blur-glow   a texture filter over a blur leaves the halo round instead
 *                  of cutting it into a square.
 */

const options: ConversionOptions = {
  outputMode: 'pure-css',
  useRem: false,
  baseFontSize: 16,
  includeReset: true,
  inlineAssets: true,
  semanticTags: true,
  responsive: false,
  intrinsicReflow: false,
  designWidth: 400,
};

function mk(over: Record<string, unknown> = {}): any {
  return {
    id: (over.id as string) ?? 'n',
    name: (over.name as string) ?? 'Frame',
    type: (over.type as string) ?? 'FRAME',
    visible: true,
    width: 100,
    height: 100,
    x: 0,
    y: 0,
    rotation: 0,
    layoutMode: 'NONE',
    children: [],
    fills: [],
    strokes: [],
    effects: [],
    ...over,
  };
}

const rgb = (r: number, g: number, b: number) => ({ r, g, b, a: 1 });
const solidFill = (color: { r: number; g: number; b: number }) => [
  { type: 'SOLID', visible: true, opacity: 1, color },
];

const gradientStroke = {
  type: 'GRADIENT_LINEAR',
  visible: true,
  opacity: 1,
  gradientTransform: [
    [1, 0, 0],
    [0, 1, 0],
  ],
  gradientStops: [
    { position: 0, color: rgb(1, 0, 0) },
    { position: 1, color: rgb(0, 0, 1) },
  ],
};

async function write(name: string, root: any, over: ConversionOptions = options): Promise<void> {
  const ir = await convertNodeToIR(root, null, over);
  if (!ir) throw new Error(`${name}: conversion produced no IR`);
  mkdirSync('harness/out', { recursive: true });
  writeFileSync(`harness/out/${name}.html`, generateFullHtmlDocument(ir, over));
}

describe('fidelity corpus', () => {
  it('23 stroke: a 4px gradient stroke on a 24px-radius card', async () => {
    // A grey page so "outside the card" and "inside the card" are different
    // colours: a white card on white paper cannot show whether the ring
    // squared the corner or followed it.
    await write(
      '23-stroke',
      mk({
        id: 'page',
        name: 'Page',
        width: 400,
        height: 240,
        fills: solidFill(rgb(0.93, 0.95, 0.97)),
        children: [
          mk({
            id: 'card',
            name: 'Gradient Card',
            type: 'RECTANGLE',
            width: 320,
            height: 160,
            x: 40,
            y: 40,
            cornerRadius: 24,
            fills: solidFill(rgb(1, 1, 1)),
            strokes: [gradientStroke],
            strokeWeight: 4,
          }),
        ],
      })
    );
  });

  it('24 blend: a multiply tint inside a group over a blue backdrop', async () => {
    // The tint sits over a *sibling* of its group, which is the case isolation
    // exists for: with the group as its backdrop the red stays red, and without
    // it the red multiplies the blue behind the group and turns black.
    await write(
      '24-blend',
      mk({
        id: 'page',
        name: 'Page',
        width: 400,
        height: 240,
        fills: solidFill(rgb(1, 1, 1)),
        children: [
          mk({
            id: 'backdrop',
            name: 'Backdrop',
            type: 'RECTANGLE',
            width: 200,
            height: 200,
            x: 40,
            y: 40,
            fills: solidFill(rgb(0, 0, 1)),
          }),
          mk({
            id: 'group',
            name: 'Tint Panel',
            width: 200,
            height: 200,
            x: 40,
            y: 40,
            fills: [],
            children: [
              mk({
                id: 'tint',
                name: 'Tint',
                type: 'RECTANGLE',
                width: 100,
                height: 100,
                x: 60,
                y: 20,
                blendMode: 'MULTIPLY',
                fills: solidFill(rgb(1, 0, 0)),
              }),
            ],
          }),
        ],
      })
    );
  });

  it('25 paragraphs: three paragraphs with 16px between them', async () => {
    // 20px line height, 16px paragraph spacing. If the spacing is ignored the
    // three paragraphs sit at 0 / 20 / 40; if it is a line break rather than a
    // margin they sit at 0 / 20 / 40 too. Only blocks give 0 / 36 / 72.
    await write(
      '25-paragraphs',
      mk({
        id: 'page',
        name: 'Page',
        width: 320,
        height: 160,
        fills: solidFill(rgb(1, 1, 1)),
        children: [
          mk({
            id: 'body',
            name: 'Body Copy',
            type: 'TEXT',
            width: 280,
            height: 92,
            x: 20,
            y: 20,
            characters: 'First paragraph.\nSecond paragraph.\nThird paragraph.',
            fontSize: 14,
            fontName: { family: 'Inter', style: 'Regular' },
            lineHeight: { unit: 'PIXELS', value: 20 },
            letterSpacing: { unit: 'PERCENT', value: 0 },
            textAlignHorizontal: 'LEFT',
            textAlignVertical: 'TOP',
            textAutoResize: 'HEIGHT',
            paragraphSpacing: 16,
            fills: solidFill(rgb(0, 0, 0)),
          }),
        ],
      })
    );
  });

  it('26 links: a whole-layer link, a per-range link, and a NODE link', async () => {
    // Three claims in one page: the layer's own link wraps the text, a link on
    // one range wraps only that run, and a link to another layer stays text
    // because a layer id is not an address.
    const body = (over: Record<string, unknown>) =>
      mk({
        type: 'TEXT',
        width: 260,
        height: 24,
        x: 20,
        fontSize: 14,
        fontName: { family: 'Inter', style: 'Regular' },
        lineHeight: { unit: 'PIXELS', value: 24 },
        letterSpacing: { unit: 'PERCENT', value: 0 },
        textAlignHorizontal: 'LEFT',
        textAlignVertical: 'TOP',
        textAutoResize: 'HEIGHT',
        fills: solidFill(rgb(0, 0, 0)),
        ...over,
      });

    await write(
      '26-links',
      mk({
        id: 'page',
        name: 'Page',
        width: 320,
        height: 160,
        fills: solidFill(rgb(1, 1, 1)),
        children: [
          body({
            id: 'whole',
            name: 'Whole Link',
            y: 20,
            characters: 'Whole layer link',
            hyperlink: { type: 'URL', value: 'https://example.com/whole' },
          }),
          body({
            id: 'range',
            name: 'Range Link',
            y: 60,
            characters: 'Read the docs',
            hyperlink: null,
            getStyledTextSegments: () => [
              {
                characters: 'Read the ',
                start: 0,
                end: 9,
                fontSize: 14,
                fontName: { family: 'Inter', style: 'Regular' },
                fontWeight: 400,
                fills: solidFill(rgb(0, 0, 0)),
                lineHeight: { unit: 'PIXELS', value: 24 },
                letterSpacing: { unit: 'PERCENT', value: 0 },
                textDecoration: 'NONE',
                textCase: 'ORIGINAL',
                hyperlink: null,
              },
              {
                characters: 'docs',
                start: 9,
                end: 13,
                fontSize: 14,
                fontName: { family: 'Inter', style: 'Regular' },
                fontWeight: 400,
                fills: solidFill(rgb(0, 0, 0)),
                lineHeight: { unit: 'PIXELS', value: 24 },
                letterSpacing: { unit: 'PERCENT', value: 0 },
                textDecoration: 'NONE',
                textCase: 'ORIGINAL',
                hyperlink: { type: 'URL', value: 'https://example.com/docs' },
              },
            ],
          }),
          body({
            id: 'node-link',
            name: 'Node Link',
            y: 100,
            characters: 'Jump to the next frame',
            hyperlink: { type: 'NODE', value: '12:34' },
          }),
        ],
      })
    );
  });

  it('27 fonts: a fallback that occupies the same line box as the font itself', async () => {
    // The font is written here rather than installed: its metrics are known,
    // deliberately unlike Arial's, and the fallback the plugin registers has to
    // reproduce whatever line box they describe. `customFonts` is also what
    // makes the converter name the twin in the stack — without it the
    // declaration would reference a family the stylesheet never registers.
    const fontOptions: ConversionOptions = {
      ...options,
      customFonts: [
        {
          id: 'synth-sans',
          family: 'Synth Sans',
          style: 'Regular',
          weight: 400,
          format: 'truetype',
          base64: toBase64(synthFont()),
          filename: 'synth-sans.ttf',
        },
      ],
    };

    await write(
      '27-fonts',
      mk({
        id: 'page',
        name: 'Page',
        width: 400,
        height: 240,
        fills: solidFill(rgb(1, 1, 1)),
        children: [
          mk({
            id: 'note',
            name: 'Note',
            type: 'TEXT',
            width: 240,
            height: 24,
            x: 20,
            y: 40,
            characters: 'Hxg Hxg',
            fontSize: 40,
            fontName: { family: 'Synth Sans', style: 'Regular' },
            lineHeight: { unit: 'PIXELS', value: 48 },
            letterSpacing: { unit: 'PERCENT', value: 0 },
            textAlignHorizontal: 'LEFT',
            textAlignVertical: 'TOP',
            textAutoResize: 'NONE',
            fills: solidFill(rgb(0, 0, 0)),
          }),
        ],
      }),
      fontOptions
    );

    // The expectations the browser measurement is held to, derived with the
    // plugin's own reader on the very file that was embedded. Writing them out
    // keeps the check free of numbers someone might one day correct by hand.
    const bytes = base64ToBytes(fontOptions.customFonts![0]!.base64);
    const metrics = parseFontMetrics(bytes);
    if (!metrics) throw new Error('27-fonts: the specimen font does not parse');
    writeFileSync(
      'harness/out/27-fonts.json',
      JSON.stringify({ metrics, overrides: metricOverrides(metrics) }, null, 2)
    );
  });

  it('28 tables: a column of digits kept in step', async () => {
    // A table drawn the way Figma draws one: a vertical frame of horizontal
    // rows of fixed-width cells, every cell holding a number. The prose layer
    // below it is the control — it is a sibling, so the figures it gets are
    // proportional ones.
    const cell = (id: string, text: string) =>
      mk({
        id,
        name: `Cell ${text}`,
        type: 'TEXT',
        width: 100,
        height: 24,
        characters: text,
        fontSize: 14,
        fontName: { family: 'Inter', style: 'Regular' },
        lineHeight: { unit: 'PIXELS', value: 24 },
        letterSpacing: { unit: 'PERCENT', value: 0 },
        textAlignHorizontal: 'LEFT',
        textAlignVertical: 'TOP',
        textAutoResize: 'NONE',
        fills: solidFill(rgb(0, 0, 0)),
      });

    const row = (id: string, texts: string[]) =>
      mk({
        id,
        name: 'Row',
        layoutMode: 'HORIZONTAL',
        width: 300,
        height: 24,
        children: texts.map((text, index) => cell(`${id}-c${index}`, text)),
      });

    await write(
      '28-tables',
      mk({
        id: 'page',
        name: 'Page',
        width: 400,
        height: 240,
        fills: solidFill(rgb(1, 1, 1)),
        children: [
          mk({
            id: 'ledger',
            name: 'Ledger',
            layoutMode: 'VERTICAL',
            width: 300,
            height: 72,
            x: 20,
            y: 20,
            children: [
              row('r0', ['1,240', '2,310', '980']),
              row('r1', ['1,110', '4,050', '7,600']),
              row('r2', ['3,470', '90', '1,005']),
            ],
          }),
          mk({
            id: 'caption',
            name: 'Caption',
            type: 'TEXT',
            width: 300,
            height: 24,
            x: 20,
            y: 120,
            characters: 'Total 1,240 at 4,050',
            fontSize: 14,
            fontName: { family: 'Inter', style: 'Regular' },
            lineHeight: { unit: 'PIXELS', value: 24 },
            letterSpacing: { unit: 'PERCENT', value: 0 },
            textAlignHorizontal: 'LEFT',
            textAlignVertical: 'TOP',
            textAutoResize: 'NONE',
            fills: solidFill(rgb(0, 0, 0)),
          }),
        ],
      })
    );
  });

  it('29 mirror: one design, exported once as drawn and once with a layer nudged', async () => {
    // The mirror's reference. A committed golden PNG would fail on every Chrome
    // upgrade for reasons that have nothing to do with this plugin, so the
    // reference is the *same fixture, same browser, same run*: the design as
    // drawn, and the same design with one layer moved 8px. A check that can see
    // the known difference — and only the known difference — is a check that
    // can be trusted to name the next one.
    //
    // The perturbation is a move, because a move is what a regression usually
    // is: a line that grows, a gap that appears, a layer that lands 8px off.
    // The debug option is on here and nowhere else in the corpus, because the
    // whole point of the diff is to be able to point at the layer.
    const mirrorOptions: ConversionOptions = { ...options, debugFigmaIds: true };

    const design = (cardX: number) =>
      mk({
        id: 'page',
        name: 'Page',
        width: 400,
        height: 240,
        fills: solidFill(rgb(1, 1, 1)),
        children: [
          mk({
            id: 'heading',
            name: 'Heading',
            type: 'TEXT',
            width: 200,
            height: 24,
            x: 40,
            y: 24,
            characters: 'Monthly ledger',
            fontSize: 18,
            fontName: { family: 'Inter', style: 'Bold' },
            fontWeight: 700,
            lineHeight: { unit: 'PIXELS', value: 24 },
            letterSpacing: { unit: 'PERCENT', value: 0 },
            textAlignHorizontal: 'LEFT',
            textAlignVertical: 'TOP',
            textAutoResize: 'NONE',
            fills: solidFill(rgb(0.1, 0.12, 0.16)),
          }),
          mk({
            id: 'card',
            name: 'Card',
            type: 'RECTANGLE',
            width: 200,
            height: 120,
            x: cardX,
            y: 64,
            cornerRadius: 12,
            fills: solidFill(rgb(0.16, 0.38, 0.85)),
            children: [
              mk({
                id: 'label',
                name: 'Label',
                type: 'TEXT',
                width: 160,
                height: 20,
                x: 16,
                y: 16,
                characters: 'Balance 1,240',
                fontSize: 14,
                fontName: { family: 'Inter', style: 'Regular' },
                lineHeight: { unit: 'PIXELS', value: 20 },
                letterSpacing: { unit: 'PERCENT', value: 0 },
                textAlignHorizontal: 'LEFT',
                textAlignVertical: 'TOP',
                textAutoResize: 'NONE',
                fills: solidFill(rgb(1, 1, 1)),
              }),
            ],
          }),
        ],
      });

    await write('29-mirror', design(40), mirrorOptions);
    await write('29-mirror-moved', design(48), mirrorOptions);

    // The check reads the geometry of the move out of here rather than out of a
    // number in the script, and the node list is what "every layer is named"
    // is held to.
    writeFileSync(
      'harness/out/29-mirror.json',
      JSON.stringify(
        {
          width: 400,
          height: 240,
          shift: { dx: 8, dy: 0 },
          movedLayer: 'card',
          nodes: ['page', 'heading', 'card', 'label'],
        },
        null,
        2
      )
    );
  });

  it('30 divider: a rotated rule holds its visual width in a regions row', async () => {
    // The row is 900 = 20 + 490 + 20 + 0 + 20 + 330 + 20. Figma stores the
    // vertical rule as a 423px horizontal LINE rotated 90°, so its layout
    // footprint is zero wide; the body has to sit beside the rail. Reading the
    // unrotated width put 423px of the row inside the rule, which pushed the
    // form out of the frame and fired the stacking query at the design width.
    await write(
      '30-divider',
      mk({
        id: 'main',
        name: 'Main',
        width: 900,
        height: 455,
        layoutMode: 'HORIZONTAL',
        itemSpacing: 20,
        paddingTop: 16,
        paddingRight: 20,
        paddingBottom: 16,
        paddingLeft: 20,
        primaryAxisSizingMode: 'FIXED',
        fills: solidFill(rgb(0.93, 0.95, 0.97)),
        children: [
          mk({
            id: 'sidebar',
            name: 'Stats',
            width: 490,
            height: 287,
            layoutMode: 'VERTICAL',
            fills: solidFill(rgb(1, 1, 1)),
          }),
          mk({
            id: 'rule',
            name: 'Line',
            type: 'LINE',
            width: 423,
            height: 0,
            rotation: 90,
            strokes: [{ type: 'SOLID', visible: true, opacity: 1, color: rgb(0, 0, 0) }],
            strokeWeight: 2,
          }),
          mk({
            id: 'form',
            name: 'Form',
            width: 330,
            height: 423,
            layoutMode: 'VERTICAL',
            fills: solidFill(rgb(0.8, 0.87, 1)),
          }),
        ],
      }),
      { ...options, responsive: true, intrinsicReflow: true, designWidth: 900 }
    );
  });

  it('31 direction: a column keeps physical alignment in an RTL page', async () => {
    // Both frames are vertical and align their children to the right, and the
    // page is RTL because the hint is Persian. CSS `flex-end` follows the
    // container's writing direction, so a column that inherited the page's
    // `rtl` would put the hint — and the panel itself — on the left. Figma's
    // counter-axis MAX is physical right, which is why the frame resolves its
    // own axes LTR and only the text node stays RTL.
    await write(
      '31-direction',
      mk({
        id: 'page',
        name: 'Page',
        width: 390,
        height: 220,
        layoutMode: 'VERTICAL',
        paddingTop: 20,
        paddingRight: 20,
        paddingBottom: 20,
        paddingLeft: 20,
        counterAxisAlignItems: 'MAX',
        fills: solidFill(rgb(0.93, 0.95, 0.97)),
        children: [
          mk({
            id: 'panel',
            name: 'Panel',
            width: 250,
            height: 140,
            layoutMode: 'VERTICAL',
            paddingTop: 16,
            paddingRight: 16,
            paddingBottom: 16,
            paddingLeft: 16,
            counterAxisAlignItems: 'MAX',
            fills: solidFill(rgb(1, 1, 1)),
            children: [
              mk({
                id: 'hint',
                name: 'Hint',
                type: 'TEXT',
                width: 120,
                height: 24,
                characters: 'حداقل ۸ کاراکتر',
                textAutoResize: 'WIDTH_AND_HEIGHT',
                textAlignHorizontal: 'RIGHT',
                fontName: { family: 'IRANYekanXVF', style: 'Medium' },
                fontSize: 12,
                lineHeight: { unit: 'PIXELS', value: 24 },
                fills: solidFill(rgb(0.53, 0.58, 0.63)),
              }),
            ],
          }),
        ],
      })
    );
  });

  it('32 glass: a clipped component keeps its soft decorations inside its box', async () => {
    // The widget bar's logo: a 28×28 instance whose master clips, holding a
    // 32×33 group of glass decorations — a purple ellipse under a 12px layer
    // blur, a gradient wash taller than the box, a 52px grain field. Figma
    // clips every one of them at the rounded square. Because the frame's own
    // decorations blur, the converter used to assume the frame must not clip
    // and let the wash run down the page.
    await write(
      '32-glass-clip',
      mk({
        id: 'page',
        name: 'Page',
        width: 200,
        height: 120,
        fills: solidFill(rgb(0.93, 0.95, 0.97)),
        children: [
          mk({
            id: 'logo',
            name: 'Logo',
            type: 'INSTANCE',
            x: 30,
            y: 30,
            width: 28,
            height: 28,
            cornerRadius: 7.3,
            clipsContent: undefined,
            fills: solidFill(rgb(0.34, 0.43, 0.86)),
            mainComponent: {
              id: 'mc-logo',
              name: 'Logo',
              type: 'COMPONENT',
              clipsContent: true,
              width: 28,
              height: 28,
            },
            children: [
              mk({
                id: 'glass',
                name: 'Group 1',
                type: 'GROUP',
                x: -2,
                y: -2,
                width: 32,
                height: 33,
                children: [
                  mk({
                    id: 'wash',
                    name: 'Ellipse 165',
                    type: 'ELLIPSE',
                    x: 1,
                    y: 26,
                    width: 30,
                    height: 7,
                    fills: solidFill(rgb(0.19, 0.11, 0.96)),
                    effects: [{ type: 'LAYER_BLUR', radius: 12, visible: true, color: rgb(0, 0, 0) }],
                  }),
                  mk({
                    id: 'sheen',
                    name: 'Rectangle 28',
                    type: 'VECTOR',
                    x: 0,
                    y: 0,
                    width: 32,
                    height: 29,
                    fills: [
                      {
                        type: 'GRADIENT_LINEAR',
                        visible: true,
                        opacity: 1,
                        gradientTransform: [
                          [1, 0, 0],
                          [0, 1, 0],
                        ],
                        gradientStops: [
                          { position: 0, color: { r: 0.35, g: 0.26, b: 0.93, a: 0 } },
                          { position: 1, color: { r: 0.98, g: 0.98, b: 0.98, a: 1 } },
                        ],
                      },
                    ],
                  }),
                ],
              }),
              mk({
                id: 'grain',
                name: 'bg',
                type: 'GROUP',
                x: -12,
                y: 0,
                width: 52,
                height: 29,
                children: [
                  mk({
                    id: 'grain-left',
                    name: 'Ellipse 1',
                    type: 'ELLIPSE',
                    x: 0,
                    y: 14,
                    width: 1,
                    height: 1,
                    fills: [{ type: 'SOLID', visible: true, opacity: 0.19, color: rgb(1, 1, 1) }],
                  }),
                  mk({
                    id: 'grain-right',
                    name: 'Ellipse 2',
                    type: 'ELLIPSE',
                    x: 51,
                    y: 14,
                    width: 1,
                    height: 1,
                    fills: [{ type: 'SOLID', visible: true, opacity: 0.37, color: rgb(1, 1, 1) }],
                  }),
                ],
              }),
            ],
          }),
        ],
      })
    );
  });

  it('33 glow: an SVG texture filter leaves a blurred halo round', async () => {
    // The active nav marker: a disc with a 12px layer blur and a texture on
    // top of it. An SVG filter only paints inside its own region, and that
    // region defaults to the element's box plus 10% — so the filter run after
    // the blur cut the halo into a square, 18px from the centre along an axis
    // but 25px along a diagonal. The region now sizes itself to the blur.
    await write(
      '33-blur-glow',
      mk({
        id: 'page',
        name: 'Page',
        width: 200,
        height: 200,
        fills: solidFill(rgb(0.05, 0.06, 0.08)),
        children: [
          mk({
            id: 'marker',
            name: 'Active Circle',
            type: 'RECTANGLE',
            x: 85,
            y: 85,
            width: 30,
            height: 30,
            cornerRadius: 15,
            fills: solidFill(rgb(0.2, 0.85, 0.45)),
            effects: [
              { type: 'LAYER_BLUR', radius: 12, visible: true, color: rgb(0, 0, 0) },
              {
                type: 'TEXTURE',
                noiseSize: 0.1,
                noiseSizeVector: { x: 0.1, y: 0.1 },
                radius: 3,
                clipToShape: true,
                visible: true,
              },
            ],
          }),
        ],
      })
    );
  });
});