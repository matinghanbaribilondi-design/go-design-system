// The Mirror — a pixel diff that says *which layer* moved.
//
//   npx vitest run harness/fidelity.test.ts && node harness/mirror-check.mjs
//
// Every other check in this folder answers a question a CSS string or a hit
// test could answer. This one answers the question none of them can: two
// renderings of the same design, pixel for pixel, with the difference located
// precisely enough to be actionable at 3am.
//
// Two decisions shape it, and both exist because they are where pixel-diff
// harnesses die:
//
// 1. **Where the reference comes from.** Not from a committed golden PNG: that
//    file makes the check fail on every Chrome upgrade for reasons that have
//    nothing to do with the plugin, and the natural response — regenerate the
//    golden, bump the tolerance — is how the check stops meaning anything. The
//    reference here is the *same fixture, rendered by the same browser in the
//    same run*, twice: once as drawn, once with one layer deliberately moved
//    8px. A stable difference proves the harness can see pixels, and a
//    difference in that difference names a regression.
//
// 2. **What the diff says.** "12% of the page changed" is not an answer; "the
//    layer `card` moved 8px to the right" is. That is what `data-figma-id` is
//    for: an option, off by default so the normal export stays byte-identical,
//    that prints each node's Figma id into the markup. The `IRNode` has
//    carried the id all along — the emitters were dropping it, which is what
//    made every diff unable to point at anything.
//
// So the check is a calibration, not a snapshot: the same page must render
// identically twice, the nudged copy must differ, every differing pixel must
// fall on the layer that was moved (its old ink or its new), and the first
// differing pixel must name it.
import path from 'path';
import { fileURLToPath } from 'url';
import { existsSync, readFileSync } from 'fs';
import { inFrame, report, screenshot } from './chrome.mjs';
import { compare } from './png.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const fixture = (name) => path.join(__dirname, 'out', `${name}.html`);

function require_(name) {
  if (!existsSync(fixture(name))) {
    console.error(`missing ${name}.html — run: npx vitest run harness/fidelity.test.ts`);
    process.exit(1);
  }
  return fixture(name);
}

/** Per-channel distance above which two pixels count as different. */
const TOLERANCE = 8;
/** Slack around the moved layer's box, for edges the renderer antialiases. */
const EDGE = 1;

/** What the fixture wrote about itself: the move, and the layers to name. */
function sidecar() {
  const file = path.join(__dirname, 'out', '29-mirror.json');
  if (!existsSync(file)) {
    console.error('missing out/29-mirror.json — run: npx vitest run harness/fidelity.test.ts');
    process.exit(1);
  }
  return JSON.parse(readFileSync(file, 'utf8'));
}

const plan = sidecar();
const size = { width: plan.width, height: plan.height };

// ── three renders, one browser, one run ────────────────────────────────────
const asDrawn = screenshot(require_('29-mirror'), size);
const again = screenshot(require_('29-mirror'), size);
const moved = screenshot(require_('29-mirror-moved'), size);

const noise = compare(asDrawn, again, TOLERANCE);
const diff = compare(asDrawn, moved, TOLERANCE);

/**
 * Every differing pixel, in the same order `compare` scans them.
 *
 * The list is cross-checked against `compare`'s count below, because two
 * copies of a rule that can drift apart quietly are worse than one.
 */
function differingPixels(a, b, tolerance) {
  const points = [];
  for (let y = 0; y < a.height; y += 1) {
    for (let x = 0; x < a.width; x += 1) {
      const i = (y * a.width + x) * 4;
      const d = Math.max(
        Math.abs(a.data[i] - b.data[i]),
        Math.abs(a.data[i + 1] - b.data[i + 1]),
        Math.abs(a.data[i + 2] - b.data[i + 2]),
        Math.abs(a.data[i + 3] - b.data[i + 3])
      );
      if (d > tolerance) points.push({ x, y });
    }
  }
  return points;
}

const pixels = differingPixels(asDrawn, moved, TOLERANCE);

// ── what each page says about the pixels that changed ──────────────────────
// `elementFromPoint` runs inside the frame that rendered the page, so the
// answer comes from the layer that is actually there rather than from a
// prediction about it. The first differing pixel is asked separately from the
// rest: for a move it lands on the ink the layer left behind, which is the
// most useful thing to be told.
function attribute(name, points) {
  return inFrame(fixture(name), {
    ...size,
    body: `
      var points = ${JSON.stringify(points)};
      var tally = {};
      function idOf(el) {
        if (!el || !el.getAttribute) return 'none';
        return el.getAttribute('data-figma-id') || el.tagName.toLowerCase();
      }
      var first = idOf(doc.elementFromPoint(points[0].x, points[0].y));
      points.forEach(function (p) {
        var id = idOf(doc.elementFromPoint(p.x, p.y));
        tally[id] = (tally[id] || 0) + 1;
      });
      var named = doc.querySelectorAll('[data-figma-id]').length;
      var card = doc.querySelector('[data-figma-id="${plan.movedLayer}"]').getBoundingClientRect();
      return {
        firstId: first,
        tally: tally,
        named: named,
        movedLayerBox: {
          left: card.left,
          top: card.top,
          right: card.right,
          bottom: card.bottom
        }
      };
    `,
  });
}

const before = attribute('29-mirror', pixels);
const after = attribute('29-mirror-moved', pixels);

// The layer as it was and as it is now: everything that changed has to be in
// the union of the two, and nothing outside it may have changed.
const union = {
  left: Math.min(before.movedLayerBox.left, after.movedLayerBox.left) - EDGE,
  top: Math.min(before.movedLayerBox.top, after.movedLayerBox.top) - EDGE,
  right: Math.max(before.movedLayerBox.right, after.movedLayerBox.right) + EDGE,
  bottom: Math.max(before.movedLayerBox.bottom, after.movedLayerBox.bottom) + EDGE,
};
const outside = pixels.filter((p) => p.x < union.left || p.x >= union.right || p.y < union.top || p.y >= union.bottom);
const insideFirst =
  pixels.length > 0 &&
  pixels[0].x >= union.left &&
  pixels[0].x < union.right &&
  pixels[0].y >= union.top &&
  pixels[0].y < union.bottom;

const tallyKeys = (t) => Object.keys(t).sort((a, b) => t[b] - t[a]);
const describeTally = (t) => tallyKeys(t).map((id) => `${id}:${t[id]}`).join(' ');

report('29-mirror · pixel diff', [
  [
    'the same page rendered twice is identical',
    noise.differing === 0,
    `${noise.differing} of ${noise.total} pixels differ`,
  ],
  [
    'the pixel scan agrees with the diff utility',
    pixels.length === diff.differing,
    `${pixels.length} scanned vs ${diff.differing} counted`,
  ],
  [
    'the nudged copy differs from the original',
    diff.differing > 100,
    `${diff.differing} pixels (${(diff.ratio * 100).toFixed(1)}%)`,
  ],
  [
    'the first difference is on the moved layer',
    insideFirst,
    `(${diff.firstDifference?.x}, ${diff.firstDifference?.y}) → ${before.firstId} before, ${after.firstId} after`,
  ],
  [
    'the first difference names the layer that moved',
    before.firstId === plan.movedLayer || after.firstId === plan.movedLayer,
    `${before.firstId} → ${after.firstId}`,
  ],
  [
    'nothing outside the moved layer changed',
    outside.length === 0,
    outside.length === 0
      ? `all ${pixels.length} pixels inside ${union.left}..${union.right} × ${union.top}..${union.bottom}`
      : `${outside.length} pixels outside — first (${outside[0].x}, ${outside[0].y})`,
  ],
  [
    'the busiest row is inside the moved layer',
    diff.busiestRow >= union.top && diff.busiestRow < union.bottom,
    `row ${diff.busiestRow}`,
  ],
  [
    'every layer in the export is named',
    before.named === plan.nodes.length && after.named === plan.nodes.length,
    `${before.named} and ${after.named} named of ${plan.nodes.length}`,
  ],
  [
    'the difference is attributed to the layers that hold it',
    Object.keys(after.tally).every((id) => plan.nodes.includes(id) || id === 'none') &&
      (after.tally[plan.movedLayer] ?? 0) >= pixels.length * 0.25,
    describeTally(after.tally),
  ],
]);

console.log(`\n  as drawn     ${describeTally(before.tally)}`);
console.log(`  moved        ${describeTally(after.tally)}`);
console.log(`  signature    ${before.firstId} → ${after.firstId} at (${diff.firstDifference?.x}, ${diff.firstDifference?.y})`);
console.log(`  busiest      row ${diff.busiestRow}, column ${diff.busiestColumn}`);
